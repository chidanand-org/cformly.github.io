"use strict";
(() => {
  // src/content.ts
  var heavyPromise = null;
  function loadHeavy() {
    heavyPromise ??= import(chrome.runtime.getURL("content-heavy.js")).catch((err) => {
      heavyPromise = null;
      throw err;
    });
    return heavyPromise;
  }
  function emptyPingResult() {
    return {
      filled: [],
      missingElements: [],
      missingValues: [],
      unsupported: [],
      manual: [],
      unverified: [],
      tooLong: [],
      totalRequired: 0,
      requiredFilled: 0,
      portalMismatchDetected: false,
      fallbackRecommended: false
    };
  }
  chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
      if (sender.id !== chrome.runtime.id) {
        sendResponse({ ok: false, error: "Unauthorized sender" });
        return false;
      }
      if (message.type === "CFORMLY_PING") {
        sendResponse({ ok: true, result: emptyPingResult() });
        return false;
      }
      loadHeavy().then((heavy) => heavy.handleFillMessage(message)).then((response) => sendResponse(response)).catch((err) => {
        sendResponse({
          ok: false,
          error: err instanceof Error ? err.message : "Failed to load the Cformly fill engine"
        });
      });
      return true;
    }
  );
  try {
    if (typeof window !== "undefined" && window.self === window.top && /formc\.jsp/i.test(location.href)) {
      void loadHeavy().then((heavy) => heavy.initPortalUi()).catch(() => {
      });
    }
  } catch {
  }
})();
