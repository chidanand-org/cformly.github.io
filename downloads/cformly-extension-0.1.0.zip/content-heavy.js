var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../../node_modules/qrcode/lib/can-promise.js
var require_can_promise = __commonJS({
  "../../node_modules/qrcode/lib/can-promise.js"(exports, module) {
    module.exports = function() {
      return typeof Promise === "function" && Promise.prototype && Promise.prototype.then;
    };
  }
});

// ../../node_modules/qrcode/lib/core/utils.js
var require_utils = __commonJS({
  "../../node_modules/qrcode/lib/core/utils.js"(exports) {
    var toSJISFunction;
    var CODEWORDS_COUNT = [
      0,
      // Not used
      26,
      44,
      70,
      100,
      134,
      172,
      196,
      242,
      292,
      346,
      404,
      466,
      532,
      581,
      655,
      733,
      815,
      901,
      991,
      1085,
      1156,
      1258,
      1364,
      1474,
      1588,
      1706,
      1828,
      1921,
      2051,
      2185,
      2323,
      2465,
      2611,
      2761,
      2876,
      3034,
      3196,
      3362,
      3532,
      3706
    ];
    exports.getSymbolSize = function getSymbolSize(version) {
      if (!version) throw new Error('"version" cannot be null or undefined');
      if (version < 1 || version > 40) throw new Error('"version" should be in range from 1 to 40');
      return version * 4 + 17;
    };
    exports.getSymbolTotalCodewords = function getSymbolTotalCodewords(version) {
      return CODEWORDS_COUNT[version];
    };
    exports.getBCHDigit = function(data) {
      let digit = 0;
      while (data !== 0) {
        digit++;
        data >>>= 1;
      }
      return digit;
    };
    exports.setToSJISFunction = function setToSJISFunction(f) {
      if (typeof f !== "function") {
        throw new Error('"toSJISFunc" is not a valid function.');
      }
      toSJISFunction = f;
    };
    exports.isKanjiModeEnabled = function() {
      return typeof toSJISFunction !== "undefined";
    };
    exports.toSJIS = function toSJIS(kanji) {
      return toSJISFunction(kanji);
    };
  }
});

// ../../node_modules/qrcode/lib/core/error-correction-level.js
var require_error_correction_level = __commonJS({
  "../../node_modules/qrcode/lib/core/error-correction-level.js"(exports) {
    exports.L = { bit: 1 };
    exports.M = { bit: 0 };
    exports.Q = { bit: 3 };
    exports.H = { bit: 2 };
    function fromString(string) {
      if (typeof string !== "string") {
        throw new Error("Param is not a string");
      }
      const lcStr = string.toLowerCase();
      switch (lcStr) {
        case "l":
        case "low":
          return exports.L;
        case "m":
        case "medium":
          return exports.M;
        case "q":
        case "quartile":
          return exports.Q;
        case "h":
        case "high":
          return exports.H;
        default:
          throw new Error("Unknown EC Level: " + string);
      }
    }
    exports.isValid = function isValid(level) {
      return level && typeof level.bit !== "undefined" && level.bit >= 0 && level.bit < 4;
    };
    exports.from = function from(value, defaultValue) {
      if (exports.isValid(value)) {
        return value;
      }
      try {
        return fromString(value);
      } catch (e) {
        return defaultValue;
      }
    };
  }
});

// ../../node_modules/qrcode/lib/core/bit-buffer.js
var require_bit_buffer = __commonJS({
  "../../node_modules/qrcode/lib/core/bit-buffer.js"(exports, module) {
    function BitBuffer() {
      this.buffer = [];
      this.length = 0;
    }
    BitBuffer.prototype = {
      get: function(index) {
        const bufIndex = Math.floor(index / 8);
        return (this.buffer[bufIndex] >>> 7 - index % 8 & 1) === 1;
      },
      put: function(num, length) {
        for (let i = 0; i < length; i++) {
          this.putBit((num >>> length - i - 1 & 1) === 1);
        }
      },
      getLengthInBits: function() {
        return this.length;
      },
      putBit: function(bit) {
        const bufIndex = Math.floor(this.length / 8);
        if (this.buffer.length <= bufIndex) {
          this.buffer.push(0);
        }
        if (bit) {
          this.buffer[bufIndex] |= 128 >>> this.length % 8;
        }
        this.length++;
      }
    };
    module.exports = BitBuffer;
  }
});

// ../../node_modules/qrcode/lib/core/bit-matrix.js
var require_bit_matrix = __commonJS({
  "../../node_modules/qrcode/lib/core/bit-matrix.js"(exports, module) {
    function BitMatrix(size) {
      if (!size || size < 1) {
        throw new Error("BitMatrix size must be defined and greater than 0");
      }
      this.size = size;
      this.data = new Uint8Array(size * size);
      this.reservedBit = new Uint8Array(size * size);
    }
    BitMatrix.prototype.set = function(row, col, value, reserved) {
      const index = row * this.size + col;
      this.data[index] = value;
      if (reserved) this.reservedBit[index] = true;
    };
    BitMatrix.prototype.get = function(row, col) {
      return this.data[row * this.size + col];
    };
    BitMatrix.prototype.xor = function(row, col, value) {
      this.data[row * this.size + col] ^= value;
    };
    BitMatrix.prototype.isReserved = function(row, col) {
      return this.reservedBit[row * this.size + col];
    };
    module.exports = BitMatrix;
  }
});

// ../../node_modules/qrcode/lib/core/alignment-pattern.js
var require_alignment_pattern = __commonJS({
  "../../node_modules/qrcode/lib/core/alignment-pattern.js"(exports) {
    var getSymbolSize = require_utils().getSymbolSize;
    exports.getRowColCoords = function getRowColCoords(version) {
      if (version === 1) return [];
      const posCount = Math.floor(version / 7) + 2;
      const size = getSymbolSize(version);
      const intervals = size === 145 ? 26 : Math.ceil((size - 13) / (2 * posCount - 2)) * 2;
      const positions = [size - 7];
      for (let i = 1; i < posCount - 1; i++) {
        positions[i] = positions[i - 1] - intervals;
      }
      positions.push(6);
      return positions.reverse();
    };
    exports.getPositions = function getPositions(version) {
      const coords = [];
      const pos = exports.getRowColCoords(version);
      const posLength = pos.length;
      for (let i = 0; i < posLength; i++) {
        for (let j = 0; j < posLength; j++) {
          if (i === 0 && j === 0 || // top-left
          i === 0 && j === posLength - 1 || // bottom-left
          i === posLength - 1 && j === 0) {
            continue;
          }
          coords.push([pos[i], pos[j]]);
        }
      }
      return coords;
    };
  }
});

// ../../node_modules/qrcode/lib/core/finder-pattern.js
var require_finder_pattern = __commonJS({
  "../../node_modules/qrcode/lib/core/finder-pattern.js"(exports) {
    var getSymbolSize = require_utils().getSymbolSize;
    var FINDER_PATTERN_SIZE = 7;
    exports.getPositions = function getPositions(version) {
      const size = getSymbolSize(version);
      return [
        // top-left
        [0, 0],
        // top-right
        [size - FINDER_PATTERN_SIZE, 0],
        // bottom-left
        [0, size - FINDER_PATTERN_SIZE]
      ];
    };
  }
});

// ../../node_modules/qrcode/lib/core/mask-pattern.js
var require_mask_pattern = __commonJS({
  "../../node_modules/qrcode/lib/core/mask-pattern.js"(exports) {
    exports.Patterns = {
      PATTERN000: 0,
      PATTERN001: 1,
      PATTERN010: 2,
      PATTERN011: 3,
      PATTERN100: 4,
      PATTERN101: 5,
      PATTERN110: 6,
      PATTERN111: 7
    };
    var PenaltyScores = {
      N1: 3,
      N2: 3,
      N3: 40,
      N4: 10
    };
    exports.isValid = function isValid(mask) {
      return mask != null && mask !== "" && !isNaN(mask) && mask >= 0 && mask <= 7;
    };
    exports.from = function from(value) {
      return exports.isValid(value) ? parseInt(value, 10) : void 0;
    };
    exports.getPenaltyN1 = function getPenaltyN1(data) {
      const size = data.size;
      let points = 0;
      let sameCountCol = 0;
      let sameCountRow = 0;
      let lastCol = null;
      let lastRow = null;
      for (let row = 0; row < size; row++) {
        sameCountCol = sameCountRow = 0;
        lastCol = lastRow = null;
        for (let col = 0; col < size; col++) {
          let module2 = data.get(row, col);
          if (module2 === lastCol) {
            sameCountCol++;
          } else {
            if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
            lastCol = module2;
            sameCountCol = 1;
          }
          module2 = data.get(col, row);
          if (module2 === lastRow) {
            sameCountRow++;
          } else {
            if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
            lastRow = module2;
            sameCountRow = 1;
          }
        }
        if (sameCountCol >= 5) points += PenaltyScores.N1 + (sameCountCol - 5);
        if (sameCountRow >= 5) points += PenaltyScores.N1 + (sameCountRow - 5);
      }
      return points;
    };
    exports.getPenaltyN2 = function getPenaltyN2(data) {
      const size = data.size;
      let points = 0;
      for (let row = 0; row < size - 1; row++) {
        for (let col = 0; col < size - 1; col++) {
          const last = data.get(row, col) + data.get(row, col + 1) + data.get(row + 1, col) + data.get(row + 1, col + 1);
          if (last === 4 || last === 0) points++;
        }
      }
      return points * PenaltyScores.N2;
    };
    exports.getPenaltyN3 = function getPenaltyN3(data) {
      const size = data.size;
      let points = 0;
      let bitsCol = 0;
      let bitsRow = 0;
      for (let row = 0; row < size; row++) {
        bitsCol = bitsRow = 0;
        for (let col = 0; col < size; col++) {
          bitsCol = bitsCol << 1 & 2047 | data.get(row, col);
          if (col >= 10 && (bitsCol === 1488 || bitsCol === 93)) points++;
          bitsRow = bitsRow << 1 & 2047 | data.get(col, row);
          if (col >= 10 && (bitsRow === 1488 || bitsRow === 93)) points++;
        }
      }
      return points * PenaltyScores.N3;
    };
    exports.getPenaltyN4 = function getPenaltyN4(data) {
      let darkCount = 0;
      const modulesCount = data.data.length;
      for (let i = 0; i < modulesCount; i++) darkCount += data.data[i];
      const k = Math.abs(Math.ceil(darkCount * 100 / modulesCount / 5) - 10);
      return k * PenaltyScores.N4;
    };
    function getMaskAt(maskPattern, i, j) {
      switch (maskPattern) {
        case exports.Patterns.PATTERN000:
          return (i + j) % 2 === 0;
        case exports.Patterns.PATTERN001:
          return i % 2 === 0;
        case exports.Patterns.PATTERN010:
          return j % 3 === 0;
        case exports.Patterns.PATTERN011:
          return (i + j) % 3 === 0;
        case exports.Patterns.PATTERN100:
          return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 === 0;
        case exports.Patterns.PATTERN101:
          return i * j % 2 + i * j % 3 === 0;
        case exports.Patterns.PATTERN110:
          return (i * j % 2 + i * j % 3) % 2 === 0;
        case exports.Patterns.PATTERN111:
          return (i * j % 3 + (i + j) % 2) % 2 === 0;
        default:
          throw new Error("bad maskPattern:" + maskPattern);
      }
    }
    exports.applyMask = function applyMask(pattern, data) {
      const size = data.size;
      for (let col = 0; col < size; col++) {
        for (let row = 0; row < size; row++) {
          if (data.isReserved(row, col)) continue;
          data.xor(row, col, getMaskAt(pattern, row, col));
        }
      }
    };
    exports.getBestMask = function getBestMask(data, setupFormatFunc) {
      const numPatterns = Object.keys(exports.Patterns).length;
      let bestPattern = 0;
      let lowerPenalty = Infinity;
      for (let p = 0; p < numPatterns; p++) {
        setupFormatFunc(p);
        exports.applyMask(p, data);
        const penalty = exports.getPenaltyN1(data) + exports.getPenaltyN2(data) + exports.getPenaltyN3(data) + exports.getPenaltyN4(data);
        exports.applyMask(p, data);
        if (penalty < lowerPenalty) {
          lowerPenalty = penalty;
          bestPattern = p;
        }
      }
      return bestPattern;
    };
  }
});

// ../../node_modules/qrcode/lib/core/error-correction-code.js
var require_error_correction_code = __commonJS({
  "../../node_modules/qrcode/lib/core/error-correction-code.js"(exports) {
    var ECLevel = require_error_correction_level();
    var EC_BLOCKS_TABLE = [
      // L  M  Q  H
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      2,
      2,
      1,
      2,
      2,
      4,
      1,
      2,
      4,
      4,
      2,
      4,
      4,
      4,
      2,
      4,
      6,
      5,
      2,
      4,
      6,
      6,
      2,
      5,
      8,
      8,
      4,
      5,
      8,
      8,
      4,
      5,
      8,
      11,
      4,
      8,
      10,
      11,
      4,
      9,
      12,
      16,
      4,
      9,
      16,
      16,
      6,
      10,
      12,
      18,
      6,
      10,
      17,
      16,
      6,
      11,
      16,
      19,
      6,
      13,
      18,
      21,
      7,
      14,
      21,
      25,
      8,
      16,
      20,
      25,
      8,
      17,
      23,
      25,
      9,
      17,
      23,
      34,
      9,
      18,
      25,
      30,
      10,
      20,
      27,
      32,
      12,
      21,
      29,
      35,
      12,
      23,
      34,
      37,
      12,
      25,
      34,
      40,
      13,
      26,
      35,
      42,
      14,
      28,
      38,
      45,
      15,
      29,
      40,
      48,
      16,
      31,
      43,
      51,
      17,
      33,
      45,
      54,
      18,
      35,
      48,
      57,
      19,
      37,
      51,
      60,
      19,
      38,
      53,
      63,
      20,
      40,
      56,
      66,
      21,
      43,
      59,
      70,
      22,
      45,
      62,
      74,
      24,
      47,
      65,
      77,
      25,
      49,
      68,
      81
    ];
    var EC_CODEWORDS_TABLE = [
      // L  M  Q  H
      7,
      10,
      13,
      17,
      10,
      16,
      22,
      28,
      15,
      26,
      36,
      44,
      20,
      36,
      52,
      64,
      26,
      48,
      72,
      88,
      36,
      64,
      96,
      112,
      40,
      72,
      108,
      130,
      48,
      88,
      132,
      156,
      60,
      110,
      160,
      192,
      72,
      130,
      192,
      224,
      80,
      150,
      224,
      264,
      96,
      176,
      260,
      308,
      104,
      198,
      288,
      352,
      120,
      216,
      320,
      384,
      132,
      240,
      360,
      432,
      144,
      280,
      408,
      480,
      168,
      308,
      448,
      532,
      180,
      338,
      504,
      588,
      196,
      364,
      546,
      650,
      224,
      416,
      600,
      700,
      224,
      442,
      644,
      750,
      252,
      476,
      690,
      816,
      270,
      504,
      750,
      900,
      300,
      560,
      810,
      960,
      312,
      588,
      870,
      1050,
      336,
      644,
      952,
      1110,
      360,
      700,
      1020,
      1200,
      390,
      728,
      1050,
      1260,
      420,
      784,
      1140,
      1350,
      450,
      812,
      1200,
      1440,
      480,
      868,
      1290,
      1530,
      510,
      924,
      1350,
      1620,
      540,
      980,
      1440,
      1710,
      570,
      1036,
      1530,
      1800,
      570,
      1064,
      1590,
      1890,
      600,
      1120,
      1680,
      1980,
      630,
      1204,
      1770,
      2100,
      660,
      1260,
      1860,
      2220,
      720,
      1316,
      1950,
      2310,
      750,
      1372,
      2040,
      2430
    ];
    exports.getBlocksCount = function getBlocksCount(version, errorCorrectionLevel) {
      switch (errorCorrectionLevel) {
        case ECLevel.L:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 0];
        case ECLevel.M:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 1];
        case ECLevel.Q:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 2];
        case ECLevel.H:
          return EC_BLOCKS_TABLE[(version - 1) * 4 + 3];
        default:
          return void 0;
      }
    };
    exports.getTotalCodewordsCount = function getTotalCodewordsCount(version, errorCorrectionLevel) {
      switch (errorCorrectionLevel) {
        case ECLevel.L:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 0];
        case ECLevel.M:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 1];
        case ECLevel.Q:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 2];
        case ECLevel.H:
          return EC_CODEWORDS_TABLE[(version - 1) * 4 + 3];
        default:
          return void 0;
      }
    };
  }
});

// ../../node_modules/qrcode/lib/core/galois-field.js
var require_galois_field = __commonJS({
  "../../node_modules/qrcode/lib/core/galois-field.js"(exports) {
    var EXP_TABLE = new Uint8Array(512);
    var LOG_TABLE = new Uint8Array(256);
    (function initTables() {
      let x = 1;
      for (let i = 0; i < 255; i++) {
        EXP_TABLE[i] = x;
        LOG_TABLE[x] = i;
        x <<= 1;
        if (x & 256) {
          x ^= 285;
        }
      }
      for (let i = 255; i < 512; i++) {
        EXP_TABLE[i] = EXP_TABLE[i - 255];
      }
    })();
    exports.log = function log(n) {
      if (n < 1) throw new Error("log(" + n + ")");
      return LOG_TABLE[n];
    };
    exports.exp = function exp(n) {
      return EXP_TABLE[n];
    };
    exports.mul = function mul(x, y) {
      if (x === 0 || y === 0) return 0;
      return EXP_TABLE[LOG_TABLE[x] + LOG_TABLE[y]];
    };
  }
});

// ../../node_modules/qrcode/lib/core/polynomial.js
var require_polynomial = __commonJS({
  "../../node_modules/qrcode/lib/core/polynomial.js"(exports) {
    var GF = require_galois_field();
    exports.mul = function mul(p1, p2) {
      const coeff = new Uint8Array(p1.length + p2.length - 1);
      for (let i = 0; i < p1.length; i++) {
        for (let j = 0; j < p2.length; j++) {
          coeff[i + j] ^= GF.mul(p1[i], p2[j]);
        }
      }
      return coeff;
    };
    exports.mod = function mod(divident, divisor) {
      let result = new Uint8Array(divident);
      while (result.length - divisor.length >= 0) {
        const coeff = result[0];
        for (let i = 0; i < divisor.length; i++) {
          result[i] ^= GF.mul(divisor[i], coeff);
        }
        let offset = 0;
        while (offset < result.length && result[offset] === 0) offset++;
        result = result.slice(offset);
      }
      return result;
    };
    exports.generateECPolynomial = function generateECPolynomial(degree) {
      let poly = new Uint8Array([1]);
      for (let i = 0; i < degree; i++) {
        poly = exports.mul(poly, new Uint8Array([1, GF.exp(i)]));
      }
      return poly;
    };
  }
});

// ../../node_modules/qrcode/lib/core/reed-solomon-encoder.js
var require_reed_solomon_encoder = __commonJS({
  "../../node_modules/qrcode/lib/core/reed-solomon-encoder.js"(exports, module) {
    var Polynomial = require_polynomial();
    function ReedSolomonEncoder(degree) {
      this.genPoly = void 0;
      this.degree = degree;
      if (this.degree) this.initialize(this.degree);
    }
    ReedSolomonEncoder.prototype.initialize = function initialize(degree) {
      this.degree = degree;
      this.genPoly = Polynomial.generateECPolynomial(this.degree);
    };
    ReedSolomonEncoder.prototype.encode = function encode(data) {
      if (!this.genPoly) {
        throw new Error("Encoder not initialized");
      }
      const paddedData = new Uint8Array(data.length + this.degree);
      paddedData.set(data);
      const remainder = Polynomial.mod(paddedData, this.genPoly);
      const start = this.degree - remainder.length;
      if (start > 0) {
        const buff = new Uint8Array(this.degree);
        buff.set(remainder, start);
        return buff;
      }
      return remainder;
    };
    module.exports = ReedSolomonEncoder;
  }
});

// ../../node_modules/qrcode/lib/core/version-check.js
var require_version_check = __commonJS({
  "../../node_modules/qrcode/lib/core/version-check.js"(exports) {
    exports.isValid = function isValid(version) {
      return !isNaN(version) && version >= 1 && version <= 40;
    };
  }
});

// ../../node_modules/qrcode/lib/core/regex.js
var require_regex = __commonJS({
  "../../node_modules/qrcode/lib/core/regex.js"(exports) {
    var numeric = "[0-9]+";
    var alphanumeric = "[A-Z $%*+\\-./:]+";
    var kanji = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";
    kanji = kanji.replace(/u/g, "\\u");
    var byte = "(?:(?![A-Z0-9 $%*+\\-./:]|" + kanji + ")(?:.|[\r\n]))+";
    exports.KANJI = new RegExp(kanji, "g");
    exports.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g");
    exports.BYTE = new RegExp(byte, "g");
    exports.NUMERIC = new RegExp(numeric, "g");
    exports.ALPHANUMERIC = new RegExp(alphanumeric, "g");
    var TEST_KANJI = new RegExp("^" + kanji + "$");
    var TEST_NUMERIC = new RegExp("^" + numeric + "$");
    var TEST_ALPHANUMERIC = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
    exports.testKanji = function testKanji(str) {
      return TEST_KANJI.test(str);
    };
    exports.testNumeric = function testNumeric(str) {
      return TEST_NUMERIC.test(str);
    };
    exports.testAlphanumeric = function testAlphanumeric(str) {
      return TEST_ALPHANUMERIC.test(str);
    };
  }
});

// ../../node_modules/qrcode/lib/core/mode.js
var require_mode = __commonJS({
  "../../node_modules/qrcode/lib/core/mode.js"(exports) {
    var VersionCheck = require_version_check();
    var Regex = require_regex();
    exports.NUMERIC = {
      id: "Numeric",
      bit: 1 << 0,
      ccBits: [10, 12, 14]
    };
    exports.ALPHANUMERIC = {
      id: "Alphanumeric",
      bit: 1 << 1,
      ccBits: [9, 11, 13]
    };
    exports.BYTE = {
      id: "Byte",
      bit: 1 << 2,
      ccBits: [8, 16, 16]
    };
    exports.KANJI = {
      id: "Kanji",
      bit: 1 << 3,
      ccBits: [8, 10, 12]
    };
    exports.MIXED = {
      bit: -1
    };
    exports.getCharCountIndicator = function getCharCountIndicator(mode, version) {
      if (!mode.ccBits) throw new Error("Invalid mode: " + mode);
      if (!VersionCheck.isValid(version)) {
        throw new Error("Invalid version: " + version);
      }
      if (version >= 1 && version < 10) return mode.ccBits[0];
      else if (version < 27) return mode.ccBits[1];
      return mode.ccBits[2];
    };
    exports.getBestModeForData = function getBestModeForData(dataStr) {
      if (Regex.testNumeric(dataStr)) return exports.NUMERIC;
      else if (Regex.testAlphanumeric(dataStr)) return exports.ALPHANUMERIC;
      else if (Regex.testKanji(dataStr)) return exports.KANJI;
      else return exports.BYTE;
    };
    exports.toString = function toString(mode) {
      if (mode && mode.id) return mode.id;
      throw new Error("Invalid mode");
    };
    exports.isValid = function isValid(mode) {
      return mode && mode.bit && mode.ccBits;
    };
    function fromString(string) {
      if (typeof string !== "string") {
        throw new Error("Param is not a string");
      }
      const lcStr = string.toLowerCase();
      switch (lcStr) {
        case "numeric":
          return exports.NUMERIC;
        case "alphanumeric":
          return exports.ALPHANUMERIC;
        case "kanji":
          return exports.KANJI;
        case "byte":
          return exports.BYTE;
        default:
          throw new Error("Unknown mode: " + string);
      }
    }
    exports.from = function from(value, defaultValue) {
      if (exports.isValid(value)) {
        return value;
      }
      try {
        return fromString(value);
      } catch (e) {
        return defaultValue;
      }
    };
  }
});

// ../../node_modules/qrcode/lib/core/version.js
var require_version = __commonJS({
  "../../node_modules/qrcode/lib/core/version.js"(exports) {
    var Utils = require_utils();
    var ECCode = require_error_correction_code();
    var ECLevel = require_error_correction_level();
    var Mode = require_mode();
    var VersionCheck = require_version_check();
    var G18 = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0;
    var G18_BCH = Utils.getBCHDigit(G18);
    function getBestVersionForDataLength(mode, length, errorCorrectionLevel) {
      for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
        if (length <= exports.getCapacity(currentVersion, errorCorrectionLevel, mode)) {
          return currentVersion;
        }
      }
      return void 0;
    }
    function getReservedBitsCount(mode, version) {
      return Mode.getCharCountIndicator(mode, version) + 4;
    }
    function getTotalBitsFromDataArray(segments, version) {
      let totalBits = 0;
      segments.forEach(function(data) {
        const reservedBits = getReservedBitsCount(data.mode, version);
        totalBits += reservedBits + data.getBitsLength();
      });
      return totalBits;
    }
    function getBestVersionForMixedData(segments, errorCorrectionLevel) {
      for (let currentVersion = 1; currentVersion <= 40; currentVersion++) {
        const length = getTotalBitsFromDataArray(segments, currentVersion);
        if (length <= exports.getCapacity(currentVersion, errorCorrectionLevel, Mode.MIXED)) {
          return currentVersion;
        }
      }
      return void 0;
    }
    exports.from = function from(value, defaultValue) {
      if (VersionCheck.isValid(value)) {
        return parseInt(value, 10);
      }
      return defaultValue;
    };
    exports.getCapacity = function getCapacity(version, errorCorrectionLevel, mode) {
      if (!VersionCheck.isValid(version)) {
        throw new Error("Invalid QR Code version");
      }
      if (typeof mode === "undefined") mode = Mode.BYTE;
      const totalCodewords = Utils.getSymbolTotalCodewords(version);
      const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
      const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;
      if (mode === Mode.MIXED) return dataTotalCodewordsBits;
      const usableBits = dataTotalCodewordsBits - getReservedBitsCount(mode, version);
      switch (mode) {
        case Mode.NUMERIC:
          return Math.floor(usableBits / 10 * 3);
        case Mode.ALPHANUMERIC:
          return Math.floor(usableBits / 11 * 2);
        case Mode.KANJI:
          return Math.floor(usableBits / 13);
        case Mode.BYTE:
        default:
          return Math.floor(usableBits / 8);
      }
    };
    exports.getBestVersionForData = function getBestVersionForData(data, errorCorrectionLevel) {
      let seg;
      const ecl = ECLevel.from(errorCorrectionLevel, ECLevel.M);
      if (Array.isArray(data)) {
        if (data.length > 1) {
          return getBestVersionForMixedData(data, ecl);
        }
        if (data.length === 0) {
          return 1;
        }
        seg = data[0];
      } else {
        seg = data;
      }
      return getBestVersionForDataLength(seg.mode, seg.getLength(), ecl);
    };
    exports.getEncodedBits = function getEncodedBits(version) {
      if (!VersionCheck.isValid(version) || version < 7) {
        throw new Error("Invalid QR Code version");
      }
      let d = version << 12;
      while (Utils.getBCHDigit(d) - G18_BCH >= 0) {
        d ^= G18 << Utils.getBCHDigit(d) - G18_BCH;
      }
      return version << 12 | d;
    };
  }
});

// ../../node_modules/qrcode/lib/core/format-info.js
var require_format_info = __commonJS({
  "../../node_modules/qrcode/lib/core/format-info.js"(exports) {
    var Utils = require_utils();
    var G15 = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0;
    var G15_MASK = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1;
    var G15_BCH = Utils.getBCHDigit(G15);
    exports.getEncodedBits = function getEncodedBits(errorCorrectionLevel, mask) {
      const data = errorCorrectionLevel.bit << 3 | mask;
      let d = data << 10;
      while (Utils.getBCHDigit(d) - G15_BCH >= 0) {
        d ^= G15 << Utils.getBCHDigit(d) - G15_BCH;
      }
      return (data << 10 | d) ^ G15_MASK;
    };
  }
});

// ../../node_modules/qrcode/lib/core/numeric-data.js
var require_numeric_data = __commonJS({
  "../../node_modules/qrcode/lib/core/numeric-data.js"(exports, module) {
    var Mode = require_mode();
    function NumericData(data) {
      this.mode = Mode.NUMERIC;
      this.data = data.toString();
    }
    NumericData.getBitsLength = function getBitsLength(length) {
      return 10 * Math.floor(length / 3) + (length % 3 ? length % 3 * 3 + 1 : 0);
    };
    NumericData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    NumericData.prototype.getBitsLength = function getBitsLength() {
      return NumericData.getBitsLength(this.data.length);
    };
    NumericData.prototype.write = function write(bitBuffer) {
      let i, group, value;
      for (i = 0; i + 3 <= this.data.length; i += 3) {
        group = this.data.substr(i, 3);
        value = parseInt(group, 10);
        bitBuffer.put(value, 10);
      }
      const remainingNum = this.data.length - i;
      if (remainingNum > 0) {
        group = this.data.substr(i);
        value = parseInt(group, 10);
        bitBuffer.put(value, remainingNum * 3 + 1);
      }
    };
    module.exports = NumericData;
  }
});

// ../../node_modules/qrcode/lib/core/alphanumeric-data.js
var require_alphanumeric_data = __commonJS({
  "../../node_modules/qrcode/lib/core/alphanumeric-data.js"(exports, module) {
    var Mode = require_mode();
    var ALPHA_NUM_CHARS = [
      "0",
      "1",
      "2",
      "3",
      "4",
      "5",
      "6",
      "7",
      "8",
      "9",
      "A",
      "B",
      "C",
      "D",
      "E",
      "F",
      "G",
      "H",
      "I",
      "J",
      "K",
      "L",
      "M",
      "N",
      "O",
      "P",
      "Q",
      "R",
      "S",
      "T",
      "U",
      "V",
      "W",
      "X",
      "Y",
      "Z",
      " ",
      "$",
      "%",
      "*",
      "+",
      "-",
      ".",
      "/",
      ":"
    ];
    function AlphanumericData(data) {
      this.mode = Mode.ALPHANUMERIC;
      this.data = data;
    }
    AlphanumericData.getBitsLength = function getBitsLength(length) {
      return 11 * Math.floor(length / 2) + 6 * (length % 2);
    };
    AlphanumericData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    AlphanumericData.prototype.getBitsLength = function getBitsLength() {
      return AlphanumericData.getBitsLength(this.data.length);
    };
    AlphanumericData.prototype.write = function write(bitBuffer) {
      let i;
      for (i = 0; i + 2 <= this.data.length; i += 2) {
        let value = ALPHA_NUM_CHARS.indexOf(this.data[i]) * 45;
        value += ALPHA_NUM_CHARS.indexOf(this.data[i + 1]);
        bitBuffer.put(value, 11);
      }
      if (this.data.length % 2) {
        bitBuffer.put(ALPHA_NUM_CHARS.indexOf(this.data[i]), 6);
      }
    };
    module.exports = AlphanumericData;
  }
});

// ../../node_modules/qrcode/lib/core/byte-data.js
var require_byte_data = __commonJS({
  "../../node_modules/qrcode/lib/core/byte-data.js"(exports, module) {
    var Mode = require_mode();
    function ByteData(data) {
      this.mode = Mode.BYTE;
      if (typeof data === "string") {
        this.data = new TextEncoder().encode(data);
      } else {
        this.data = new Uint8Array(data);
      }
    }
    ByteData.getBitsLength = function getBitsLength(length) {
      return length * 8;
    };
    ByteData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    ByteData.prototype.getBitsLength = function getBitsLength() {
      return ByteData.getBitsLength(this.data.length);
    };
    ByteData.prototype.write = function(bitBuffer) {
      for (let i = 0, l = this.data.length; i < l; i++) {
        bitBuffer.put(this.data[i], 8);
      }
    };
    module.exports = ByteData;
  }
});

// ../../node_modules/qrcode/lib/core/kanji-data.js
var require_kanji_data = __commonJS({
  "../../node_modules/qrcode/lib/core/kanji-data.js"(exports, module) {
    var Mode = require_mode();
    var Utils = require_utils();
    function KanjiData(data) {
      this.mode = Mode.KANJI;
      this.data = data;
    }
    KanjiData.getBitsLength = function getBitsLength(length) {
      return length * 13;
    };
    KanjiData.prototype.getLength = function getLength() {
      return this.data.length;
    };
    KanjiData.prototype.getBitsLength = function getBitsLength() {
      return KanjiData.getBitsLength(this.data.length);
    };
    KanjiData.prototype.write = function(bitBuffer) {
      let i;
      for (i = 0; i < this.data.length; i++) {
        let value = Utils.toSJIS(this.data[i]);
        if (value >= 33088 && value <= 40956) {
          value -= 33088;
        } else if (value >= 57408 && value <= 60351) {
          value -= 49472;
        } else {
          throw new Error(
            "Invalid SJIS character: " + this.data[i] + "\nMake sure your charset is UTF-8"
          );
        }
        value = (value >>> 8 & 255) * 192 + (value & 255);
        bitBuffer.put(value, 13);
      }
    };
    module.exports = KanjiData;
  }
});

// ../../node_modules/dijkstrajs/dijkstra.js
var require_dijkstra = __commonJS({
  "../../node_modules/dijkstrajs/dijkstra.js"(exports, module) {
    "use strict";
    var dijkstra = {
      single_source_shortest_paths: function(graph, s, d) {
        var predecessors = {};
        var costs = {};
        costs[s] = 0;
        var open = dijkstra.PriorityQueue.make();
        open.push(s, 0);
        var closest, u, v, cost_of_s_to_u, adjacent_nodes, cost_of_e, cost_of_s_to_u_plus_cost_of_e, cost_of_s_to_v, first_visit;
        while (!open.empty()) {
          closest = open.pop();
          u = closest.value;
          cost_of_s_to_u = closest.cost;
          adjacent_nodes = graph[u] || {};
          for (v in adjacent_nodes) {
            if (adjacent_nodes.hasOwnProperty(v)) {
              cost_of_e = adjacent_nodes[v];
              cost_of_s_to_u_plus_cost_of_e = cost_of_s_to_u + cost_of_e;
              cost_of_s_to_v = costs[v];
              first_visit = typeof costs[v] === "undefined";
              if (first_visit || cost_of_s_to_v > cost_of_s_to_u_plus_cost_of_e) {
                costs[v] = cost_of_s_to_u_plus_cost_of_e;
                open.push(v, cost_of_s_to_u_plus_cost_of_e);
                predecessors[v] = u;
              }
            }
          }
        }
        if (typeof d !== "undefined" && typeof costs[d] === "undefined") {
          var msg2 = ["Could not find a path from ", s, " to ", d, "."].join("");
          throw new Error(msg2);
        }
        return predecessors;
      },
      extract_shortest_path_from_predecessor_list: function(predecessors, d) {
        var nodes = [];
        var u = d;
        var predecessor;
        while (u) {
          nodes.push(u);
          predecessor = predecessors[u];
          u = predecessors[u];
        }
        nodes.reverse();
        return nodes;
      },
      find_path: function(graph, s, d) {
        var predecessors = dijkstra.single_source_shortest_paths(graph, s, d);
        return dijkstra.extract_shortest_path_from_predecessor_list(
          predecessors,
          d
        );
      },
      /**
       * A very naive priority queue implementation.
       */
      PriorityQueue: {
        make: function(opts) {
          var T = dijkstra.PriorityQueue, t = {}, key;
          opts = opts || {};
          for (key in T) {
            if (T.hasOwnProperty(key)) {
              t[key] = T[key];
            }
          }
          t.queue = [];
          t.sorter = opts.sorter || T.default_sorter;
          return t;
        },
        default_sorter: function(a, b) {
          return a.cost - b.cost;
        },
        /**
         * Add a new item to the queue and ensure the highest priority element
         * is at the front of the queue.
         */
        push: function(value, cost) {
          var item = { value, cost };
          this.queue.push(item);
          this.queue.sort(this.sorter);
        },
        /**
         * Return the highest priority element in the queue.
         */
        pop: function() {
          return this.queue.shift();
        },
        empty: function() {
          return this.queue.length === 0;
        }
      }
    };
    if (typeof module !== "undefined") {
      module.exports = dijkstra;
    }
  }
});

// ../../node_modules/qrcode/lib/core/segments.js
var require_segments = __commonJS({
  "../../node_modules/qrcode/lib/core/segments.js"(exports) {
    var Mode = require_mode();
    var NumericData = require_numeric_data();
    var AlphanumericData = require_alphanumeric_data();
    var ByteData = require_byte_data();
    var KanjiData = require_kanji_data();
    var Regex = require_regex();
    var Utils = require_utils();
    var dijkstra = require_dijkstra();
    function getStringByteLength(str) {
      return unescape(encodeURIComponent(str)).length;
    }
    function getSegments(regex, mode, str) {
      const segments = [];
      let result;
      while ((result = regex.exec(str)) !== null) {
        segments.push({
          data: result[0],
          index: result.index,
          mode,
          length: result[0].length
        });
      }
      return segments;
    }
    function getSegmentsFromString(dataStr) {
      const numSegs = getSegments(Regex.NUMERIC, Mode.NUMERIC, dataStr);
      const alphaNumSegs = getSegments(Regex.ALPHANUMERIC, Mode.ALPHANUMERIC, dataStr);
      let byteSegs;
      let kanjiSegs;
      if (Utils.isKanjiModeEnabled()) {
        byteSegs = getSegments(Regex.BYTE, Mode.BYTE, dataStr);
        kanjiSegs = getSegments(Regex.KANJI, Mode.KANJI, dataStr);
      } else {
        byteSegs = getSegments(Regex.BYTE_KANJI, Mode.BYTE, dataStr);
        kanjiSegs = [];
      }
      const segs = numSegs.concat(alphaNumSegs, byteSegs, kanjiSegs);
      return segs.sort(function(s1, s2) {
        return s1.index - s2.index;
      }).map(function(obj) {
        return {
          data: obj.data,
          mode: obj.mode,
          length: obj.length
        };
      });
    }
    function getSegmentBitsLength(length, mode) {
      switch (mode) {
        case Mode.NUMERIC:
          return NumericData.getBitsLength(length);
        case Mode.ALPHANUMERIC:
          return AlphanumericData.getBitsLength(length);
        case Mode.KANJI:
          return KanjiData.getBitsLength(length);
        case Mode.BYTE:
          return ByteData.getBitsLength(length);
      }
    }
    function mergeSegments(segs) {
      return segs.reduce(function(acc, curr) {
        const prevSeg = acc.length - 1 >= 0 ? acc[acc.length - 1] : null;
        if (prevSeg && prevSeg.mode === curr.mode) {
          acc[acc.length - 1].data += curr.data;
          return acc;
        }
        acc.push(curr);
        return acc;
      }, []);
    }
    function buildNodes(segs) {
      const nodes = [];
      for (let i = 0; i < segs.length; i++) {
        const seg = segs[i];
        switch (seg.mode) {
          case Mode.NUMERIC:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode.ALPHANUMERIC, length: seg.length },
              { data: seg.data, mode: Mode.BYTE, length: seg.length }
            ]);
            break;
          case Mode.ALPHANUMERIC:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode.BYTE, length: seg.length }
            ]);
            break;
          case Mode.KANJI:
            nodes.push([
              seg,
              { data: seg.data, mode: Mode.BYTE, length: getStringByteLength(seg.data) }
            ]);
            break;
          case Mode.BYTE:
            nodes.push([
              { data: seg.data, mode: Mode.BYTE, length: getStringByteLength(seg.data) }
            ]);
        }
      }
      return nodes;
    }
    function buildGraph(nodes, version) {
      const table = {};
      const graph = { start: {} };
      let prevNodeIds = ["start"];
      for (let i = 0; i < nodes.length; i++) {
        const nodeGroup = nodes[i];
        const currentNodeIds = [];
        for (let j = 0; j < nodeGroup.length; j++) {
          const node = nodeGroup[j];
          const key = "" + i + j;
          currentNodeIds.push(key);
          table[key] = { node, lastCount: 0 };
          graph[key] = {};
          for (let n = 0; n < prevNodeIds.length; n++) {
            const prevNodeId = prevNodeIds[n];
            if (table[prevNodeId] && table[prevNodeId].node.mode === node.mode) {
              graph[prevNodeId][key] = getSegmentBitsLength(table[prevNodeId].lastCount + node.length, node.mode) - getSegmentBitsLength(table[prevNodeId].lastCount, node.mode);
              table[prevNodeId].lastCount += node.length;
            } else {
              if (table[prevNodeId]) table[prevNodeId].lastCount = node.length;
              graph[prevNodeId][key] = getSegmentBitsLength(node.length, node.mode) + 4 + Mode.getCharCountIndicator(node.mode, version);
            }
          }
        }
        prevNodeIds = currentNodeIds;
      }
      for (let n = 0; n < prevNodeIds.length; n++) {
        graph[prevNodeIds[n]].end = 0;
      }
      return { map: graph, table };
    }
    function buildSingleSegment(data, modesHint) {
      let mode;
      const bestMode = Mode.getBestModeForData(data);
      mode = Mode.from(modesHint, bestMode);
      if (mode !== Mode.BYTE && mode.bit < bestMode.bit) {
        throw new Error('"' + data + '" cannot be encoded with mode ' + Mode.toString(mode) + ".\n Suggested mode is: " + Mode.toString(bestMode));
      }
      if (mode === Mode.KANJI && !Utils.isKanjiModeEnabled()) {
        mode = Mode.BYTE;
      }
      switch (mode) {
        case Mode.NUMERIC:
          return new NumericData(data);
        case Mode.ALPHANUMERIC:
          return new AlphanumericData(data);
        case Mode.KANJI:
          return new KanjiData(data);
        case Mode.BYTE:
          return new ByteData(data);
      }
    }
    exports.fromArray = function fromArray(array) {
      return array.reduce(function(acc, seg) {
        if (typeof seg === "string") {
          acc.push(buildSingleSegment(seg, null));
        } else if (seg.data) {
          acc.push(buildSingleSegment(seg.data, seg.mode));
        }
        return acc;
      }, []);
    };
    exports.fromString = function fromString(data, version) {
      const segs = getSegmentsFromString(data, Utils.isKanjiModeEnabled());
      const nodes = buildNodes(segs);
      const graph = buildGraph(nodes, version);
      const path = dijkstra.find_path(graph.map, "start", "end");
      const optimizedSegs = [];
      for (let i = 1; i < path.length - 1; i++) {
        optimizedSegs.push(graph.table[path[i]].node);
      }
      return exports.fromArray(mergeSegments(optimizedSegs));
    };
    exports.rawSplit = function rawSplit(data) {
      return exports.fromArray(
        getSegmentsFromString(data, Utils.isKanjiModeEnabled())
      );
    };
  }
});

// ../../node_modules/qrcode/lib/core/qrcode.js
var require_qrcode = __commonJS({
  "../../node_modules/qrcode/lib/core/qrcode.js"(exports) {
    var Utils = require_utils();
    var ECLevel = require_error_correction_level();
    var BitBuffer = require_bit_buffer();
    var BitMatrix = require_bit_matrix();
    var AlignmentPattern = require_alignment_pattern();
    var FinderPattern = require_finder_pattern();
    var MaskPattern = require_mask_pattern();
    var ECCode = require_error_correction_code();
    var ReedSolomonEncoder = require_reed_solomon_encoder();
    var Version = require_version();
    var FormatInfo = require_format_info();
    var Mode = require_mode();
    var Segments = require_segments();
    function setupFinderPattern(matrix, version) {
      const size = matrix.size;
      const pos = FinderPattern.getPositions(version);
      for (let i = 0; i < pos.length; i++) {
        const row = pos[i][0];
        const col = pos[i][1];
        for (let r = -1; r <= 7; r++) {
          if (row + r <= -1 || size <= row + r) continue;
          for (let c = -1; c <= 7; c++) {
            if (col + c <= -1 || size <= col + c) continue;
            if (r >= 0 && r <= 6 && (c === 0 || c === 6) || c >= 0 && c <= 6 && (r === 0 || r === 6) || r >= 2 && r <= 4 && c >= 2 && c <= 4) {
              matrix.set(row + r, col + c, true, true);
            } else {
              matrix.set(row + r, col + c, false, true);
            }
          }
        }
      }
    }
    function setupTimingPattern(matrix) {
      const size = matrix.size;
      for (let r = 8; r < size - 8; r++) {
        const value = r % 2 === 0;
        matrix.set(r, 6, value, true);
        matrix.set(6, r, value, true);
      }
    }
    function setupAlignmentPattern(matrix, version) {
      const pos = AlignmentPattern.getPositions(version);
      for (let i = 0; i < pos.length; i++) {
        const row = pos[i][0];
        const col = pos[i][1];
        for (let r = -2; r <= 2; r++) {
          for (let c = -2; c <= 2; c++) {
            if (r === -2 || r === 2 || c === -2 || c === 2 || r === 0 && c === 0) {
              matrix.set(row + r, col + c, true, true);
            } else {
              matrix.set(row + r, col + c, false, true);
            }
          }
        }
      }
    }
    function setupVersionInfo(matrix, version) {
      const size = matrix.size;
      const bits = Version.getEncodedBits(version);
      let row, col, mod;
      for (let i = 0; i < 18; i++) {
        row = Math.floor(i / 3);
        col = i % 3 + size - 8 - 3;
        mod = (bits >> i & 1) === 1;
        matrix.set(row, col, mod, true);
        matrix.set(col, row, mod, true);
      }
    }
    function setupFormatInfo(matrix, errorCorrectionLevel, maskPattern) {
      const size = matrix.size;
      const bits = FormatInfo.getEncodedBits(errorCorrectionLevel, maskPattern);
      let i, mod;
      for (i = 0; i < 15; i++) {
        mod = (bits >> i & 1) === 1;
        if (i < 6) {
          matrix.set(i, 8, mod, true);
        } else if (i < 8) {
          matrix.set(i + 1, 8, mod, true);
        } else {
          matrix.set(size - 15 + i, 8, mod, true);
        }
        if (i < 8) {
          matrix.set(8, size - i - 1, mod, true);
        } else if (i < 9) {
          matrix.set(8, 15 - i - 1 + 1, mod, true);
        } else {
          matrix.set(8, 15 - i - 1, mod, true);
        }
      }
      matrix.set(size - 8, 8, 1, true);
    }
    function setupData(matrix, data) {
      const size = matrix.size;
      let inc = -1;
      let row = size - 1;
      let bitIndex = 7;
      let byteIndex = 0;
      for (let col = size - 1; col > 0; col -= 2) {
        if (col === 6) col--;
        while (true) {
          for (let c = 0; c < 2; c++) {
            if (!matrix.isReserved(row, col - c)) {
              let dark = false;
              if (byteIndex < data.length) {
                dark = (data[byteIndex] >>> bitIndex & 1) === 1;
              }
              matrix.set(row, col - c, dark);
              bitIndex--;
              if (bitIndex === -1) {
                byteIndex++;
                bitIndex = 7;
              }
            }
          }
          row += inc;
          if (row < 0 || size <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    }
    function createData(version, errorCorrectionLevel, segments) {
      const buffer = new BitBuffer();
      segments.forEach(function(data) {
        buffer.put(data.mode.bit, 4);
        buffer.put(data.getLength(), Mode.getCharCountIndicator(data.mode, version));
        data.write(buffer);
      });
      const totalCodewords = Utils.getSymbolTotalCodewords(version);
      const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
      const dataTotalCodewordsBits = (totalCodewords - ecTotalCodewords) * 8;
      if (buffer.getLengthInBits() + 4 <= dataTotalCodewordsBits) {
        buffer.put(0, 4);
      }
      while (buffer.getLengthInBits() % 8 !== 0) {
        buffer.putBit(0);
      }
      const remainingByte = (dataTotalCodewordsBits - buffer.getLengthInBits()) / 8;
      for (let i = 0; i < remainingByte; i++) {
        buffer.put(i % 2 ? 17 : 236, 8);
      }
      return createCodewords(buffer, version, errorCorrectionLevel);
    }
    function createCodewords(bitBuffer, version, errorCorrectionLevel) {
      const totalCodewords = Utils.getSymbolTotalCodewords(version);
      const ecTotalCodewords = ECCode.getTotalCodewordsCount(version, errorCorrectionLevel);
      const dataTotalCodewords = totalCodewords - ecTotalCodewords;
      const ecTotalBlocks = ECCode.getBlocksCount(version, errorCorrectionLevel);
      const blocksInGroup2 = totalCodewords % ecTotalBlocks;
      const blocksInGroup1 = ecTotalBlocks - blocksInGroup2;
      const totalCodewordsInGroup1 = Math.floor(totalCodewords / ecTotalBlocks);
      const dataCodewordsInGroup1 = Math.floor(dataTotalCodewords / ecTotalBlocks);
      const dataCodewordsInGroup2 = dataCodewordsInGroup1 + 1;
      const ecCount = totalCodewordsInGroup1 - dataCodewordsInGroup1;
      const rs = new ReedSolomonEncoder(ecCount);
      let offset = 0;
      const dcData = new Array(ecTotalBlocks);
      const ecData = new Array(ecTotalBlocks);
      let maxDataSize = 0;
      const buffer = new Uint8Array(bitBuffer.buffer);
      for (let b = 0; b < ecTotalBlocks; b++) {
        const dataSize = b < blocksInGroup1 ? dataCodewordsInGroup1 : dataCodewordsInGroup2;
        dcData[b] = buffer.slice(offset, offset + dataSize);
        ecData[b] = rs.encode(dcData[b]);
        offset += dataSize;
        maxDataSize = Math.max(maxDataSize, dataSize);
      }
      const data = new Uint8Array(totalCodewords);
      let index = 0;
      let i, r;
      for (i = 0; i < maxDataSize; i++) {
        for (r = 0; r < ecTotalBlocks; r++) {
          if (i < dcData[r].length) {
            data[index++] = dcData[r][i];
          }
        }
      }
      for (i = 0; i < ecCount; i++) {
        for (r = 0; r < ecTotalBlocks; r++) {
          data[index++] = ecData[r][i];
        }
      }
      return data;
    }
    function createSymbol(data, version, errorCorrectionLevel, maskPattern) {
      let segments;
      if (Array.isArray(data)) {
        segments = Segments.fromArray(data);
      } else if (typeof data === "string") {
        let estimatedVersion = version;
        if (!estimatedVersion) {
          const rawSegments = Segments.rawSplit(data);
          estimatedVersion = Version.getBestVersionForData(rawSegments, errorCorrectionLevel);
        }
        segments = Segments.fromString(data, estimatedVersion || 40);
      } else {
        throw new Error("Invalid data");
      }
      const bestVersion = Version.getBestVersionForData(segments, errorCorrectionLevel);
      if (!bestVersion) {
        throw new Error("The amount of data is too big to be stored in a QR Code");
      }
      if (!version) {
        version = bestVersion;
      } else if (version < bestVersion) {
        throw new Error(
          "\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: " + bestVersion + ".\n"
        );
      }
      const dataBits = createData(version, errorCorrectionLevel, segments);
      const moduleCount = Utils.getSymbolSize(version);
      const modules = new BitMatrix(moduleCount);
      setupFinderPattern(modules, version);
      setupTimingPattern(modules);
      setupAlignmentPattern(modules, version);
      setupFormatInfo(modules, errorCorrectionLevel, 0);
      if (version >= 7) {
        setupVersionInfo(modules, version);
      }
      setupData(modules, dataBits);
      if (isNaN(maskPattern)) {
        maskPattern = MaskPattern.getBestMask(
          modules,
          setupFormatInfo.bind(null, modules, errorCorrectionLevel)
        );
      }
      MaskPattern.applyMask(maskPattern, modules);
      setupFormatInfo(modules, errorCorrectionLevel, maskPattern);
      return {
        modules,
        version,
        errorCorrectionLevel,
        maskPattern,
        segments
      };
    }
    exports.create = function create(data, options) {
      if (typeof data === "undefined" || data === "") {
        throw new Error("No input text");
      }
      let errorCorrectionLevel = ECLevel.M;
      let version;
      let mask;
      if (typeof options !== "undefined") {
        errorCorrectionLevel = ECLevel.from(options.errorCorrectionLevel, ECLevel.M);
        version = Version.from(options.version);
        mask = MaskPattern.from(options.maskPattern);
        if (options.toSJISFunc) {
          Utils.setToSJISFunction(options.toSJISFunc);
        }
      }
      return createSymbol(data, version, errorCorrectionLevel, mask);
    };
  }
});

// ../../node_modules/qrcode/lib/renderer/utils.js
var require_utils2 = __commonJS({
  "../../node_modules/qrcode/lib/renderer/utils.js"(exports) {
    function hex2rgba(hex) {
      if (typeof hex === "number") {
        hex = hex.toString();
      }
      if (typeof hex !== "string") {
        throw new Error("Color should be defined as hex string");
      }
      let hexCode = hex.slice().replace("#", "").split("");
      if (hexCode.length < 3 || hexCode.length === 5 || hexCode.length > 8) {
        throw new Error("Invalid hex color: " + hex);
      }
      if (hexCode.length === 3 || hexCode.length === 4) {
        hexCode = Array.prototype.concat.apply([], hexCode.map(function(c) {
          return [c, c];
        }));
      }
      if (hexCode.length === 6) hexCode.push("F", "F");
      const hexValue = parseInt(hexCode.join(""), 16);
      return {
        r: hexValue >> 24 & 255,
        g: hexValue >> 16 & 255,
        b: hexValue >> 8 & 255,
        a: hexValue & 255,
        hex: "#" + hexCode.slice(0, 6).join("")
      };
    }
    exports.getOptions = function getOptions(options) {
      if (!options) options = {};
      if (!options.color) options.color = {};
      const margin = typeof options.margin === "undefined" || options.margin === null || options.margin < 0 ? 4 : options.margin;
      const width = options.width && options.width >= 21 ? options.width : void 0;
      const scale = options.scale || 4;
      return {
        width,
        scale: width ? 4 : scale,
        margin,
        color: {
          dark: hex2rgba(options.color.dark || "#000000ff"),
          light: hex2rgba(options.color.light || "#ffffffff")
        },
        type: options.type,
        rendererOpts: options.rendererOpts || {}
      };
    };
    exports.getScale = function getScale(qrSize, opts) {
      return opts.width && opts.width >= qrSize + opts.margin * 2 ? opts.width / (qrSize + opts.margin * 2) : opts.scale;
    };
    exports.getImageWidth = function getImageWidth(qrSize, opts) {
      const scale = exports.getScale(qrSize, opts);
      return Math.floor((qrSize + opts.margin * 2) * scale);
    };
    exports.qrToImageData = function qrToImageData(imgData, qr, opts) {
      const size = qr.modules.size;
      const data = qr.modules.data;
      const scale = exports.getScale(size, opts);
      const symbolSize = Math.floor((size + opts.margin * 2) * scale);
      const scaledMargin = opts.margin * scale;
      const palette = [opts.color.light, opts.color.dark];
      for (let i = 0; i < symbolSize; i++) {
        for (let j = 0; j < symbolSize; j++) {
          let posDst = (i * symbolSize + j) * 4;
          let pxColor = opts.color.light;
          if (i >= scaledMargin && j >= scaledMargin && i < symbolSize - scaledMargin && j < symbolSize - scaledMargin) {
            const iSrc = Math.floor((i - scaledMargin) / scale);
            const jSrc = Math.floor((j - scaledMargin) / scale);
            pxColor = palette[data[iSrc * size + jSrc] ? 1 : 0];
          }
          imgData[posDst++] = pxColor.r;
          imgData[posDst++] = pxColor.g;
          imgData[posDst++] = pxColor.b;
          imgData[posDst] = pxColor.a;
        }
      }
    };
  }
});

// ../../node_modules/qrcode/lib/renderer/canvas.js
var require_canvas = __commonJS({
  "../../node_modules/qrcode/lib/renderer/canvas.js"(exports) {
    var Utils = require_utils2();
    function clearCanvas(ctx, canvas, size) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      if (!canvas.style) canvas.style = {};
      canvas.height = size;
      canvas.width = size;
      canvas.style.height = size + "px";
      canvas.style.width = size + "px";
    }
    function getCanvasElement() {
      try {
        return document.createElement("canvas");
      } catch (e) {
        throw new Error("You need to specify a canvas element");
      }
    }
    exports.render = function render(qrData, canvas, options) {
      let opts = options;
      let canvasEl = canvas;
      if (typeof opts === "undefined" && (!canvas || !canvas.getContext)) {
        opts = canvas;
        canvas = void 0;
      }
      if (!canvas) {
        canvasEl = getCanvasElement();
      }
      opts = Utils.getOptions(opts);
      const size = Utils.getImageWidth(qrData.modules.size, opts);
      const ctx = canvasEl.getContext("2d");
      const image = ctx.createImageData(size, size);
      Utils.qrToImageData(image.data, qrData, opts);
      clearCanvas(ctx, canvasEl, size);
      ctx.putImageData(image, 0, 0);
      return canvasEl;
    };
    exports.renderToDataURL = function renderToDataURL(qrData, canvas, options) {
      let opts = options;
      if (typeof opts === "undefined" && (!canvas || !canvas.getContext)) {
        opts = canvas;
        canvas = void 0;
      }
      if (!opts) opts = {};
      const canvasEl = exports.render(qrData, canvas, opts);
      const type = opts.type || "image/png";
      const rendererOpts = opts.rendererOpts || {};
      return canvasEl.toDataURL(type, rendererOpts.quality);
    };
  }
});

// ../../node_modules/qrcode/lib/renderer/svg-tag.js
var require_svg_tag = __commonJS({
  "../../node_modules/qrcode/lib/renderer/svg-tag.js"(exports) {
    var Utils = require_utils2();
    function getColorAttrib(color, attrib) {
      const alpha = color.a / 255;
      const str = attrib + '="' + color.hex + '"';
      return alpha < 1 ? str + " " + attrib + '-opacity="' + alpha.toFixed(2).slice(1) + '"' : str;
    }
    function svgCmd(cmd, x, y) {
      let str = cmd + x;
      if (typeof y !== "undefined") str += " " + y;
      return str;
    }
    function qrToPath(data, size, margin) {
      let path = "";
      let moveBy = 0;
      let newRow = false;
      let lineLength = 0;
      for (let i = 0; i < data.length; i++) {
        const col = Math.floor(i % size);
        const row = Math.floor(i / size);
        if (!col && !newRow) newRow = true;
        if (data[i]) {
          lineLength++;
          if (!(i > 0 && col > 0 && data[i - 1])) {
            path += newRow ? svgCmd("M", col + margin, 0.5 + row + margin) : svgCmd("m", moveBy, 0);
            moveBy = 0;
            newRow = false;
          }
          if (!(col + 1 < size && data[i + 1])) {
            path += svgCmd("h", lineLength);
            lineLength = 0;
          }
        } else {
          moveBy++;
        }
      }
      return path;
    }
    exports.render = function render(qrData, options, cb) {
      const opts = Utils.getOptions(options);
      const size = qrData.modules.size;
      const data = qrData.modules.data;
      const qrcodesize = size + opts.margin * 2;
      const bg = !opts.color.light.a ? "" : "<path " + getColorAttrib(opts.color.light, "fill") + ' d="M0 0h' + qrcodesize + "v" + qrcodesize + 'H0z"/>';
      const path = "<path " + getColorAttrib(opts.color.dark, "stroke") + ' d="' + qrToPath(data, size, opts.margin) + '"/>';
      const viewBox = 'viewBox="0 0 ' + qrcodesize + " " + qrcodesize + '"';
      const width = !opts.width ? "" : 'width="' + opts.width + '" height="' + opts.width + '" ';
      const svgTag = '<svg xmlns="http://www.w3.org/2000/svg" ' + width + viewBox + ' shape-rendering="crispEdges">' + bg + path + "</svg>\n";
      if (typeof cb === "function") {
        cb(null, svgTag);
      }
      return svgTag;
    };
  }
});

// ../../node_modules/qrcode/lib/browser.js
var require_browser = __commonJS({
  "../../node_modules/qrcode/lib/browser.js"(exports) {
    var canPromise = require_can_promise();
    var QRCode2 = require_qrcode();
    var CanvasRenderer = require_canvas();
    var SvgRenderer = require_svg_tag();
    function renderCanvas(renderFunc, canvas, text, opts, cb) {
      const args = [].slice.call(arguments, 1);
      const argsNum = args.length;
      const isLastArgCb = typeof args[argsNum - 1] === "function";
      if (!isLastArgCb && !canPromise()) {
        throw new Error("Callback required as last argument");
      }
      if (isLastArgCb) {
        if (argsNum < 2) {
          throw new Error("Too few arguments provided");
        }
        if (argsNum === 2) {
          cb = text;
          text = canvas;
          canvas = opts = void 0;
        } else if (argsNum === 3) {
          if (canvas.getContext && typeof cb === "undefined") {
            cb = opts;
            opts = void 0;
          } else {
            cb = opts;
            opts = text;
            text = canvas;
            canvas = void 0;
          }
        }
      } else {
        if (argsNum < 1) {
          throw new Error("Too few arguments provided");
        }
        if (argsNum === 1) {
          text = canvas;
          canvas = opts = void 0;
        } else if (argsNum === 2 && !canvas.getContext) {
          opts = text;
          text = canvas;
          canvas = void 0;
        }
        return new Promise(function(resolve, reject) {
          try {
            const data = QRCode2.create(text, opts);
            resolve(renderFunc(data, canvas, opts));
          } catch (e) {
            reject(e);
          }
        });
      }
      try {
        const data = QRCode2.create(text, opts);
        cb(null, renderFunc(data, canvas, opts));
      } catch (e) {
        cb(e);
      }
    }
    exports.create = QRCode2.create;
    exports.toCanvas = renderCanvas.bind(null, CanvasRenderer.render);
    exports.toDataURL = renderCanvas.bind(null, CanvasRenderer.renderToDataURL);
    exports.toString = renderCanvas.bind(null, function(data, _, opts) {
      return SvgRenderer.render(data, opts);
    });
  }
});

// ../../packages/form-mapping/src/portal-data/select-options.json
var select_options_default = {
  star_rat: {
    id: "star_rat",
    options: [
      {
        value: "1s",
        label: "One Star"
      },
      {
        value: "2s",
        label: "Two Star"
      },
      {
        value: "3s",
        label: "Three Star"
      },
      {
        value: "4s",
        label: "Four Star"
      },
      {
        value: "5s",
        label: "Five Star"
      },
      {
        value: "6s",
        label: "Others"
      }
    ]
  },
  u_secques: {
    id: "u_secques",
    options: [
      {
        value: "2",
        label: "What is the name of the hospital where you were born?"
      },
      {
        value: "4",
        label: "What is the name of the street where you grew up?"
      },
      {
        value: "3",
        label: "What is the name of your favorite book?"
      },
      {
        value: "1",
        label: "What is your favorite author?"
      },
      {
        value: "5",
        label: "where did you meet your spouse?"
      }
    ]
  },
  u_gender: {
    id: "u_gender",
    options: [
      {
        value: "M",
        label: "Male"
      },
      {
        value: "F",
        label: "Female"
      },
      {
        value: "X",
        label: "Transgender"
      }
    ]
  },
  u_nationality: {
    id: "u_nationality",
    options: [
      {
        value: "IND",
        label: "INDIA"
      },
      {
        value: "AFG",
        label: "AFGHANISTAN"
      },
      {
        value: "ALA",
        label: "ALAND ISLANDS"
      },
      {
        value: "ALB",
        label: "ALBANIA"
      },
      {
        value: "DZA",
        label: "ALGERIA"
      },
      {
        value: "ASM",
        label: "AMERICAN SAMOA"
      },
      {
        value: "AND",
        label: "ANDORRA"
      },
      {
        value: "AGO",
        label: "ANGOLA"
      },
      {
        value: "AIA",
        label: "ANGUILLA"
      },
      {
        value: "ATG",
        label: "ANTIGUA AND BARBUDA"
      },
      {
        value: "ARG",
        label: "ARGENTINA"
      },
      {
        value: "ARM",
        label: "ARMENIA"
      },
      {
        value: "ABW",
        label: "ARUBA"
      },
      {
        value: "AUS",
        label: "AUSTRALIA"
      },
      {
        value: "AUT",
        label: "AUSTRIA"
      },
      {
        value: "AZE",
        label: "AZERBAIJAN"
      },
      {
        value: "BHS",
        label: "BAHAMAS"
      },
      {
        value: "BHR",
        label: "BAHRAIN"
      },
      {
        value: "BGD",
        label: "BANGLADESH"
      },
      {
        value: "BRB",
        label: "BARBADOS"
      },
      {
        value: "BLR",
        label: "BELARUS"
      },
      {
        value: "BEL",
        label: "BELGIUM"
      },
      {
        value: "BLZ",
        label: "BELIZE"
      },
      {
        value: "BEN",
        label: "BENIN (DAHOMEY)"
      },
      {
        value: "BMU",
        label: "BERMUDA"
      },
      {
        value: "BTN",
        label: "BHUTAN"
      },
      {
        value: "BOL",
        label: "BOLIVIA"
      },
      {
        value: "BIH",
        label: "BOSNIA AND HERZEGOVINA"
      },
      {
        value: "BWA",
        label: "BOTSWANA"
      },
      {
        value: "BVT",
        label: "BOUVET ISLAND"
      },
      {
        value: "BRA",
        label: "BRAZIL"
      },
      {
        value: "IOT",
        label: "BRITISH INDIAN OCEAN TERRITORY"
      },
      {
        value: "BRN",
        label: "BRUNEI DARUSSALAM"
      },
      {
        value: "BGR",
        label: "BULGARIA"
      },
      {
        value: "BFA",
        label: "BURKINA FASO ( UPPER VOLTA)"
      },
      {
        value: "BDI",
        label: "BURUNDI"
      },
      {
        value: "KHM",
        label: "CAMBODIA (KAMPUCHEA)"
      },
      {
        value: "CMR",
        label: "CAMEROON"
      },
      {
        value: "CAN",
        label: "CANADA"
      },
      {
        value: "CPV",
        label: "CAPE VERDE ISLANDS"
      },
      {
        value: "XCC",
        label: "CARRIBEAN COMMUNITY"
      },
      {
        value: "CYM",
        label: "CAYMAN ISLANDS"
      },
      {
        value: "CAF",
        label: "CENTRAL AFRICAN REPUBLIC"
      },
      {
        value: "TCD",
        label: "CHAD"
      },
      {
        value: "CHL",
        label: "CHILE"
      },
      {
        value: "CHN",
        label: "CHINA"
      },
      {
        value: "CXR",
        label: "CHRISTMAS ISLANDS"
      },
      {
        value: "CCK",
        label: "COCOS (KEELING) ISLANDS"
      },
      {
        value: "COL",
        label: "COLOMBIA"
      },
      {
        value: "COM",
        label: "COMOROS"
      },
      {
        value: "COG",
        label: "CONGO"
      },
      {
        value: "COD",
        label: "CONGO, DEMOCRATIC REPUBLIC OF THE (ZAIRE)"
      },
      {
        value: "COK",
        label: "COOK ISLANDS"
      },
      {
        value: "CRI",
        label: "COSTA RICA"
      },
      {
        value: "CIV",
        label: "COTE DIVOIRE"
      },
      {
        value: "HRV",
        label: "CROATIA -REPUBLIC OF CROATIA"
      },
      {
        value: "CUB",
        label: "CUBA"
      },
      {
        value: "CYP",
        label: "CYPRUS"
      },
      {
        value: "CZE",
        label: "CZECH REPUBLIC"
      },
      {
        value: "DNK",
        label: "DENMARK"
      },
      {
        value: "DJI",
        label: "DJIBOUTI"
      },
      {
        value: "DMA",
        label: "DOMINICA"
      },
      {
        value: "DOM",
        label: "DOMINICAN REPUBLIC"
      },
      {
        value: "TLS",
        label: "EAST TIMOR, DEMOCRATIC REPUBLIC OF"
      },
      {
        value: "ECU",
        label: "ECUADOR"
      },
      {
        value: "EGY",
        label: "EGYPT"
      },
      {
        value: "SLV",
        label: "EL SALVADOR"
      },
      {
        value: "GNQ",
        label: "EQUITORIAL GUINEA"
      },
      {
        value: "ERI",
        label: "ERITREA"
      },
      {
        value: "EST",
        label: "ESTONIA"
      },
      {
        value: "ETH",
        label: "ETHIOPIA"
      },
      {
        value: "FLK",
        label: "FALKLAND ISLANDS (MALVINAS)"
      },
      {
        value: "FRO",
        label: "FAROE ISLANDS"
      },
      {
        value: "FJI",
        label: "FIJI"
      },
      {
        value: "FIN",
        label: "FINLAND"
      },
      {
        value: "FRA",
        label: "FRANCE"
      },
      {
        value: "FXX",
        label: "FRANCE METROPOLITAN"
      },
      {
        value: "GUF",
        label: "FRENCH GUIANA"
      },
      {
        value: "ATF",
        label: "FRENCH SOUTHERN TERRITORIES"
      },
      {
        value: "GAB",
        label: "GABON"
      },
      {
        value: "GMB",
        label: "GAMBIA"
      },
      {
        value: "GEO",
        label: "GEORGIA"
      },
      {
        value: "DEU",
        label: "GERMANY"
      },
      {
        value: "GHA",
        label: "GHANA"
      },
      {
        value: "GIB",
        label: "GIBRALTAR"
      },
      {
        value: "GRC",
        label: "GREECE"
      },
      {
        value: "GRL",
        label: "GREENLAND"
      },
      {
        value: "GRD",
        label: "GRENADA"
      },
      {
        value: "GLP",
        label: "GUADELOUPE"
      },
      {
        value: "GUM",
        label: "GUAM"
      },
      {
        value: "GTM",
        label: "GUATEMALA"
      },
      {
        value: "GGY",
        label: "GUERNSEY"
      },
      {
        value: "GIN",
        label: "GUINEA"
      },
      {
        value: "GNB",
        label: "GUINEA BISSAU"
      },
      {
        value: "GUY",
        label: "GUYANA"
      },
      {
        value: "HTI",
        label: "HAITI"
      },
      {
        value: "HMD",
        label: "HEARD AND MCDONALD ISLANDS"
      },
      {
        value: "VAT",
        label: "HOLY SEE (VATICAN CITY STATE)"
      },
      {
        value: "HND",
        label: "HONDURAS"
      },
      {
        value: "HKG",
        label: "HONG KONG"
      },
      {
        value: "HUN",
        label: "HUNGARY"
      },
      {
        value: "ISL",
        label: "ICELAND"
      },
      {
        value: "IDN",
        label: "INDONESIA"
      },
      {
        value: "IRN",
        label: "IRAN"
      },
      {
        value: "IRQ",
        label: "IRAQ"
      },
      {
        value: "IRL",
        label: "IRELAND"
      },
      {
        value: "IMN",
        label: "ISLE OF MAN"
      },
      {
        value: "ISR",
        label: "ISRAEL"
      },
      {
        value: "ITA",
        label: "ITALY"
      },
      {
        value: "JAM",
        label: "JAMAICA"
      },
      {
        value: "JPN",
        label: "JAPAN"
      },
      {
        value: "JEY",
        label: "JERSEY"
      },
      {
        value: "JOR",
        label: "JORDAN"
      },
      {
        value: "KAZ",
        label: "KAZAKHSTAN"
      },
      {
        value: "KEN",
        label: "KENYA"
      },
      {
        value: "SWZ",
        label: "KINGDOM OF ESWATINI"
      },
      {
        value: "KIR",
        label: "KIRIBATI"
      },
      {
        value: "PRK",
        label: "KOREA, DEMOCRATIC PEOPLES REPUBLIC OF"
      },
      {
        value: "KOR",
        label: "KOREA, REPUBLIC OF"
      },
      {
        value: "KWT",
        label: "KUWAIT"
      },
      {
        value: "KGZ",
        label: "KYRGYZSTAN"
      },
      {
        value: "LAO",
        label: "LAOS"
      },
      {
        value: "LVA",
        label: "LATVIA"
      },
      {
        value: "LBN",
        label: "LEBANON"
      },
      {
        value: "LSO",
        label: "LESOTHO"
      },
      {
        value: "LBR",
        label: "LIBERIA"
      },
      {
        value: "LBY",
        label: "LIBYA"
      },
      {
        value: "LIE",
        label: "LIECHTENSTEIN"
      },
      {
        value: "LTU",
        label: "LITHUANIA"
      },
      {
        value: "LUX",
        label: "LUXEMBOURG"
      },
      {
        value: "MAC",
        label: "MACAU"
      },
      {
        value: "MDG",
        label: "MADAGASCAR"
      },
      {
        value: "MWI",
        label: "MALAWI"
      },
      {
        value: "MYS",
        label: "MALAYSIA"
      },
      {
        value: "MDV",
        label: "MALDIVES"
      },
      {
        value: "MLI",
        label: "MALI"
      },
      {
        value: "MLT",
        label: "MALTA"
      },
      {
        value: "MHL",
        label: "MARSHALL ISLANDS"
      },
      {
        value: "MTQ",
        label: "MARTINIQUE"
      },
      {
        value: "MRT",
        label: "MAURITANIA"
      },
      {
        value: "MUS",
        label: "MAURITIUS"
      },
      {
        value: "MYT",
        label: "MAYOTTE"
      },
      {
        value: "MEX",
        label: "MEXICO"
      },
      {
        value: "FSM",
        label: "MICRONESIA, FEDERATED STATES OF"
      },
      {
        value: "MDA",
        label: "MOLDOVA, REPUBLIC OF"
      },
      {
        value: "MCO",
        label: "MONACO"
      },
      {
        value: "MNG",
        label: "MONGOLIA"
      },
      {
        value: "MNE",
        label: "MONTENEGRO"
      },
      {
        value: "MSR",
        label: "MONTSERRAT"
      },
      {
        value: "MAR",
        label: "MOROCCO"
      },
      {
        value: "MOZ",
        label: "MOZAMBIQUE"
      },
      {
        value: "MMR",
        label: "MYANMAR (BURMA)"
      },
      {
        value: "NAM",
        label: "NAMIBIA"
      },
      {
        value: "NRU",
        label: "NAURU"
      },
      {
        value: "NPL",
        label: "NEPAL"
      },
      {
        value: "NLD",
        label: "NETHERLANDS"
      },
      {
        value: "ANT",
        label: "NETHERLANDS ANTILLES"
      },
      {
        value: "NTZ",
        label: "NEUTRAL ZONE"
      },
      {
        value: "NCL",
        label: "NEW CALEDONIA"
      },
      {
        value: "NZL",
        label: "NEW ZEALAND"
      },
      {
        value: "NIC",
        label: "NICARAGUA"
      },
      {
        value: "NER",
        label: "NIGER"
      },
      {
        value: "NGA",
        label: "NIGERIA"
      },
      {
        value: "NIU",
        label: "NIUE"
      },
      {
        value: "NFK",
        label: "NORFOLK ISLAND"
      },
      {
        value: "MNP",
        label: "NORTHERN MARIANA ISLANDS"
      },
      {
        value: "NOR",
        label: "NORWAY"
      },
      {
        value: "OMN",
        label: "OMAN"
      },
      {
        value: "PAK",
        label: "PAKISTAN"
      },
      {
        value: "PLW",
        label: "PALAU"
      },
      {
        value: "PSE",
        label: "PALESTINE"
      },
      {
        value: "PAN",
        label: "PANAMA"
      },
      {
        value: "PNG",
        label: "PAPUA NEW GUINEA"
      },
      {
        value: "PRY",
        label: "PARAGUAY"
      },
      {
        value: "XXX",
        label: "PERSON OF UNSPECIFIED NATIONALITY"
      },
      {
        value: "PER",
        label: "PERU"
      },
      {
        value: "PHL",
        label: "PHILIPPINES"
      },
      {
        value: "PCN",
        label: "PITCAIRN"
      },
      {
        value: "POL",
        label: "POLAND"
      },
      {
        value: "PRT",
        label: "PORTUGAL"
      },
      {
        value: "PRI",
        label: "PUERTO RICO"
      },
      {
        value: "QAT",
        label: "QATAR"
      },
      {
        value: "XXB",
        label: "REFUGEE"
      },
      {
        value: "XXC",
        label: "REFUGEE (NON-CONVENTIONAL) OTHER THAN XXB"
      },
      {
        value: "MKD",
        label: "REPUBLIC OF NORTH MACEDONIA"
      },
      {
        value: "UNK",
        label: "RESIDENT OF KOSOVO (UNMIK)"
      },
      {
        value: "REU",
        label: "REUNION ISLANDS"
      },
      {
        value: "ROU",
        label: "ROMANIA"
      },
      {
        value: "RUS",
        label: "RUSSIAN FEDERATION"
      },
      {
        value: "RWA",
        label: "RWANDA"
      },
      {
        value: "BLM",
        label: "SAINT BARTHELEMY"
      },
      {
        value: "SHN",
        label: "SAINT HELENA, ASCENSION AND TRISTAN DA CUNHA"
      },
      {
        value: "KNA",
        label: "SAINT KITTS AND NEVIS"
      },
      {
        value: "LCA",
        label: "SAINT LUCIA"
      },
      {
        value: "SPM",
        label: "SAINT PIERRE AND MIQUELON"
      },
      {
        value: "VCT",
        label: "SAINT VINCENT AND THE GRENADINES"
      },
      {
        value: "WSM",
        label: "SAMOA"
      },
      {
        value: "SMR",
        label: "SAN MARINO"
      },
      {
        value: "STP",
        label: "SAO TOME AND PRINCIPE"
      },
      {
        value: "SAU",
        label: "SAUDI ARABIA"
      },
      {
        value: "SEN",
        label: "SENEGAL"
      },
      {
        value: "SRB",
        label: "SERBIA"
      },
      {
        value: "SYC",
        label: "SEYCHELLES"
      },
      {
        value: "SLE",
        label: "SIERRA LEONE"
      },
      {
        value: "SGP",
        label: "SINGAPORE"
      },
      {
        value: "SVK",
        label: "SLOVAK REPUBLIC"
      },
      {
        value: "SVN",
        label: "SLOVENIA"
      },
      {
        value: "SLB",
        label: "SOLOMON ISLANDS"
      },
      {
        value: "SOM",
        label: "SOMALIA"
      },
      {
        value: "ZAF",
        label: "SOUTH AFRICA"
      },
      {
        value: "SGS",
        label: "SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS"
      },
      {
        value: "SSD",
        label: "SOUTH SUDAN"
      },
      {
        value: "XOM",
        label: "SOVEREIGN MILITARY ORDER OF MALTA"
      },
      {
        value: "ESP",
        label: "SPAIN"
      },
      {
        value: "LKA",
        label: "SRI LANKA"
      },
      {
        value: "XXA",
        label: "STATELESS PERSON"
      },
      {
        value: "SDN",
        label: "SUDAN"
      },
      {
        value: "SUR",
        label: "SURINAME"
      },
      {
        value: "SJM",
        label: "SVALBARD AND JAN MAYEN ISLANDS"
      },
      {
        value: "SWE",
        label: "SWEDEN"
      },
      {
        value: "CHE",
        label: "SWITZERLAND"
      },
      {
        value: "SYR",
        label: "SYRIA"
      },
      {
        value: "TWN",
        label: "TAIWAN"
      },
      {
        value: "TJK",
        label: "TAJIKISTAN"
      },
      {
        value: "TZA",
        label: "TANZANIA"
      },
      {
        value: "THA",
        label: "THAILAND"
      },
      {
        value: "TBT",
        label: "TIBETAN ORIGIN"
      },
      {
        value: "TGO",
        label: "TOGO"
      },
      {
        value: "TKL",
        label: "TOKELAU"
      },
      {
        value: "TON",
        label: "TONGA"
      },
      {
        value: "TTO",
        label: "TRINIDAD AND TOBAGO"
      },
      {
        value: "TUN",
        label: "TUNISIA"
      },
      {
        value: "TUR",
        label: "TURKEY"
      },
      {
        value: "TKM",
        label: "TURKMENISTAN"
      },
      {
        value: "TCA",
        label: "TURKS AND CAICOS ISLANDS"
      },
      {
        value: "TUV",
        label: "TUVALU"
      },
      {
        value: "UGA",
        label: "UGANDA"
      },
      {
        value: "GBD",
        label: "UK BRITISH DEPENDENT TERRITORIES CITIZEN"
      },
      {
        value: "GBO",
        label: "UK BRITISH OVERSEAS CITIZEN"
      },
      {
        value: "GBN",
        label: "UK BRITISH OVERSEAS NATIONAL"
      },
      {
        value: "GBP",
        label: "UK BRITISH PROTECTED PERSON"
      },
      {
        value: "GBS",
        label: "UK BRITISH SUBJECT"
      },
      {
        value: "UKR",
        label: "UKRAINE"
      },
      {
        value: "ARE",
        label: "UNITED ARAB EMIRATES"
      },
      {
        value: "GBR",
        label: "UNITED KINGDOM"
      },
      {
        value: "UNO",
        label: "UNITED NATIONS ORGANIZATION"
      },
      {
        value: "UNA",
        label: "UNITED NATIONS SPECIALIZED AGENCY"
      },
      {
        value: "UMI",
        label: "UNITED STATES MINOR OUTLYING ISLANDS"
      },
      {
        value: "USA",
        label: "UNITED STATES OF AMERICA"
      },
      {
        value: "URY",
        label: "URUGUAY"
      },
      {
        value: "UZB",
        label: "UZBEKISTAN"
      },
      {
        value: "VUT",
        label: "VANUATU (NEW HEBRIDES)"
      },
      {
        value: "VEN",
        label: "VENEZUELA"
      },
      {
        value: "VNM",
        label: "VIETNAM"
      },
      {
        value: "VGB",
        label: "VIRGIN ISLANDS (BRITISH)"
      },
      {
        value: "VIR",
        label: "VIRGIN ISLANDS (US)"
      },
      {
        value: "WLF",
        label: "WALLIS AND FUTUNA ISLANDS"
      },
      {
        value: "ESH",
        label: "WESTERN SAHARA"
      },
      {
        value: "YEM",
        label: "YEMEN"
      },
      {
        value: "YUG",
        label: "YUGOSLAVIA"
      },
      {
        value: "ZMB",
        label: "ZAMBIA"
      },
      {
        value: "ZWE",
        label: "ZIMBABWE"
      }
    ]
  },
  state: {
    id: "state",
    options: [
      {
        value: "1",
        label: "ANDAMAN AND NICOBAR ISLANDS"
      },
      {
        value: "2",
        label: "ANDHRA PRADESH"
      },
      {
        value: "3",
        label: "ARUNACHAL PRADESH"
      },
      {
        value: "4",
        label: "ASSAM"
      },
      {
        value: "5",
        label: "BIHAR"
      },
      {
        value: "34",
        label: "CHANDIGARH"
      },
      {
        value: "6",
        label: "CHHATTISGARH"
      },
      {
        value: "39",
        label: "DADRA AND NAGAR HAVELI AND DAMAN AND DIU"
      },
      {
        value: "8",
        label: "DELHI"
      },
      {
        value: "9",
        label: "GOA"
      },
      {
        value: "10",
        label: "GUJARAT"
      },
      {
        value: "11",
        label: "HARYANA"
      },
      {
        value: "12",
        label: "HIMACHAL PRADESH"
      },
      {
        value: "13",
        label: "JAMMU AND KASHMIR"
      },
      {
        value: "14",
        label: "JHARKHAND"
      },
      {
        value: "15",
        label: "KARNATAKA"
      },
      {
        value: "16",
        label: "KERALA"
      },
      {
        value: "38",
        label: "LADAKH"
      },
      {
        value: "36",
        label: "LAKSHADWEEP"
      },
      {
        value: "17",
        label: "MADHYA PRADESH"
      },
      {
        value: "18",
        label: "MAHARASHTRA"
      },
      {
        value: "19",
        label: "MANIPUR"
      },
      {
        value: "20",
        label: "MEGHALAYA"
      },
      {
        value: "21",
        label: "MIZORAM"
      },
      {
        value: "22",
        label: "NAGALAND"
      },
      {
        value: "23",
        label: "ODISHA"
      },
      {
        value: "24",
        label: "PUDUCHERRY"
      },
      {
        value: "25",
        label: "PUNJAB"
      },
      {
        value: "26",
        label: "RAJASTHAN"
      },
      {
        value: "27",
        label: "SIKKIM"
      },
      {
        value: "28",
        label: "TAMIL NADU"
      },
      {
        value: "37",
        label: "TELANGANA"
      },
      {
        value: "29",
        label: "TRIPURA"
      },
      {
        value: "31",
        label: "UTTARAKHAND"
      },
      {
        value: "30",
        label: "UTTAR PRADESH"
      },
      {
        value: "32",
        label: "WEST BENGAL"
      }
    ]
  },
  acco_type: {
    id: "acco_type",
    options: [
      {
        value: "BB",
        label: "Bed and Breakfast"
      },
      {
        value: "D",
        label: "Dharmshala"
      },
      {
        value: "GH",
        label: "Guest House"
      },
      {
        value: "H",
        label: "Hotel"
      },
      {
        value: "IH",
        label: "Individual House"
      },
      {
        value: "I",
        label: "Institute"
      },
      {
        value: "O",
        label: "Others"
      },
      {
        value: "S",
        label: "Service Apartment"
      }
    ]
  },
  state_o: {
    id: "state_o",
    options: [
      {
        value: "1",
        label: "ANDAMAN AND NICOBAR ISLANDS"
      },
      {
        value: "2",
        label: "ANDHRA PRADESH"
      },
      {
        value: "3",
        label: "ARUNACHAL PRADESH"
      },
      {
        value: "4",
        label: "ASSAM"
      },
      {
        value: "5",
        label: "BIHAR"
      },
      {
        value: "34",
        label: "CHANDIGARH"
      },
      {
        value: "6",
        label: "CHHATTISGARH"
      },
      {
        value: "39",
        label: "DADRA AND NAGAR HAVELI AND DAMAN AND DIU"
      },
      {
        value: "8",
        label: "DELHI"
      },
      {
        value: "9",
        label: "GOA"
      },
      {
        value: "10",
        label: "GUJARAT"
      },
      {
        value: "11",
        label: "HARYANA"
      },
      {
        value: "12",
        label: "HIMACHAL PRADESH"
      },
      {
        value: "13",
        label: "JAMMU AND KASHMIR"
      },
      {
        value: "14",
        label: "JHARKHAND"
      },
      {
        value: "15",
        label: "KARNATAKA"
      },
      {
        value: "16",
        label: "KERALA"
      },
      {
        value: "38",
        label: "LADAKH"
      },
      {
        value: "36",
        label: "LAKSHADWEEP"
      },
      {
        value: "17",
        label: "MADHYA PRADESH"
      },
      {
        value: "18",
        label: "MAHARASHTRA"
      },
      {
        value: "19",
        label: "MANIPUR"
      },
      {
        value: "20",
        label: "MEGHALAYA"
      },
      {
        value: "21",
        label: "MIZORAM"
      },
      {
        value: "22",
        label: "NAGALAND"
      },
      {
        value: "23",
        label: "ODISHA"
      },
      {
        value: "24",
        label: "PUDUCHERRY"
      },
      {
        value: "25",
        label: "PUNJAB"
      },
      {
        value: "26",
        label: "RAJASTHAN"
      },
      {
        value: "27",
        label: "SIKKIM"
      },
      {
        value: "28",
        label: "TAMIL NADU"
      },
      {
        value: "37",
        label: "TELANGANA"
      },
      {
        value: "29",
        label: "TRIPURA"
      },
      {
        value: "31",
        label: "UTTARAKHAND"
      },
      {
        value: "30",
        label: "UTTAR PRADESH"
      },
      {
        value: "32",
        label: "WEST BENGAL"
      }
    ]
  }
};

// ../../packages/form-mapping/src/portal-data/formc-select-options.json
var formc_select_options_default = {
  source: "Live FRRO portal formc.jsp extraction (2026-07-19)",
  specialCategory: {
    fieldName: "applicant_special_category",
    options: [
      { value: "13", label: "Born in India" },
      { value: "3", label: "Crew" },
      { value: "7", label: "Diplomat Exempted" },
      { value: "4", label: "Emergency Transit" },
      { value: "14", label: "Indian Origin" },
      { value: "12", label: "Loss of Passport" },
      { value: "10", label: "OCI" },
      { value: "6", label: "Official Exempted" },
      { value: "8", label: "Other Exempted" },
      { value: "9", label: "Others" },
      { value: "11", label: "PIO" },
      { value: "2", label: "Refugee" },
      { value: "5", label: "TLP" }
    ]
  },
  visaType: {
    fieldName: "applicant_visatype",
    onchange: "visaTypeModalClose(),showvisasubtype(this.value,'ptype',document.OnlineForm.applicant_visa_subtype_code.value,document.OnlineForm.applicant_visa_subtype_code);",
    options: [
      { value: "161", label: "AYUSH VISA" },
      { value: "1", label: "BUSINESS VISA" },
      { value: "2", label: "CONFERENCE VISA" },
      { value: "91", label: "DIPLOMATIC DEPENDENT VISA" },
      { value: "3", label: "DIPLOMATIC VISA" },
      {
        value: "97",
        label: "DOUBLE ENTRY VISA (ONLY FOR BANGLADESH NATIONALS)"
      },
      { value: "37", label: "e-Emergency X-Misc Visa" },
      { value: "44", label: "e-Entry Visa" },
      { value: "50", label: "e-Family Visa" },
      { value: "45", label: "e-Film Visa" },
      { value: "51", label: "e-Miscellaneous Visa" },
      { value: "46", label: "e-Mountaineering Visa" },
      { value: "4", label: "EMPLOYMENT VISA" },
      { value: "94", label: "ENTRY VISA" },
      { value: "48", label: "e-PRODUCTION INVESTMENT VISA" },
      { value: "42", label: "e-Student Visa" },
      { value: "43", label: "e-Student X Visa" },
      { value: "47", label: "e-Transit Visa" },
      { value: "98", label: "e-VISA" },
      { value: "52", label: "FAMILY VISA" },
      { value: "28", label: "FILMS VISA" },
      { value: "6", label: "JOURNALIST VISA" },
      { value: "7", label: "LONG TERM VISA" },
      { value: "92", label: "MEDICAL VISA" },
      { value: "54", label: "MISCELLANEOUS VISA" },
      { value: "10", label: "MISC SP PERMISSION" },
      { value: "11", label: "MISSIONARY VISA" },
      { value: "93", label: "MOUNTAINEERING VISA" },
      { value: "22", label: "OCI" },
      { value: "90", label: "OFFICIAL DEPENDENT VISA" },
      { value: "12", label: "OFFICIAL VISA" },
      { value: "53", label: "PAKISTAN SPECIFIC VISAS" },
      { value: "13", label: "PIO CARD HOLDER" },
      { value: "96", label: "PLIGRIM VISA(ONLY FOR PAKISTAN NATIONALS)" },
      { value: "16", label: "STUDENT VISA" },
      { value: "24", label: "TEMPORARY LANDING PERMIT" },
      { value: "17", label: "TOURIST VISA" },
      { value: "57", label: "TOURIST VISA FIVE YEARS" },
      { value: "56", label: "TOURIST VISA ONE MONTH" },
      { value: "18", label: "TRANSIT VISA" },
      { value: "33", label: "UN DIPLOMAT VISA" },
      { value: "19", label: "UNITED NATION" },
      { value: "34", label: "UN OFFICIAL VISA" },
      { value: "99", label: "VISA-ON-ARRIVAL" },
      { value: "95", label: "VISITOR VISA(ONLY FOR PAKISTAN NATIONALS)" },
      { value: "55", label: "WORK VISA" }
    ]
  },
  purposeOfVisit: {
    fieldName: "applicant_purpovisit",
    options: [
      { value: "18", label: "Accompanying Parents" },
      { value: "9", label: "Accompanying Patient" },
      { value: "10", label: "Accompanying Patient as Doctor" },
      { value: "17", label: "Accompanying Spouse" },
      { value: "6", label: "Business" },
      { value: "12", label: "Diplomatic" },
      { value: "5", label: "Education" },
      { value: "13", label: "Employment" },
      { value: "19", label: "Internship" },
      { value: "2", label: "Joining spouse" },
      { value: "7", label: "Journalism" },
      { value: "8", label: "Medical Treatment of self" },
      { value: "1", label: "Meeting friends/relatives" },
      { value: "3", label: "Minor child(either parent is Indian)" },
      { value: "11", label: "Official" },
      { value: "15", label: "Others" },
      { value: "4", label: "Seminar/conference in India" },
      { value: "14", label: "Studies" },
      { value: "20", label: "Surrogacy" },
      { value: "16", label: "Tourism" }
    ]
  },
  dobFormat: {
    fieldName: "dobformat",
    fieldId: "",
    onchange: "document.OnlineForm.applicant_dob.value='';document.OnlineForm.applicant_age.value=''",
    options: [
      { value: "DY", label: "Date of birth in DD/MM/YYYY" },
      { value: "YY", label: "Year of birth in YYYY" },
      { value: "MY", label: "Month & Year of birth in MM/YYYY" },
      { value: "AG", label: "Age in XXX years" }
    ]
  },
  sex: {
    fieldName: "applicant_sex",
    options: [
      { value: "M", label: "Male" },
      { value: "F", label: "Female" },
      { value: "X", label: "Transgender" }
    ]
  }
};

// ../../packages/form-mapping/src/portal-data/state-cities.json
var state_cities_default = {
  "1": {
    stateName: "ANDAMAN AND NICOBAR ISLANDS",
    cities: [
      {
        value: "2D",
        label: "NICOBAR"
      },
      {
        value: "3D",
        label: "NORTH AND MIDDLE ANDAMAN"
      },
      {
        value: "1D",
        label: "SOUTH ANDAMAN"
      }
    ]
  },
  "2": {
    stateName: "ANDHRA PRADESH",
    cities: [
      {
        value: "8D",
        label: "ALLURI SEETHA RAMA RAJU"
      },
      {
        value: "2D",
        label: "ANANTHAPURAMU"
      },
      {
        value: "29D",
        label: "ANNAMAYYA"
      },
      {
        value: "25D",
        label: "BAPATLA"
      },
      {
        value: "3D",
        label: "CHITTOOR"
      },
      {
        value: "5D",
        label: "EAST GODAVARI"
      },
      {
        value: "31D",
        label: "ELURU"
      },
      {
        value: "6D",
        label: "GUNTUR"
      },
      {
        value: "24D",
        label: "KONASEEMA"
      },
      {
        value: "10D",
        label: "KRISHNA"
      },
      {
        value: "11D",
        label: "KURNOOL"
      },
      {
        value: "27D",
        label: "NANDYAL"
      },
      {
        value: "15D",
        label: "NELLORE"
      },
      {
        value: "30D",
        label: "PARVATHIPURAM MANYAM"
      },
      {
        value: "17D",
        label: "PRAKASAM"
      },
      {
        value: "19D",
        label: "SRIKAKULAM"
      },
      {
        value: "28D",
        label: "SRI SATYA SAI"
      },
      {
        value: "32D",
        label: "TIRUPATI"
      },
      {
        value: "13C",
        label: "VIJAYWADA"
      },
      {
        value: "20D",
        label: "VISAKHAPATNAM"
      },
      {
        value: "21D",
        label: "VIZIANAGARAM"
      },
      {
        value: "23D",
        label: "WEST GODAVARI"
      },
      {
        value: "4D",
        label: "YSR DISTRICT KADAPA"
      }
    ]
  },
  "3": {
    stateName: "ARUNACHAL PRADESH",
    cities: [
      {
        value: "22D",
        label: "ANJAW"
      },
      {
        value: "1D",
        label: "CHANGLANG"
      },
      {
        value: "2D",
        label: "DIBANG VALLEY"
      },
      {
        value: "3D",
        label: "EAST KAMENG"
      },
      {
        value: "4D",
        label: "EAST SIANG"
      },
      {
        value: "16D",
        label: "KAMLE"
      },
      {
        value: "25D",
        label: "KEYI PANYOR"
      },
      {
        value: "19D",
        label: "KRA DAADI"
      },
      {
        value: "5D",
        label: "KURUNG KUMEY"
      },
      {
        value: "23D",
        label: "LEPA RADA"
      },
      {
        value: "6D",
        label: "LOHIT"
      },
      {
        value: "20D",
        label: "LONGDING"
      },
      {
        value: "7D",
        label: "LOWER DIBANG VALLEY"
      },
      {
        value: "8D",
        label: "LOWER SIANG"
      },
      {
        value: "79D",
        label: "LOWER SUBANSIRI"
      },
      {
        value: "21D",
        label: "NAMSAI"
      },
      {
        value: "24D",
        label: "PAKKE KESSANG"
      },
      {
        value: "9D",
        label: "PAPUM PARE"
      },
      {
        value: "18D",
        label: "SHI YOMI"
      },
      {
        value: "17D",
        label: "SIANG"
      },
      {
        value: "10D",
        label: "TAWANG"
      },
      {
        value: "11D",
        label: "TIRAP"
      },
      {
        value: "12D",
        label: "UPPER SIANG"
      },
      {
        value: "13D",
        label: "UPPER SUBANSIRI"
      },
      {
        value: "14D",
        label: "WEST KAMENG"
      },
      {
        value: "15D",
        label: "WEST SIANG"
      }
    ]
  },
  "4": {
    stateName: "ASSAM",
    cities: [
      {
        value: "31D",
        label: "BAJALI"
      },
      {
        value: "4D",
        label: "BAKSA"
      },
      {
        value: "1D",
        label: "BARPETA"
      },
      {
        value: "28D",
        label: "BISWANATH"
      },
      {
        value: "2D",
        label: "BONGAIGAON"
      },
      {
        value: "3D",
        label: "CACHAR"
      },
      {
        value: "30D",
        label: "CHARAIDEO"
      },
      {
        value: "8D",
        label: "CHIRANG"
      },
      {
        value: "16D",
        label: "DARRANG"
      },
      {
        value: "5D",
        label: "DHEMAJI"
      },
      {
        value: "6D",
        label: "DHUBRI"
      },
      {
        value: "7D",
        label: "DIBRUGARH"
      },
      {
        value: "20D",
        label: "DIMA HASAO"
      },
      {
        value: "80D",
        label: "GOALPARA"
      },
      {
        value: "9D",
        label: "GOLAGHAT"
      },
      {
        value: "149D",
        label: "GUWAHATI"
      },
      {
        value: "10D",
        label: "HAILAKANDI"
      },
      {
        value: "25C",
        label: "HAMREN"
      },
      {
        value: "26D",
        label: "HOJAI"
      },
      {
        value: "11D",
        label: "JORHAT"
      },
      {
        value: "12D",
        label: "KAMRUP"
      },
      {
        value: "13D",
        label: "KARBI ANGLONG"
      },
      {
        value: "14D",
        label: "KARIMGANJ"
      },
      {
        value: "15D",
        label: "KOKRAJHAR"
      },
      {
        value: "81D",
        label: "LAKHIMPUR"
      },
      {
        value: "29D",
        label: "MAJULI"
      },
      {
        value: "17D",
        label: "MORIGAON"
      },
      {
        value: "18D",
        label: "NAGAON"
      },
      {
        value: "19D",
        label: "NALBARI"
      },
      {
        value: "25D",
        label: "SADIA"
      },
      {
        value: "21D",
        label: "SIVASAGAR"
      },
      {
        value: "22D",
        label: "SONITPUR"
      },
      {
        value: "27D",
        label: "SOUTH SALMARA"
      },
      {
        value: "32D",
        label: "TAMULPUR"
      },
      {
        value: "23D",
        label: "TINSUKIA"
      },
      {
        value: "24D",
        label: "UDALGURI"
      },
      {
        value: "33D",
        label: "WEST KARBI ANGLONG"
      }
    ]
  },
  "5": {
    stateName: "BIHAR",
    cities: [
      {
        value: "1D",
        label: "ARARIA"
      },
      {
        value: "4D",
        label: "ARWAL"
      },
      {
        value: "2D",
        label: "AURANGABAD"
      },
      {
        value: "3D",
        label: "BANKA"
      },
      {
        value: "142D",
        label: "BEGUSARAI"
      },
      {
        value: "5D",
        label: "BHAGALPUR"
      },
      {
        value: "6D",
        label: "BHOJPUR"
      },
      {
        value: "7D",
        label: "BUXAR"
      },
      {
        value: "77D",
        label: "DARBHANGA"
      },
      {
        value: "9D",
        label: "EAST CHAMPARAN"
      },
      {
        value: "10D",
        label: "GAYA"
      },
      {
        value: "11D",
        label: "GOPALGANJ"
      },
      {
        value: "12D",
        label: "JAMUI"
      },
      {
        value: "13D",
        label: "JEHANABAD"
      },
      {
        value: "14D",
        label: "KAIMUR"
      },
      {
        value: "15D",
        label: "KATIHAR"
      },
      {
        value: "8D",
        label: "KHAGARIA"
      },
      {
        value: "17D",
        label: "KISHANGANJ"
      },
      {
        value: "18D",
        label: "LAKHISARAI"
      },
      {
        value: "19D",
        label: "MADHEPURA"
      },
      {
        value: "20D",
        label: "MADHUBANI"
      },
      {
        value: "21D",
        label: "MUNGER"
      },
      {
        value: "22D",
        label: "MUZAFFARPUR"
      },
      {
        value: "23D",
        label: "NALANDA"
      },
      {
        value: "24D",
        label: "NAWADA"
      },
      {
        value: "25D",
        label: "PATNA"
      },
      {
        value: "26D",
        label: "PURNIA"
      },
      {
        value: "27D",
        label: "ROHTAS"
      },
      {
        value: "28D",
        label: "SAHARSA"
      },
      {
        value: "29D",
        label: "SAMASTIPUR"
      },
      {
        value: "30D",
        label: "SARAN"
      },
      {
        value: "31D",
        label: "SHEIKHPURA"
      },
      {
        value: "16D",
        label: "SHEOHAR"
      },
      {
        value: "33D",
        label: "SITAMARHI"
      },
      {
        value: "34D",
        label: "SIWAN"
      },
      {
        value: "35D",
        label: "SUPAUL"
      },
      {
        value: "36D",
        label: "VAISHALI"
      },
      {
        value: "37D",
        label: "WEST CHAMPARAN"
      }
    ]
  },
  "34": {
    stateName: "CHANDIGARH",
    cities: [
      {
        value: "71D",
        label: "CHANDIGARH"
      }
    ]
  },
  "6": {
    stateName: "CHHATTISGARH",
    cities: [
      {
        value: "4D",
        label: "BALOD"
      },
      {
        value: "8D",
        label: "BALODA BAZAR"
      },
      {
        value: "16D",
        label: "BALRAMPUR"
      },
      {
        value: "1D",
        label: "BASTAR"
      },
      {
        value: "18D",
        label: "BEMETARA"
      },
      {
        value: "19D",
        label: "BIJAPUR"
      },
      {
        value: "2D",
        label: "BILASPUR"
      },
      {
        value: "3D",
        label: "DANTEWADA"
      },
      {
        value: "17D",
        label: "DHAMTARI"
      },
      {
        value: "5D",
        label: "DURG"
      },
      {
        value: "20D",
        label: "GARIABAND"
      },
      {
        value: "26D",
        label: "Gaurella-Pendra-Marwahi"
      },
      {
        value: "6D",
        label: "JANJGIR-CHAMPA"
      },
      {
        value: "7D",
        label: "JASHPUR"
      },
      {
        value: "9D",
        label: "KABIRDHAM"
      },
      {
        value: "82D",
        label: "KANKER"
      },
      {
        value: "28D",
        label: "KHAIRAGARH-CHHUIKHADAN-GANDAI"
      },
      {
        value: "21D",
        label: "KONDAGAON"
      },
      {
        value: "10D",
        label: "KORBA"
      },
      {
        value: "11D",
        label: "KOREA"
      },
      {
        value: "12D",
        label: "MAHASAMUND"
      },
      {
        value: "30D",
        label: "Manendragarh-Chirmiri-Bharatpur"
      },
      {
        value: "27D",
        label: "Mohla-Manpur-Ambagarh Chowki"
      },
      {
        value: "22D",
        label: "MUNGELI"
      },
      {
        value: "23D",
        label: "NARAYANPUR"
      },
      {
        value: "13D",
        label: "RAIGARH"
      },
      {
        value: "14D",
        label: "RAIPUR"
      },
      {
        value: "15D",
        label: "RAJNANDGAON"
      },
      {
        value: "29D",
        label: "SAKTI"
      },
      {
        value: "31D",
        label: "Sarangarh-Bilaigarh"
      },
      {
        value: "24D",
        label: "SUKMA"
      },
      {
        value: "25D",
        label: "SURAJPUR"
      },
      {
        value: "83D",
        label: "SURGUJA"
      }
    ]
  },
  "39": {
    stateName: "DADRA AND NAGAR HAVELI AND DAMAN AND DIU",
    cities: [
      {
        value: "3D",
        label: "DADRA NAGAR HAVELI"
      },
      {
        value: "1D",
        label: "DAMAN"
      },
      {
        value: "2D",
        label: "DIU"
      }
    ]
  },
  "8": {
    stateName: "DELHI",
    cities: [
      {
        value: "1C",
        label: "DELHI"
      }
    ]
  },
  "9": {
    stateName: "GOA",
    cities: [
      {
        value: "15C",
        label: "GOA"
      }
    ]
  },
  "10": {
    stateName: "GUJARAT",
    cities: [
      {
        value: "1D",
        label: "AHMEDABAD"
      },
      {
        value: "2D",
        label: "AMRELI"
      },
      {
        value: "3D",
        label: "ANAND"
      },
      {
        value: "8D",
        label: "ARAVALLI"
      },
      {
        value: "27D",
        label: "BANASKANTHA"
      },
      {
        value: "6D",
        label: "BHARUCH"
      },
      {
        value: "7D",
        label: "BHAVNAGAR"
      },
      {
        value: "16D",
        label: "BOTAD"
      },
      {
        value: "29D",
        label: "CHHOTA UDEPUR"
      },
      {
        value: "84D",
        label: "DAHOD"
      },
      {
        value: "30D",
        label: "DEVBHOOMI DWARKA"
      },
      {
        value: "31D",
        label: "GIR SOMNATH"
      },
      {
        value: "10D",
        label: "JAMNAGAR"
      },
      {
        value: "11D",
        label: "JUNAGADH"
      },
      {
        value: "13D",
        label: "KHEDA"
      },
      {
        value: "12D",
        label: "KUTCH"
      },
      {
        value: "32D",
        label: "MAHISAGAR"
      },
      {
        value: "14D",
        label: "MEHSANA"
      },
      {
        value: "33D",
        label: "MORBI"
      },
      {
        value: "15D",
        label: "NARMADA"
      },
      {
        value: "145D",
        label: "NAVSARI"
      },
      {
        value: "17D",
        label: "PANCHMAHAL"
      },
      {
        value: "18D",
        label: "PATAN"
      },
      {
        value: "19D",
        label: "PORBANDAR"
      },
      {
        value: "20D",
        label: "RAJKOT"
      },
      {
        value: "21D",
        label: "SABARKANTHA"
      },
      {
        value: "22D",
        label: "SURAT"
      },
      {
        value: "23D",
        label: "SURENDRANAGAR"
      },
      {
        value: "4D",
        label: "TAPI"
      },
      {
        value: "24D",
        label: "THE DANGS"
      },
      {
        value: "25D",
        label: "VADODARA"
      },
      {
        value: "26D",
        label: "VALSAD"
      },
      {
        value: "34D",
        label: "VAV THARAD"
      }
    ]
  },
  "11": {
    stateName: "HARYANA",
    cities: [
      {
        value: "1D",
        label: "AMBALA"
      },
      {
        value: "2D",
        label: "BHIWANI"
      },
      {
        value: "16D",
        label: "CHARKHI DADRI"
      },
      {
        value: "3D",
        label: "FARIDABAD"
      },
      {
        value: "87D",
        label: "FATEHABAD"
      },
      {
        value: "5D",
        label: "GURGAON"
      },
      {
        value: "6D",
        label: "HISAR"
      },
      {
        value: "7D",
        label: "JHAJJAR"
      },
      {
        value: "88D",
        label: "JIND"
      },
      {
        value: "9D",
        label: "KAITHAL"
      },
      {
        value: "10D",
        label: "KARNAL"
      },
      {
        value: "11D",
        label: "KURUKSHETRA"
      },
      {
        value: "12D",
        label: "MAHENDRAGARH"
      },
      {
        value: "4D",
        label: "MEWAT"
      },
      {
        value: "8D",
        label: "PALWAL"
      },
      {
        value: "13D",
        label: "PANCHKULA"
      },
      {
        value: "14D",
        label: "PANIPAT"
      },
      {
        value: "15D",
        label: "REWARI"
      },
      {
        value: "89D",
        label: "ROHTAK"
      },
      {
        value: "17D",
        label: "SIRSA"
      },
      {
        value: "18D",
        label: "SONIPAT"
      },
      {
        value: "19D",
        label: "YAMUNANAGAR"
      }
    ]
  },
  "12": {
    stateName: "HIMACHAL PRADESH",
    cities: [
      {
        value: "1D",
        label: "BILASPUR"
      },
      {
        value: "2D",
        label: "CHAMBA"
      },
      {
        value: "3D",
        label: "HAMIRPUR"
      },
      {
        value: "85D",
        label: "KANGRA"
      },
      {
        value: "5D",
        label: "KINNAUR"
      },
      {
        value: "6D",
        label: "KULLU"
      },
      {
        value: "7D",
        label: "LAHAUL AND SPITI"
      },
      {
        value: "86D",
        label: "MANDI"
      },
      {
        value: "9D",
        label: "SHIMLA"
      },
      {
        value: "10D",
        label: "SIRMAUR"
      },
      {
        value: "11D",
        label: "SOLAN"
      },
      {
        value: "12D",
        label: "UNA"
      }
    ]
  },
  "13": {
    stateName: "JAMMU AND KASHMIR",
    cities: [
      {
        value: "1D",
        label: "ANANTNAG"
      },
      {
        value: "30C",
        label: "AWANTIPORA"
      },
      {
        value: "8D",
        label: "BANDIPORE"
      },
      {
        value: "2D",
        label: "BARAMULLA"
      },
      {
        value: "3D",
        label: "BUDGAM"
      },
      {
        value: "91D",
        label: "DODA"
      },
      {
        value: "15D",
        label: "GANDERBAL"
      },
      {
        value: "32C",
        label: "HANDWARA"
      },
      {
        value: "5D",
        label: "JAMMU"
      },
      {
        value: "7D",
        label: "KATHUA"
      },
      {
        value: "18D",
        label: "KISHTWAR"
      },
      {
        value: "20D",
        label: "KULGAM"
      },
      {
        value: "90D",
        label: "KUPWARA"
      },
      {
        value: "9D",
        label: "POONCH"
      },
      {
        value: "10D",
        label: "PULWAMA"
      },
      {
        value: "11D",
        label: "RAJOURI"
      },
      {
        value: "19D",
        label: "RAMBAN"
      },
      {
        value: "16D",
        label: "REASI"
      },
      {
        value: "17D",
        label: "SAMBA"
      },
      {
        value: "4D",
        label: "SHOPIAN"
      },
      {
        value: "31C",
        label: "SOPORE"
      },
      {
        value: "12D",
        label: "SRINAGAR"
      },
      {
        value: "13D",
        label: "UDHAMPUR"
      }
    ]
  },
  "14": {
    stateName: "JHARKHAND",
    cities: [
      {
        value: "1D",
        label: "BOKARO"
      },
      {
        value: "2D",
        label: "CHATRA"
      },
      {
        value: "3D",
        label: "DEOGHAR"
      },
      {
        value: "4D",
        label: "DHANBAD"
      },
      {
        value: "5D",
        label: "DUMKA"
      },
      {
        value: "6D",
        label: "EAST SINGHBHUM"
      },
      {
        value: "7D",
        label: "GARHWA"
      },
      {
        value: "93D",
        label: "GIRIDIH"
      },
      {
        value: "9D",
        label: "GODDA"
      },
      {
        value: "10D",
        label: "GUMLA"
      },
      {
        value: "11D",
        label: "HAZARIBAG"
      },
      {
        value: "12D",
        label: "JAMTARA"
      },
      {
        value: "8D",
        label: "KHUNTI"
      },
      {
        value: "13D",
        label: "KODERMA"
      },
      {
        value: "14D",
        label: "LATEHAR"
      },
      {
        value: "15D",
        label: "LOHARDAGA"
      },
      {
        value: "92D",
        label: "PAKUR"
      },
      {
        value: "17D",
        label: "PALAMU"
      },
      {
        value: "16D",
        label: "RAMGARH"
      },
      {
        value: "18D",
        label: "RANCHI"
      },
      {
        value: "19D",
        label: "SAHIBGANJ"
      },
      {
        value: "20D",
        label: "SERAIKELA"
      },
      {
        value: "21D",
        label: "SIMDEGA"
      },
      {
        value: "22D",
        label: "WEST SINGHBHUM"
      }
    ]
  },
  "15": {
    stateName: "KARNATAKA",
    cities: [
      {
        value: "1D",
        label: "BAGALKOT"
      },
      {
        value: "141D",
        label: "BELAGAVI"
      },
      {
        value: "5D",
        label: "BELLARY"
      },
      {
        value: "5C",
        label: "BENGALURU"
      },
      {
        value: "6D",
        label: "BIDAR"
      },
      {
        value: "7D",
        label: "BIJAPUR"
      },
      {
        value: "95D",
        label: "CHAMARAJANAGAR"
      },
      {
        value: "9D",
        label: "CHICKMAGALUR"
      },
      {
        value: "8D",
        label: "CHIKBALLAPUR"
      },
      {
        value: "10D",
        label: "CHITRADURGA"
      },
      {
        value: "25D",
        label: "DAKSHINA KANNADA"
      },
      {
        value: "11D",
        label: "DAVANAGERE"
      },
      {
        value: "12D",
        label: "DHARWAD"
      },
      {
        value: "13D",
        label: "GADAG"
      },
      {
        value: "15D",
        label: "HASSAN"
      },
      {
        value: "94D",
        label: "HAVERI"
      },
      {
        value: "14D",
        label: "KALABURAGI"
      },
      {
        value: "17D",
        label: "KODAGU"
      },
      {
        value: "18D",
        label: "KOLAR"
      },
      {
        value: "10C",
        label: "KOLAR GOLD FIELDS"
      },
      {
        value: "19D",
        label: "KOPPAL"
      },
      {
        value: "20D",
        label: "MANDYA"
      },
      {
        value: "21D",
        label: "MYSORE"
      },
      {
        value: "23D",
        label: "RAICHUR"
      },
      {
        value: "4D",
        label: "RAMNAGARA"
      },
      {
        value: "24D",
        label: "SHIMOGA"
      },
      {
        value: "26D",
        label: "TUMKUR"
      },
      {
        value: "27D",
        label: "UDUPI"
      },
      {
        value: "22D",
        label: "UTTARA KANNADA"
      },
      {
        value: "29D",
        label: "VIJAYANAGARA"
      },
      {
        value: "16D",
        label: "YADGIR"
      }
    ]
  },
  "16": {
    stateName: "KERALA",
    cities: [
      {
        value: "1D",
        label: "ALAPPUZHA"
      },
      {
        value: "19D",
        label: "ERNAKULAM"
      },
      {
        value: "3D",
        label: "IDUKKI"
      },
      {
        value: "96D",
        label: "KANNUR"
      },
      {
        value: "5D",
        label: "KASARAGOD"
      },
      {
        value: "6D",
        label: "KOLLAM"
      },
      {
        value: "7D",
        label: "KOTTAYAM"
      },
      {
        value: "15D",
        label: "KOZHIKODE"
      },
      {
        value: "9D",
        label: "MALAPPURAM"
      },
      {
        value: "10D",
        label: "PALAKKAD"
      },
      {
        value: "11D",
        label: "PATHANAMTHITTA"
      },
      {
        value: "12D",
        label: "THIRUVANANTHAPURAM"
      },
      {
        value: "13D",
        label: "THRISSUR"
      },
      {
        value: "14D",
        label: "WAYANAD"
      }
    ]
  },
  "38": {
    stateName: "LADAKH",
    cities: [
      {
        value: "2D",
        label: "KARGIL"
      },
      {
        value: "1D",
        label: "LEH"
      }
    ]
  },
  "36": {
    stateName: "LAKSHADWEEP",
    cities: [
      {
        value: "34C",
        label: "AGATTI ISLAND"
      },
      {
        value: "36C",
        label: "AMINI ISLAND"
      },
      {
        value: "37C",
        label: "ANDOTH ISLAND"
      },
      {
        value: "43C",
        label: "BANGARAM ISLAND"
      },
      {
        value: "42C",
        label: "BITRA ISLAND"
      },
      {
        value: "41C",
        label: "CHETLAT ISLAND"
      },
      {
        value: "35C",
        label: "KADMAT ISLAND"
      },
      {
        value: "38C",
        label: "KALPENI ISLAND"
      },
      {
        value: "140D",
        label: "KAVARATTI"
      },
      {
        value: "40C",
        label: "KILTAN ISLAND"
      },
      {
        value: "39C",
        label: "MINICOY ISLAND"
      },
      {
        value: "45C",
        label: "SUHELI ISLAND"
      },
      {
        value: "44C",
        label: "THINNAKARA ISLAND"
      }
    ]
  },
  "17": {
    stateName: "MADHYA PRADESH",
    cities: [
      {
        value: "8D",
        label: "AGAR MALWA"
      },
      {
        value: "16D",
        label: "ALIRAJPUR"
      },
      {
        value: "1D",
        label: "ANUPPUR"
      },
      {
        value: "2D",
        label: "ASHOKNAGAR"
      },
      {
        value: "3D",
        label: "BALAGHAT"
      },
      {
        value: "102D",
        label: "BARWANI"
      },
      {
        value: "5D",
        label: "BETUL"
      },
      {
        value: "6D",
        label: "BHIND"
      },
      {
        value: "7D",
        label: "BHOPAL"
      },
      {
        value: "32D",
        label: "BURHANPUR"
      },
      {
        value: "9D",
        label: "CHHATARPUR"
      },
      {
        value: "10D",
        label: "CHHINDWARA"
      },
      {
        value: "11D",
        label: "DAMOH"
      },
      {
        value: "12D",
        label: "DATIA"
      },
      {
        value: "13D",
        label: "DEWAS"
      },
      {
        value: "14D",
        label: "DHAR"
      },
      {
        value: "15D",
        label: "DINDORI"
      },
      {
        value: "103D",
        label: "GUNA"
      },
      {
        value: "17D",
        label: "GWALIOR"
      },
      {
        value: "18D",
        label: "HARDA"
      },
      {
        value: "20D",
        label: "INDORE"
      },
      {
        value: "21D",
        label: "JABALPUR"
      },
      {
        value: "22D",
        label: "JHABUA"
      },
      {
        value: "23D",
        label: "KATNI"
      },
      {
        value: "24D",
        label: "KHANDWA"
      },
      {
        value: "25D",
        label: "KHARGONE"
      },
      {
        value: "52D",
        label: "MAIHAR"
      },
      {
        value: "26D",
        label: "MANDLA"
      },
      {
        value: "27D",
        label: "MANDSAUR"
      },
      {
        value: "53D",
        label: "MAUGANJ"
      },
      {
        value: "28D",
        label: "MORENA"
      },
      {
        value: "19D",
        label: "NARMADAPURAM"
      },
      {
        value: "29D",
        label: "NARSINGHPUR"
      },
      {
        value: "30D",
        label: "NEEMUCH"
      },
      {
        value: "50D",
        label: "NIWARI"
      },
      {
        value: "51D",
        label: "PANDHURNA"
      },
      {
        value: "31D",
        label: "PANNA"
      },
      {
        value: "49D",
        label: "RAISEN"
      },
      {
        value: "33D",
        label: "RAJGARH"
      },
      {
        value: "34D",
        label: "RATLAM"
      },
      {
        value: "35D",
        label: "REWA"
      },
      {
        value: "36D",
        label: "SAGAR"
      },
      {
        value: "37D",
        label: "SATNA"
      },
      {
        value: "38D",
        label: "SEHORE"
      },
      {
        value: "39D",
        label: "SEONI"
      },
      {
        value: "40D",
        label: "SHAHDOL"
      },
      {
        value: "41D",
        label: "SHAJAPUR"
      },
      {
        value: "42D",
        label: "SHEOPUR"
      },
      {
        value: "43D",
        label: "SHIVPURI"
      },
      {
        value: "44D",
        label: "SIDHI"
      },
      {
        value: "4D",
        label: "SINGRAULI"
      },
      {
        value: "45D",
        label: "TIKAMGARH"
      },
      {
        value: "46D",
        label: "UJJAIN"
      },
      {
        value: "47D",
        label: "UMARIA"
      },
      {
        value: "48D",
        label: "VIDISHA"
      }
    ]
  },
  "18": {
    stateName: "MAHARASHTRA",
    cities: [
      {
        value: "1D",
        label: "AHILYANAGAR"
      },
      {
        value: "153D",
        label: "AKOLA"
      },
      {
        value: "98D",
        label: "AMRAVATI"
      },
      {
        value: "5D",
        label: "BEED"
      },
      {
        value: "6D",
        label: "BHANDARA"
      },
      {
        value: "7D",
        label: "BULDHANA"
      },
      {
        value: "147D",
        label: "CHANDRAPUR"
      },
      {
        value: "3D",
        label: "CHHATRAPATI SAMBHAJINAGAR"
      },
      {
        value: "22D",
        label: "DHARASHIV"
      },
      {
        value: "9D",
        label: "DHULE"
      },
      {
        value: "10D",
        label: "GADCHIROLI"
      },
      {
        value: "11D",
        label: "GONDIA"
      },
      {
        value: "12D",
        label: "HINGOLI"
      },
      {
        value: "13D",
        label: "JALGAON"
      },
      {
        value: "14D",
        label: "JALNA"
      },
      {
        value: "15D",
        label: "KOLHAPUR"
      },
      {
        value: "99D",
        label: "LATUR"
      },
      {
        value: "2C",
        label: "MUMBAI"
      },
      {
        value: "18D",
        label: "NAGPUR"
      },
      {
        value: "19D",
        label: "NANDED"
      },
      {
        value: "20D",
        label: "NANDURBAR"
      },
      {
        value: "21D",
        label: "NASHIK"
      },
      {
        value: "11C",
        label: "NAVI MUMBAI"
      },
      {
        value: "32D",
        label: "PALGHAR"
      },
      {
        value: "23D",
        label: "PARBHANI"
      },
      {
        value: "24D",
        label: "PUNE"
      },
      {
        value: "25D",
        label: "RAIGAD"
      },
      {
        value: "26D",
        label: "RATNAGIRI"
      },
      {
        value: "27D",
        label: "SANGLI"
      },
      {
        value: "28D",
        label: "SATARA"
      },
      {
        value: "29D",
        label: "SINDHUDURG"
      },
      {
        value: "30D",
        label: "SOLAPUR"
      },
      {
        value: "31D",
        label: "THANE"
      },
      {
        value: "152D",
        label: "WARDHA"
      },
      {
        value: "33D",
        label: "WASHIM"
      },
      {
        value: "34D",
        label: "YAVATMAL"
      }
    ]
  },
  "19": {
    stateName: "MANIPUR",
    cities: [
      {
        value: "1D",
        label: "BISHNUPUR"
      },
      {
        value: "2D",
        label: "CHANDEL"
      },
      {
        value: "3D",
        label: "CHURACHANDPUR"
      },
      {
        value: "4D",
        label: "IMPHAL EAST"
      },
      {
        value: "5D",
        label: "IMPHAL WEST"
      },
      {
        value: "6D",
        label: "SENAPATI"
      },
      {
        value: "7D",
        label: "TAMENGLONG"
      },
      {
        value: "101D",
        label: "THOUBAL"
      },
      {
        value: "9D",
        label: "UKHRUL"
      }
    ]
  },
  "20": {
    stateName: "MEGHALAYA",
    cities: [
      {
        value: "2D",
        label: "EAST KHASI HILLS"
      },
      {
        value: "10D",
        label: "SOUTH WEST GARO HILLS"
      },
      {
        value: "6D",
        label: "WEST GARO HILLS"
      }
    ]
  },
  "21": {
    stateName: "MIZORAM",
    cities: [
      {
        value: "1D",
        label: "AIZAWL"
      },
      {
        value: "2D",
        label: "CHAMPHAI"
      },
      {
        value: "9D",
        label: "HNAHTHIAL"
      },
      {
        value: "8D",
        label: "KHAWZAWL"
      },
      {
        value: "3D",
        label: "KOLASIB"
      },
      {
        value: "106D",
        label: "LAWNGTLAI"
      },
      {
        value: "5D",
        label: "LUNGLEI"
      },
      {
        value: "6D",
        label: "MAMIT"
      },
      {
        value: "7D",
        label: "SAIHA"
      },
      {
        value: "4D",
        label: "SAITUAL"
      },
      {
        value: "107D",
        label: "SERCHHIP"
      }
    ]
  },
  "22": {
    stateName: "NAGALAND",
    cities: [
      {
        value: "13D",
        label: "CHUMOUKEDIMA"
      },
      {
        value: "1D",
        label: "DIMAPUR"
      },
      {
        value: "10D",
        label: "KIPHIRE"
      },
      {
        value: "2D",
        label: "KOHIMA"
      },
      {
        value: "9D",
        label: "LONGLENG"
      },
      {
        value: "15D",
        label: "MELURI"
      },
      {
        value: "3D",
        label: "MOKOKCHUNG"
      },
      {
        value: "108D",
        label: "MON"
      },
      {
        value: "14D",
        label: "NIULAND"
      },
      {
        value: "4D",
        label: "NOKLAK"
      },
      {
        value: "8D",
        label: "PEREN"
      },
      {
        value: "5D",
        label: "PHEK"
      },
      {
        value: "12D",
        label: "SHAMATOR"
      },
      {
        value: "11D",
        label: "TSEMINYU"
      },
      {
        value: "6D",
        label: "TUENSANG"
      },
      {
        value: "7D",
        label: "WOKHA"
      },
      {
        value: "109D",
        label: "ZUNHEBOTO"
      }
    ]
  },
  "23": {
    stateName: "ODISHA",
    cities: [
      {
        value: "1D",
        label: "ANGUL"
      },
      {
        value: "2D",
        label: "BALANGIR"
      },
      {
        value: "3D",
        label: "BALASORE"
      },
      {
        value: "4D",
        label: "BARGARH"
      },
      {
        value: "22C",
        label: "BERHAMPUR"
      },
      {
        value: "5D",
        label: "BHADRAK"
      },
      {
        value: "14C",
        label: "BHUBANESWAR"
      },
      {
        value: "6D",
        label: "BOUDH"
      },
      {
        value: "7D",
        label: "CUTTACK"
      },
      {
        value: "111D",
        label: "DEOGARH"
      },
      {
        value: "9D",
        label: "DHENKANAL"
      },
      {
        value: "10D",
        label: "GAJAPATI"
      },
      {
        value: "11D",
        label: "GANJAM"
      },
      {
        value: "12D",
        label: "JAGATSINGHAPUR"
      },
      {
        value: "13D",
        label: "JAJPUR"
      },
      {
        value: "14D",
        label: "JHARSUGUDA"
      },
      {
        value: "113D",
        label: "KALAHANDI"
      },
      {
        value: "114D",
        label: "KANDHAMAL"
      },
      {
        value: "17D",
        label: "KENDRAPARA"
      },
      {
        value: "112D",
        label: "KEONJHAR"
      },
      {
        value: "19D",
        label: "KHORDHA"
      },
      {
        value: "20D",
        label: "KORAPUT"
      },
      {
        value: "21D",
        label: "MALKANGIRI"
      },
      {
        value: "22D",
        label: "MAYURBHANJ"
      },
      {
        value: "23D",
        label: "NABARANGAPUR"
      },
      {
        value: "24D",
        label: "NAYAGARH"
      },
      {
        value: "25D",
        label: "NUAPADA"
      },
      {
        value: "26D",
        label: "PURI"
      },
      {
        value: "27D",
        label: "RAYAGADA"
      },
      {
        value: "23C",
        label: "ROURKELA"
      },
      {
        value: "28D",
        label: "SAMBALPUR"
      },
      {
        value: "29D",
        label: "SONEPUR"
      },
      {
        value: "30D",
        label: "SUNDARGARH"
      }
    ]
  },
  "25": {
    stateName: "PUNJAB",
    cities: [
      {
        value: "7C",
        label: "AMRITSAR"
      },
      {
        value: "18D",
        label: "BARNALA"
      },
      {
        value: "21C",
        label: "BATALA"
      },
      {
        value: "2D",
        label: "BATHINDA"
      },
      {
        value: "3D",
        label: "FARIDKOT"
      },
      {
        value: "115D",
        label: "FATEHGARH SAHIB"
      },
      {
        value: "19D",
        label: "FAZILKA"
      },
      {
        value: "5D",
        label: "FEROZEPUR"
      },
      {
        value: "6D",
        label: "GURDASPUR"
      },
      {
        value: "7D",
        label: "HOSHIARPUR"
      },
      {
        value: "8D",
        label: "JALANDHAR"
      },
      {
        value: "9D",
        label: "KAPURTHALA"
      },
      {
        value: "16C",
        label: "KHANNA"
      },
      {
        value: "10D",
        label: "LUDHIANA"
      },
      {
        value: "20D",
        label: "MALERKOTLA"
      },
      {
        value: "11D",
        label: "MANSA"
      },
      {
        value: "12D",
        label: "MOGA"
      },
      {
        value: "150D",
        label: "MOHALI"
      },
      {
        value: "14D",
        label: "NAWANSHAHR"
      },
      {
        value: "16D",
        label: "PATHANKOT"
      },
      {
        value: "15D",
        label: "PATIALA"
      },
      {
        value: "117D",
        label: "RUPNAGAR"
      },
      {
        value: "17D",
        label: "SANGRUR"
      },
      {
        value: "13D",
        label: "SHRI MUKATSAR SAHIB"
      },
      {
        value: "4D",
        label: "TARN TARAN"
      }
    ]
  },
  "26": {
    stateName: "RAJASTHAN",
    cities: [
      {
        value: "1D",
        label: "AJMER"
      },
      {
        value: "2D",
        label: "ALWAR"
      },
      {
        value: "37D",
        label: "BALOTRA"
      },
      {
        value: "3D",
        label: "BANSWARA"
      },
      {
        value: "120D",
        label: "BARAN"
      },
      {
        value: "5D",
        label: "BARMER"
      },
      {
        value: "39D",
        label: "BEAWAR"
      },
      {
        value: "6D",
        label: "BHARATPUR"
      },
      {
        value: "7D",
        label: "BHILWARA"
      },
      {
        value: "28C",
        label: "BHIWADI"
      },
      {
        value: "8D",
        label: "BIKANER"
      },
      {
        value: "9D",
        label: "BUNDI"
      },
      {
        value: "10D",
        label: "CHITTORGARH"
      },
      {
        value: "11D",
        label: "CHURU"
      },
      {
        value: "12D",
        label: "DAUSA"
      },
      {
        value: "41D",
        label: "DEEG"
      },
      {
        value: "13D",
        label: "DHOLPUR"
      },
      {
        value: "43D",
        label: "DIDWANA-KUCHAMAN"
      },
      {
        value: "14D",
        label: "DUNGARPUR"
      },
      {
        value: "121D",
        label: "HANUMANGARH"
      },
      {
        value: "17D",
        label: "JAIPUR"
      },
      {
        value: "18D",
        label: "JAISALMER"
      },
      {
        value: "19D",
        label: "JALORE"
      },
      {
        value: "20D",
        label: "JHALAWAR"
      },
      {
        value: "21D",
        label: "JHUNJHUNU"
      },
      {
        value: "22D",
        label: "JODHPUR"
      },
      {
        value: "23D",
        label: "KARAULI"
      },
      {
        value: "38D",
        label: "KHAIRTHAL-TIJARA"
      },
      {
        value: "24D",
        label: "KOTA"
      },
      {
        value: "36D",
        label: "KOTPUTLI-BEHROR"
      },
      {
        value: "25D",
        label: "NAGAUR"
      },
      {
        value: "29C",
        label: "NEEMRANA"
      },
      {
        value: "26D",
        label: "PALI"
      },
      {
        value: "42D",
        label: "PHALODI"
      },
      {
        value: "4D",
        label: "PRATAPGARH"
      },
      {
        value: "27D",
        label: "RAJSAMAND"
      },
      {
        value: "44D",
        label: "SALUMBER"
      },
      {
        value: "28D",
        label: "SAWAI MADHOPUR"
      },
      {
        value: "30D",
        label: "SIKAR"
      },
      {
        value: "31D",
        label: "SIROHI"
      },
      {
        value: "15D",
        label: "SRI GANGANAGAR"
      },
      {
        value: "32D",
        label: "TONK"
      },
      {
        value: "33D",
        label: "UDAIPUR"
      }
    ]
  },
  "27": {
    stateName: "SIKKIM",
    cities: [
      {
        value: "1D",
        label: "EAST SIKKIM"
      }
    ]
  },
  "28": {
    stateName: "TAMIL NADU",
    cities: [
      {
        value: "123D",
        label: "ARIYALUR"
      },
      {
        value: "16D",
        label: "CHENGALPATTU"
      },
      {
        value: "4C",
        label: "CHENNAI"
      },
      {
        value: "2D",
        label: "COIMBATORE"
      },
      {
        value: "3D",
        label: "CUDDALORE"
      },
      {
        value: "124D",
        label: "DHARMAPURI"
      },
      {
        value: "5D",
        label: "DINDIGUL"
      },
      {
        value: "6D",
        label: "ERODE"
      },
      {
        value: "27D",
        label: "KALLAKURICHI"
      },
      {
        value: "7D",
        label: "KANCHIPURAM"
      },
      {
        value: "125D",
        label: "KANYAKUMARI"
      },
      {
        value: "9D",
        label: "KARUR"
      },
      {
        value: "10D",
        label: "KRISHNAGIRI"
      },
      {
        value: "11D",
        label: "MADURAI"
      },
      {
        value: "32D",
        label: "MAYILADUTHURAI"
      },
      {
        value: "12D",
        label: "NAGAPATTINAM"
      },
      {
        value: "13D",
        label: "NAMAKKAL"
      },
      {
        value: "14D",
        label: "NILGIRIS"
      },
      {
        value: "15D",
        label: "PERAMBALUR"
      },
      {
        value: "126D",
        label: "PUDUKKOTTAI"
      },
      {
        value: "17D",
        label: "RAMANATHAPURAM"
      },
      {
        value: "26D",
        label: "RANIPET"
      },
      {
        value: "18D",
        label: "SALEM"
      },
      {
        value: "19D",
        label: "SIVAGANGA"
      },
      {
        value: "28D",
        label: "TENKASI"
      },
      {
        value: "20D",
        label: "THANJAVUR"
      },
      {
        value: "21D",
        label: "THENI"
      },
      {
        value: "22D",
        label: "THOOTHUKUDI"
      },
      {
        value: "23D",
        label: "TIRUCHIRAPPALLI"
      },
      {
        value: "24D",
        label: "TIRUNELVELI"
      },
      {
        value: "8D",
        label: "TIRUPATHUR"
      },
      {
        value: "4D",
        label: "TIRUPPUR"
      },
      {
        value: "25D",
        label: "TIRUVALLUR"
      },
      {
        value: "29D",
        label: "TIRUVANNAMALAI"
      },
      {
        value: "30D",
        label: "TIRUVARUR"
      },
      {
        value: "31D",
        label: "VELLORE"
      },
      {
        value: "127D",
        label: "VILLUPURAM"
      },
      {
        value: "33D",
        label: "VIRUDHUNAGAR"
      }
    ]
  },
  "37": {
    stateName: "TELANGANA",
    cities: [
      {
        value: "1D",
        label: "ADILABAD"
      },
      {
        value: "11D",
        label: "BHADRADRI KOTHAGUDEM"
      },
      {
        value: "2D",
        label: "HYDERABAD"
      },
      {
        value: "13D",
        label: "JAGTIAL"
      },
      {
        value: "15D",
        label: "JAYASHANKAR BHUPALPALLY"
      },
      {
        value: "16D",
        label: "JOGULAMBA GADWAL"
      },
      {
        value: "17D",
        label: "KAMAREDDY"
      },
      {
        value: "3D",
        label: "KARIMNAGAR"
      },
      {
        value: "4D",
        label: "KHAMMAM"
      },
      {
        value: "18D",
        label: "KUMURAM BHEEM ASIFABAD"
      },
      {
        value: "19D",
        label: "MAHABUBABAD"
      },
      {
        value: "5D",
        label: "MAHABUBNAGAR"
      },
      {
        value: "20D",
        label: "MANCHERIAL"
      },
      {
        value: "6D",
        label: "MEDAK"
      },
      {
        value: "21D",
        label: "MEDCHAL-MALKAJGIRI"
      },
      {
        value: "22D",
        label: "MULUGU"
      },
      {
        value: "23D",
        label: "NAGARKURNOOL"
      },
      {
        value: "7D",
        label: "NALGONDA"
      },
      {
        value: "24D",
        label: "NARAYANPET"
      },
      {
        value: "25D",
        label: "NIRMAL"
      },
      {
        value: "8D",
        label: "NIZAMABAD"
      },
      {
        value: "26D",
        label: "PEDDAPALLI"
      },
      {
        value: "27D",
        label: "RAJANNA SIRCILLA"
      },
      {
        value: "9D",
        label: "RANGAREDDY"
      },
      {
        value: "28D",
        label: "SANGAREDDY"
      },
      {
        value: "29D",
        label: "SIDDIPET"
      },
      {
        value: "30D",
        label: "SURYAPET"
      },
      {
        value: "31D",
        label: "VIKARABAD"
      },
      {
        value: "32D",
        label: "WANAPARTHY"
      },
      {
        value: "10D",
        label: "WARANGAL"
      },
      {
        value: "33D",
        label: "YADADRI BHUVANAGIRI"
      }
    ]
  },
  "29": {
    stateName: "TRIPURA",
    cities: [
      {
        value: "1D",
        label: "DHALAI"
      },
      {
        value: "4D",
        label: "GOMATI"
      },
      {
        value: "5D",
        label: "KHOWAI"
      },
      {
        value: "2D",
        label: "NORTH TRIPURA"
      },
      {
        value: "6D",
        label: "SEPAHIJALA"
      },
      {
        value: "3D",
        label: "SOUTH TRIPURA"
      },
      {
        value: "7D",
        label: "UNAKOTI"
      },
      {
        value: "128D",
        label: "WEST TRIPURA"
      }
    ]
  },
  "31": {
    stateName: "UTTARAKHAND",
    cities: [
      {
        value: "1D",
        label: "ALMORA"
      },
      {
        value: "2D",
        label: "BAGESHWAR"
      },
      {
        value: "3D",
        label: "CHAMOLI"
      },
      {
        value: "134D",
        label: "CHAMPAWAT"
      },
      {
        value: "5D",
        label: "DEHRADUN"
      },
      {
        value: "6D",
        label: "HARIDWAR"
      },
      {
        value: "7D",
        label: "NAINITAL"
      },
      {
        value: "135D",
        label: "PAURI GARHWAL"
      },
      {
        value: "9D",
        label: "PITHORAGARH"
      },
      {
        value: "10D",
        label: "RUDRAPRAYAG"
      },
      {
        value: "11D",
        label: "TEHRI GARHWAL"
      },
      {
        value: "12D",
        label: "UDHAM SINGH NAGAR"
      },
      {
        value: "13D",
        label: "UTTARKASHI"
      }
    ]
  },
  "30": {
    stateName: "UTTAR PRADESH",
    cities: [
      {
        value: "1D",
        label: "AGRA"
      },
      {
        value: "2D",
        label: "ALIGARH"
      },
      {
        value: "3D",
        label: "ALLAHABAD"
      },
      {
        value: "129D",
        label: "AMBEDKAR NAGAR"
      },
      {
        value: "4D",
        label: "AMETHI"
      },
      {
        value: "5D",
        label: "AURAIYA"
      },
      {
        value: "6D",
        label: "AZAMGARH"
      },
      {
        value: "7D",
        label: "BAGPAT"
      },
      {
        value: "131D",
        label: "BAHRAICH"
      },
      {
        value: "9D",
        label: "BALLIA"
      },
      {
        value: "10D",
        label: "BALRAMPUR"
      },
      {
        value: "11D",
        label: "BANDA"
      },
      {
        value: "12D",
        label: "BARABANKI"
      },
      {
        value: "13D",
        label: "BAREILLY"
      },
      {
        value: "14D",
        label: "BASTI"
      },
      {
        value: "15D",
        label: "BIJNOR"
      },
      {
        value: "130D",
        label: "BUDAUN"
      },
      {
        value: "17D",
        label: "BULANDSHAHR"
      },
      {
        value: "18D",
        label: "CHANDAULI"
      },
      {
        value: "19D",
        label: "CHITRAKOOT"
      },
      {
        value: "20D",
        label: "DEORIA"
      },
      {
        value: "21D",
        label: "ETAH"
      },
      {
        value: "22D",
        label: "ETAWAH"
      },
      {
        value: "23D",
        label: "FAIZABAD"
      },
      {
        value: "24D",
        label: "FARRUKHABAD"
      },
      {
        value: "25D",
        label: "FATEHPUR"
      },
      {
        value: "26D",
        label: "FIROZABAD"
      },
      {
        value: "27D",
        label: "GAUTAM BUDDHA NAGAR"
      },
      {
        value: "28D",
        label: "GHAZIABAD"
      },
      {
        value: "29D",
        label: "GHAZIPUR"
      },
      {
        value: "30D",
        label: "GONDA"
      },
      {
        value: "31D",
        label: "GORAKHPUR"
      },
      {
        value: "76D",
        label: "HAMIRPUR"
      },
      {
        value: "8D",
        label: "HAPUR"
      },
      {
        value: "151D",
        label: "HARDOI"
      },
      {
        value: "34D",
        label: "HATHRAS"
      },
      {
        value: "35D",
        label: "JALAUN"
      },
      {
        value: "36D",
        label: "JAUNPUR"
      },
      {
        value: "37D",
        label: "JHANSI"
      },
      {
        value: "38D",
        label: "JYOTIBA PHULE NAGAR"
      },
      {
        value: "39D",
        label: "KANNAUJ"
      },
      {
        value: "40D",
        label: "KANPUR DEHAT"
      },
      {
        value: "41D",
        label: "KANPUR NAGAR"
      },
      {
        value: "71D",
        label: "KASGANJ"
      },
      {
        value: "42D",
        label: "KAUSHAMBI"
      },
      {
        value: "44D",
        label: "KUSHINAGAR"
      },
      {
        value: "32D",
        label: "LAKHIMPUR KHERI"
      },
      {
        value: "45D",
        label: "LALITPUR"
      },
      {
        value: "46D",
        label: "LUCKNOW"
      },
      {
        value: "47D",
        label: "MAHARAJGANJ"
      },
      {
        value: "48D",
        label: "MAHOBA"
      },
      {
        value: "49D",
        label: "MAINPURI"
      },
      {
        value: "50D",
        label: "MATHURA"
      },
      {
        value: "51D",
        label: "MAU"
      },
      {
        value: "52D",
        label: "MEERUT"
      },
      {
        value: "53D",
        label: "MIRZAPUR"
      },
      {
        value: "54D",
        label: "MORADABAD"
      },
      {
        value: "55D",
        label: "MUZAFFARNAGAR"
      },
      {
        value: "56D",
        label: "PILIBHIT"
      },
      {
        value: "57D",
        label: "PRATAPGARH"
      },
      {
        value: "133D",
        label: "RAE BARELI"
      },
      {
        value: "59D",
        label: "RAMPUR"
      },
      {
        value: "60D",
        label: "SAHARANPUR"
      },
      {
        value: "72D",
        label: "SAMBHAL"
      },
      {
        value: "61D",
        label: "SANT KABIR NAGAR"
      },
      {
        value: "62D",
        label: "SANT RAVIDAS NAGAR"
      },
      {
        value: "63D",
        label: "SHAHJAHANPUR"
      },
      {
        value: "16D",
        label: "SHAMLI"
      },
      {
        value: "64D",
        label: "SHRAVASTI"
      },
      {
        value: "65D",
        label: "SIDDHARTHNAGAR"
      },
      {
        value: "66D",
        label: "SITAPUR"
      },
      {
        value: "67D",
        label: "SONBHADRA"
      },
      {
        value: "68D",
        label: "SULTANPUR"
      },
      {
        value: "69D",
        label: "UNNAO"
      },
      {
        value: "70D",
        label: "VARANASI"
      }
    ]
  },
  "32": {
    stateName: "WEST BENGAL",
    cities: [
      {
        value: "4D",
        label: "ALIPURDUAR"
      },
      {
        value: "24C",
        label: "ASANSOL DURGAPUR"
      },
      {
        value: "1D",
        label: "BANKURA"
      },
      {
        value: "19C",
        label: "BARRACKPUR"
      },
      {
        value: "18C",
        label: "BIDHANNAGAR"
      },
      {
        value: "3D",
        label: "BIRBHUM"
      },
      {
        value: "2D",
        label: "BURDWAN"
      },
      {
        value: "8D",
        label: "CHANDANNAGAR"
      },
      {
        value: "137D",
        label: "Cooch Behar"
      },
      {
        value: "5D",
        label: "Darjeeling"
      },
      {
        value: "6D",
        label: "East Medinipur"
      },
      {
        value: "7D",
        label: "HOOGHLY RURAL"
      },
      {
        value: "136D",
        label: "Howrah"
      },
      {
        value: "9D",
        label: "JALPAIGURI"
      },
      {
        value: "20C",
        label: "JHARGRAM"
      },
      {
        value: "16D",
        label: "KALIMPONG"
      },
      {
        value: "3C",
        label: "KOLKATA"
      },
      {
        value: "10D",
        label: "MALDA"
      },
      {
        value: "11D",
        label: "MURSHIDABAD"
      },
      {
        value: "12D",
        label: "NADIA"
      },
      {
        value: "13D",
        label: "NORTH 24 PARGANAS"
      },
      {
        value: "14D",
        label: "NORTH DINAJPUR"
      },
      {
        value: "15D",
        label: "Purulia"
      },
      {
        value: "12C",
        label: "SILIGURI"
      },
      {
        value: "146D",
        label: "SOUTH 24 PARGANAS"
      },
      {
        value: "17D",
        label: "SOUTH DINAJPUR"
      },
      {
        value: "18D",
        label: "West Medinipur"
      }
    ]
  },
  "24": {
    stateName: "PUDUCHERRY",
    cities: [
      {
        value: "1D",
        label: "KARAIKAL"
      },
      {
        value: "2D",
        label: "MAHE"
      },
      {
        value: "9C",
        label: "PONDICHERRY AND AUREVILLE"
      },
      {
        value: "118D",
        label: "YANAM"
      }
    ]
  }
};

// ../../packages/form-mapping/src/portal-data/index.ts
var portalSelects = {
  ...formc_select_options_default,
  ...select_options_default
};
var stateCityMap = state_cities_default;
var nationalityOptions = portalSelects.u_nationality?.options ?? [];
var stateOptions = portalSelects.state?.options ?? [];
var accommodationTypeOptions = portalSelects.acco_type?.options ?? [
  { value: "BB", label: "Bed and Breakfast" },
  { value: "D", label: "Dharmshala" },
  { value: "GH", label: "Guest House" },
  { value: "H", label: "Hotel" },
  { value: "IH", label: "Individual House" },
  { value: "I", label: "Institute" },
  { value: "O", label: "Others" },
  { value: "S", label: "Service Apartment" }
];
var starRatingOptions = portalSelects.star_rat?.options ?? [
  { value: "1s", label: "One Star" },
  { value: "2s", label: "Two Star" },
  { value: "3s", label: "Three Star" },
  { value: "4s", label: "Four Star" },
  { value: "5s", label: "Five Star" },
  { value: "6s", label: "Others" }
];
var sexOptions = portalSelects.u_gender?.options ?? [
  { value: "M", label: "Male" },
  { value: "F", label: "Female" },
  { value: "X", label: "Transgender" }
];
var specialCategoryOptions = portalSelects.specialCategory?.options ?? [];
var visaTypeOptions = portalSelects.visaType?.options ?? [];
var purposeOfVisitOptions = portalSelects.purposeOfVisit?.options ?? [];
function getCitiesForState(stateValue) {
  return stateCityMap[stateValue]?.cities ?? [];
}
function normalizeName(name) {
  return name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, " ");
}
var COUNTRY_ALIASES = {
  uk: "GBR",
  britain: "GBR",
  "great britain": "GBR",
  "north korea": "PRK",
  "south korea": "KOR",
  korea: "KOR",
  czechia: "CZE",
  "czech republic": "CZE",
  "ivory coast": "CIV",
  "cote divoire": "CIV",
  "cote d ivoire": "CIV",
  "equatorial guinea": "GIN",
  "viet nam": "VNM",
  "democratic republic of the congo": "COD",
  "dr congo": "COD",
  drc: "COD",
  "us virgin islands": "VIR",
  "british virgin islands": "VGB",
  holland: "NLD",
  myanmar: "MMR",
  swaziland: "SWZ",
  eswatini: "SWZ",
  "cabo verde": "CPV",
  "sao tome": "STP",
  "timor leste": "TLS",
  "united states": "USA",
  usa: "USA",
  uae: "ARE",
  "united arab emirates": "ARE",
  // Portal labels that abbreviate the common English name — reverse substring
  // alone can't bridge these (e.g. "SLOVAKIA" vs portal "SLOVAK REPUBLIC").
  slovakia: "SVK",
  "slovak republic": "SVK",
  "russian federation": "RUS",
  "lao people democratic republic": "LAO",
  // Kingdom of the Netherlands Caribbean constituents — real passports store
  // CUW/BES/SXM which the portal u_nationality list does not offer; the portal's
  // NETHERLANDS ANTILLES (ANT) is the natural target.
  curacao: "ANT",
  bonaire: "ANT",
  "sint maarten": "ANT",
  "saint martin": "FRA",
  "french polynesia": "FRA",
  tahiti: "FRA"
};
var CITY_ALIASES = {
  bangalore: "bengaluru",
  bengaluru: "bengaluru",
  puducherry: "pondicherry and aureville",
  pondicherry: "pondicherry and aureville",
  trichy: "tiruchirappalli",
  cochin: "ernakulam",
  kochi: "ernakulam",
  calicut: "kozhikode",
  kannur: "kannur",
  madras: "chennai",
  calcutta: "kolkata",
  bombay: "mumbai",
  poona: "pune",
  baroda: "vadodara",
  quilon: "kollam",
  alleppey: "alappuzha",
  // Karnataka 2014 rename family (portal still uses the pre-2014 names).
  mysuru: "mysore",
  mysore: "mysore",
  belgaum: "belagavi",
  belagavi: "belagavi",
  gulbarga: "kalaburagi",
  kalaburagi: "kalaburagi",
  // The portal's Karnataka list carries the OLD spelling (BELLARY, 5D) —
  // the previous "ballari" target exists in NO state list, so both spellings
  // resolved to an unmatchable value.
  bellary: "bellary",
  ballari: "bellary",
  hubli: "dharwad",
  // Mangaluru is the HQ of the DAKSHINA KANNADA district — the portal's
  // Karnataka list has NO 'MANGALORE' district, so a property storing the city
  // name must resolve to its district for the district select to match.
  mangalore: "dakshina kannada",
  mangaluru: "dakshina kannada",
  // Post-2014/2023 district renames. The portal keeps the OLD name for
  // Gurgaon and Allahabad but uses the NEW name for Chhatrapati Sambhajinagar
  // (Aurangabad MH), Dharashiv (Osmanabad) and Ahilyanagar (Ahmednagar), so
  // each alias maps whichever name the property stored onto the label the
  // portal's list actually carries. Alias resolution is state-scoped (the
  // alias must exist in THAT state's list), and exact-match runs after it —
  // so Bihar's own AURANGABAD district still exact-matches its own label.
  gurugram: "gurgaon",
  prayagraj: "allahabad",
  noida: "gautam buddha nagar",
  aurangabad: "chhatrapati sambhajinagar",
  osmanabad: "dharashiv",
  ahmednagar: "ahilyanagar"
};
function findCountryCode(countryName) {
  const normalized = normalizeName(countryName);
  if (!normalized) return void 0;
  const exact = nationalityOptions.find(
    (opt) => normalizeName(opt.label) === normalized
  );
  if (exact) return exact.value;
  if (COUNTRY_ALIASES[normalized]) return COUNTRY_ALIASES[normalized];
  const substringHits = nationalityOptions.filter(
    (opt) => normalizeName(opt.label).includes(normalized)
  );
  const natHit = substringHits[0];
  if (substringHits.length === 1 && natHit) return natHit.value;
  const reverseHits = nationalityOptions.filter((opt) => {
    const normLabel = normalizeName(opt.label);
    return !!normLabel && normalized.includes(normLabel);
  });
  const revNatHit = reverseHits[0];
  return reverseHits.length === 1 && revNatHit ? revNatHit.value : void 0;
}
function findStateCode(stateName) {
  const normalized = normalizeName(stateName);
  if (!normalized) return void 0;
  const exact = stateOptions.find(
    (opt) => normalizeName(opt.label) === normalized
  );
  if (exact) return exact.value;
  const hits = stateOptions.filter(
    (opt) => normalizeName(opt.label).includes(normalized)
  );
  const hit = hits[0];
  return hits.length === 1 && hit ? hit.value : void 0;
}
function findCityCode(stateValue, cityName) {
  const cities = getCitiesForState(stateValue);
  const normalized = normalizeName(cityName);
  if (!normalized) return void 0;
  const alias = CITY_ALIASES[normalized];
  if (alias) {
    const hit = cities.find((opt) => normalizeName(opt.label) === alias);
    if (hit) return hit.value;
  }
  const exact = cities.find((opt) => normalizeName(opt.label) === normalized);
  if (exact) return exact.value;
  const subHits = cities.filter(
    (opt) => normalizeName(opt.label).includes(normalized)
  );
  const subHit = subHits[0];
  if (subHits.length === 1 && subHit) return subHit.value;
  const revHits = cities.filter((opt) => {
    const nl = normalizeName(opt.label);
    return !!nl && normalized.includes(nl);
  });
  const revHit = revHits[0];
  return revHits.length === 1 && revHit ? revHit.value : void 0;
}

// ../../packages/form-mapping/src/index.ts
var ARRIVAL_FIELD_MAPS = [
  // --- B1: Personal Details ---
  {
    appField: "surname",
    by: { name: "applicant_surname", id: "applicant_surname" },
    control: "text",
    required: false
    // optional per single-name passports (companion spec B1)
  },
  {
    appField: "givenName",
    by: { name: "applicant_givenname", id: "applicant_givenname" },
    control: "text",
    required: true
  },
  {
    appField: "sex",
    by: { name: "applicant_sex", id: "applicant_sex" },
    control: "select",
    required: true
    // Portal uses M/F/X directly — no transform needed (values match our schema)
  },
  {
    appField: "dobFormat",
    by: { name: "dobformat" },
    // NO id on this select (verified)
    control: "select",
    transform: "dob_format_label",
    required: true
  },
  {
    appField: "dateOfBirth",
    by: { name: "applicant_dob", id: "applicant_dob" },
    control: "date",
    transform: "date_ddmmyyyy",
    required: true
  },
  {
    appField: "age",
    by: { name: "applicant_age", id: "applicant_age" },
    control: "text",
    transform: "number",
    required: false
    // only entered in AGE mode; readOnly when DY format
  },
  {
    appField: "specialCategory",
    by: {
      name: "applicant_special_category",
      id: "applicant_special_category"
    },
    control: "select",
    transform: "special_category_code",
    required: true
  },
  {
    appField: "nationality",
    by: { name: "applicant_nationality", id: "applicant_nationality" },
    control: "select",
    transform: "country_alpha3",
    required: true
  },
  // --- B2: Address in country where residing permanently ---
  {
    appField: "permanentAddressAbroad",
    by: { name: "applicant_permaddr", id: "applicant_permaddr" },
    control: "textarea",
    required: true
  },
  {
    appField: "permanentCityAbroad",
    by: { name: "applicant_permcity", id: "applicant_permcity" },
    control: "text",
    required: true
  },
  {
    appField: "permanentCountry",
    by: { name: "applicant_permcountry", id: "applicant_permcountry" },
    control: "select",
    transform: "country_alpha3",
    required: true
  },
  // --- B3: Address/Reference in India (host-defaulted) ---
  {
    appField: "indiaAddress",
    by: { name: "applicant_refaddr", id: "applicant_refaddr" },
    control: "textarea",
    required: true
  },
  {
    appField: "indiaState",
    by: { name: "applicant_refstate", id: "applicant_refstate" },
    control: "select",
    transform: "state_code",
    required: true
  },
  {
    appField: "indiaCityDistrict",
    by: { name: "applicant_refstatedistr", id: "applicant_refstatedistr" },
    control: "select",
    transform: "district_code",
    required: true,
    dependsOn: "indiaState"
    // dependent dropdown: showcities() AJAX (companion spec B3, D4 step 4)
  },
  {
    appField: "indiaPincode",
    by: { name: "applicant_refpincode", id: "applicant_refpincode" },
    control: "text",
    required: true
  },
  // --- B4: Passport Details ---
  {
    appField: "passportNumber",
    by: { name: "applicant_passpno", id: "applicant_passpno" },
    control: "text",
    required: true
  },
  {
    appField: "passportPlaceOfIssueCity",
    by: { name: "applicant_passplcofissue", id: "applicant_passplcofissue" },
    control: "text",
    required: true
  },
  {
    appField: "passportPlaceOfIssueCountry",
    by: { name: "passport_issue_country", id: "passport_issue_country" },
    control: "select",
    transform: "country_alpha3",
    required: true
  },
  {
    appField: "passportDateOfIssue",
    by: { name: "applicant_passpdoissue", id: "applicant_passpdoissue" },
    control: "date",
    transform: "date_ddmmyyyy",
    required: true
  },
  {
    appField: "passportValidTill",
    by: { name: "applicant_passpvalidtill", id: "applicant_passpvalidtill" },
    control: "date",
    transform: "date_ddmmyyyy",
    required: true
  },
  // --- B5: Visa Details ---
  {
    appField: "visaNumber",
    by: { name: "applicant_visano", id: "applicant_visano" },
    control: "text",
    required: true
  },
  {
    appField: "visaPlaceOfIssueCity",
    by: { name: "applicant_visaplcoissue", id: "applicant_visaplcoissue" },
    control: "text",
    required: true
  },
  {
    appField: "visaPlaceOfIssueCountry",
    by: { name: "visa_issue_country", id: "visa_issue_country" },
    control: "select",
    transform: "country_alpha3",
    required: true
  },
  {
    appField: "visaDateOfIssue",
    by: { name: "applicant_visadoissue", id: "applicant_visadoissue" },
    control: "date",
    transform: "date_ddmmyyyy",
    required: true
  },
  {
    appField: "visaValidTill",
    by: { name: "applicant_visavalidtill", id: "applicant_visavalidtill" },
    control: "date",
    transform: "date_ddmmyyyy",
    required: true
  },
  {
    appField: "visaType",
    by: { name: "applicant_visatype", id: "applicant_visatype" },
    control: "select",
    transform: "visa_type_code",
    required: true
  },
  {
    appField: "visaSubType",
    by: {
      name: "applicant_visa_subtype_code",
      id: "applicant_visa_subtype_code"
    },
    control: "select",
    required: false,
    dependsOn: "visaType"
    // dependent dropdown: showvisasubtype() AJAX (companion spec B5, D4 step 4)
  },
  // --- B6: Arrival Information ---
  {
    appField: "arrivedFromCountry",
    by: {
      name: "applicant_arrivedfromcountry",
      id: "applicant_arrivedfromcountry"
    },
    control: "select",
    transform: "country_alpha3",
    required: true
  },
  {
    appField: "arrivedFromCity",
    by: { name: "applicant_arrivedfromcity", id: "applicant_arrivedfromcity" },
    control: "text",
    required: true
  },
  {
    appField: "arrivedFromPlace",
    by: {
      name: "applicant_arrivedfromplace",
      id: "applicant_arrivedfromplace"
    },
    control: "text",
    required: true
  },
  {
    appField: "dateOfArrivalIndia",
    by: { name: "applicant_doarrivalindia", id: "applicant_doarrivalindia" },
    control: "date",
    transform: "date_ddmmyyyy",
    required: true
  },
  {
    appField: "checkInDate",
    by: { name: "applicant_doarrivalhotel", id: "applicant_doarrivalhotel" },
    control: "date",
    transform: "date_ddmmyyyy",
    required: true
  },
  {
    appField: "checkInTime",
    by: {
      name: "applicant_timeoarrivalhotel",
      id: "applicant_timeoarrivalhotel"
    },
    control: "time",
    transform: "time_hhmm",
    required: true
  },
  {
    appField: "intendedDurationDays",
    by: { name: "applicant_intnddurhotel", id: "applicant_intnddurhotel" },
    control: "text",
    transform: "number",
    required: true
  },
  // --- B7: Other Details ---
  {
    appField: "employedInIndia",
    by: { name: "employed" },
    // NO id on this radio (verified)
    control: "radio",
    transform: "yesno_y_n",
    required: true
  },
  {
    appField: "purposeOfVisit",
    by: { name: "applicant_purpovisit", id: "applicant_purpovisit" },
    control: "select",
    transform: "purpose_code",
    required: true
  },
  {
    appField: "nextDestinationType",
    by: { name: "applicant_next_dest_country_flag_r" },
    // NO id (verified)
    control: "radio",
    transform: "next_destination_i_o",
    required: true
  },
  {
    appField: "nextDestinationState",
    by: {
      name: "applicant_next_destination_state_IN",
      id: "applicant_next_destination_state_IN"
    },
    control: "select",
    transform: "state_code",
    required: false,
    dependsOn: "nextDestinationType"
    // only shown when Inside India (I)
  },
  {
    appField: "nextDestinationCityDistrict",
    by: {
      name: "applicant_next_destination_city_district_IN",
      id: "applicant_next_destination_city_district_IN"
    },
    control: "select",
    transform: "district_code",
    required: false,
    dependsOn: "nextDestinationState"
    // showcities_dest() AJAX
  },
  {
    appField: "nextDestinationPlace",
    by: {
      name: "applicant_next_destination_place_IN",
      id: "applicant_next_destination_place_IN"
    },
    control: "text",
    required: false,
    dependsOn: "nextDestinationType"
  },
  {
    appField: "contactPhoneIndia",
    by: {
      name: "applicant_contactnoinindia",
      id: "applicant_contactnoinindia"
    },
    control: "text",
    required: false
  },
  {
    appField: "mobileIndia",
    by: {
      name: "applicant_mcontactnoinindia",
      id: "applicant_mcontactnoinindia"
    },
    control: "text",
    required: false
  },
  {
    appField: "contactPhoneAbroad",
    by: { name: "applicant_contactnoperm", id: "applicant_contactnoperm" },
    control: "text",
    required: false
  },
  {
    appField: "mobileAbroad",
    by: { name: "applicant_mcontactnoperm", id: "applicant_mcontactnoperm" },
    control: "text",
    required: false
  },
  {
    appField: "remarks",
    by: { name: "applicant_remark", id: "applicant_remark" },
    control: "textarea",
    required: false
  },
  // Photo upload (companion spec A4/A5/D11): the portal photo is file1
  // (VERIFIED). The extension cannot set file inputs (browser security) — the
  // host manually Choose File / Upload / Save. With NO entry, the engine
  // never reported 'manual', so a fill could render fully green with the
  // mandatory guest photo unattached. This entry surfaces the step.
  {
    appField: "guestPhoto",
    by: { name: "file1", id: "file1" },
    control: "file",
    required: true
  }
];
function isRealDate(year, month, day) {
  if (month < 1 || month > 12 || day < 1 || day > 31) return false;
  const dt = new Date(Date.UTC(year, month - 1, day));
  return dt.getUTCFullYear() === year && dt.getUTCMonth() === month - 1 && dt.getUTCDate() === day;
}
var DEFAULT_FORM_MAPPING = {
  version: 3,
  // v3: verified against live portal (2026-07-19)
  signature: "aJy91Swo0/cK6Hy1TLG4C2jnC8/Y+USCtONWZiKd3yzi5ib8D81a27WCK9Nvb6Wn6N1dlRO+3QYu+0zPnCThCg==",
  lastVerified: "2026-07-19T14:04:08Z",
  photoFieldSelector: "input[type=file][name=file1]",
  // VERIFIED: was uploadPhoto
  photoMaxSizeBytes: 5e4,
  // companion spec A4: 50 KB hard ceiling
  mappings: ARRIVAL_FIELD_MAPS
};
var transforms = {
  // Dates -> DD/MM/YYYY (companion spec D3, verified: portal uses DD/MM/YYYY)
  date_ddmmyyyy: (value) => {
    if (typeof value !== "string" || !value) return "";
    const match = /^(\d{4})-(\d{1,2})-(\d{1,2})/.exec(value);
    if (!match) return value;
    const [, y, m, d] = match;
    const yy = Number(y);
    const mm = Number(m);
    const dd = Number(d);
    if (!isRealDate(yy, mm, dd)) return "";
    return `${String(dd).padStart(2, "0")}/${String(mm).padStart(2, "0")}/${y}`;
  },
  // Time -> HH:MM 24h (companion spec D3, verified: maxlength=5, format HH:MM)
  time_hhmm: (input) => {
    if (typeof input !== "string") return "";
    const value = input.trim();
    if (!value) return "";
    if (/^\d{2}:\d{2}$/.test(value)) {
      const parts = value.split(":").map(Number);
      const hh = parts[0] ?? NaN;
      const mi = parts[1] ?? NaN;
      return hh < 24 && mi < 60 ? value : "";
    }
    const pad = /^(\d{1,2}):(\d{1,2})$/.exec(value);
    if (pad) {
      const hh = Number(pad[1]);
      const mi = Number(pad[2]);
      if (hh < 24 && mi < 60)
        return `${String(hh).padStart(2, "0")}:${String(mi).padStart(2, "0")}`;
      return "";
    }
    const iso = /T(\d{1,2}):(\d{2})/.exec(value);
    if (iso) {
      const hh = Number(iso[1]);
      const mi = Number(iso[2]);
      return hh < 24 && mi < 60 ? `${String(hh).padStart(2, "0")}:${String(mi).padStart(2, "0")}` : "";
    }
    return "";
  },
  // Yes/No -> Y/N (VERIFIED: employed radio uses value="Y" and value="N")
  yesno_y_n: (value) => {
    if (typeof value === "boolean") return value ? "Y" : "N";
    if (typeof value === "number")
      return value === 1 ? "Y" : value === 0 ? "N" : "";
    if (typeof value === "string") {
      const v = value.trim().toUpperCase();
      if (v === "YES" || v === "Y" || v === "TRUE" || v === "1") return "Y";
      if (v === "NO" || v === "N" || v === "FALSE" || v === "0") return "N";
    }
    return "";
  },
  // Next destination: inside/outside -> I/O
  // VERIFIED: radio value="I" for Inside India, value="O" for Outside India.
  // Accepts the app's "inside"/"outside" AND the portal's own radio labels
  // "Inside India"/"Outside India" — previously the labels passed through
  // unchanged and could never match the I/O radio values.
  next_destination_i_o: (value) => {
    if (typeof value !== "string") return "";
    const v = value.trim().toLowerCase();
    if (v === "inside" || v === "i" || v === "inside india") return "I";
    if (v === "outside" || v === "o" || v === "outside india") return "O";
    return value;
  },
  // DOB format: full/my/y/age -> DY/MY/YY/AG
  // VERIFIED: portal uses DY (DD/MM/YYYY), YY (YYYY), MY (MM/YYYY), AG (Age)
  dob_format_label: (input) => {
    if (typeof input !== "string") return "";
    const value = input.trim();
    const map = {
      full: "DY",
      my: "MY",
      y: "YY",
      age: "AG",
      // Pass through if already in portal format
      DY: "DY",
      MY: "MY",
      YY: "YY",
      AG: "AG"
    };
    if (map[value] !== void 0) return map[value];
    const lower = value.toLowerCase();
    return map[lower] ?? value;
  },
  // Special category: label -> numeric code
  // VERIFIED: portal uses numeric option values (13=Born in India, 3=Crew, etc.)
  special_category_code: (value) => {
    if (typeof value !== "string") return "";
    const labelToCode = {
      "BORN IN INDIA": "13",
      CREW: "3",
      "DIPLOMAT EXEMPTED": "7",
      "EMERGENCY TRANSIT": "4",
      "INDIAN ORIGIN": "14",
      "LOSS OF PASSPORT": "12",
      OCI: "10",
      "OFFICIAL EXEMPTED": "6",
      "OTHER EXEMPTED": "8",
      OTHERS: "9",
      PIO: "11",
      REFUGEE: "2",
      TLP: "5"
    };
    if (value.match(/^[0-9]+$/))
      return Object.values(labelToCode).includes(value) ? value : "";
    const norm2 = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
    const key = norm2(value);
    const hit = Object.keys(labelToCode).find((k) => norm2(k) === key);
    return hit ? labelToCode[hit] ?? value : value;
  },
  // Visa type: label -> numeric code
  // VERIFIED: portal uses numeric option values (1=Business, 17=Tourist, etc.)
  // Lookup is case- AND punctuation-insensitive (both sides normalized to
  // lowercase alnum): the previous mixed-case map only matched the exact stored
  // key case, so "e-Visa" / "E-VISA" / "eVISA" (common from OCR) fell through
  // untransformed and the portal select got a value it could never match.
  visa_type_code: (value) => {
    if (typeof value !== "string") return "";
    const labelToCode = {
      "AYUSH VISA": "161",
      "BUSINESS VISA": "1",
      "CONFERENCE VISA": "2",
      "DIPLOMATIC VISA": "3",
      "EMPLOYMENT VISA": "4",
      "JOURNALIST VISA": "6",
      "LONG TERM VISA": "7",
      "MISSIONARY VISA": "11",
      "OFFICIAL VISA": "12",
      "STUDENT VISA": "16",
      "TOURIST VISA": "17",
      "TRANSIT VISA": "18",
      "UNITED NATION": "19",
      "MISC SP PERMISSION": "10",
      "TEMPORARY LANDING PERMIT": "24",
      OCI: "22",
      "PIO CARD HOLDER": "13",
      "FILMS VISA": "28",
      "UN DIPLOMAT VISA": "33",
      "UN OFFICIAL VISA": "34",
      "ENTRY VISA": "94",
      "MEDICAL VISA": "92",
      "MOUNTAINEERING VISA": "93",
      "DIPLOMATIC DEPENDENT VISA": "91",
      "OFFICIAL DEPENDENT VISA": "90",
      "E-VISA": "98",
      // The OCR eVisa extractor emits the document's own printed type line, and
      // the highest-volume Indian e-visas print SUBTYPE labels ("e-Tourist Visa",
      // "e-Business Visa", "e-Medical Visa", "e-Conference Visa",
      // "e-Employment Visa"). The portal has NO distinct option for these — they
      // are all filed as the generic "e-VISA" (98). Previously the subtype label
      // fell through untransformed and the required visaType select reported
      // missing-value on every such filing (fallback + host re-pick). Map them to
      // 98 like the bare "E-VISA" the extractor also emits.
      "E-TOURIST VISA": "98",
      "E-BUSINESS VISA": "98",
      "E-MEDICAL VISA": "98",
      "E-CONFERENCE VISA": "98",
      "E-EMPLOYMENT VISA": "98",
      "VISA-ON-ARRIVAL": "99",
      "VISITOR VISA(ONLY FOR PAKISTAN NATIONALS)": "95",
      "DOUBLE ENTRY VISA (ONLY FOR BANGLADESH NATIONALS)": "97",
      "PLIGRIM VISA(ONLY FOR PAKISTAN NATIONALS)": "96",
      // The portal's label is misspelled ("PLIGRIM"); the correctly-spelled
      // variant and the bare label (no parenthetical suffix) previously fell
      // through un-transformed because the lookup is normalized-exact.
      "PILGRIM VISA(ONLY FOR PAKISTAN NATIONALS)": "96",
      "PLIGRIM VISA": "96",
      "PILGRIM VISA": "96",
      "PAKISTAN SPECIFIC VISAS": "53",
      "WORK VISA": "55",
      "FAMILY VISA": "52",
      "MISCELLANEOUS VISA": "54",
      "TOURIST VISA FIVE YEARS": "57",
      "TOURIST VISA ONE MONTH": "56",
      "E-ENTRY VISA": "44",
      "E-FILM VISA": "45",
      "E-MOUNTAINEERING VISA": "46",
      "E-STUDENT VISA": "42",
      "E-STUDENT X VISA": "43",
      "E-TRANSIT VISA": "47",
      "E-PRODUCTION INVESTMENT VISA": "48",
      "E-FAMILY VISA": "50",
      "E-MISCELLANEOUS VISA": "51",
      "E-EMERGENCY X-MISC VISA": "37"
    };
    if (value.match(/^[0-9]+$/))
      return Object.values(labelToCode).includes(value) ? value : "";
    const norm2 = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
    const key = norm2(value);
    const hit = Object.keys(labelToCode).find((k) => norm2(k) === key);
    return hit ? labelToCode[hit] ?? value : value;
  },
  // Purpose of visit: label -> numeric code
  // VERIFIED: portal uses numeric option values (1=Meeting friends, 16=Tourism, etc.)
  purpose_code: (value) => {
    if (typeof value !== "string") return "";
    const norm2 = (s) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
    const key = norm2(value.trim());
    const labelToCode = {
      // The mobile app's own canonical picker values (stay-details PURPOSES)
      // that differ from the portal's labels — without these, 6 of the 9
      // choices fell through UNTRANSFORMED and the required purpose select
      // could never match them (missing-value on every filing).
      "VISITING FAMILY/FRIENDS": "1",
      // portal: Meeting friends/relatives
      "CONFERENCE/SEMINAR": "4",
      // portal: Seminar/conference in India
      "MEDICAL TREATMENT": "8",
      // portal: Medical treatment of self
      STUDY: "14",
      // portal: Studies
      OTHER: "15",
      // portal: Others
      // NOTE: no RESEARCH entry by design. The portal has no "Research"
      // purpose and the mobile app exposes it as a canonical choice, so
      // silently filing "Others" (15) would record a WRONG purpose on a
      // required legal field. Like every other unresolvable label it
      // pass-throughs and the fill reports missing-value for the host to
      // pick manually (see purpose_code tests).
      "MEETING FRIENDS/RELATIVES": "1",
      "JOINING SPOUSE": "2",
      "MINOR CHILD(EITHER PARENT IS INDIAN)": "3",
      "SEMINAR/CONFERENCE IN INDIA": "4",
      EDUCATION: "5",
      BUSINESS: "6",
      JOURNALISM: "7",
      "MEDICAL TREATMENT OF SELF": "8",
      "ACCOMPANYING PATIENT": "9",
      "ACCOMPANYING PATIENT AS DOCTOR": "10",
      OFFICIAL: "11",
      DIPLOMATIC: "12",
      EMPLOYMENT: "13",
      STUDIES: "14",
      OTHERS: "15",
      TOURISM: "16",
      "ACCOMPANYING SPOUSE": "17",
      "ACCOMPANYING PARENTS": "18",
      INTERNSHIP: "19",
      SURROGACY: "20"
    };
    if (/^\d+$/.test(value))
      return Object.values(labelToCode).includes(value) ? value : "";
    const hit = Object.keys(labelToCode).find((k) => norm2(k) === key);
    return hit ? labelToCode[hit] ?? value : value;
  },
  // Country: alpha-3 code (VERIFIED: portal uses ISO 3166-1 alpha-3 codes as option values)
  country_alpha3: (value) => {
    if (typeof value !== "string") return "";
    const NON_PORTAL_TO_PORTAL = {
      CUW: "ANT",
      BES: "ANT",
      SXM: "ANT",
      RKS: "UNK",
      PYF: "FRA",
      MAF: "FRA"
    };
    if (/^[a-zA-Z]{3}$/.test(value)) {
      const up = value.toUpperCase();
      const code2 = NON_PORTAL_TO_PORTAL[up] ?? up;
      return nationalityOptions.some((o) => o.value === code2) ? code2 : "";
    }
    const code = findCountryCode(value);
    if (code) return code.toUpperCase();
    return "";
  },
  // State: numeric code (VERIFIED: portal uses numeric option values 1-39)
  state_code: (value) => {
    if (typeof value !== "string") return "";
    const labelToCode = {
      "ANDAMAN AND NICOBAR ISLANDS": "1",
      "ANDAMAN & NICOBAR ISLANDS": "1",
      "ANDHRA PRADESH": "2",
      "ARUNACHAL PRADESH": "3",
      ASSAM: "4",
      BIHAR: "5",
      CHHATTISGARH: "6",
      GOA: "9",
      GUJARAT: "10",
      HARYANA: "11",
      "HIMACHAL PRADESH": "12",
      "JAMMU AND KASHMIR": "13",
      "JAMMU & KASHMIR": "13",
      JHARKHAND: "14",
      KARNATAKA: "15",
      KERALA: "16",
      "MADHYA PRADESH": "17",
      MAHARASHTRA: "18",
      MANIPUR: "19",
      MEGHALAYA: "20",
      MIZORAM: "21",
      NAGALAND: "22",
      ODISHA: "23",
      PUDUCHERRY: "24",
      PUNJAB: "25",
      RAJASTHAN: "26",
      SIKKIM: "27",
      "TAMIL NADU": "28",
      TRIPURA: "29",
      "UTTAR PRADESH": "30",
      UTTARAKHAND: "31",
      "WEST BENGAL": "32",
      CHANDIGARH: "34",
      LAKSHADWEEP: "36",
      TELANGANA: "37",
      LADAKH: "38",
      "DADRA AND NAGAR HAVELI AND DAMAN AND DIU": "39",
      "DADRA & NAGAR HAVELI AND DAMAN AND DIU": "39",
      DELHI: "8"
    };
    if (value.match(/^[0-9]+$/))
      return Object.values(labelToCode).includes(value) ? value : "";
    return labelToCode[value.toUpperCase()] ?? findStateCode(value) ?? value;
  },
  // District: pass through (codes are dynamic, loaded via AJAX)
  district_code: (value, ctx) => {
    if (typeof value !== "string" || value === "") return "";
    const field = ctx && ctx.__applyField;
    const stateKey = field === "nextDestinationCityDistrict" ? "nextDestinationState" : "indiaState";
    const stateName = ctx && typeof ctx[stateKey] === "string" ? ctx[stateKey] : void 0;
    const stateCode = stateName && typeof stateName === "string" ? findStateCode(stateName) ?? stateName : void 0;
    if (stateCode) {
      const code = findCityCode(stateCode, value);
      if (code) return code;
    }
    return value;
  },
  string: (value) => {
    if (value === null || value === void 0) return "";
    return asPlainText(value);
  },
  number: (value) => {
    if (value === null || value === void 0) return "";
    if (typeof value === "number" && !Number.isFinite(value)) return "";
    if (typeof value === "string") {
      const s = value.trim();
      if (s === "" || /^(nan|infinity|-?infinity)$/i.test(s)) return "";
      return /^\d+$/.test(s) ? s : "";
    }
    return asPlainText(value);
  }
};
function asPlainText(value) {
  if (typeof value === "string") return value;
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  if (typeof value === "boolean") return String(value);
  return "";
}
function applyTransform(transformName, value, context) {
  const fn = Object.prototype.hasOwnProperty.call(transforms, transformName) ? transforms[transformName] : void 0;
  if (fn) {
    return fn(
      value,
      context
    );
  }
  return asPlainText(value);
}
var APPLICATION_ID_REGEX = /Application[ \t:]*ID[ \t:]*(?:is[ \t:]*|[.][ \t:]*)?([A-Za-z0-9]+)/i;
var NON_ID_TOKENS = /* @__PURE__ */ new Set([
  "undefined",
  "null",
  "nan",
  "is",
  "of",
  "the",
  "not",
  "required",
  "will",
  "be",
  // Prose continuations commonly follow "Application ID <word>" in
  // confirmation/error snippets; without these a token like "needs" or
  // "can" was recorded as a bogus applicationId.
  "needs",
  "need",
  "can",
  "cannot",
  "must",
  "would",
  "should",
  "has",
  "have",
  "was",
  "were",
  "is",
  "are",
  "shown",
  "number",
  "id",
  "letter"
]);
function extractApplicationId(text) {
  const globalRegex = new RegExp(
    APPLICATION_ID_REGEX.source,
    APPLICATION_ID_REGEX.flags + "g"
  );
  for (const match of text.matchAll(globalRegex)) {
    const candidate = match[1];
    if (!candidate) continue;
    const lower = candidate.toLowerCase();
    if (NON_ID_TOKENS.has(lower)) continue;
    if (candidate.length < 3) continue;
    if (candidate.length > 12) continue;
    const conf = text.toLowerCase().replace(/\s+/g, " ");
    const POST_SAVE_MARKERS = [
      "saved permanently",
      "saved successfully",
      "no further changes can be made",
      "application id is",
      "application id:",
      "application id ."
    ];
    if (!POST_SAVE_MARKERS.some((m) => conf.includes(m))) continue;
    return candidate;
  }
  return null;
}

// src/types.ts
var PORTAL_MISMATCH_THRESHOLD = 0.5;

// src/fill.ts
var BUNDLED_REQUIRED = new Set(
  DEFAULT_FORM_MAPPING.mappings.filter((m) => m.required).map((m) => m.appField)
);
var SAFE_SELECTOR_RE = /^[a-zA-Z0-9_\-:. ]+$/;
function sanitizeSelector(value) {
  if (!SAFE_SELECTOR_RE.test(value)) return "";
  return value.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/'/g, "\\'").replace(/;/g, "\\;").replace(/\(/g, "\\(").replace(/\)/g, "\\)").replace(/\]/g, "\\]").replace(/:/g, "\\:").replace(/\./g, "\\.");
}
function resolveSelector(fm) {
  if (fm.by.name) {
    const s = sanitizeSelector(fm.by.name);
    return s ? `[name="${s}"]` : "";
  }
  if (fm.by.id) {
    const s = sanitizeSelector(fm.by.id);
    return s ? `[id="${s}"]` : "";
  }
  if (fm.by.labelText) {
    const s = sanitizeSelector(fm.by.labelText);
    return s ? `label:contains("${s}") + input` : "";
  }
  return "";
}
async function fillField(element, value, control, eventFactory, queryAllRadios, dependsOn) {
  if (!element) return "missing-element";
  if (control === "file") {
    return "manual";
  }
  if (value === void 0 || value === "") return "missing-value";
  const disabledAttr = element.getAttribute?.("disabled");
  const readonlyAttr = element.getAttribute?.("readonly") ?? element.getAttribute?.("readOnly");
  if (disabledAttr != null || readonlyAttr != null || element.type === "hidden")
    return "unverified";
  const norm2 = (s) => (s ?? "").trim().toLowerCase().replace(/\s+/g, " ");
  const tag = element.tagName.toLowerCase();
  if (control === "radio") {
    if (!queryAllRadios) {
      if (norm2(element.value) === norm2(value) && element.click) {
        element.click();
        if (element.checked === false) return "unverified";
        return "filled";
      }
      return "missing-value";
    }
    const radioName = element.name ?? "";
    if (!radioName) return "missing-value";
    const radios = queryAllRadios(radioName);
    if (radios.length === 0) return "missing-element";
    const matching = radios.find((r) => norm2(r.value) === norm2(value));
    if (matching) {
      if (matching.click) {
        matching.click();
        if (!matching.checked) return "unverified";
        return "filled";
      }
    }
    return "missing-value";
  }
  if (tag === "input" || tag === "textarea") {
    let writeValue = value;
    if (element.type === "date") {
      const iso = toNativeDateValue(value);
      if (!iso) return "unverified";
      writeValue = iso;
    }
    const maxLenAttr = element.getAttribute?.("maxlength");
    const maxLen = maxLenAttr ? Number(maxLenAttr) : NaN;
    if (Number.isFinite(maxLen) && maxLen > 0 && value.length > maxLen)
      return "too-long";
    element.value = writeValue;
    element.dispatchEvent(eventFactory("input"));
    element.dispatchEvent(eventFactory("change"));
    element.dispatchEvent(eventFactory("blur"));
    if (element.value === void 0 || norm2(element.value) !== norm2(writeValue))
      return "unverified";
    return "filled";
  }
  if (tag === "select" && element.options) {
    const match = Array.from(element.options).find(
      (opt) => opt.value !== "" && (norm2(opt.text) === norm2(value) || norm2(opt.value) === norm2(value))
    );
    if (match) {
      element.value = match.value;
      element.dispatchEvent(eventFactory("input"));
      element.dispatchEvent(eventFactory("change"));
      element.dispatchEvent(eventFactory("blur"));
      if (norm2(element.value) !== norm2(match.value)) return "unverified";
      if (dependsOn) {
        await new Promise(
          (resolve) => setTimeout(resolve, DEPENDENT_SETTLE_MS)
        );
        if (norm2(element.value) !== norm2(match.value)) {
          const rematch = Array.from(element.options).find(
            (opt) => (
              // Same placeholder exclusion as the primary match (mob-r45-5):
              // a value="" row matched by text would report filled-empty.
              opt.value !== "" && (norm2(opt.text) === norm2(value) || norm2(opt.value) === norm2(value))
            )
          );
          if (!rematch) return "unverified";
          element.value = rematch.value;
          element.dispatchEvent(eventFactory("input"));
          element.dispatchEvent(eventFactory("change"));
          element.dispatchEvent(eventFactory("blur"));
          if (norm2(element.value) !== norm2(rematch.value)) return "unverified";
        }
      }
      return "filled";
    }
    return "missing-value";
  }
  return "unsupported";
}
var DEPENDENT_SETTLE_MS = 500;
function toNativeDateValue(value) {
  const dmy = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(value.trim());
  if (dmy) {
    const [, d = "", m = "", y = ""] = dmy;
    return `${y}-${m.padStart(2, "0")}-${d.padStart(2, "0")}`;
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(value.trim())) return value.trim();
  return null;
}
function sortByDependencies(mappings) {
  const result = [...mappings];
  for (const _ of mappings) {
    let swapped = false;
    for (let i = 0; i < result.length; i++) {
      const entry = result[i];
      if (!entry) continue;
      const dep = entry.dependsOn;
      if (!dep) continue;
      const depPos = result.findIndex((m) => m.appField === dep);
      if (depPos > i) {
        result.splice(depPos, 0, ...result.splice(i, 1));
        swapped = true;
      }
    }
    if (!swapped) break;
  }
  return result;
}
function makeQueryAllRadios(queryAll) {
  return (name) => {
    if (!queryAll) return [];
    const s = sanitizeSelector(name);
    return s ? queryAll(`[name="${s}"]`) : [];
  };
}
async function runFill(payload, mapping, options) {
  const { querySelector, queryAll, waitForDependent, findLabelInput } = options;
  const eventFactory = options.eventFactory ?? ((type) => ({ type }));
  const queryAllRadios = makeQueryAllRadios(queryAll);
  const results = [];
  const sortedMappings = sortByDependencies(mapping.mappings);
  let progressCount = 0;
  for (const m of sortedMappings) {
    const rawValue = payload[m.appField];
    const value = m.transform ? applyTransform(m.transform, rawValue, {
      ...payload,
      __applyField: m.appField
    }) : rawValue;
    if (m.dependsOn && m.control === "select" && waitForDependent && (value || m.required)) {
      try {
        await waitForDependent(m.appField, m.dependsOn);
      } catch {
      }
    }
    let selector = "";
    let element = null;
    let status;
    try {
      if (m.by.labelText && findLabelInput) {
        element = findLabelInput(m.by.labelText);
        selector = `label:"${m.by.labelText}"`;
      } else {
        selector = resolveSelector(m);
        element = selector ? querySelector(selector) : null;
      }
      status = await fillField(
        element,
        value,
        m.control,
        eventFactory,
        queryAllRadios,
        // Settle-reapply only when we actually waited on the parent's AJAX
        // (waitForDependent provided) — the rebuild race is a real-DOM event.
        m.dependsOn && waitForDependent ? m.dependsOn : void 0
      );
    } catch {
      status = "missing-element";
      selector = selector || `(bad-selector: ${m.appField})`;
    }
    results.push({
      field: m.appField,
      selector,
      status,
      // In AGE mode the schema forbids a dateOfBirth and the portal's AG layout
      // uses applicant_age instead — applicant_dob is only required in the
      // DY/MY/YY date formats. Marking it required in age mode made EVERY
      // age-mode filing warn/fallback even though the correct field (age) filled.
      // dobFormat may carry the raw schema value "age" OR the portal code "AG"
      // (dob_format_label) depending on payload provenance — accept both.
      required: m.appField === "dateOfBirth" && // AGE/AG carry only `age`; the schema also allows dobFormat "y" (YY)
      // and "my" (MY) with dateOfBirth absent — those records are
      // schema-valid and must not amber on a required dateOfBirth at every
      // fill (mob-r44-10).
      ["AGE", "AG", "Y", "MY"].includes(
        (payload.dobFormat ?? "").trim().toUpperCase()
      ) ? false : (
        // In AGE/AG mode the portal's required DOB field is `age`
        // (applicant_age), which the mapping marks optional — an empty age
        // would otherwise slip a green fill with the required portal field
        // blank. Force it required so a missing age falls back/ambers.
        m.appField === "age" && ["AGE", "AG"].includes(
          (payload.dobFormat ?? "").trim().toUpperCase()
        ) ? true : m.required || BUNDLED_REQUIRED.has(m.appField)
      ),
      ...m.dependsOn ? { dependsOn: m.dependsOn } : {}
    });
    if (options.onProgress) {
      progressCount += 1;
      options.onProgress({
        completed: progressCount,
        total: sortedMappings.length,
        field: m.appField,
        status
      });
    }
  }
  const filled = results.filter((r) => r.status === "filled").map((r) => r.field);
  const missingElements = results.filter((r) => r.status === "missing-element").map((r) => r.field);
  const missingValues = results.filter((r) => r.status === "missing-value" && r.required).map((r) => r.field);
  const unsupported = results.filter((r) => r.status === "unsupported").map((r) => r.field);
  const manual = results.filter((r) => r.status === "manual").map((r) => r.field);
  const unverified = results.filter((r) => r.status === "unverified").map((r) => r.field);
  const tooLong = results.filter((r) => r.status === "too-long").map((r) => r.field);
  const requiredResults = results.filter(
    (r) => r.required && r.status !== "manual"
  );
  const totalRequired = requiredResults.length;
  const requiredFilled = requiredResults.filter(
    (r) => r.status === "filled"
  ).length;
  const requiredMissingElement = requiredResults.filter(
    (r) => r.status === "missing-element"
  ).length;
  const portalMismatchDetected = totalRequired > 0 && requiredMissingElement / totalRequired > PORTAL_MISMATCH_THRESHOLD;
  const fallbackRecommended = portalMismatchDetected || requiredResults.some((r) => r.status === "missing-value") || requiredResults.some((r) => r.status === "unverified") || requiredResults.some((r) => r.status === "too-long") || requiredResults.some((r) => r.status === "unsupported");
  return {
    filled,
    missingElements,
    missingValues,
    unsupported,
    manual,
    unverified,
    tooLong,
    totalRequired,
    requiredFilled,
    portalMismatchDetected,
    fallbackRecommended
  };
}
function restorePriorValue(element, kind, value, radioName, eventFactory, queryAllRadios) {
  if (!element) return "missing";
  const norm2 = (s) => (s ?? "").trim().toLowerCase().replace(/\s+/g, " ");
  if (kind === "radio") {
    if (value === "" || !radioName) return "unrestorable";
    const matching = queryAllRadios(radioName).find(
      (r) => norm2(r.value) === norm2(value)
    );
    if (!matching?.click) return "unrestorable";
    matching.click();
    return matching.checked === true ? "restored" : "unrestorable";
  }
  if (kind === "select" && element.options) {
    const match = Array.from(element.options).find(
      (opt) => opt.value === value || norm2(opt.text) === norm2(value)
    );
    if (!match) return "unrestorable";
    element.value = match.value;
    element.dispatchEvent(eventFactory("input"));
    element.dispatchEvent(eventFactory("change"));
    element.dispatchEvent(eventFactory("blur"));
    return norm2(element.value) === norm2(match.value) ? "restored" : "unrestorable";
  }
  element.value = value;
  element.dispatchEvent(eventFactory("input"));
  element.dispatchEvent(eventFactory("change"));
  element.dispatchEvent(eventFactory("blur"));
  return element.value === void 0 || norm2(element.value) !== norm2(value) ? "unrestorable" : "restored";
}
function prettifyFieldName(appField) {
  return appField.replace(/([a-z0-9])([A-Z])/g, "$1 $2").replace(/[_-]+/g, " ").trim().replace(/\b\w/g, (c) => c.toUpperCase());
}
var MAX_PASTED_CHARS = 512e3;
function parseClipboardPayload(text) {
  const payload = {};
  for (const line of text.split("\n")) {
    const idx = line.indexOf(": ");
    if (idx <= 0) continue;
    const key = line.slice(0, idx).trim();
    const value = line.slice(idx + 2).trim();
    if (!key || !value || value === "(not provided)") continue;
    if (!(key in payload)) payload[key] = value;
  }
  return payload;
}
function normalizeAccommodationCode(raw) {
  const isLower = (c) => c >= 97 && c <= 122;
  const isUpper = (c) => c >= 65 && c <= 90;
  const isLetter = (c) => isLower(c) || isUpper(c);
  const isDigit = (c) => c >= 48 && c <= 57;
  const isAlnum = (c) => isLetter(c) || isDigit(c);
  const lower = raw.toLowerCase();
  let head = 0;
  while (head < lower.length && isLetter(lower.charCodeAt(head))) head++;
  let k = head;
  let sawSeparator = false;
  while (k < lower.length && !isAlnum(lower.charCodeAt(k))) {
    sawSeparator = true;
    k++;
  }
  const digitAfterPrefix = sawSeparator && k < lower.length && isDigit(lower.charCodeAt(k));
  let alnum = "";
  for (let j = 0; j < lower.length; j++)
    if (isAlnum(lower.charCodeAt(j))) alnum += lower.charAt(j);
  let lead = 0;
  while (lead < alnum.length && alnum.charCodeAt(lead) === 48) lead++;
  const cleaned = alnum.slice(lead) || alnum || lower;
  if (digitAfterPrefix) {
    let p = 0;
    while (p < cleaned.length && isLetter(cleaned.charCodeAt(p))) p++;
    const rest = cleaned.slice(p);
    let allDigits = rest.length > 0;
    for (let q = 0; q < rest.length && allDigits; q++)
      if (!isDigit(rest.charCodeAt(q))) allDigits = false;
    if (allDigits) return rest;
  }
  return cleaned;
}
function extractAccommodation(payload) {
  const accommodationId = payload["hostFrroAccommodationId"] ?? payload["hostAccocod"] ?? payload["frroAccommodationId"] ?? payload["accocod"];
  const establishmentName = payload["hostEstablishmentName"] ?? payload["establishmentName"];
  const result = {};
  if (accommodationId) result.accommodationId = accommodationId;
  if (establishmentName) result.establishmentName = establishmentName;
  return result;
}

// src/content-heavy.ts
var import_qrcode = __toESM(require_browser(), 1);

// src/i18n/en.ts
var en = {
  // popup
  "popup.title": "Cformly Auto-Fill",
  "popup.eyebrow": "Auto-fill",
  "popup.bandSub": "FRRO Form III \xB7 within 24 hours of check-in",
  "popup.fillFromClipboard": "Fill Form from Clipboard",
  "popup.fillHint": "Copy the guest fields from the Cformly app, then fill this portal form.",
  "popup.clipboardReadFailed": "Could not read the clipboard. Check the browser's clipboard permissions.",
  "popup.clipboardEmpty": "The clipboard doesn't contain Cformly fields. Copy the guest fields from the Cformly app first.",
  "popup.settings": "Settings",
  "popup.loadingMapping": "Loading form mapping...",
  "popup.filling": "Filling form...",
  "popup.fillingProgress": "Filling\u2026 field {completed} of {total}",
  "popup.noTab": "No active tab found.",
  "popup.filled": "Required fields filled: {filledRequired} of {required} ({filled} total filled)",
  "popup.portalMismatch": "Portal mismatch detected (DOM changed). Re-copy the guest fields in the Cformly app and retry.",
  "popup.missingElements": "Missing elements: {list}",
  "popup.missingValues": "Missing values: {list}",
  "popup.manualFields": "Manual steps needed: {list}",
  "popup.unsupportedFields": "Fields that cannot be auto-filled: {list}",
  "popup.tooLongFields": "Values too long for these fields \u2014 nothing was written, type a shorter value: {list}",
  "popup.unverifiedFields": "Check these fields \u2014 the value may not have stuck: {list}",
  "popup.applicationId": "Application ID: {id}",
  "popup.accommodationMismatch": "WARNING: The FRRO session may be for a different property. Verify before submitting.",
  "popup.attention": "Some fields need attention. Re-copy the guest fields in the Cformly app and retry.",
  "popup.openPrint": "Open Individual Print",
  "popup.printNoId": "No Application ID captured yet \u2014 fill the form first.",
  "popup.printSent": "Reopened the filed application for ID {id}. Use the portal's Individual Print menu to download the PDF.",
  "popup.formFilled": "Form filled. Review and submit on the portal.",
  "popup.fillError": "Fill error: {message}",
  "popup.connectionFailed": "Could not reach the FRRO portal page. Open the Form III page in this tab and try again.",
  "popup.unknownError": "unknown",
  "popup.apiBaseFallback": "Warning: the stored API URL is invalid \u2014 using the default. Update it in Settings.",
  "popup.mappingFallback": "Warning: the mapping server is unreachable \u2014 using the built-in field map, which may be outdated.",
  "popup.pasteLabel": "Or paste the fields here",
  "popup.pdfPick": "Open the Cformly PDF",
  "popup.pdfLoaded": "Guest fields loaded from the Cformly PDF \u2014 review below, then press Fill Form.",
  "popup.pdfRejected": "That PDF doesn't carry Cformly fields or couldn't be read \u2014 use the summary PDF exported by the Cformly app.",
  "popup.pastePlaceholder": "Paste the copied Cformly fields here",
  "popup.pasteHint": "If the clipboard button fails, paste the fields you sent to this computer (or drop the text file here), then press Fill.",
  "popup.payloadTooLarge": "The pasted text is too large \u2014 paste only the fields copied from the Cformly app.",
  // in-page filing panel
  "panel.title": "Cformly \u2014 finish filing on the portal",
  "panel.dismiss": "Close",
  "panel.filled": "Fields filled: {filledRequired} of {required} required",
  "panel.photoStep": "Attach the guest photo (Choose File \u2192 Upload)",
  "panel.captchaStep": "Type the security code (CAPTCHA)",
  "panel.saveStep": "Press Save and Continue",
  "panel.warnSession": "Cformly warning: this FRRO session may be for a DIFFERENT property ({reason}). Verify before saving.",
  "panel.warnUnverified": "Cformly warning: values may not have stuck for: {list}. Verify before saving.",
  "panel.saving": "Waiting for the portal's confirmation\u2026",
  "panel.progress": "Filling fields\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO session expired \u2014 log in again, reopen the form and press Fill. Your guest details are still saved in the Cformly app.",
  "panel.portalError": "The portal reported:",
  "panel.appIdFound": "Filed successfully. Application ID:",
  "panel.scanHint": "Open the Cformly app \u2192 Push to Portal \u2192 Scan from Computer and point it at this code \u2014 or copy the ID.",
  "panel.copy": "Copy Application ID",
  "panel.copied": "Copied.",
  "panel.confirmNotDetected": "No confirmation detected \u2014 check whether the portal saved, then continue.",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "Drop the guest photo here to attach it",
  "panel.photoBrowse": "Browse\u2026",
  "panel.photoAttachFailed": "Could not attach automatically \u2014 use the portal's own Choose File button.",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "Fill this form with Cformly",
  "chip.hint": "Paste the guest fields you sent to this computer (or drop the text file here), then press Fill Form.",
  "chip.fill": "Fill Form",
  "chip.filling": "Filling\u2026",
  "chip.empty": "Nothing to fill \u2014 paste the guest fields copied from the Cformly app first.",
  "chip.tooLarge": "The pasted text is too large \u2014 paste only the fields copied from the Cformly app.",
  "chip.collapse": "Close",
  "chip.mappingFallback": "Note: the mapping server is unreachable \u2014 using the built-in field map, which may be outdated.",
  // round-66: popup first-run onboarding
  "onboarding.title": "First time here? Three steps:",
  "onboarding.step1": "On your phone: open the guest \u2192 Push to Portal \u2192 Send to Computer.",
  "onboarding.step2": "On this computer: paste the fields you sent yourself into the box below (or press the blue Cformly button on the form page).",
  "onboarding.step3": "Press Fill Form \u2014 the portal form fills itself. You do the photo, the security code, and Save.",
  "onboarding.done": "Got it",
  // settings
  "settings.title": "Cformly Settings",
  "settings.eyebrow": "Settings",
  "settings.bandSub": "Configure the backend that serves form mappings.",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "The backend that serves form mappings. HTTPS only; localhost works only in development builds.",
  "settings.save": "Save",
  "settings.back": "Back",
  "settings.backInTab": "Settings opened as a tab \u2014 use the Cformly toolbar icon to open the fill popup.",
  "settings.urlEmpty": "URL cannot be empty.",
  "settings.httpsOnly": "Only HTTPS URLs are allowed for security. Use https:// for production.",
  "settings.hostNotAllowed": "URL hostname must be localhost or *.cformly.com (got {host}).",
  "settings.invalidUrl": "Invalid URL. Include https://",
  "settings.urlPathNotAllowed": "Use the bare origin only \u2014 remove the path, query, and #fragment.",
  "settings.loopbackNotGranted": "Localhost API URLs only work in development builds. This build can only reach https:// hosts.",
  "settings.saved": "Saved.",
  "settings.saveError": "Couldn't save. Try again.",
  "settings.langLabel": "Language",
  "settings.langEnglish": "English",
  "settings.langHindi": "\u0939\u093F\u0928\u094D\u0926\u0940",
  "settings.langAuto": "Follow browser",
  "settings.langHint": "Defaults to your browser language until you choose.",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{filled} of {total} fields were filled at {time}. Resume to fill them again.",
  "resume.button": "Resume fill",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "This portal page doesn't look like the Form III Cformly knows \u2014 the portal may have changed. Copy the guest fields from the Cformly app and fill them manually this time; we'll catch up.",
  "canary.detail": "Cformly recognized only {found} of {total} known form fields on this page.",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "Guest queue",
  "queue.add": "Add to Queue",
  "queue.fill": "Fill",
  "queue.remove": "Remove",
  "queue.unnamed": "Guest",
  "queue.added": "Added {name} to the queue.",
  "queue.duplicate": "This guest is already in the queue.",
  "queue.full": "The queue is full ({max} guests). File or remove a guest first.",
  "queue.hint": "Guests waiting to be filed. A complete fill removes the guest from the queue; the queue clears when the browser closes.",
  "queue.unavailable": "The guest queue is unavailable in this browser.",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "This FRRO tab was opened before Cformly was installed or updated. Reload this tab once (F5), then press Fill.",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "Form mapping",
  "settings.mapVersion": "Version",
  "settings.mapLastVerified": "Last verified",
  "settings.mapFetchedAt": "Fetched",
  "settings.mapSignature": "Ed25519 signature",
  "settings.mapRefresh": "Refresh now",
  "settings.mapRefreshed": "Mapping refreshed.",
  "settings.mapRefreshFailed": "Could not refresh the mapping - using the best available copy.",
  "settings.mapStatusRemote": "VERIFIED - live copy fetched from the mapping server.",
  "settings.mapStatusCached": "VERIFIED - recently cached copy.",
  "settings.mapStatusBundled": "Built-in baseline copy (server unreachable). Signature intact.",
  "settings.mapStatusTampered": "SIGNATURE CHECK FAILED - this copy is rejected and not in use.",
  // roadmap 160: honest worker-unavailable error (no CORS-doomed fetch fallback)
  "chip.mappingUnavailable": "Cformly could not load the form mapping - the extension background worker did not respond. Reload the portal tab and retry.",
  // roadmap 161: staged fill deadlines (which stage failed)
  "popup.timeoutMapping": "Timed out loading the form mapping ({seconds}s). Check the connection and retry.",
  "popup.timeoutNoProgress": "The fill did not start within {seconds}s - the Form III page is not responding. Reload the tab and retry.",
  "popup.timeoutStalled": "The fill stalled for {seconds}s with no progress - the Form III page stopped responding.",
  "popup.timeoutCap": "The fill passed the overall time limit ({seconds}s) and was stopped.",
  // roadmap 162: fill preview (dry-run diff)
  "popup.preview": "Preview Changes",
  "popup.previewApply": "Apply - Fill the Form",
  "popup.undo": "Undo Last Fill",
  "popup.undoDone": "Restored {restored} of {total} fields to their prior values.",
  "popup.undoPartial": "Restored {restored} of {total} fields; {failed} could not be restored (the page may have re-rendered).",
  "popup.undoStale": "The page changed since the fill \u2014 the restore may be incomplete.",
  "popup.undoNone": "Nothing to undo \u2014 no fill has been made on this tab in this session.",
  "popup.previewUnresolved": "not found on this page",
  "popup.previewManual": "manual step",
  "popup.previewNoValue": "(not provided)"
};

// src/i18n/hi.ts
var hi = {
  // popup
  "popup.title": "Cformly \u0911\u091F\u094B-\u092B\u093C\u093F\u0932",
  "popup.eyebrow": "\u0911\u091F\u094B-\u092B\u093C\u093F\u0932",
  "popup.bandSub": "FRRO Form III \xB7 \u091A\u0947\u0915-\u0907\u0928 \u0915\u0947 24 \u0918\u0902\u091F\u0947 \u0915\u0947 \u092D\u0940\u0924\u0930",
  "popup.fillFromClipboard": "\u0915\u094D\u0932\u093F\u092A\u092C\u094B\u0930\u094D\u0921 \u0938\u0947 \u092B\u093C\u0949\u0930\u094D\u092E \u092D\u0930\u0947\u0902",
  "popup.fillHint": "\u092A\u0939\u0932\u0947 Cformly \u0910\u092A \u0938\u0947 \u0905\u0924\u093F\u0925\u093F \u092B\u093C\u0940\u0932\u094D\u0921 \u0915\u0949\u092A\u0940 \u0915\u0930\u0947\u0902, \u092B\u093F\u0930 \u092F\u0939 \u092A\u094B\u0930\u094D\u091F\u0932 \u092B\u093C\u0949\u0930\u094D\u092E \u092D\u0930\u0947\u0902\u0964",
  "popup.clipboardReadFailed": "\u0915\u094D\u0932\u093F\u092A\u092C\u094B\u0930\u094D\u0921 \u092A\u0922\u093C\u093E \u0928\u0939\u0940\u0902 \u091C\u093E \u0938\u0915\u093E\u0964 \u092C\u094D\u0930\u093E\u0909\u091C\u093C\u0930 \u0915\u0940 \u0915\u094D\u0932\u093F\u092A\u092C\u094B\u0930\u094D\u0921 \u0905\u0928\u0941\u092E\u0924\u093F\u092F\u093E\u0901 \u091C\u093E\u0901\u091A\u0947\u0902\u0964",
  "popup.clipboardEmpty": "\u0915\u094D\u0932\u093F\u092A\u092C\u094B\u0930\u094D\u0921 \u092E\u0947\u0902 Cformly \u092B\u093C\u0940\u0932\u094D\u0921 \u0928\u0939\u0940\u0902 \u0939\u0948\u0902\u0964 \u092A\u0939\u0932\u0947 Cformly \u0910\u092A \u0938\u0947 \u0905\u0924\u093F\u0925\u093F \u092B\u093C\u0940\u0932\u094D\u0921 \u0915\u0949\u092A\u0940 \u0915\u0930\u0947\u0902\u0964",
  "popup.settings": "\u0938\u0947\u091F\u093F\u0902\u0917\u094D\u0938",
  "popup.loadingMapping": "\u092B\u093C\u0949\u0930\u094D\u092E \u092E\u0948\u092A\u093F\u0902\u0917 \u0932\u094B\u0921 \u0939\u094B \u0930\u0939\u0940 \u0939\u0948...",
  "popup.filling": "\u092B\u093C\u0949\u0930\u094D\u092E \u092D\u0930\u093E \u091C\u093E \u0930\u0939\u093E \u0939\u0948...",
  "popup.fillingProgress": "\u092D\u0930\u093E \u091C\u093E \u0930\u0939\u093E \u0939\u0948\u2026 \u092B\u093C\u0940\u0932\u094D\u0921 {completed}/{total}",
  "popup.noTab": "\u0915\u094B\u0908 \u0938\u0915\u094D\u0930\u093F\u092F \u091F\u0948\u092C \u0928\u0939\u0940\u0902 \u092E\u093F\u0932\u093E\u0964",
  "popup.filled": "\u0906\u0935\u0936\u094D\u092F\u0915 \u092B\u093C\u0940\u0932\u094D\u0921 \u092D\u0930\u0947 \u0917\u090F: {required} \u092E\u0947\u0902 \u0938\u0947 {filledRequired} ({filled} \u0915\u0941\u0932 \u092D\u0930\u0947 \u0917\u090F)",
  "popup.portalMismatch": "\u092A\u094B\u0930\u094D\u091F\u0932 \u092C\u0926\u0932\u093E\u0935 \u0915\u093E \u092A\u0924\u093E \u091A\u0932\u093E (DOM \u092C\u0926\u0932\u093E \u0939\u0941\u0906 \u0939\u0948)\u0964 Cformly \u0910\u092A \u092E\u0947\u0902 \u0905\u0924\u093F\u0925\u093F \u092B\u093C\u0940\u0932\u094D\u0921 \u092B\u093F\u0930 \u0938\u0947 \u0915\u0949\u092A\u0940 \u0915\u0930\u0947\u0902 \u0914\u0930 \u092A\u0941\u0928\u0903 \u092A\u094D\u0930\u092F\u093E\u0938 \u0915\u0930\u0947\u0902\u0964",
  "popup.missingElements": "\u0932\u093E\u092A\u0924\u093E \u0924\u0924\u094D\u0935: {list}",
  "popup.missingValues": "\u0932\u093E\u092A\u0924\u093E \u092E\u093E\u0928: {list}",
  "popup.manualFields": "\u092E\u0948\u0928\u094D\u092F\u0941\u0905\u0932 \u091A\u0930\u0923 \u0906\u0935\u0936\u094D\u092F\u0915: {list}",
  "popup.unsupportedFields": "\u0938\u094D\u0935\u0924\u0903 \u092D\u0930\u0947 \u091C\u093E\u0928\u0947 \u092E\u0947\u0902 \u0905\u0938\u092E\u0930\u094D\u0925 \u092B\u093C\u0940\u0932\u094D\u0921: {list}",
  "popup.unverifiedFields": "\u0907\u0928 \u092B\u093C\u0940\u0932\u094D\u0921 \u0915\u0940 \u091C\u093E\u0901\u091A \u0915\u0930\u0947\u0902 \u2014 \u092E\u093E\u0928 \u0936\u093E\u092F\u0926 \u0928\u0939\u0940\u0902 \u091A\u093F\u092A\u0915\u0947: {list}",
  "popup.tooLongFields": "\u0907\u0928 \u092B\u093C\u0940\u0932\u094D\u0921 \u0915\u0947 \u092E\u093E\u0928 \u092C\u0939\u0941\u0924 \u0932\u0902\u092C\u0947 \u0939\u0948\u0902 \u2014 \u0915\u0941\u091B \u092D\u0940 \u0928\u0939\u0940\u0902 \u0932\u093F\u0916\u093E \u0917\u092F\u093E, \u091B\u094B\u091F\u093E \u092E\u093E\u0928 \u091F\u093E\u0907\u092A \u0915\u0930\u0947\u0902: {list}",
  "popup.applicationId": "\u0906\u0935\u0947\u0926\u0928 \u0906\u0908\u0921\u0940: {id}",
  "popup.accommodationMismatch": "\u091A\u0947\u0924\u093E\u0935\u0928\u0940: FRRO \u0938\u0924\u094D\u0930 \u0915\u093F\u0938\u0940 \u092D\u093F\u0928\u094D\u0928 \u0938\u0902\u092A\u0924\u094D\u0924\u093F \u0915\u0947 \u0932\u093F\u090F \u0939\u094B \u0938\u0915\u0924\u093E \u0939\u0948\u0964 \u091C\u092E\u093E \u0915\u0930\u0928\u0947 \u0938\u0947 \u092A\u0939\u0932\u0947 \u0938\u0924\u094D\u092F\u093E\u092A\u093F\u0924 \u0915\u0930\u0947\u0902\u0964",
  "popup.attention": "\u0915\u0941\u091B \u092B\u093C\u0940\u0932\u094D\u0921 \u092A\u0930 \u0927\u094D\u092F\u093E\u0928 \u0926\u0947\u0928\u0947 \u0915\u0940 \u091C\u093C\u0930\u0942\u0930\u0924 \u0939\u0948\u0964 Cformly \u0910\u092A \u092E\u0947\u0902 \u0905\u0924\u093F\u0925\u093F \u092B\u093C\u0940\u0932\u094D\u0921 \u092B\u093F\u0930 \u0938\u0947 \u0915\u0949\u092A\u0940 \u0915\u0930\u0947\u0902 \u0914\u0930 \u092A\u0941\u0928\u0903 \u092A\u094D\u0930\u092F\u093E\u0938 \u0915\u0930\u0947\u0902\u0964",
  "popup.openPrint": "\u0935\u094D\u092F\u0915\u094D\u0924\u093F\u0917\u0924 \u092A\u094D\u0930\u093F\u0902\u091F \u0916\u094B\u0932\u0947\u0902",
  "popup.printNoId": "\u0905\u092D\u0940 \u0924\u0915 \u0915\u094B\u0908 \u0906\u0935\u0947\u0926\u0928 \u0906\u0908\u0921\u0940 \u0915\u0948\u092A\u094D\u091A\u0930 \u0928\u0939\u0940\u0902 \u0939\u0941\u0908 \u2014 \u092A\u0939\u0932\u0947 \u092B\u093C\u0949\u0930\u094D\u092E \u092D\u0930\u0947\u0902\u0964",
  "popup.printSent": "\u0906\u0935\u0947\u0926\u0928 \u0906\u0908\u0921\u0940 {id} \u0915\u0947 \u0932\u093F\u090F \u0926\u093E\u092F\u0930 \u0906\u0935\u0947\u0926\u0928 \u092B\u093F\u0930 \u0938\u0947 \u0916\u094B\u0932\u093E \u0917\u092F\u093E\u0964 \u092A\u0940\u0921\u0940\u090F\u092B \u0921\u093E\u0909\u0928\u0932\u094B\u0921 \u0915\u0930\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u092A\u094B\u0930\u094D\u091F\u0932 \u0915\u0947 \u0935\u094D\u092F\u0915\u094D\u0924\u093F\u0917\u0924 \u092A\u094D\u0930\u093F\u0902\u091F \u092E\u0947\u0928\u0942 \u0915\u093E \u0909\u092A\u092F\u094B\u0917 \u0915\u0930\u0947\u0902\u0964",
  "popup.formFilled": "\u092B\u093C\u0949\u0930\u094D\u092E \u092D\u0930 \u0917\u092F\u093E\u0964 \u092A\u094B\u0930\u094D\u091F\u0932 \u092A\u0930 \u0938\u092E\u0940\u0915\u094D\u0937\u093E \u0915\u0930\u0947\u0902 \u0914\u0930 \u091C\u092E\u093E \u0915\u0930\u0947\u0902\u0964",
  "popup.fillError": "\u092D\u0930\u0928\u0947 \u092E\u0947\u0902 \u0924\u094D\u0930\u0941\u091F\u093F: {message}",
  "popup.connectionFailed": "FRRO \u092A\u094B\u0930\u094D\u091F\u0932 \u092A\u0947\u091C \u0924\u0915 \u0928\u0939\u0940\u0902 \u092A\u0939\u0941\u0902\u091A\u093E \u091C\u093E \u0938\u0915\u093E\u0964 \u0907\u0938 \u091F\u0948\u092C \u092E\u0947\u0902 Form III \u092A\u0947\u091C \u0916\u094B\u0932\u0947\u0902 \u0914\u0930 \u092B\u093F\u0930 \u0938\u0947 \u092A\u094D\u0930\u092F\u093E\u0938 \u0915\u0930\u0947\u0902\u0964",
  "popup.unknownError": "\u0905\u091C\u094D\u091E\u093E\u0924",
  "popup.apiBaseFallback": "\u091A\u0947\u0924\u093E\u0935\u0928\u0940: \u0938\u0902\u0917\u094D\u0930\u0939\u0940\u0924 API URL \u0905\u092E\u093E\u0928\u094D\u092F \u0939\u0948 \u2014 \u0921\u093F\u092B\u093C\u0949\u0932\u094D\u091F \u0909\u092A\u092F\u094B\u0917 \u0915\u093F\u092F\u093E \u091C\u093E \u0930\u0939\u093E \u0939\u0948\u0964 \u0938\u0947\u091F\u093F\u0902\u0917\u094D\u0938 \u092E\u0947\u0902 \u0907\u0938\u0947 \u0905\u092A\u0921\u0947\u091F \u0915\u0930\u0947\u0902\u0964",
  "popup.mappingFallback": "\u091A\u0947\u0924\u093E\u0935\u0928\u0940: \u092E\u0948\u092A\u093F\u0902\u0917 \u0938\u0930\u094D\u0935\u0930 \u0905\u0928\u0941\u092A\u0932\u092C\u094D\u0927 \u0939\u0948 \u2014 \u0905\u0902\u0924\u0930\u094D\u0928\u093F\u0939\u093F\u0924 \u092B\u093C\u0940\u0932\u094D\u0921 \u092E\u0948\u092A \u0909\u092A\u092F\u094B\u0917 \u0915\u093F\u092F\u093E \u091C\u093E \u0930\u0939\u093E \u0939\u0948, \u091C\u094B \u092A\u0941\u0930\u093E\u0928\u093E \u0939\u094B \u0938\u0915\u0924\u093E \u0939\u0948\u0964",
  // settings
  "settings.title": "Cformly \u0938\u0947\u091F\u093F\u0902\u0917\u094D\u0938",
  "settings.eyebrow": "\u0938\u0947\u091F\u093F\u0902\u0917\u094D\u0938",
  "settings.bandSub": "\u092B\u093C\u0949\u0930\u094D\u092E \u092E\u0948\u092A\u093F\u0902\u0917 \u0926\u0947\u0928\u0947 \u0935\u093E\u0932\u0947 \u092C\u0948\u0915\u090F\u0902\u0921 \u0915\u094B \u0915\u0949\u0928\u094D\u092B\u093C\u093F\u0917\u0930 \u0915\u0930\u0947\u0902\u0964",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "\u092F\u0939 \u092C\u0948\u0915\u090F\u0902\u0921 \u092B\u093C\u0949\u0930\u094D\u092E \u092E\u0948\u092A\u093F\u0902\u0917 \u0909\u092A\u0932\u092C\u094D\u0927 \u0915\u0930\u093E\u0924\u093E \u0939\u0948\u0964 \u0915\u0947\u0935\u0932 HTTPS; localhost \u0915\u0947\u0935\u0932 \u0921\u0947\u0935\u0932\u092A\u092E\u0947\u0902\u091F \u092C\u093F\u0932\u094D\u0921 \u092E\u0947\u0902 \u0915\u093E\u092E \u0915\u0930\u0924\u093E \u0939\u0948\u0964",
  "settings.save": "\u0938\u0939\u0947\u091C\u0947\u0902",
  "settings.back": "\u0935\u093E\u092A\u0938",
  "settings.backInTab": "\u0938\u0947\u091F\u093F\u0902\u0917\u094D\u0938 \u090F\u0915 \u091F\u0948\u092C \u0915\u0947 \u0930\u0942\u092A \u092E\u0947\u0902 \u0916\u0941\u0932\u0940 \u0939\u0948 \u2014 \u092B\u093C\u093F\u0932 \u092A\u0949\u092A\u0905\u092A \u0915\u0947 \u0932\u093F\u090F Cformly \u091F\u0942\u0932\u092C\u093E\u0930 \u0906\u0907\u0915\u0928 \u0915\u093E \u0909\u092A\u092F\u094B\u0917 \u0915\u0930\u0947\u0902\u0964",
  "settings.urlEmpty": "URL \u0916\u093E\u0932\u0940 \u0928\u0939\u0940\u0902 \u0939\u094B \u0938\u0915\u0924\u093E\u0964",
  "settings.httpsOnly": "\u0938\u0941\u0930\u0915\u094D\u0937\u093E \u0915\u0947 \u0932\u093F\u090F \u0915\u0947\u0935\u0932 HTTPS URL \u0915\u0940 \u0905\u0928\u0941\u092E\u0924\u093F \u0939\u0948\u0964 \u092A\u094D\u0930\u094B\u0921\u0915\u094D\u0936\u0928 \u0915\u0947 \u0932\u093F\u090F https:// \u0909\u092A\u092F\u094B\u0917 \u0915\u0930\u0947\u0902\u0964",
  "settings.hostNotAllowed": "URL \u0939\u094B\u0938\u094D\u091F\u0928\u093E\u092E localhost \u092F\u093E *.cformly.com \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F (\u092A\u094D\u0930\u093E\u092A\u094D\u0924: {host})\u0964",
  "settings.invalidUrl": "\u0905\u092E\u093E\u0928\u094D\u092F URL\u0964 https:// \u0936\u093E\u092E\u093F\u0932 \u0915\u0930\u0947\u0902",
  "settings.urlPathNotAllowed": "\u0915\u0947\u0935\u0932 \u092E\u0942\u0932 origin \u0909\u092A\u092F\u094B\u0917 \u0915\u0930\u0947\u0902 \u2014 path, query \u0914\u0930 #fragment \u0939\u091F\u093E\u090F\u0901\u0964",
  "settings.loopbackNotGranted": "Localhost API URL \u0915\u0947\u0935\u0932 \u0921\u0947\u0935\u0932\u092A\u092E\u0947\u0902\u091F \u092C\u093F\u0932\u094D\u0921 \u092E\u0947\u0902 \u0915\u093E\u092E \u0915\u0930\u0924\u0947 \u0939\u0948\u0902\u0964 \u092F\u0939 \u092C\u093F\u0932\u094D\u0921 \u0915\u0947\u0935\u0932 https:// \u0939\u094B\u0938\u094D\u091F \u0924\u0915 \u092A\u0939\u0941\u0901\u091A \u0938\u0915\u0924\u093E \u0939\u0948\u0964",
  "settings.saved": "\u0938\u0939\u0947\u091C\u093E \u0917\u092F\u093E\u0964",
  "settings.saveError": "\u0938\u0939\u0947\u091C\u093E \u0928\u0939\u0940\u0902 \u091C\u093E \u0938\u0915\u093E\u0964 \u092B\u093F\u0930 \u0938\u0947 \u092A\u094D\u0930\u092F\u093E\u0938 \u0915\u0930\u0947\u0902\u0964",
  "settings.langLabel": "\u092D\u093E\u0937\u093E",
  "settings.langEnglish": "\u0905\u0902\u0917\u094D\u0930\u0947\u091C\u093C\u0940",
  "settings.langHindi": "\u0939\u093F\u0928\u094D\u0926\u0940",
  "settings.langAuto": "\u092C\u094D\u0930\u093E\u0909\u091C\u093C\u0930 \u092D\u093E\u0937\u093E",
  "settings.langHint": "\u091A\u0941\u0928\u0928\u0947 \u0924\u0915 \u0906\u092A\u0915\u0940 \u092C\u094D\u0930\u093E\u0909\u091C\u093C\u0930 \u092D\u093E\u0937\u093E \u0909\u092A\u092F\u094B\u0917 \u0939\u094B\u0917\u0940\u0964",
  // round-65: paste intake + in-page filing panel
  "popup.pasteLabel": "\u092F\u093E \u092B\u093C\u0940\u0932\u094D\u0921 \u092F\u0939\u093E\u0901 \u091A\u093F\u092A\u0915\u093E\u090F\u0901",
  "popup.pdfPick": "Cformly PDF \u0916\u094B\u0932\u0947\u0902",
  "popup.pdfLoaded": "\u092E\u0947\u0939\u092E\u093E\u0928 \u0915\u0947 \u092B\u093C\u0940\u0932\u094D\u0921 Cformly PDF \u0938\u0947 \u0932\u094B\u0921 \u0939\u0941\u090F \u2014 \u0928\u0940\u091A\u0947 \u091C\u093E\u0901\u091A\u0947\u0902, \u092B\u093F\u0930 Fill Form \u0926\u092C\u093E\u090F\u0901\u0964",
  "popup.pdfRejected": "\u0907\u0938 PDF \u092E\u0947\u0902 Cformly \u092B\u093C\u0940\u0932\u094D\u0921 \u0928\u0939\u0940\u0902 \u0939\u0948\u0902 \u092F\u093E \u0935\u0939 \u092A\u0922\u093C\u0940 \u0928\u0939\u0940\u0902 \u091C\u093E \u0938\u0915\u0940 \u2014 Cformly \u0910\u092A \u0938\u0947 \u0928\u093F\u0930\u094D\u092F\u093E\u0924 \u0915\u0940 \u0917\u0908 PDF \u0939\u0940 \u0907\u0938\u094D\u0924\u0947\u092E\u093E\u0932 \u0915\u0930\u0947\u0902\u0964",
  "popup.pastePlaceholder": "\u0915\u0949\u092A\u0940 \u0915\u0940 \u0917\u0908 Cformly \u092B\u093C\u0940\u0932\u094D\u0921 \u092F\u0939\u093E\u0901 \u091A\u093F\u092A\u0915\u093E\u090F\u0901",
  "popup.pasteHint": "\u0905\u0917\u0930 \u0915\u094D\u0932\u093F\u092A\u092C\u094B\u0930\u094D\u0921 \u092C\u091F\u0928 \u0915\u093E\u092E \u0928 \u0915\u0930\u0947, \u0924\u094B \u0907\u0938 \u0915\u0902\u092A\u094D\u092F\u0942\u091F\u0930 \u092A\u0930 \u092D\u0947\u091C\u0940 \u092B\u093C\u0940\u0932\u094D\u0921 \u092F\u0939\u093E\u0901 \u091A\u093F\u092A\u0915\u093E\u090F\u0901 (\u092F\u093E \u091F\u0947\u0915\u094D\u0938\u094D\u091F \u092B\u093C\u093E\u0907\u0932 \u091B\u094B\u0921\u093C\u0947\u0902), \u092B\u093F\u0930 \u092D\u0930\u0947\u0902 \u0926\u092C\u093E\u090F\u0901\u0964",
  "popup.payloadTooLarge": "\u091A\u093F\u092A\u0915\u093E\u092F\u093E \u0917\u092F\u093E \u091F\u0947\u0915\u094D\u0938\u094D\u091F \u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E \u0939\u0948 \u2014 \u0915\u0947\u0935\u0932 Cformly \u0910\u092A \u0938\u0947 \u0915\u0949\u092A\u0940 \u0915\u0940 \u0917\u0908 \u092B\u093C\u0940\u0932\u094D\u0921 \u091A\u093F\u092A\u0915\u093E\u090F\u0901\u0964",
  "panel.title": "Cformly \u2014 \u092A\u094B\u0930\u094D\u091F\u0932 \u092A\u0930 \u092B\u093C\u093E\u0907\u0932\u093F\u0902\u0917 \u092A\u0942\u0930\u0940 \u0915\u0930\u0947\u0902",
  "panel.dismiss": "\u092C\u0902\u0926 \u0915\u0930\u0947\u0902",
  "panel.filled": "\u092B\u093C\u0940\u0932\u094D\u0921 \u092D\u0930\u0940 \u0917\u0908\u0902: {filledRequired} / {required} \u0905\u0928\u093F\u0935\u093E\u0930\u094D\u092F",
  "panel.photoStep": "\u0905\u0924\u093F\u0925\u093F \u0915\u0940 \u092B\u093C\u094B\u091F\u094B \u0932\u0917\u093E\u090F\u0901 (\u092B\u093C\u093E\u0907\u0932 \u091A\u0941\u0928\u0947\u0902 \u2192 \u0905\u092A\u0932\u094B\u0921 \u0915\u0930\u0947\u0902)",
  "panel.captchaStep": "\u0938\u0941\u0930\u0915\u094D\u0937\u093E \u0915\u094B\u0921 (CAPTCHA) \u091F\u093E\u0907\u092A \u0915\u0930\u0947\u0902",
  "panel.saveStep": "\u0938\u0939\u0947\u091C\u0947\u0902 \u0914\u0930 \u091C\u093E\u0930\u0940 \u0930\u0916\u0947\u0902 \u0926\u092C\u093E\u090F\u0901",
  "panel.warnSession": "Cformly \u091A\u0947\u0924\u093E\u0935\u0928\u0940: \u092F\u0939 FRRO \u0938\u0924\u094D\u0930 \u0915\u093F\u0938\u0940 \u0926\u0942\u0938\u0930\u0940 \u092A\u094D\u0930\u0949\u092A\u0930\u094D\u091F\u0940 \u0915\u093E \u0939\u094B \u0938\u0915\u0924\u093E \u0939\u0948 ({reason})\u0964 \u0938\u0939\u0947\u091C\u0928\u0947 \u0938\u0947 \u092A\u0939\u0932\u0947 \u091C\u093E\u0901\u091A \u0932\u0947\u0902\u0964",
  "panel.warnUnverified": "Cformly \u091A\u0947\u0924\u093E\u0935\u0928\u0940: \u0907\u0928 \u092B\u093C\u0940\u0932\u094D\u0921 \u0915\u0947 \u092E\u093E\u0928 \u091F\u093F\u0915\u0947 \u0928\u0939\u0940\u0902 \u0939\u094B \u0938\u0915\u0924\u0947: {list}\u0964 \u0938\u0939\u0947\u091C\u0928\u0947 \u0938\u0947 \u092A\u0939\u0932\u0947 \u091C\u093E\u0901\u091A \u0932\u0947\u0902\u0964",
  "panel.saving": "\u092A\u094B\u0930\u094D\u091F\u0932 \u0915\u0940 \u092A\u0941\u0937\u094D\u091F\u093F \u0915\u0940 \u092A\u094D\u0930\u0924\u0940\u0915\u094D\u0937\u093E\u2026",
  "panel.progress": "\u092B\u093C\u0940\u0932\u094D\u0921 \u092D\u0930\u0947 \u091C\u093E \u0930\u0939\u0947 \u0939\u0948\u0902\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO \u0938\u0924\u094D\u0930 \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u094B \u0917\u092F\u093E \u0939\u0948 \u2014 \u0926\u094B\u092C\u093E\u0930\u093E \u0932\u0949\u0917 \u0907\u0928 \u0915\u0930\u0947\u0902, \u092B\u093C\u0949\u0930\u094D\u092E \u0916\u094B\u0932\u0915\u0930 Fill \u0926\u092C\u093E\u090F\u0901\u0964 \u0906\u092A\u0915\u0947 \u092E\u0947\u0939\u092E\u093E\u0928 \u0915\u093E \u0935\u093F\u0935\u0930\u0923 Cformly \u0910\u092A \u092E\u0947\u0902 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0939\u0948\u0964",
  "panel.portalError": "\u092A\u094B\u0930\u094D\u091F\u0932 \u0928\u0947 \u0938\u092E\u0938\u094D\u092F\u093E \u092C\u0924\u093E\u0908:",
  "panel.appIdFound": "\u0938\u092B\u0932\u0924\u093E\u092A\u0942\u0930\u094D\u0935\u0915 \u092B\u093C\u093E\u0907\u0932 \u0939\u0941\u0908\u0964 \u0906\u0935\u0947\u0926\u0928 \u0906\u0908\u0921\u0940:",
  "panel.scanHint": "Cformly \u0910\u092A \u0916\u094B\u0932\u0947\u0902 \u2192 \u092A\u094B\u0930\u094D\u091F\u0932 \u092A\u0930 \u092D\u0947\u091C\u0947\u0902 \u2192 \u0915\u0902\u092A\u094D\u092F\u0942\u091F\u0930 \u0938\u0947 \u0938\u094D\u0915\u0948\u0928 \u0915\u0930\u0947\u0902 \u0914\u0930 \u0907\u0938 \u0915\u094B\u0921 \u092A\u0930 \u0915\u0948\u092E\u0930\u093E \u0918\u0941\u092E\u093E\u090F\u0901 \u2014 \u092F\u093E \u0906\u0908\u0921\u0940 \u0915\u0949\u092A\u0940 \u0915\u0930\u0947\u0902\u0964",
  "panel.copy": "\u0906\u0935\u0947\u0926\u0928 \u0906\u0908\u0921\u0940 \u0915\u0949\u092A\u0940 \u0915\u0930\u0947\u0902",
  "panel.copied": "\u0915\u0949\u092A\u0940 \u0939\u094B \u0917\u092F\u093E\u0964",
  "panel.confirmNotDetected": "\u092A\u0941\u0937\u094D\u091F\u093F \u0928\u0939\u0940\u0902 \u092E\u093F\u0932\u0940 \u2014 \u091C\u093E\u0901\u091A \u0932\u0947\u0902 \u0915\u093F \u092A\u094B\u0930\u094D\u091F\u0932 \u0928\u0947 \u0938\u0939\u0947\u091C\u093E \u0939\u0948 \u092F\u093E \u0928\u0939\u0940\u0902, \u092B\u093F\u0930 \u0906\u0917\u0947 \u092C\u0922\u093C\u0947\u0902\u0964",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "\u0905\u0924\u093F\u0925\u093F \u0915\u0940 \u092B\u093C\u094B\u091F\u094B \u0938\u0902\u0932\u0917\u094D\u0928 \u0915\u0930\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u092F\u0939\u093E\u0901 \u091B\u094B\u0921\u093C\u0947\u0902",
  "panel.photoBrowse": "\u092C\u094D\u0930\u093E\u0909\u091C\u093C \u0915\u0930\u0947\u0902\u2026",
  "panel.photoAttachFailed": "\u0905\u092A\u0928\u0947 \u0906\u092A \u0938\u0902\u0932\u0917\u094D\u0928 \u0928\u0939\u0940\u0902 \u0939\u094B \u0938\u0915\u0940 \u2014 \u092A\u094B\u0930\u094D\u091F\u0932 \u0915\u093E \u0905\u092A\u0928\u093E \u092B\u093C\u093E\u0907\u0932 \u091A\u0941\u0928\u0947\u0902 \u092C\u091F\u0928 \u0909\u092A\u092F\u094B\u0917 \u0915\u0930\u0947\u0902\u0964",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "\u092F\u0939 \u092A\u094D\u0930\u092A\u0924\u094D\u0930 Cformly \u0938\u0947 \u092D\u0930\u0947\u0902",
  "chip.hint": "\u0905\u0924\u093F\u0925\u093F \u0915\u0947 \u092B\u093C\u0940\u0932\u094D\u0921 \u091C\u094B \u0906\u092A\u0928\u0947 \u0907\u0938 \u0915\u0902\u092A\u094D\u092F\u0942\u091F\u0930 \u092A\u0930 \u092D\u0947\u091C\u0947 \u0939\u0948\u0902 \u0909\u0928\u094D\u0939\u0947\u0902 \u092F\u0939\u093E\u0901 \u092A\u0947\u0938\u094D\u091F \u0915\u0930\u0947\u0902 (\u092F\u093E \u091F\u0947\u0915\u094D\u0938\u094D\u091F \u092B\u093C\u093E\u0907\u0932 \u092F\u0939\u093E\u0901 \u091B\u094B\u0921\u093C\u0947\u0902), \u092B\u093F\u0930 \u092A\u094D\u0930\u092A\u0924\u094D\u0930 \u092D\u0930\u0947\u0902 \u0926\u092C\u093E\u090F\u0901\u0964",
  "chip.fill": "\u092A\u094D\u0930\u092A\u0924\u094D\u0930 \u092D\u0930\u0947\u0902",
  "chip.filling": "\u092D\u0930\u093E \u091C\u093E \u0930\u0939\u093E \u0939\u0948\u2026",
  "chip.empty": "\u092D\u0930\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0915\u0941\u091B \u0928\u0939\u0940\u0902 \u2014 \u092A\u0939\u0932\u0947 Cformly \u0910\u092A \u0938\u0947 \u0915\u0949\u092A\u0940 \u0915\u093F\u090F \u0917\u090F \u0905\u0924\u093F\u0925\u093F \u092B\u093C\u0940\u0932\u094D\u0921 \u092A\u0947\u0938\u094D\u091F \u0915\u0930\u0947\u0902\u0964",
  "chip.tooLarge": "\u092A\u0947\u0938\u094D\u091F \u0915\u093F\u092F\u093E \u0917\u092F\u093E \u091F\u0947\u0915\u094D\u0938\u094D\u091F \u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E \u0939\u0948 \u2014 \u0915\u0947\u0935\u0932 Cformly \u0910\u092A \u0938\u0947 \u0915\u0949\u092A\u0940 \u0915\u093F\u090F \u0917\u090F \u092B\u093C\u0940\u0932\u094D\u0921 \u092A\u0947\u0938\u094D\u091F \u0915\u0930\u0947\u0902\u0964",
  "chip.collapse": "\u092C\u0902\u0926 \u0915\u0930\u0947\u0902",
  "chip.mappingFallback": "\u0938\u0942\u091A\u0928\u093E: \u092E\u0948\u092A\u093F\u0902\u0917 \u0938\u0930\u094D\u0935\u0930 \u0924\u0915 \u0928\u0939\u0940\u0902 \u092A\u0939\u0941\u0901\u091A\u093E \u091C\u093E \u0938\u0915\u093E \u2014 \u0905\u0902\u0924\u0930\u094D\u0928\u093F\u0939\u093F\u0924 \u092B\u093C\u0940\u0932\u094D\u0921 \u092E\u0948\u092A \u0909\u092A\u092F\u094B\u0917 \u0939\u094B \u0930\u0939\u093E \u0939\u0948, \u091C\u094B \u092A\u0941\u0930\u093E\u0928\u093E \u0939\u094B \u0938\u0915\u0924\u093E \u0939\u0948\u0964",
  // round-66: popup first-run onboarding
  "onboarding.title": "\u092A\u0939\u0932\u0940 \u092C\u093E\u0930 \u092F\u0939\u093E\u0901? \u0924\u0940\u0928 \u0915\u0926\u092E:",
  "onboarding.step1": "\u0905\u092A\u0928\u0947 \u092B\u093C\u094B\u0928 \u092A\u0930: \u0905\u0924\u093F\u0925\u093F \u0916\u094B\u0932\u0947\u0902 \u2192 \u092A\u094B\u0930\u094D\u091F\u0932 \u092A\u0930 \u092D\u0947\u091C\u0947\u0902 \u2192 \u0915\u0902\u092A\u094D\u092F\u0942\u091F\u0930 \u092A\u0930 \u092D\u0947\u091C\u0947\u0902\u0964",
  "onboarding.step2": "\u0907\u0938 \u0915\u0902\u092A\u094D\u092F\u0942\u091F\u0930 \u092A\u0930: \u0905\u092A\u0928\u0947 \u0906\u092A \u0915\u094B \u092D\u0947\u091C\u0947 \u0917\u090F \u092B\u093C\u0940\u0932\u094D\u0921 \u0928\u0940\u091A\u0947 \u092C\u0949\u0915\u094D\u0938 \u092E\u0947\u0902 \u092A\u0947\u0938\u094D\u091F \u0915\u0930\u0947\u0902 (\u092F\u093E \u092B\u093C\u0949\u0930\u094D\u092E \u092A\u0947\u091C \u092A\u0930 \u0928\u0940\u0932\u093E Cformly \u092C\u091F\u0928 \u0926\u092C\u093E\u090F\u0901)\u0964",
  "onboarding.step3": "\u092A\u094D\u0930\u092A\u0924\u094D\u0930 \u092D\u0930\u0947\u0902 \u0926\u092C\u093E\u090F\u0901 \u2014 \u092A\u094B\u0930\u094D\u091F\u0932 \u092B\u093C\u0949\u0930\u094D\u092E \u0905\u092A\u0928\u0947 \u0906\u092A \u092D\u0930 \u091C\u093E\u090F\u0917\u093E\u0964 \u092B\u093C\u094B\u091F\u094B, \u0938\u0941\u0930\u0915\u094D\u0937\u093E \u0915\u094B\u0921 \u0914\u0930 \u0938\u0939\u0947\u091C\u0947\u0902 \u0906\u092A \u0915\u0930\u0947\u0902\u0964",
  "onboarding.done": "\u0938\u092E\u091D \u0917\u090F",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{total} \u092E\u0947\u0902 \u0938\u0947 {filled} \u092B\u093C\u0940\u0932\u094D\u0921 {time} \u092C\u091C\u0947 \u092D\u0930\u0947 \u0917\u090F \u0925\u0947\u0964 \u0926\u094B\u092C\u093E\u0930\u093E \u092D\u0930\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u092B\u093F\u0930 \u0938\u0947 \u0936\u0941\u0930\u0942 \u0915\u0930\u0947\u0902\u0964",
  "resume.button": "\u092B\u093F\u0930 \u0938\u0947 \u092D\u0930\u0947\u0902",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "\u092F\u0939 \u092A\u094B\u0930\u094D\u091F\u0932 \u092A\u0947\u091C Cformly \u0915\u0940 \u091C\u093E\u0928\u0940-\u092A\u0939\u091A\u093E\u0928\u0940 Form III \u091C\u0948\u0938\u093E \u0928\u0939\u0940\u0902 \u0932\u0917 \u0930\u0939\u093E \u2014 \u0938\u0902\u092D\u0935 \u0939\u0948 \u092A\u094B\u0930\u094D\u091F\u0932 \u092C\u0926\u0932 \u0917\u092F\u093E \u0939\u094B\u0964 \u0907\u0938 \u092C\u093E\u0930 Cformly \u0910\u092A \u0938\u0947 \u0905\u0924\u093F\u0925\u093F \u092B\u093C\u0940\u0932\u094D\u0921 \u0915\u0949\u092A\u0940 \u0915\u0930\u0915\u0947 \u0938\u094D\u0935\u092F\u0902 \u092D\u0930\u0947\u0902; \u0939\u092E \u0905\u092A\u0921\u0947\u091F \u0915\u0940 \u091C\u093E\u0901\u091A \u0915\u0930 \u0930\u0939\u0947 \u0939\u0948\u0902\u0964",
  "canary.detail": "\u0907\u0938 \u092A\u0947\u091C \u092A\u0930 Cformly \u0915\u094B {total} \u091C\u094D\u091E\u093E\u0924 \u092B\u093C\u0940\u0932\u094D\u0921 \u092E\u0947\u0902 \u0938\u0947 \u0915\u0947\u0935\u0932 {found} \u092E\u093F\u0932\u0940\u0902\u0964",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "\u0905\u0924\u093F\u0925\u093F \u0915\u0924\u093E\u0930",
  "queue.add": "\u0915\u0924\u093E\u0930 \u092E\u0947\u0902 \u091C\u094B\u0921\u093C\u0947\u0902",
  "queue.fill": "\u092D\u0930\u0947\u0902",
  "queue.remove": "\u0939\u091F\u093E\u090F\u0901",
  "queue.unnamed": "\u0905\u0924\u093F\u0925\u093F",
  "queue.added": "{name} \u0915\u094B \u0915\u0924\u093E\u0930 \u092E\u0947\u0902 \u091C\u094B\u0921\u093C\u093E \u0917\u092F\u093E\u0964",
  "queue.duplicate": "\u092F\u0939 \u0905\u0924\u093F\u0925\u093F \u092A\u0939\u0932\u0947 \u0938\u0947 \u0915\u0924\u093E\u0930 \u092E\u0947\u0902 \u0939\u0948\u0964",
  "queue.full": "\u0915\u0924\u093E\u0930 \u092D\u0930\u0940 \u0939\u0948 ({max} \u0905\u0924\u093F\u0925\u093F)\u0964 \u092A\u0939\u0932\u0947 \u0915\u093F\u0938\u0940 \u0905\u0924\u093F\u0925\u093F \u0915\u093E \u092B\u093C\u0949\u0930\u094D\u092E \u092D\u0930\u0947\u0902 \u092F\u093E \u0909\u0938\u0947 \u0939\u091F\u093E\u090F\u0901\u0964",
  "queue.hint": "\u092D\u0930\u0928\u0947 \u0915\u0940 \u092A\u094D\u0930\u0924\u0940\u0915\u094D\u0937\u093E \u092E\u0947\u0902 \u0905\u0924\u093F\u0925\u093F\u0964 \u092A\u0942\u0930\u094D\u0923 \u092D\u0930\u093E\u0908 \u092A\u0930 \u0905\u0924\u093F\u0925\u093F \u0915\u0924\u093E\u0930 \u0938\u0947 \u0939\u091F \u091C\u093E\u0924\u093E \u0939\u0948; \u092C\u094D\u0930\u093E\u0909\u091C\u093C\u0930 \u092C\u0902\u0926 \u0939\u094B\u0928\u0947 \u092A\u0930 \u0915\u0924\u093E\u0930 \u0938\u093E\u092B\u093C \u0939\u094B \u091C\u093E\u0924\u0940 \u0939\u0948\u0964",
  "queue.unavailable": "\u0907\u0938 \u092C\u094D\u0930\u093E\u0909\u091C\u093C\u0930 \u092E\u0947\u0902 \u0905\u0924\u093F\u0925\u093F \u0915\u0924\u093E\u0930 \u0909\u092A\u0932\u092C\u094D\u0927 \u0928\u0939\u0940\u0902 \u0939\u0948\u0964",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "\u092F\u0939 FRRO \u091F\u0948\u092C Cformly \u0915\u0947 \u0907\u0902\u0938\u094D\u091F\u0949\u0932 \u092F\u093E \u0905\u092A\u0921\u0947\u091F \u0939\u094B\u0928\u0947 \u0938\u0947 \u092A\u0939\u0932\u0947 \u0916\u094B\u0932\u093E \u0917\u092F\u093E \u0925\u093E\u0964 \u0907\u0938 \u091F\u0948\u092C \u0915\u094B \u090F\u0915 \u092C\u093E\u0930 \u0930\u0940\u0932\u094B\u0921 \u0915\u0930\u0947\u0902 (F5), \u092B\u093F\u0930 Fill \u0926\u092C\u093E\u090F\u0901\u0964",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "\u092B\u093C\u0949\u0930\u094D\u092E \u092E\u0948\u092A\u093F\u0902\u0917",
  "settings.mapVersion": "\u0938\u0902\u0938\u094D\u0915\u0930\u0923",
  "settings.mapLastVerified": "\u0905\u0902\u0924\u093F\u092E \u0938\u0924\u094D\u092F\u093E\u092A\u093F\u0924",
  "settings.mapFetchedAt": "\u092A\u094D\u0930\u093E\u092A\u094D\u0924",
  "settings.mapSignature": "Ed25519 \u0939\u0938\u094D\u0924\u093E\u0915\u094D\u0937\u0930",
  "settings.mapRefresh": "\u0905\u092D\u0940 \u0930\u0940\u092B\u093C\u094D\u0930\u0947\u0936 \u0915\u0930\u0947\u0902",
  "settings.mapRefreshed": "\u092E\u0948\u092A\u093F\u0902\u0917 \u0930\u0940\u092B\u093C\u094D\u0930\u0947\u0936 \u0939\u094B \u0917\u0908\u0964",
  "settings.mapRefreshFailed": "\u092E\u0948\u092A\u093F\u0902\u0917 \u0930\u0940\u092B\u093C\u094D\u0930\u0947\u0936 \u0928\u0939\u0940\u0902 \u0939\u094B \u0938\u0915\u0940 - \u0909\u092A\u0932\u092C\u094D\u0927 \u0938\u092C\u0938\u0947 \u0905\u091A\u094D\u091B\u0940 \u0915\u0949\u092A\u0940 \u0909\u092A\u092F\u094B\u0917 \u092E\u0947\u0902 \u0939\u0948\u0964",
  "settings.mapStatusRemote": "\u0938\u0924\u094D\u092F\u093E\u092A\u093F\u0924 - \u092E\u0948\u092A\u093F\u0902\u0917 \u0938\u0930\u094D\u0935\u0930 \u0938\u0947 \u0932\u093E\u0908 \u0917\u0908 \u0924\u093E\u091C\u093C\u093E \u0915\u0949\u092A\u0940\u0964",
  "settings.mapStatusCached": "\u0938\u0924\u094D\u092F\u093E\u092A\u093F\u0924 - \u0939\u093E\u0932 \u0915\u0940 \u0915\u0948\u0936 \u0915\u0949\u092A\u0940\u0964",
  "settings.mapStatusBundled": "\u092C\u093F\u0932\u094D\u091F-\u0907\u0928 \u092C\u0947\u0938\u0932\u093E\u0907\u0928 \u0915\u0949\u092A\u0940 (\u0938\u0930\u094D\u0935\u0930 \u0909\u092A\u0932\u092C\u094D\u0927 \u0928\u0939\u0940\u0902)\u0964 \u0939\u0938\u094D\u0924\u093E\u0915\u094D\u0937\u0930 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 \u0939\u0948\u0964",
  "settings.mapStatusTampered": "\u0939\u0938\u094D\u0924\u093E\u0915\u094D\u0937\u0930 \u091C\u093E\u0901\u091A \u0935\u093F\u092B\u0932 - \u092F\u0939 \u0915\u0949\u092A\u0940 \u0905\u0938\u094D\u0935\u0940\u0915\u0943\u0924 \u0939\u0948 \u0914\u0930 \u0909\u092A\u092F\u094B\u0917 \u092E\u0947\u0902 \u0928\u0939\u0940\u0902 \u0939\u0948\u0964",
  // roadmap 160/161/162
  "chip.mappingUnavailable": "\u092B\u093C\u0949\u0930\u094D\u092E \u092E\u0948\u092A\u093F\u0902\u0917 \u0932\u094B\u0921 \u0928\u0939\u0940\u0902 \u0939\u094B \u0938\u0915\u0940 \u2014 \u090F\u0915\u094D\u0938\u091F\u0947\u0902\u0936\u0928 \u0915\u0947 \u092C\u0948\u0915\u0917\u094D\u0930\u093E\u0909\u0902\u0921 \u0935\u0930\u094D\u0915\u0930 \u0928\u0947 \u091C\u0935\u093E\u092C \u0928\u0939\u0940\u0902 \u0926\u093F\u092F\u093E\u0964 \u092A\u094B\u0930\u094D\u091F\u0932 \u091F\u0948\u092C \u0930\u0940\u0932\u094B\u0921 \u0915\u0930\u0915\u0947 \u092B\u093F\u0930 \u0938\u0947 \u0915\u094B\u0936\u093F\u0936 \u0915\u0930\u0947\u0902\u0964",
  "popup.timeoutMapping": "\u092B\u093C\u0949\u0930\u094D\u092E \u092E\u0948\u092A\u093F\u0902\u0917 \u0932\u094B\u0921 \u0939\u094B\u0928\u0947 \u0915\u093E \u0938\u092E\u092F \u0938\u092E\u093E\u092A\u094D\u0924 ({seconds} \u0938\u0947\u0915\u0902\u0921)\u0964 \u0915\u0928\u0947\u0915\u094D\u0936\u0928 \u091C\u093E\u0901\u091A\u0915\u0930 \u092B\u093F\u0930 \u0938\u0947 \u0915\u094B\u0936\u093F\u0936 \u0915\u0930\u0947\u0902\u0964",
  "popup.timeoutNoProgress": "\u092D\u0930\u093E\u0908 {seconds} \u0938\u0947\u0915\u0902\u0921 \u092E\u0947\u0902 \u0936\u0941\u0930\u0942 \u0928\u0939\u0940\u0902 \u0939\u0941\u0908 \u2014 Form III \u092A\u0947\u091C \u091C\u0935\u093E\u092C \u0928\u0939\u0940\u0902 \u0926\u0947 \u0930\u0939\u093E \u0939\u0948\u0964 \u091F\u0948\u092C \u0930\u0940\u0932\u094B\u0921 \u0915\u0930\u0915\u0947 \u092B\u093F\u0930 \u0915\u094B\u0936\u093F\u0936 \u0915\u0930\u0947\u0902\u0964",
  "popup.timeoutStalled": "\u092D\u0930\u093E\u0908 {seconds} \u0938\u0947\u0915\u0902\u0921 \u0938\u0947 \u0930\u0941\u0915\u0940 \u0939\u0941\u0908 \u0939\u0948 \u2014 Form III \u092A\u0947\u091C \u0928\u0947 \u091C\u0935\u093E\u092C \u0926\u0947\u0928\u093E \u092C\u0902\u0926 \u0915\u0930 \u0926\u093F\u092F\u093E \u0939\u0948\u0964",
  "popup.timeoutCap": "\u092D\u0930\u093E\u0908 \u0915\u0941\u0932 \u0938\u092E\u092F \u0938\u0940\u092E\u093E ({seconds} \u0938\u0947\u0915\u0902\u0921) \u092A\u093E\u0930 \u0915\u0930 \u0917\u0908 \u0914\u0930 \u0930\u094B\u0915 \u0926\u0940 \u0917\u0908 \u0939\u0948\u0964",
  "popup.preview": "\u092C\u0926\u0932\u093E\u0935 \u0926\u0947\u0916\u0947\u0902",
  "popup.previewApply": "\u0932\u093E\u0917\u0942 \u0915\u0930\u0947\u0902 \u2014 \u092B\u093C\u0949\u0930\u094D\u092E \u092D\u0930\u0947\u0902",
  "popup.undo": "\u092A\u093F\u091B\u0932\u0940 \u092B\u093C\u093F\u0932 \u0935\u093E\u092A\u0938 \u0932\u0947\u0902",
  "popup.undoDone": "{total} \u092E\u0947\u0902 \u0938\u0947 {restored} \u092B\u093C\u0940\u0932\u094D\u0921 \u0909\u0928\u0915\u0947 \u092A\u0942\u0930\u094D\u0935 \u092E\u093E\u0928\u094B\u0902 \u092A\u0930 \u0932\u094C\u091F\u093E \u0926\u093F\u090F \u0917\u090F\u0964",
  "popup.undoPartial": "{total} \u092E\u0947\u0902 \u0938\u0947 {restored} \u092B\u093C\u0940\u0932\u094D\u0921 \u0932\u094C\u091F\u0947; {failed} \u0935\u093E\u092A\u0938 \u0928\u0939\u0940\u0902 \u0939\u094B \u0938\u0915\u0947 (\u092A\u0947\u091C \u0926\u094B\u092C\u093E\u0930\u093E \u092C\u0928\u093E \u0939\u094B \u0938\u0915\u0924\u093E \u0939\u0948)\u0964",
  "popup.undoStale": "\u092B\u093C\u093F\u0932 \u0915\u0947 \u092C\u093E\u0926 \u092A\u0947\u091C \u092C\u0926\u0932 \u0917\u092F\u093E \u2014 \u092A\u0941\u0928\u0930\u094D\u0938\u094D\u0925\u093E\u092A\u0928\u093E \u0905\u092A\u0942\u0930\u094D\u0923 \u0939\u094B \u0938\u0915\u0924\u0940 \u0939\u0948\u0964",
  "popup.undoNone": "\u0935\u093E\u092A\u0938 \u0932\u0947\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0915\u0941\u091B \u0928\u0939\u0940\u0902 \u2014 \u0907\u0938 \u0938\u0924\u094D\u0930 \u092E\u0947\u0902 \u0907\u0938 \u091F\u0948\u092C \u092A\u0930 \u0915\u094B\u0908 \u092B\u093C\u093F\u0932 \u0928\u0939\u0940\u0902 \u0939\u0941\u0908\u0964",
  "popup.previewUnresolved": "\u0907\u0938 \u092A\u0947\u091C \u092A\u0930 \u0928\u0939\u0940\u0902 \u092E\u093F\u0932\u093E",
  "popup.previewManual": "\u092E\u0948\u0928\u094D\u092F\u0941\u0905\u0932 \u091A\u0930\u0923",
  "popup.previewNoValue": "(\u092A\u094D\u0930\u0926\u093E\u0928 \u0928\u0939\u0940\u0902)"
};

// src/i18n/kn.ts
var kn = {
  // popup
  "popup.title": "Cformly \u0CB8\u0CCD\u0CB5\u0CAF\u0C82-\u0CAD\u0CB0\u0CCD\u0CA4\u0CBF",
  "popup.eyebrow": "\u0CB8\u0CCD\u0CB5\u0CAF\u0C82-\u0CAD\u0CB0\u0CCD\u0CA4\u0CBF",
  "popup.bandSub": "FRRO Form III \xB7 \u0C9A\u0CC6\u0C95\u0CCD-\u0C87\u0CA8\u0CCD \u0C86\u0CA6 24 \u0C97\u0C82\u0C9F\u0CC6\u0C97\u0CB3 \u0C92\u0CB3\u0C97\u0CC6",
  "popup.fillFromClipboard": "\u0C95\u0CCD\u0CB2\u0CBF\u0CAA\u0CCD\u200C\u0CAC\u0CCB\u0CB0\u0CCD\u0CA1\u0CCD\u200C\u0CA8\u0CBF\u0C82\u0CA6 \u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAD\u0CB0\u0CCD\u0CA4\u0CBF \u0CAE\u0CBE\u0CA1\u0CBF",
  "popup.fillHint": "Cformly \u0C85\u0CAA\u0CCD\u0CB2\u0CBF\u0C95\u0CC7\u0CB6\u0CA8\u0CCD\u200C\u0CA8\u0CBF\u0C82\u0CA6 \u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CB5\u0CBF\u0CB5\u0CB0\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0C95\u0CB2\u0CBF\u0CB8\u0CBF, \u0CA8\u0C82\u0CA4\u0CB0 \u0C88 \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD \u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0C85\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAD\u0CB0\u0CCD\u0CA4\u0CBF \u0CAE\u0CBE\u0CA1\u0CBF.",
  "popup.clipboardReadFailed": "\u0C95\u0CCD\u0CB2\u0CBF\u0CAA\u0CCD\u200C\u0CAC\u0CCB\u0CB0\u0CCD\u0CA1\u0CCD \u0C93\u0CA6\u0CB2\u0CC1 \u0CB8\u0CBE\u0CA7\u0CCD\u0CAF\u0CB5\u0CBE\u0C97\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2. \u0CAC\u0CCD\u0CB0\u0CCC\u0CB8\u0CB0\u0CCD\u200C\u0CA8 \u0C95\u0CCD\u0CB2\u0CBF\u0CAA\u0CCD\u200C\u0CAC\u0CCB\u0CB0\u0CCD\u0CA1\u0CCD \u0C85\u0CA8\u0CC1\u0CAE\u0CA4\u0CBF\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAA\u0CB0\u0CBF\u0CB6\u0CC0\u0CB2\u0CBF\u0CB8\u0CBF.",
  "popup.clipboardEmpty": "\u0C95\u0CCD\u0CB2\u0CBF\u0CAA\u0CCD\u200C\u0CAC\u0CCB\u0CB0\u0CCD\u0CA1\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF Cformly \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CBF\u0CB2\u0CCD\u0CB2. \u0CAE\u0CCA\u0CA6\u0CB2\u0CC1 Cformly \u0C85\u0CAA\u0CCD\u0CB2\u0CBF\u0C95\u0CC7\u0CB6\u0CA8\u0CCD\u200C\u0CA8\u0CBF\u0C82\u0CA6 \u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CB5\u0CBF\u0CB5\u0CB0\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0C95\u0CB2\u0CBF\u0CB8\u0CBF.",
  "popup.settings": "\u0CB8\u0CC6\u0C9F\u0CCD\u0C9F\u0CBF\u0C82\u0C97\u0CCD\u200C\u0C97\u0CB3\u0CC1",
  "popup.loadingMapping": "\u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAE\u0CCD\u0CAF\u0CBE\u0CAA\u0CBF\u0C82\u0C97\u0CCD \u0CB2\u0CCB\u0CA1\u0CCD \u0C86\u0C97\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CA6\u0CC6...",
  "popup.filling": "\u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAD\u0CB0\u0CCD\u0CA4\u0CBF\u0CAF\u0CBE\u0C97\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CA6\u0CC6...",
  "popup.fillingProgress": "\u0CA4\u0CC1\u0C82\u0CAC\u0CB2\u0CBE\u0C97\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CA6\u0CC6\u2026 \u0C95\u0CCD\u0CB7\u0CC7\u0CA4\u0CCD\u0CB0 {completed}/{total}",
  "popup.noTab": "\u0CAF\u0CBE\u0CB5\u0CC1\u0CA6\u0CC7 \u0CB8\u0C95\u0CCD\u0CB0\u0CBF\u0CAF \u0C9F\u0CCD\u0CAF\u0CBE\u0CAC\u0CCD \u0CB8\u0CBF\u0C97\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2.",
  "popup.filled": "\u0C95\u0CA1\u0CCD\u0CA1\u0CBE\u0CAF \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CC1 \u0CAD\u0CB0\u0CCD\u0CA4\u0CBF\u0CAF\u0CBE\u0C97\u0CBF\u0CB5\u0CC6: {required} \u0CB0\u0CB2\u0CCD\u0CB2\u0CBF {filledRequired} (\u0C92\u0C9F\u0CCD\u0C9F\u0CC1 {filled} \u0CAD\u0CB0\u0CCD\u0CA4\u0CBF\u0CAF\u0CBE\u0C97\u0CBF\u0CB5\u0CC6)",
  "popup.portalMismatch": "\u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD \u0CB9\u0CCA\u0C82\u0CA6\u0CBE\u0CA3\u0CBF\u0C95\u0CC6\u0CAF\u0CBE\u0C97\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CB2\u0CCD\u0CB2 \u0C8E\u0C82\u0CA6\u0CC1 \u0CAA\u0CA4\u0CCD\u0CA4\u0CC6\u0CAF\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 (DOM \u0CAC\u0CA6\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6). Cformly \u0C85\u0CAA\u0CCD\u0CB2\u0CBF\u0C95\u0CC7\u0CB6\u0CA8\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CB5\u0CBF\u0CB5\u0CB0\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAE\u0CA4\u0CCD\u0CA4\u0CC6 \u0CA8\u0C95\u0CB2\u0CBF\u0CB8\u0CBF \u0CB9\u0CBE\u0C97\u0CC2 \u0CAE\u0CB0\u0CC1\u0CAA\u0CCD\u0CB0\u0CAF\u0CA4\u0CCD\u0CA8\u0CBF\u0CB8\u0CBF.",
  "popup.missingElements": "\u0C95\u0CBE\u0CA3\u0CC6\u0CAF\u0CBE\u0CA6 \u0C85\u0C82\u0CB6\u0C97\u0CB3\u0CC1: {list}",
  "popup.missingValues": "\u0C95\u0CBE\u0CA3\u0CC6\u0CAF\u0CBE\u0CA6 \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF\u0C97\u0CB3\u0CC1: {list}",
  "popup.manualFields": "\u0C95\u0CC8\u0CAF\u0CBF\u0C82\u0CA6 \u0CAE\u0CBE\u0CA1\u0CAC\u0CC7\u0C95\u0CBE\u0CA6 \u0CB9\u0C82\u0CA4\u0C97\u0CB3\u0CC1: {list}",
  "popup.unsupportedFields": "\u0CB8\u0CCD\u0CB5\u0CAF\u0C82-\u0CAD\u0CB0\u0CCD\u0CA4\u0CBF\u0C97\u0CC6 \u0CB8\u0CBE\u0CA7\u0CCD\u0CAF\u0CB5\u0CBF\u0CB2\u0CCD\u0CB2\u0CA6 \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CC1: {list}",
  "popup.tooLongFields": "\u0C88 \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CBF\u0C97\u0CC6 \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF\u0C97\u0CB3\u0CC1 \u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C89\u0CA6\u0CCD\u0CA6\u0CB5\u0CBE\u0C97\u0CBF\u0CB5\u0CC6 \u2014 \u0C8F\u0CA8\u0CA8\u0CCD\u0CA8\u0CC2 \u0CAC\u0CB0\u0CC6\u0CAF\u0CB2\u0CBE\u0C97\u0CBF\u0CB2\u0CCD\u0CB2, \u0C9A\u0CBF\u0C95\u0CCD\u0C95 \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF\u0CB5\u0CA8\u0CCD\u0CA8\u0CC1 \u0C9F\u0CC8\u0CAA\u0CCD \u0CAE\u0CBE\u0CA1\u0CBF: {list}",
  "popup.unverifiedFields": "\u0C88 \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAA\u0CB0\u0CBF\u0CB6\u0CC0\u0CB2\u0CBF\u0CB8\u0CBF \u2014 \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF\u0CB5\u0CC1 \u0CB8\u0CB0\u0CBF\u0CAF\u0CBE\u0C97\u0CBF \u0C85\u0C82\u0C9F\u0CBF\u0CB0\u0CA6\u0CBF\u0CB0\u0CAC\u0CB9\u0CC1\u0CA6\u0CC1: {list}",
  "popup.applicationId": "\u0C85\u0CB0\u0CCD\u0C9C\u0CBF ID: {id}",
  "popup.accommodationMismatch": "\u0C8E\u0C9A\u0CCD\u0C9A\u0CB0\u0CBF\u0C95\u0CC6: FRRO \u0CB8\u0CC6\u0CB7\u0CA8\u0CCD \u0CAC\u0CC7\u0CB0\u0CC6 \u0C86\u0CB8\u0CCD\u0CA4\u0CBF\u0C97\u0CC6 \u0CB8\u0CC7\u0CB0\u0CBF\u0CA6\u0CCD\u0CA6\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CB9\u0CC1\u0CA6\u0CC1. \u0CB8\u0CB2\u0CCD\u0CB2\u0CBF\u0CB8\u0CC1\u0CB5 \u0CAE\u0CCA\u0CA6\u0CB2\u0CC1 \u0C96\u0C9A\u0CBF\u0CA4\u0CAA\u0CA1\u0CBF\u0CB8\u0CBF\u0C95\u0CCA\u0CB3\u0CCD\u0CB3\u0CBF.",
  "popup.attention": "\u0C95\u0CC6\u0CB2\u0CB5\u0CC1 \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CBF\u0C97\u0CC6 \u0C97\u0CAE\u0CA8 \u0CAC\u0CC7\u0C95\u0CC1. Cformly \u0C85\u0CAA\u0CCD\u0CB2\u0CBF\u0C95\u0CC7\u0CB6\u0CA8\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CB5\u0CBF\u0CB5\u0CB0\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAE\u0CA4\u0CCD\u0CA4\u0CC6 \u0CA8\u0C95\u0CB2\u0CBF\u0CB8\u0CBF \u0CB9\u0CBE\u0C97\u0CC2 \u0CAE\u0CB0\u0CC1\u0CAA\u0CCD\u0CB0\u0CAF\u0CA4\u0CCD\u0CA8\u0CBF\u0CB8\u0CBF.",
  "popup.openPrint": "\u0CB5\u0CC8\u0CAF\u0C95\u0CCD\u0CA4\u0CBF\u0C95 \u0CAA\u0CCD\u0CB0\u0CBF\u0C82\u0C9F\u0CCD \u0CA4\u0CC6\u0CB0\u0CC6\u0CAF\u0CBF\u0CB0\u0CBF",
  "popup.printNoId": "\u0C87\u0CA8\u0CCD\u0CA8\u0CC2 \u0CAF\u0CBE\u0CB5\u0CC1\u0CA6\u0CC7 \u0C85\u0CB0\u0CCD\u0C9C\u0CBF ID \u0CA6\u0CBE\u0C96\u0CB2\u0CBE\u0C97\u0CBF\u0CB2\u0CCD\u0CB2 \u2014 \u0CAE\u0CCA\u0CA6\u0CB2\u0CC1 \u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAD\u0CB0\u0CCD\u0CA4\u0CBF \u0CAE\u0CBE\u0CA1\u0CBF.",
  "popup.printSent": "ID {id} \u0C97\u0CC6 \u0CB8\u0CB2\u0CCD\u0CB2\u0CBF\u0CB8\u0CBF\u0CA6 \u0C85\u0CB0\u0CCD\u0C9C\u0CBF\u0CAF\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAE\u0CB0\u0CC1-\u0CA4\u0CC6\u0CB0\u0CC6\u0CAF\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6. PDF \u0CA1\u0CCC\u0CA8\u0CCD\u200C\u0CB2\u0CCB\u0CA1\u0CCD \u0CAE\u0CBE\u0CA1\u0CB2\u0CC1 \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD\u200C\u0CA8 \u0CB5\u0CC8\u0CAF\u0C95\u0CCD\u0CA4\u0CBF\u0C95 \u0CAA\u0CCD\u0CB0\u0CBF\u0C82\u0C9F\u0CCD \u0CAE\u0CC6\u0CA8\u0CC1 \u0CAC\u0CB3\u0CB8\u0CBF.",
  "popup.formFilled": "\u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAD\u0CB0\u0CCD\u0CA4\u0CBF\u0CAF\u0CBE\u0C97\u0CBF\u0CA6\u0CC6. \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF \u0CAA\u0CB0\u0CBF\u0CB6\u0CC0\u0CB2\u0CBF\u0CB8\u0CBF \u0CB9\u0CBE\u0C97\u0CC2 \u0CB8\u0CB2\u0CCD\u0CB2\u0CBF\u0CB8\u0CBF.",
  "popup.fillError": "\u0CAD\u0CB0\u0CCD\u0CA4\u0CBF \u0CA6\u0CCB\u0CB7: {message}",
  "popup.connectionFailed": "FRRO \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD \u0CAA\u0CC1\u0C9F\u0CB5\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA4\u0CB2\u0CC1\u0CAA\u0CB2\u0CC1 \u0CB8\u0CBE\u0CA7\u0CCD\u0CAF\u0CB5\u0CBE\u0C97\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2. \u0C88 \u0C9F\u0CCD\u0CAF\u0CBE\u0CAC\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF Form III \u0CAA\u0CC1\u0C9F\u0CB5\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA4\u0CC6\u0CB0\u0CC6\u0CA6\u0CC1 \u0CAE\u0CA4\u0CCD\u0CA4\u0CC6 \u0CAA\u0CCD\u0CB0\u0CAF\u0CA4\u0CCD\u0CA8\u0CBF\u0CB8\u0CBF.",
  "popup.unknownError": "\u0C85\u0C9C\u0CCD\u0C9E\u0CBE\u0CA4",
  "popup.apiBaseFallback": "\u0C8E\u0C9A\u0CCD\u0C9A\u0CB0\u0CBF\u0C95\u0CC6: \u0CB8\u0C82\u0C97\u0CCD\u0CB0\u0CB9\u0CBF\u0CB8\u0CBF\u0CA6 API URL \u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 \u2014 \u0CAA\u0CC2\u0CB0\u0CCD\u0CB5\u0CA8\u0CBF\u0CAF\u0CCB\u0C9C\u0CBF\u0CA4\u0CB5\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAC\u0CB3\u0CB8\u0CB2\u0CBE\u0C97\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CA6\u0CC6. \u0CB8\u0CC6\u0C9F\u0CCD\u0C9F\u0CBF\u0C82\u0C97\u0CCD\u200C\u0C97\u0CB3\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0CA6\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0CB5\u0CC0\u0C95\u0CB0\u0CBF\u0CB8\u0CBF.",
  "popup.mappingFallback": "\u0C8E\u0C9A\u0CCD\u0C9A\u0CB0\u0CBF\u0C95\u0CC6: \u0CAE\u0CCD\u0CAF\u0CBE\u0CAA\u0CBF\u0C82\u0C97\u0CCD \u0CB8\u0CB0\u0CCD\u0CB5\u0CB0\u0CCD \u0CA4\u0CB2\u0CC1\u0CAA\u0CB2\u0CC1 \u0CB8\u0CBE\u0CA7\u0CCD\u0CAF\u0CB5\u0CBE\u0C97\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CB2\u0CCD\u0CB2 \u2014 \u0C92\u0CB3\u0C97\u0CCA\u0C82\u0CA1\u0CBF\u0CB0\u0CC1\u0CB5 \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD \u0CA8\u0C95\u0CCD\u0CB7\u0CC6\u0CAF\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAC\u0CB3\u0CB8\u0CB2\u0CBE\u0C97\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CA6\u0CC6; \u0C85\u0CA6\u0CC1 \u0CB9\u0CB3\u0CC6\u0CAF\u0CA6\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CB9\u0CC1\u0CA6\u0CC1.",
  // settings
  "settings.title": "Cformly \u0CB8\u0CC6\u0C9F\u0CCD\u0C9F\u0CBF\u0C82\u0C97\u0CCD\u200C\u0C97\u0CB3\u0CC1",
  "settings.eyebrow": "\u0CB8\u0CC6\u0C9F\u0CCD\u0C9F\u0CBF\u0C82\u0C97\u0CCD\u200C\u0C97\u0CB3\u0CC1",
  "settings.bandSub": "\u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAE\u0CCD\u0CAF\u0CBE\u0CAA\u0CBF\u0C82\u0C97\u0CCD \u0C92\u0CA6\u0C97\u0CBF\u0CB8\u0CC1\u0CB5 \u0CAC\u0CCD\u0CAF\u0CBE\u0C95\u0CCD\u200C\u0C8E\u0C82\u0CA1\u0CCD \u0C85\u0CA8\u0CCD\u0CA8\u0CC1 \u0CB8\u0C82\u0CB0\u0C9A\u0CBF\u0CB8\u0CBF.",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "\u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAE\u0CCD\u0CAF\u0CBE\u0CAA\u0CBF\u0C82\u0C97\u0CCD \u0C92\u0CA6\u0C97\u0CBF\u0CB8\u0CC1\u0CB5 \u0CAC\u0CCD\u0CAF\u0CBE\u0C95\u0CCD\u200C\u0C8E\u0C82\u0CA1\u0CCD. HTTPS \u0CAE\u0CBE\u0CA4\u0CCD\u0CB0; localhost \u0C95\u0CC7\u0CB5\u0CB2 \u0CA1\u0CC6\u0CB5\u0CB2\u0CAA\u0CCD\u200C\u0CAE\u0CC6\u0C82\u0C9F\u0CCD \u0CAC\u0CBF\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CB2\u0CCD\u0CB2\u0CBF \u0C95\u0CC6\u0CB2\u0CB8 \u0CAE\u0CBE\u0CA1\u0CC1\u0CA4\u0CCD\u0CA4\u0CA6\u0CC6.",
  "settings.save": "\u0C89\u0CB3\u0CBF\u0CB8\u0CBF",
  "settings.back": "\u0CB9\u0CBF\u0C82\u0CA6\u0CC6",
  "settings.backInTab": "\u0CB8\u0CC6\u0C9F\u0CCD\u0C9F\u0CBF\u0C82\u0C97\u0CCD\u200C\u0C97\u0CB3\u0CC1 \u0C9F\u0CCD\u0CAF\u0CBE\u0CAC\u0CCD \u0C86\u0C97\u0CBF \u0CA4\u0CC6\u0CB0\u0CC6\u0CA6\u0CBF\u0CB5\u0CC6 \u2014 \u0CAD\u0CB0\u0CCD\u0CA4\u0CBF \u0CAA\u0CBE\u0CAA\u0CCD\u200C\u0C85\u0CAA\u0CCD \u0CA4\u0CC6\u0CB0\u0CC6\u0CAF\u0CB2\u0CC1 Cformly \u0C9F\u0CC2\u0CB2\u0CCD\u200C\u0CAC\u0CBE\u0CB0\u0CCD \u0C90\u0C95\u0CBE\u0CA8\u0CCD \u0CAC\u0CB3\u0CB8\u0CBF.",
  "settings.urlEmpty": "URL \u0C96\u0CBE\u0CB2\u0CBF \u0C87\u0CB0\u0CAC\u0CBE\u0CB0\u0CA6\u0CC1.",
  "settings.httpsOnly": "\u0CAD\u0CA6\u0CCD\u0CB0\u0CA4\u0CC6\u0C97\u0CBE\u0C97\u0CBF \u0C95\u0CC7\u0CB5\u0CB2 HTTPS URL \u0C97\u0CB3\u0CBF\u0C97\u0CC6 \u0C85\u0CA8\u0CC1\u0CAE\u0CA4\u0CBF \u0C87\u0CA6\u0CC6. \u0C89\u0CA4\u0CCD\u0CAA\u0CBE\u0CA6\u0CA8\u0CC6\u0C97\u0CC6 https:// \u0CAC\u0CB3\u0CB8\u0CBF.",
  "settings.hostNotAllowed": "URL \u0CB9\u0CCB\u0CB8\u0CCD\u0C9F\u0CCD\u200C\u0CA8\u0CC7\u0CAE\u0CCD localhost \u0C85\u0CA5\u0CB5\u0CBE *.cformly.com \u0C86\u0C97\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 (\u0CA6\u0CCA\u0CB0\u0CC6\u0CA4\u0CBF\u0CA6\u0CC6: {host}).",
  "settings.invalidUrl": "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF URL. https:// \u0CB8\u0CC7\u0CB0\u0CBF\u0CB8\u0CBF",
  "settings.urlPathNotAllowed": "\u0C95\u0CC7\u0CB5\u0CB2 \u0CAE\u0CC2\u0CB2 origin \u0CAC\u0CB3\u0CB8\u0CBF \u2014 path, query \u0CAE\u0CA4\u0CCD\u0CA4\u0CC1 #fragment \u0CA4\u0CC6\u0C97\u0CC6\u0CA6\u0CC1\u0CB9\u0CBE\u0C95\u0CBF.",
  "settings.loopbackNotGranted": "Localhost API URL \u0C97\u0CB3\u0CC1 \u0CA1\u0CC6\u0CB5\u0CB2\u0CAA\u0CCD\u200C\u0CAE\u0CC6\u0C82\u0C9F\u0CCD \u0CAC\u0CBF\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CB2\u0CCD\u0CB2\u0CBF \u0CAE\u0CBE\u0CA4\u0CCD\u0CB0 \u0C95\u0CC6\u0CB2\u0CB8 \u0CAE\u0CBE\u0CA1\u0CC1\u0CA4\u0CCD\u0CA4\u0CB5\u0CC6. \u0C88 \u0CAC\u0CBF\u0CB2\u0CCD\u0CA1\u0CCD \u0C95\u0CC7\u0CB5\u0CB2 https:// \u0CB9\u0CCB\u0CB8\u0CCD\u0C9F\u0CCD\u200C\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA4\u0CB2\u0CC1\u0CAA\u0CAC\u0CB2\u0CCD\u0CB2\u0CA6\u0CC1.",
  "settings.saved": "\u0C89\u0CB3\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6.",
  "settings.saveError": "\u0C89\u0CB3\u0CBF\u0CB8\u0CB2\u0CC1 \u0CB8\u0CBE\u0CA7\u0CCD\u0CAF\u0CB5\u0CBE\u0C97\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2. \u0CAE\u0CA4\u0CCD\u0CA4\u0CC6 \u0CAA\u0CCD\u0CB0\u0CAF\u0CA4\u0CCD\u0CA8\u0CBF\u0CB8\u0CBF.",
  "settings.langLabel": "\u0CAD\u0CBE\u0CB7\u0CC6",
  "settings.langEnglish": "English",
  "settings.langHindi": "\u0939\u093F\u0928\u094D\u0926\u0940",
  "settings.langAuto": "\u0CAC\u0CCD\u0CB0\u0CCC\u0CB8\u0CB0\u0CCD \u0C85\u0CA8\u0CC1\u0CB8\u0CB0\u0CBF\u0CB8\u0CBF",
  "settings.langHint": "\u0CA8\u0CC0\u0CB5\u0CC1 \u0C86\u0CAF\u0CCD\u0C95\u0CC6 \u0CAE\u0CBE\u0CA1\u0CC1\u0CB5\u0CB5\u0CB0\u0CC6\u0C97\u0CC6 \u0CA8\u0CBF\u0CAE\u0CCD\u0CAE \u0CAC\u0CCD\u0CB0\u0CCC\u0CB8\u0CB0\u0CCD \u0CAD\u0CBE\u0CB7\u0CC6\u0CAF\u0CC7 \u0CAA\u0CC2\u0CB0\u0CCD\u0CB5\u0CA8\u0CBF\u0CAF\u0CCB\u0C9C\u0CBF\u0CA4\u0CB5\u0CBE\u0C97\u0CBF\u0CB0\u0CC1\u0CA4\u0CCD\u0CA4\u0CA6\u0CC6.",
  // round-65: paste intake + in-page filing panel
  "popup.pasteLabel": "\u0C85\u0CA5\u0CB5\u0CBE \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0C87\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0C82\u0C9F\u0CBF\u0CB8\u0CBF",
  "popup.pdfPick": "Cformly PDF \u0CA4\u0CC6\u0CB0\u0CC6\u0CAF\u0CBF\u0CB0\u0CBF",
  "popup.pdfLoaded": "\u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CC1 Cformly PDF \u0CAF\u0CBF\u0C82\u0CA6 \u0CB2\u0CCB\u0CA1\u0CCD \u0C86\u0C97\u0CBF\u0CB5\u0CC6 \u2014 \u0C95\u0CC6\u0CB3\u0C97\u0CC6 \u0CAA\u0CB0\u0CBF\u0CB6\u0CC0\u0CB2\u0CBF\u0CB8\u0CBF, \u0CA8\u0C82\u0CA4\u0CB0 Fill Form \u0C92\u0CA4\u0CCD\u0CA4\u0CBF.",
  "popup.pdfRejected": "\u0C88 PDF \u0CA8\u0CB2\u0CCD\u0CB2\u0CBF Cformly \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CBF\u0CB2\u0CCD\u0CB2 \u0C85\u0CA5\u0CB5\u0CBE \u0C85\u0CA6\u0CA8\u0CCD\u0CA8\u0CC1 \u0C93\u0CA6\u0CB2\u0CBE\u0C97\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2 \u2014 Cformly \u0C86\u0CCD\u0CAF\u0CAA\u0CCD\u200C\u0CA8\u0CBF\u0C82\u0CA6 \u0CB0\u0CAB\u0CCD\u0CA4\u0CC1 \u0CAE\u0CBE\u0CA1\u0CBF\u0CA6 PDF \u0C85\u0CA8\u0CCD\u0CA8\u0CC7 \u0CAC\u0CB3\u0CB8\u0CBF.",
  "popup.pastePlaceholder": "\u0CA8\u0C95\u0CB2\u0CBF\u0CB8\u0CBF\u0CA6 Cformly \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0C87\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0C82\u0C9F\u0CBF\u0CB8\u0CBF",
  "popup.pasteHint": "\u0C95\u0CCD\u0CB2\u0CBF\u0CAA\u0CCD\u200C\u0CAC\u0CCB\u0CB0\u0CCD\u0CA1\u0CCD \u0CAC\u0C9F\u0CA8\u0CCD \u0C95\u0CC6\u0CB2\u0CB8 \u0CAE\u0CBE\u0CA1\u0CA6\u0CBF\u0CA6\u0CCD\u0CA6\u0CB0\u0CC6, \u0C88 \u0C95\u0C82\u0CAA\u0CCD\u0CAF\u0CC2\u0C9F\u0CB0\u0CCD\u200C\u0C97\u0CC6 \u0C95\u0CB3\u0CC1\u0CB9\u0CBF\u0CB8\u0CBF\u0CA6 \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0C87\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0C82\u0C9F\u0CBF\u0CB8\u0CBF (\u0C85\u0CA5\u0CB5\u0CBE \u0C9F\u0CC6\u0C95\u0CCD\u0CB8\u0CCD\u0C9F\u0CCD \u0CAB\u0CC8\u0CB2\u0CCD \u0CAC\u0CBF\u0CA1\u0CBF), \u0CA8\u0C82\u0CA4\u0CB0 \u0CA4\u0CC1\u0C82\u0CAC\u0CBF\u0CB8\u0CBF \u0C92\u0CA4\u0CCD\u0CA4\u0CBF\u0CB0\u0CBF.",
  "popup.payloadTooLarge": "\u0C85\u0C82\u0C9F\u0CBF\u0CB8\u0CBF\u0CA6 \u0CAA\u0CA0\u0CCD\u0CAF \u0CAC\u0CB9\u0CB3 \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 \u2014 Cformly \u0C86\u0CCD\u0CAF\u0CAA\u0CCD\u200C\u0CA8\u0CBF\u0C82\u0CA6 \u0CA8\u0C95\u0CB2\u0CBF\u0CB8\u0CBF\u0CA6 \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAE\u0CBE\u0CA4\u0CCD\u0CB0 \u0C85\u0C82\u0C9F\u0CBF\u0CB8\u0CBF.",
  "panel.title": "Cformly \u2014 \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF \u0CAB\u0CC8\u0CB2\u0CBF\u0C82\u0C97\u0CCD \u0CAA\u0CC2\u0CB0\u0CCD\u0CA3\u0C97\u0CCA\u0CB3\u0CBF\u0CB8\u0CBF",
  "panel.dismiss": "\u0CAE\u0CC1\u0C9A\u0CCD\u0C9A\u0CBF\u0CB0\u0CBF",
  "panel.filled": "\u0CA4\u0CC1\u0C82\u0CAC\u0CBF\u0CA6 \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CC1: {filledRequired} / {required} \u0C95\u0CA1\u0CCD\u0CA1\u0CBE\u0CAF",
  "panel.photoStep": "\u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CAB\u0CCB\u0C9F\u0CCB \u0CB8\u0CC7\u0CB0\u0CBF\u0CB8\u0CBF (\u0CAB\u0CC8\u0CB2\u0CCD \u0C86\u0CAF\u0CCD\u0C95\u0CC6\u0CAE\u0CBE\u0CA1\u0CBF \u2192 \u0C85\u0CAA\u0CCD\u200C\u0CB2\u0CCB\u0CA1\u0CCD)",
  "panel.captchaStep": "\u0CAD\u0CA6\u0CCD\u0CB0\u0CA4\u0CBE \u0C95\u0CCB\u0CA1\u0CCD (CAPTCHA) \u0C9F\u0CC8\u0CAA\u0CCD \u0CAE\u0CBE\u0CA1\u0CBF",
  "panel.saveStep": "\u0C89\u0CB3\u0CBF\u0CB8\u0CBF \u0CAE\u0CA4\u0CCD\u0CA4\u0CC1 \u0CAE\u0CC1\u0C82\u0CA6\u0CC1\u0CB5\u0CB0\u0CBF\u0CB8\u0CBF \u0C92\u0CA4\u0CCD\u0CA4\u0CBF\u0CB0\u0CBF",
  "panel.warnSession": "Cformly \u0C8E\u0C9A\u0CCD\u0C9A\u0CB0\u0CBF\u0C95\u0CC6: \u0C88 FRRO \u0CB8\u0CC6\u0CB7\u0CA8\u0CCD \u0CAC\u0CC7\u0CB0\u0CC6 \u0C86\u0CB8\u0CCD\u0CA4\u0CBF\u0CAF\u0CA6\u0CCD\u0CA6\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CB9\u0CC1\u0CA6\u0CC1 ({reason}). \u0C89\u0CB3\u0CBF\u0CB8\u0CC1\u0CB5 \u0CAE\u0CCA\u0CA6\u0CB2\u0CC1 \u0CAA\u0CB0\u0CBF\u0CB6\u0CC0\u0CB2\u0CBF\u0CB8\u0CBF.",
  "panel.warnUnverified": "Cformly \u0C8E\u0C9A\u0CCD\u0C9A\u0CB0\u0CBF\u0C95\u0CC6: \u0C88 \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3 \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF\u0C97\u0CB3\u0CC1 \u0C89\u0CB3\u0CBF\u0CA6\u0CBF\u0CB2\u0CCD\u0CB2\u0CA6\u0CBF\u0CB0\u0CAC\u0CB9\u0CC1\u0CA6\u0CC1: {list}. \u0C89\u0CB3\u0CBF\u0CB8\u0CC1\u0CB5 \u0CAE\u0CCA\u0CA6\u0CB2\u0CC1 \u0CAA\u0CB0\u0CBF\u0CB6\u0CC0\u0CB2\u0CBF\u0CB8\u0CBF.",
  "panel.saving": "\u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD \u0CA6\u0CC3\u0CA2\u0CC0\u0C95\u0CB0\u0CA3\u0C95\u0CCD\u0C95\u0CBE\u0C97\u0CBF \u0C95\u0CBE\u0CAF\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CA6\u0CC6\u2026",
  "panel.progress": "\u0C95\u0CCD\u0CB7\u0CC7\u0CA4\u0CCD\u0CB0\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA4\u0CC1\u0C82\u0CAC\u0CB2\u0CBE\u0C97\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CA6\u0CC6\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO \u0C85\u0CB5\u0CA7\u0CBF \u0C85\u0C82\u0CA4\u0CCD\u0CAF\u0CB5\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 \u2014 \u0CAE\u0CA4\u0CCD\u0CA4\u0CC6 \u0CB2\u0CBE\u0C97\u0CCD \u0C87\u0CA8\u0CCD \u0CAE\u0CBE\u0CA1\u0CBF, \u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CA4\u0CC6\u0CB0\u0CC6\u0CA6\u0CC1 Fill \u0C92\u0CA4\u0CCD\u0CA4\u0CBF\u0CB0\u0CBF. \u0CA8\u0CBF\u0CAE\u0CCD\u0CAE \u0C85\u0CA4\u0CBF\u0CA5\u0CBF\u0CAF \u0CB5\u0CBF\u0CB5\u0CB0\u0C97\u0CB3\u0CC1 Cformly \u0C86\u0CCD\u0CAF\u0CAA\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF \u0C89\u0CB3\u0CBF\u0CA6\u0CBF\u0CB5\u0CC6.",
  "panel.portalError": "\u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD \u0CB8\u0CAE\u0CB8\u0CCD\u0CAF\u0CC6 \u0CA4\u0CCB\u0CB0\u0CBF\u0CB8\u0CBF\u0CA6\u0CC6:",
  "panel.appIdFound": "\u0CAF\u0CB6\u0CB8\u0CCD\u0CB5\u0CBF\u0CAF\u0CBE\u0C97\u0CBF \u0CAB\u0CC8\u0CB2\u0CCD \u0C86\u0C97\u0CBF\u0CA6\u0CC6. \u0C85\u0CB0\u0CCD\u0C9C\u0CBF \u0C90\u0CA1\u0CBF:",
  "panel.scanHint": "Cformly \u0C86\u0CCD\u0CAF\u0CAA\u0CCD \u0CA4\u0CC6\u0CB0\u0CC6\u0CAF\u0CBF\u0CB0\u0CBF \u2192 \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD\u200C\u0C97\u0CC6 \u0C95\u0CB3\u0CC1\u0CB9\u0CBF\u0CB8\u0CBF \u2192 \u0C95\u0C82\u0CAA\u0CCD\u0CAF\u0CC2\u0C9F\u0CB0\u0CCD\u200C\u0CA8\u0CBF\u0C82\u0CA6 \u0CB8\u0CCD\u0C95\u0CCD\u0CAF\u0CBE\u0CA8\u0CCD \u0CAE\u0CBE\u0CA1\u0CBF \u0CAE\u0CA4\u0CCD\u0CA4\u0CC1 \u0C88 \u0C95\u0CCB\u0CA1\u0CCD\u200C\u0C97\u0CC6 \u0C95\u0CCD\u0CAF\u0CBE\u0CAE\u0CC6\u0CB0\u0CBE \u0CA4\u0CCB\u0CB0\u0CBF\u0CB8\u0CBF \u2014 \u0C85\u0CA5\u0CB5\u0CBE \u0C90\u0CA1\u0CBF \u0CA8\u0C95\u0CB2\u0CBF\u0CB8\u0CBF.",
  "panel.copy": "\u0C85\u0CB0\u0CCD\u0C9C\u0CBF \u0C90\u0CA1\u0CBF \u0CA8\u0C95\u0CB2\u0CBF\u0CB8\u0CBF",
  "panel.copied": "\u0CA8\u0C95\u0CB2\u0CBE\u0CAF\u0CBF\u0CA4\u0CC1.",
  "panel.confirmNotDetected": "\u0CA6\u0CC3\u0CA2\u0CC0\u0C95\u0CB0\u0CA3 \u0C95\u0C82\u0CA1\u0CC1\u0CAC\u0C82\u0CA6\u0CBF\u0CB2\u0CCD\u0CB2 \u2014 \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD \u0C89\u0CB3\u0CBF\u0CB8\u0CBF\u0CA6\u0CC6\u0CAF\u0CC7 \u0C8E\u0C82\u0CA6\u0CC1 \u0CAA\u0CB0\u0CBF\u0CB6\u0CC0\u0CB2\u0CBF\u0CB8\u0CBF, \u0CA8\u0C82\u0CA4\u0CB0 \u0CAE\u0CC1\u0C82\u0CA6\u0CC1\u0CB5\u0CB0\u0CBF\u0CB8\u0CBF.",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "\u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CAB\u0CCB\u0C9F\u0CCB \u0CB2\u0C97\u0CA4\u0CCD \u0CAE\u0CBE\u0CA1\u0CB2\u0CC1 \u0C87\u0CB2\u0CCD\u0CB2\u0CBF \u0CAC\u0CBF\u0CA1\u0CBF",
  "panel.photoBrowse": "\u0CAC\u0CCD\u0CB0\u0CCC\u0CB8\u0CCD\u2026",
  "panel.photoAttachFailed": "\u0CA4\u0CBE\u0CA8\u0CBE\u0C97\u0CBF \u0CB2\u0C97\u0CA4\u0CCD \u0C86\u0C97\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2 \u2014 \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD\u200C\u0CA8 \u0CAB\u0CC8\u0CB2\u0CCD \u0C86\u0CAF\u0CCD\u0C95\u0CC6 \u0C97\u0CC1\u0C82\u0CA1\u0CBF \u0CAC\u0CB3\u0CB8\u0CBF.",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "\u0C88 \u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CA8\u0CCD\u0CA8\u0CC1 Cformly \u0C9C\u0CCA\u0CA4\u0CC6 \u0CA4\u0CC1\u0C82\u0CAC\u0CBF\u0CB0\u0CBF",
  "chip.hint": "\u0C88 \u0C97\u0CA3\u0C95\u0C95\u0CCD\u0C95\u0CC6 \u0C95\u0CB3\u0CC1\u0CB9\u0CBF\u0CB8\u0CBF\u0CA6 \u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CB5\u0CBF\u0CB5\u0CB0\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0C87\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0C82\u0C9F\u0CBF\u0CB8\u0CBF (\u0C85\u0CA5\u0CB5\u0CBE \u0CAA\u0CA0\u0CCD\u0CAF \u0CAB\u0CC8\u0CB2\u0CCD \u0C87\u0CB2\u0CCD\u0CB2\u0CBF \u0CAC\u0CBF\u0CA1\u0CBF), \u0CA8\u0C82\u0CA4\u0CB0 \u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CA4\u0CC1\u0C82\u0CAC\u0CBF \u0C92\u0CA4\u0CCD\u0CA4\u0CBF\u0CB0\u0CBF.",
  "chip.fill": "\u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CA4\u0CC1\u0C82\u0CAC\u0CBF",
  "chip.filling": "\u0CA4\u0CC1\u0C82\u0CAC\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CA6\u0CC6\u2026",
  "chip.empty": "\u0CA4\u0CC1\u0C82\u0CAC\u0CB2\u0CC1 \u0C8F\u0CA8\u0CC2 \u0C87\u0CB2\u0CCD\u0CB2 \u2014 \u0CAE\u0CCA\u0CA6\u0CB2\u0CC1 Cformly \u0C86\u0CCD\u0CAF\u0CAA\u0CCD\u200C\u0CA8\u0CBF\u0C82\u0CA6 \u0CA8\u0C95\u0CB2\u0CBF\u0CB8\u0CBF\u0CA6 \u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CB5\u0CBF\u0CB5\u0CB0\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0C85\u0C82\u0C9F\u0CBF\u0CB8\u0CBF.",
  "chip.tooLarge": "\u0C85\u0C82\u0C9F\u0CBF\u0CB8\u0CBF\u0CA6 \u0CAA\u0CA0\u0CCD\u0CAF \u0CAC\u0CB9\u0CB3 \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 \u2014 Cformly \u0C86\u0CCD\u0CAF\u0CAA\u0CCD\u200C\u0CA8\u0CBF\u0C82\u0CA6 \u0CA8\u0C95\u0CB2\u0CBF\u0CB8\u0CBF\u0CA6 \u0CB5\u0CBF\u0CB5\u0CB0\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAE\u0CBE\u0CA4\u0CCD\u0CB0 \u0C85\u0C82\u0C9F\u0CBF\u0CB8\u0CBF.",
  "chip.collapse": "\u0CAE\u0CC1\u0C9A\u0CCD\u0C9A\u0CBF\u0CB0\u0CBF",
  "chip.mappingFallback": "\u0C9F\u0CBF\u0CAA\u0CCD\u0CAA\u0CA3\u0CBF: \u0CAE\u0CCD\u0CAF\u0CBE\u0CAA\u0CBF\u0C82\u0C97\u0CCD \u0CB8\u0CB0\u0CCD\u0CB5\u0CB0\u0CCD \u0CA4\u0CB2\u0CC1\u0CAA\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2 \u2014 \u0C92\u0CB3\u0CA8\u0CBF\u0CB0\u0CCD\u0CAE\u0CBF\u0CA4 \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD \u0CA8\u0C95\u0CCD\u0CB7\u0CC6 \u0CAC\u0CB3\u0C95\u0CC6\u0CAF\u0CBE\u0C97\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CA6\u0CC6, \u0C85\u0CA6\u0CC1 \u0CB9\u0CB3\u0CC6\u0CAF\u0CA6\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CB9\u0CC1\u0CA6\u0CC1.",
  // round-66: popup first-run onboarding
  "onboarding.title": "\u0CAE\u0CCA\u0CA6\u0CB2 \u0CAC\u0CBE\u0CB0\u0CBF \u0C87\u0CB2\u0CCD\u0CB2\u0CBF\u0CAF\u0CC7? \u0CAE\u0CC2\u0CB0\u0CC1 \u0CB9\u0CC6\u0C9C\u0CCD\u0C9C\u0CC6:",
  "onboarding.step1": "\u0CA8\u0CBF\u0CAE\u0CCD\u0CAE \u0CAB\u0CCB\u0CA8\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF: \u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CA4\u0CC6\u0CB0\u0CC6\u0CAF\u0CBF\u0CB0\u0CBF \u2192 \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD\u200C\u0C97\u0CC6 \u0C95\u0CB3\u0CC1\u0CB9\u0CBF\u0CB8\u0CBF \u2192 \u0C97\u0CA3\u0C95\u0C95\u0CCD\u0C95\u0CC6 \u0C95\u0CB3\u0CC1\u0CB9\u0CBF\u0CB8\u0CBF.",
  "onboarding.step2": "\u0C88 \u0C97\u0CA3\u0C95\u0CA6\u0CB2\u0CCD\u0CB2\u0CBF: \u0CA8\u0CBF\u0CAE\u0C97\u0CC6 \u0C95\u0CB3\u0CC1\u0CB9\u0CBF\u0CB8\u0CBF\u0CA6 \u0CB5\u0CBF\u0CB5\u0CB0\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0C95\u0CC6\u0CB3\u0C97\u0CBF\u0CA8 \u0C9A\u0CCC\u0C95\u0CA6\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0C82\u0C9F\u0CBF\u0CB8\u0CBF (\u0C85\u0CA5\u0CB5\u0CBE \u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAA\u0CC1\u0C9F\u0CA6\u0CB2\u0CCD\u0CB2\u0CBF\u0CA8 \u0CA8\u0CC0\u0CB2\u0CBF Cformly \u0C97\u0CC1\u0C82\u0CA1\u0CBF \u0C92\u0CA4\u0CCD\u0CA4\u0CBF\u0CB0\u0CBF).",
  "onboarding.step3": "\u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CA4\u0CC1\u0C82\u0CAC\u0CBF \u0C92\u0CA4\u0CCD\u0CA4\u0CBF\u0CB0\u0CBF \u2014 \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD \u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CA4\u0CBE\u0CA8\u0CBE\u0C97\u0CBF\u0CAF\u0CC7 \u0CA4\u0CC1\u0C82\u0CAC\u0CC1\u0CA4\u0CCD\u0CA4\u0CA6\u0CC6. \u0CAB\u0CCB\u0C9F\u0CCB, \u0CAD\u0CA6\u0CCD\u0CB0\u0CA4\u0CBE \u0CB8\u0C82\u0C95\u0CC7\u0CA4 \u0CAE\u0CA4\u0CCD\u0CA4\u0CC1 \u0C89\u0CB3\u0CBF\u0CB8\u0CBF \u0CA8\u0CC0\u0CB5\u0CC1 \u0CAE\u0CBE\u0CA1\u0CBF.",
  "onboarding.done": "\u0C85\u0CB0\u0CCD\u0CA5\u0CB5\u0CBE\u0CAF\u0CBF\u0CA4\u0CC1",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{total} \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CB2\u0CCD\u0CB2\u0CBF {filled} {time} \u0CB8\u0CAE\u0CAF\u0CA6\u0CB2\u0CCD\u0CB2\u0CBF \u0CA4\u0CC1\u0C82\u0CAC\u0CB2\u0CBE\u0C97\u0CBF\u0CA4\u0CCD\u0CA4\u0CC1. \u0CAE\u0CA4\u0CCD\u0CA4\u0CC6 \u0CA4\u0CC1\u0C82\u0CAC\u0CB2\u0CC1 \u0CAA\u0CC1\u0CA8\u0CB0\u0CBE\u0CB0\u0C82\u0CAD\u0CBF\u0CB8\u0CBF.",
  "resume.button": "\u0CAE\u0CA4\u0CCD\u0CA4\u0CC6 \u0CA4\u0CC1\u0C82\u0CAC\u0CBF\u0CB8\u0CBF",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "\u0C88 \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD \u0CAA\u0CC1\u0C9F Cformly \u0C97\u0CC6 \u0C97\u0CCA\u0CA4\u0CCD\u0CA4\u0CBF\u0CB0\u0CC1\u0CB5 Form III \u0CA8\u0C82\u0CA4\u0CC6 \u0C95\u0CBE\u0CA3\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CB2\u0CCD\u0CB2 \u2014 \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD \u0CAC\u0CA6\u0CB2\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CB9\u0CC1\u0CA6\u0CC1. \u0C88 \u0CAC\u0CBE\u0CB0\u0CBF Cformly \u0C86\u0CCD\u0CAF\u0CAA\u0CCD \u0CA8\u0CBF\u0C82\u0CA6 \u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0C95\u0CB2\u0CBF\u0CB8\u0CBF \u0CB8\u0CCD\u0CB5\u0CA4\u0C83 \u0CAD\u0CB0\u0CBF\u0CB8\u0CBF; \u0C85\u0CAA\u0CCD\u200C\u0CA1\u0CC7\u0C9F\u0CCD \u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0CBE\u0CB5\u0CC1 \u0CAA\u0CB0\u0CBF\u0CB6\u0CC0\u0CB2\u0CBF\u0CB8\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CA6\u0CCD\u0CA6\u0CC7\u0CB5\u0CC6.",
  "canary.detail": "\u0C88 \u0CAA\u0CC1\u0C9F\u0CA6\u0CB2\u0CCD\u0CB2\u0CBF Cformly \u0C97\u0CCA\u0CA4\u0CCD\u0CA4\u0CBF\u0CB0\u0CC1\u0CB5 {total} \u0CAB\u0CC0\u0CB2\u0CCD\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CB2\u0CCD\u0CB2\u0CBF {found} \u0CAE\u0CBE\u0CA4\u0CCD\u0CB0 \u0C95\u0C82\u0CA1\u0CC1\u0CAC\u0C82\u0CA6\u0CBF\u0CB5\u0CC6.",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "\u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CB8\u0CBE\u0CB2\u0CC1",
  "queue.add": "\u0CB8\u0CBE\u0CB2\u0CBF\u0C97\u0CC6 \u0CB8\u0CC7\u0CB0\u0CBF\u0CB8\u0CBF",
  "queue.fill": "\u0CAD\u0CB0\u0CBF\u0CB8\u0CBF",
  "queue.remove": "\u0CA4\u0CC6\u0C97\u0CC6\u0CA6\u0CC1\u0CB9\u0CBE\u0C95\u0CBF",
  "queue.unnamed": "\u0C85\u0CA4\u0CBF\u0CA5\u0CBF",
  "queue.added": "{name} \u0C85\u0CB5\u0CB0\u0CA8\u0CCD\u0CA8\u0CC1 \u0CB8\u0CBE\u0CB2\u0CBF\u0C97\u0CC6 \u0CB8\u0CC7\u0CB0\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6.",
  "queue.duplicate": "\u0C88 \u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0C88\u0C97\u0CBE\u0C97\u0CB2\u0CC7 \u0CB8\u0CBE\u0CB2\u0CBF\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF\u0CA6\u0CCD\u0CA6\u0CBE\u0CB0\u0CC6.",
  "queue.full": "\u0CB8\u0CBE\u0CB2\u0CC1 \u0CA4\u0CC1\u0C82\u0CAC\u0CBF\u0CA6\u0CC6 ({max} \u0C85\u0CA4\u0CBF\u0CA5\u0CBF\u0C97\u0CB3\u0CC1). \u0CAE\u0CCA\u0CA6\u0CB2\u0CC1 \u0C92\u0CAC\u0CCD\u0CAC \u0C85\u0CA4\u0CBF\u0CA5\u0CBF\u0CAF\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAD\u0CB0\u0CCD\u0CA4\u0CBF \u0CAE\u0CBE\u0CA1\u0CBF \u0C85\u0CA5\u0CB5\u0CBE \u0CA4\u0CC6\u0C97\u0CC6\u0CA6\u0CC1\u0CB9\u0CBE\u0C95\u0CBF.",
  "queue.hint": "\u0CAD\u0CB0\u0CCD\u0CA4\u0CBF\u0C97\u0CBE\u0C97\u0CBF \u0C95\u0CBE\u0CAF\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CB0\u0CC1\u0CB5 \u0C85\u0CA4\u0CBF\u0CA5\u0CBF\u0C97\u0CB3\u0CC1. \u0CAA\u0CC2\u0CB0\u0CCD\u0CA3 \u0CAD\u0CB0\u0CCD\u0CA4\u0CBF\u0CAF\u0CBE\u0CA6\u0CBE\u0C97 \u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CB8\u0CBE\u0CB2\u0CBF\u0CA8\u0CBF\u0C82\u0CA6 \u0CA4\u0CC6\u0C97\u0CC6\u0CA6\u0CC1\u0CB9\u0CBE\u0C95\u0CB2\u0CCD\u0CAA\u0CA1\u0CC1\u0CA4\u0CCD\u0CA4\u0CBE\u0CB0\u0CC6; \u0CAC\u0CCD\u0CB0\u0CCC\u0CB8\u0CB0\u0CCD \u0CAE\u0CC1\u0C9A\u0CCD\u0C9A\u0CBF\u0CA6\u0CBE\u0C97 \u0CB8\u0CBE\u0CB2\u0CC1 \u0C85\u0CB3\u0CBF\u0CAF\u0CC1\u0CA4\u0CCD\u0CA4\u0CA6\u0CC6.",
  "queue.unavailable": "\u0C88 \u0CAC\u0CCD\u0CB0\u0CCC\u0CB8\u0CB0\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0CA4\u0CBF\u0CA5\u0CBF \u0CB8\u0CBE\u0CB2\u0CC1 \u0CB2\u0CAD\u0CCD\u0CAF\u0CB5\u0CBF\u0CB2\u0CCD\u0CB2.",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "\u0C88 FRRO \u0C9F\u0CCD\u0CAF\u0CBE\u0CAC\u0CCD \u0C85\u0CA8\u0CCD\u0CA8\u0CC1 Cformly \u0CB8\u0CCD\u0CA5\u0CBE\u0CAA\u0CBF\u0CB8\u0CC1\u0CB5 \u0C85\u0CA5\u0CB5\u0CBE \u0CA8\u0CB5\u0CC0\u0C95\u0CB0\u0CBF\u0CB8\u0CC1\u0CB5 \u0CAE\u0CCA\u0CA6\u0CB2\u0CC1 \u0CA4\u0CC6\u0CB0\u0CC6\u0CAF\u0CB2\u0CBE\u0C97\u0CBF\u0CA4\u0CCD\u0CA4\u0CC1. \u0C88 \u0C9F\u0CCD\u0CAF\u0CBE\u0CAC\u0CCD \u0C85\u0CA8\u0CCD\u0CA8\u0CC1 \u0C92\u0CAE\u0CCD\u0CAE\u0CC6 \u0CAA\u0CC1\u0CA8\u0C83 \u0CB2\u0CCB\u0CA1\u0CCD \u0CAE\u0CBE\u0CA1\u0CBF (F5), \u0CA8\u0C82\u0CA4\u0CB0 Fill \u0C92\u0CA4\u0CCD\u0CA4\u0CBF\u0CB0\u0CBF.",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "\u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAE\u0CCD\u0CAF\u0CBE\u0CAA\u0CBF\u0C82\u0C97\u0CCD",
  "settings.mapVersion": "\u0C86\u0CB5\u0CC3\u0CA4\u0CCD\u0CA4\u0CBF",
  "settings.mapLastVerified": "\u0C95\u0CCA\u0CA8\u0CC6\u0CAF \u0CA6\u0CC3\u0CA2\u0CC0\u0C95\u0CB0\u0CA3",
  "settings.mapFetchedAt": "\u0CAA\u0CA1\u0CC6\u0CAF\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6",
  "settings.mapSignature": "Ed25519 \u0CB8\u0CB9\u0CBF",
  "settings.mapRefresh": "\u0C88\u0C97 \u0CB0\u0CBF\u0CAB\u0CCD\u0CB0\u0CC6\u0CB6\u0CCD \u0CAE\u0CBE\u0CA1\u0CBF",
  "settings.mapRefreshed": "\u0CAE\u0CCD\u0CAF\u0CBE\u0CAA\u0CBF\u0C82\u0C97\u0CCD \u0CB0\u0CBF\u0CAB\u0CCD\u0CB0\u0CC6\u0CB6\u0CCD \u0C86\u0CAF\u0CBF\u0CA4\u0CC1.",
  "settings.mapRefreshFailed": "\u0CAE\u0CCD\u0CAF\u0CBE\u0CAA\u0CBF\u0C82\u0C97\u0CCD \u0C85\u0CA8\u0CCD\u0CA8\u0CC1 \u0CB0\u0CBF\u0CAB\u0CCD\u0CB0\u0CC6\u0CB6\u0CCD \u0CAE\u0CBE\u0CA1\u0CB2\u0CBE\u0C97\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2 - \u0CB2\u0CAD\u0CCD\u0CAF\u0CB5\u0CBF\u0CB0\u0CC1\u0CB5 \u0C89\u0CA4\u0CCD\u0CA4\u0CAE \u0CAA\u0CCD\u0CB0\u0CA4\u0CBF\u0CAF\u0CA8\u0CCD\u0CA8\u0CC1 \u0CAC\u0CB3\u0CB8\u0CB2\u0CBE\u0C97\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CA6\u0CC6.",
  "settings.mapStatusRemote": "\u0CA6\u0CC3\u0CA2\u0CC0\u0C95\u0CC3\u0CA4 - \u0CAE\u0CCD\u0CAF\u0CBE\u0CAA\u0CBF\u0C82\u0C97\u0CCD \u0CB8\u0CB0\u0CCD\u0CB5\u0CB0\u0CCD\u200C\u0CA8\u0CBF\u0C82\u0CA6 \u0CAA\u0CA1\u0CC6\u0CA6 \u0CA4\u0CBE\u0C9C\u0CBE \u0CAA\u0CCD\u0CB0\u0CA4\u0CBF.",
  "settings.mapStatusCached": "\u0CA6\u0CC3\u0CA2\u0CC0\u0C95\u0CC3\u0CA4 - \u0C87\u0CA4\u0CCD\u0CA4\u0CC0\u0C9A\u0CBF\u0CA8 \u0C95\u0CCD\u0CAF\u0CBE\u0CB6\u0CC6 \u0CAA\u0CCD\u0CB0\u0CA4\u0CBF.",
  "settings.mapStatusBundled": "\u0C92\u0CB3\u0C97\u0CCA\u0C82\u0CA1\u0CBF\u0CB0\u0CC1\u0CB5 \u0CAE\u0CC2\u0CB2 \u0CAA\u0CCD\u0CB0\u0CA4\u0CBF (\u0CB8\u0CB0\u0CCD\u0CB5\u0CB0\u0CCD \u0CB2\u0CAD\u0CCD\u0CAF\u0CB5\u0CBF\u0CB2\u0CCD\u0CB2). \u0CB8\u0CB9\u0CBF \u0CB8\u0CB0\u0CBF\u0CAF\u0CBE\u0C97\u0CBF\u0CA6\u0CC6.",
  "settings.mapStatusTampered": "\u0CB8\u0CB9\u0CBF \u0CAA\u0CB0\u0CBF\u0CB6\u0CC0\u0CB2\u0CA8\u0CC6 \u0CB5\u0CBF\u0CAB\u0CB2\u0CB5\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 - \u0C88 \u0CAA\u0CCD\u0CB0\u0CA4\u0CBF \u0CA4\u0CBF\u0CB0\u0CB8\u0CCD\u0C95\u0CB0\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6, \u0CAC\u0CB3\u0C95\u0CC6\u0CAF\u0CB2\u0CCD\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2.",
  "chip.mappingUnavailable": "\u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAE\u0CCD\u0CAF\u0CBE\u0CAA\u0CBF\u0C82\u0C97\u0CCD \u0CB2\u0CCB\u0CA1\u0CCD \u0C86\u0C97\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2 \u2014 \u0C8E\u0C95\u0CCD\u0CB8\u0CCD\u200C\u0C9F\u0CC6\u0CA8\u0CCD\u0CB6\u0CA8\u0CCD \u0CB9\u0CBF\u0CA8\u0CCD\u0CA8\u0CC6\u0CB2\u0CC6 \u0C95\u0CBE\u0CB0\u0CCD\u0CAF\u0C95\u0CB0\u0CCD\u0CA4 \u0C89\u0CA4\u0CCD\u0CA4\u0CB0\u0CBF\u0CB8\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2. \u0CAA\u0CCB\u0CB0\u0CCD\u0C9F\u0CB2\u0CCD \u0C9F\u0CCD\u0CAF\u0CBE\u0CAC\u0CCD \u0C85\u0CA8\u0CCD\u0CA8\u0CC1 \u0CB0\u0CC0\u0CB2\u0CCB\u0CA1\u0CCD \u0CAE\u0CBE\u0CA1\u0CBF \u0CAE\u0CA4\u0CCD\u0CA4\u0CC6 \u0CAA\u0CCD\u0CB0\u0CAF\u0CA4\u0CCD\u0CA8\u0CBF\u0CB8\u0CBF.",
  "popup.timeoutMapping": "\u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAE\u0CCD\u0CAF\u0CBE\u0CAA\u0CBF\u0C82\u0C97\u0CCD \u0CB2\u0CCB\u0CA1\u0CCD \u0C86\u0C97\u0CC1\u0CB5 \u0CB8\u0CAE\u0CAF \u0CAE\u0CC0\u0CB0\u0CBF\u0CA6\u0CC6 ({seconds} \u0CB8\u0CC6\u0C95\u0CC6\u0C82\u0CA1\u0CCD). \u0CB8\u0C82\u0CAA\u0CB0\u0CCD\u0C95 \u0CAA\u0CB0\u0CBF\u0CB6\u0CC0\u0CB2\u0CBF\u0CB8\u0CBF \u0CAE\u0CA4\u0CCD\u0CA4\u0CC6 \u0CAA\u0CCD\u0CB0\u0CAF\u0CA4\u0CCD\u0CA8\u0CBF\u0CB8\u0CBF.",
  "popup.timeoutNoProgress": "\u0CAD\u0CB0\u0CCD\u0CA4\u0CBF {seconds} \u0CB8\u0CC6\u0C95\u0CC6\u0C82\u0CA1\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF \u0CAA\u0CCD\u0CB0\u0CBE\u0CB0\u0C82\u0CAD\u0CB5\u0CBE\u0C97\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2 \u2014 Form III \u0CAA\u0CC1\u0C9F \u0CAA\u0CCD\u0CB0\u0CA4\u0CBF\u0C95\u0CCD\u0CB0\u0CBF\u0CAF\u0CBF\u0CB8\u0CC1\u0CA4\u0CCD\u0CA4\u0CBF\u0CB2\u0CCD\u0CB2. \u0C9F\u0CCD\u0CAF\u0CBE\u0CAC\u0CCD \u0CB0\u0CC0\u0CB2\u0CCB\u0CA1\u0CCD \u0CAE\u0CBE\u0CA1\u0CBF \u0CAE\u0CA4\u0CCD\u0CA4\u0CC6 \u0CAA\u0CCD\u0CB0\u0CAF\u0CA4\u0CCD\u0CA8\u0CBF\u0CB8\u0CBF.",
  "popup.timeoutStalled": "\u0CAD\u0CB0\u0CCD\u0CA4\u0CBF {seconds} \u0CB8\u0CC6\u0C95\u0CC6\u0C82\u0CA1\u0CCD\u200C\u0C97\u0CB3\u0CBF\u0C82\u0CA6 \u0CA8\u0CBF\u0C82\u0CA4\u0CBF\u0CA6\u0CC6 \u2014 Form III \u0CAA\u0CC1\u0C9F \u0CAA\u0CCD\u0CB0\u0CA4\u0CBF\u0C95\u0CCD\u0CB0\u0CBF\u0CAF\u0CBF\u0CB8\u0CC1\u0CB5\u0CC1\u0CA6\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0CBF\u0CB2\u0CCD\u0CB2\u0CBF\u0CB8\u0CBF\u0CA6\u0CC6.",
  "popup.timeoutCap": "\u0CAD\u0CB0\u0CCD\u0CA4\u0CBF \u0C92\u0C9F\u0CCD\u0C9F\u0CC1 \u0CB8\u0CAE\u0CAF \u0CAE\u0CBF\u0CA4\u0CBF ({seconds} \u0CB8\u0CC6\u0C95\u0CC6\u0C82\u0CA1\u0CCD) \u0CAE\u0CC0\u0CB0\u0CBF\u0CA4\u0CC1 \u0CAE\u0CA4\u0CCD\u0CA4\u0CC1 \u0CA8\u0CBF\u0CB2\u0CCD\u0CB2\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6.",
  "popup.preview": "\u0CAC\u0CA6\u0CB2\u0CBE\u0CB5\u0CA3\u0CC6\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0CCB\u0CA1\u0CBF",
  "popup.previewApply": "\u0C85\u0CA8\u0CCD\u0CB5\u0CAF\u0CBF\u0CB8\u0CBF \u2014 \u0CAB\u0CBE\u0CB0\u0CCD\u0CAE\u0CCD \u0CAD\u0CB0\u0CCD\u0CA4\u0CBF \u0CAE\u0CBE\u0CA1\u0CBF",
  "popup.undo": "\u0C95\u0CCA\u0CA8\u0CC6\u0CAF \u0CAB\u0CBF\u0CB2\u0CCD \u0C85\u0CA8\u0CCD\u0CA1\u0CC1 \u0CAE\u0CBE\u0CA1\u0CBF",
  "popup.undoDone": "{total}\u0CB0\u0CB2\u0CCD\u0CB2\u0CBF {restored} \u0C95\u0CCD\u0CB7\u0CC7\u0CA4\u0CCD\u0CB0\u0C97\u0CB3\u0CA8\u0CCD\u0CA8\u0CC1 \u0CB9\u0CBF\u0C82\u0CA6\u0CBF\u0CA8 \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF\u0C97\u0CB3\u0CBF\u0C97\u0CC6 \u0CAE\u0CB0\u0CB3\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6.",
  "popup.undoPartial": "{total}\u0CB0\u0CB2\u0CCD\u0CB2\u0CBF {restored} \u0CAE\u0CB0\u0CB3\u0CBF\u0CB5\u0CC6; {failed} \u0CAE\u0CB0\u0CB3\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CB2\u0CBF\u0CB2\u0CCD\u0CB2 (\u0CAA\u0CC1\u0C9F \u0CAE\u0CB0\u0CC1\u0CA8\u0CBF\u0CB0\u0CCD\u0CAE\u0CBE\u0CA3\u0CB5\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CB9\u0CC1\u0CA6\u0CC1).",
  "popup.undoStale": "\u0CAB\u0CBF\u0CB2\u0CCD \u0C86\u0CA6 \u0CA8\u0C82\u0CA4\u0CB0 \u0CAA\u0CC1\u0C9F \u0CAC\u0CA6\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 \u2014 \u0CAE\u0CB0\u0CC1\u0CB8\u0CCD\u0CA5\u0CBE\u0CAA\u0CA8\u0CC6 \u0C85\u0CAA\u0CC2\u0CB0\u0CCD\u0CA3\u0CB5\u0CBF\u0CB0\u0CAC\u0CB9\u0CC1\u0CA6\u0CC1.",
  "popup.undoNone": "\u0C85\u0CA8\u0CCD\u0CA1\u0CC1 \u0CAE\u0CBE\u0CA1\u0CB2\u0CC1 \u0C8F\u0CA8\u0CC2 \u0C87\u0CB2\u0CCD\u0CB2 \u2014 \u0C88 \u0CB8\u0CC6\u0CB7\u0CA8\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF \u0C88 \u0C9F\u0CCD\u0CAF\u0CBE\u0CAC\u0CCD\u200C\u0CA8\u0CB2\u0CCD\u0CB2\u0CBF \u0CAF\u0CBE\u0CB5\u0CC1\u0CA6\u0CC7 \u0CAB\u0CBF\u0CB2\u0CCD \u0C86\u0C97\u0CBF\u0CB2\u0CCD\u0CB2.",
  "popup.previewUnresolved": "\u0C88 \u0CAA\u0CC1\u0C9F\u0CA6\u0CB2\u0CCD\u0CB2\u0CBF \u0C95\u0C82\u0CA1\u0CC1\u0CAC\u0C82\u0CA6\u0CBF\u0CB2\u0CCD\u0CB2",
  "popup.previewManual": "\u0C95\u0CC8\u0CAF\u0CBE\u0CB0\u0CC6 \u0CB9\u0C82\u0CA4",
  "popup.previewNoValue": "(\u0C92\u0CA6\u0C97\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CB2\u0CCD\u0CB2)"
};

// src/i18n/ta.ts
var ta = {
  // popup
  "popup.title": "Cformly \u0BA4\u0BBE\u0BA9\u0BBF\u0BAF\u0B99\u0BCD\u0B95\u0BBF \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0BA4\u0BB2\u0BCD",
  "popup.eyebrow": "\u0BA4\u0BBE\u0BA9\u0BBF\u0BAF\u0B99\u0BCD\u0B95\u0BBF \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0BA4\u0BB2\u0BCD",
  "popup.bandSub": "FRRO Form III \xB7 \u0B9A\u0BC6\u0B95\u0BCD-\u0B87\u0BA9\u0BCD \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4 24 \u0BAE\u0BA3\u0BBF \u0BA8\u0BC7\u0BB0\u0BA4\u0BCD\u0BA4\u0BBF\u0BB1\u0BCD\u0B95\u0BC1\u0BB3\u0BCD",
  "popup.fillFromClipboard": "\u0B95\u0BBF\u0BB3\u0BBF\u0BAA\u0BCD\u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BBF\u0BB2\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BAA\u0B9F\u0BBF\u0BB5\u0BA4\u0BCD\u0BA4\u0BC8 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BB5\u0BC1\u0BAE\u0BCD",
  "popup.fillHint": "Cformly \u0B9A\u0BC6\u0BAF\u0BB2\u0BBF\u0BAF\u0BBF\u0BB2\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BB5\u0BBF\u0BB5\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1, \u0BAA\u0BBF\u0BA9\u0BCD\u0BA9\u0BB0\u0BCD \u0B87\u0BA8\u0BCD\u0BA4 \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BCD \u0BAA\u0B9F\u0BBF\u0BB5\u0BA4\u0BCD\u0BA4\u0BC8 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.clipboardReadFailed": "\u0B95\u0BBF\u0BB3\u0BBF\u0BAA\u0BCD\u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BC8\u0BAA\u0BCD \u0BAA\u0B9F\u0BBF\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0B89\u0BB2\u0BBE\u0BB5\u0BBF\u0BAF\u0BBF\u0BA9\u0BCD \u0B95\u0BBF\u0BB3\u0BBF\u0BAA\u0BCD\u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BC1 \u0B85\u0BA9\u0BC1\u0BAE\u0BA4\u0BBF\u0B95\u0BB3\u0BC8\u0B9A\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.clipboardEmpty": "\u0B95\u0BBF\u0BB3\u0BBF\u0BAA\u0BCD\u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BBF\u0BB2\u0BCD Cformly \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8. \u0BAE\u0BC1\u0BA4\u0BB2\u0BBF\u0BB2\u0BCD Cformly \u0B9A\u0BC6\u0BAF\u0BB2\u0BBF\u0BAF\u0BBF\u0BB2\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BB5\u0BBF\u0BB5\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.settings": "\u0B85\u0BAE\u0BC8\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD",
  "popup.loadingMapping": "\u0BAA\u0B9F\u0BBF\u0BB5 \u0BAE\u0BC7\u0BAA\u0BCD\u0BAA\u0BBF\u0B99\u0BCD \u0B8F\u0BB1\u0BCD\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1...",
  "popup.filling": "\u0BAA\u0B9F\u0BBF\u0BB5\u0BAE\u0BCD \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1...",
  "popup.fillingProgress": "\u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1\u2026 \u0BAA\u0BC1\u0BB2\u0BAE\u0BCD {completed}/{total}",
  "popup.noTab": "\u0B9A\u0BC6\u0BAF\u0BB2\u0BBF\u0BB2\u0BCD \u0B89\u0BB3\u0BCD\u0BB3 \u0B9F\u0BC7\u0BAA\u0BCD \u0B8E\u0BA4\u0BC1\u0BB5\u0BC1\u0BAE\u0BCD \u0B95\u0BBF\u0B9F\u0BC8\u0B95\u0BCD\u0B95\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8.",
  "popup.filled": "\u0B95\u0B9F\u0BCD\u0B9F\u0BBE\u0BAF\u0BAA\u0BCD \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA9: {required} \u0B87\u0BB2\u0BCD {filledRequired} (\u0BAE\u0BCA\u0BA4\u0BCD\u0BA4\u0BAE\u0BCD {filled} \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA9)",
  "popup.portalMismatch": "\u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 \u0B8E\u0BA9\u0BCD\u0BB1\u0BC1 \u0B95\u0BA3\u0BCD\u0B9F\u0BB1\u0BBF\u0BAF\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 (DOM \u0BAE\u0BBE\u0BB1\u0BBF\u0BAF\u0BC1\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1). Cformly \u0B9A\u0BC6\u0BAF\u0BB2\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BB5\u0BBF\u0BB5\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.missingElements": "\u0BB5\u0BBF\u0B9F\u0BC1\u0BAA\u0B9F\u0BCD\u0B9F \u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD: {list}",
  "popup.missingValues": "\u0BB5\u0BBF\u0B9F\u0BC1\u0BAA\u0B9F\u0BCD\u0B9F \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD: {list}",
  "popup.manualFields": "\u0B95\u0BC8\u0BAE\u0BC1\u0BB1\u0BC8\u0BAF\u0BBE\u0B95\u0B9A\u0BCD \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BBF\u0BAF\u0BB5\u0BC8: {list}",
  "popup.unsupportedFields": "\u0BA4\u0BBE\u0BA9\u0BBF\u0BAF\u0B99\u0BCD\u0B95\u0BBF\u0BAF\u0BBE\u0B95 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BBE\u0BA4 \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BCD: {list}",
  "popup.tooLongFields": "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD \u0BAE\u0BBF\u0B95 \u0BA8\u0BC0\u0BB3\u0BAE\u0BBE\u0B95 \u0B89\u0BB3\u0BCD\u0BB3\u0BA9 \u2014 \u0B8E\u0BA4\u0BC1\u0BB5\u0BC1\u0BAE\u0BCD \u0B8E\u0BB4\u0BC1\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8, \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC8\u0BA4\u0BCD \u0BA4\u0B9F\u0BCD\u0B9F\u0B9A\u0BCD\u0B9A\u0BC1 \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BB5\u0BC1\u0BAE\u0BCD: {list}",
  "popup.unverifiedFields": "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BC8\u0B9A\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD \u2014 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1 \u0B9A\u0BB0\u0BBF\u0BAF\u0BBE\u0B95 \u0B92\u0B9F\u0BCD\u0B9F\u0BBE\u0BAE\u0BB2\u0BCD \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BB2\u0BBE\u0BAE\u0BCD: {list}",
  "popup.applicationId": "\u0BB5\u0BBF\u0BA3\u0BCD\u0BA3\u0BAA\u0BCD\u0BAA \u0B90\u0B9F\u0BBF: {id}",
  "popup.accommodationMismatch": "\u0B8E\u0B9A\u0BCD\u0B9A\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BC8: FRRO \u0B85\u0BAE\u0BB0\u0BCD\u0BB5\u0BC1 \u0BB5\u0BC7\u0BB1\u0BC1 \u0B92\u0BB0\u0BC1 \u0BB5\u0BBF\u0B9F\u0BC1\u0BA4\u0BBF\u0B95\u0BCD\u0B95\u0BC1\u0B9A\u0BCD \u0B9A\u0BCA\u0BA8\u0BCD\u0BA4\u0BAE\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BB2\u0BBE\u0BAE\u0BCD. \u0B9A\u0BAE\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BBF\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BA9\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.attention": "\u0B9A\u0BBF\u0BB2 \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0B95\u0BCD \u0B95\u0BB5\u0BA9\u0BAE\u0BCD \u0BA4\u0BC7\u0BB5\u0BC8. Cformly \u0B9A\u0BC6\u0BAF\u0BB2\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BB5\u0BBF\u0BB5\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.openPrint": "\u0BA4\u0BA9\u0BBF\u0BA8\u0BAA\u0BB0\u0BCD \u0B85\u0B9A\u0BCD\u0B9A\u0BC1 \u0BA4\u0BBF\u0BB1\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD",
  "popup.printNoId": "\u0B87\u0BA9\u0BCD\u0BA9\u0BC1\u0BAE\u0BCD \u0BB5\u0BBF\u0BA3\u0BCD\u0BA3\u0BAA\u0BCD\u0BAA \u0B90\u0B9F\u0BBF \u0BAA\u0BA4\u0BBF\u0BB5\u0BBE\u0B95\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 \u2014 \u0BAE\u0BC1\u0BA4\u0BB2\u0BBF\u0BB2\u0BCD \u0BAA\u0B9F\u0BBF\u0BB5\u0BA4\u0BCD\u0BA4\u0BC8 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.printSent": "\u0B90\u0B9F\u0BBF {id} \u0B95\u0BCD\u0B95\u0BC1 \u0B9A\u0BAE\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0BB5\u0BBF\u0BA3\u0BCD\u0BA3\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BA4\u0BBF\u0BB1\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1. PDF \u0BAA\u0BA4\u0BBF\u0BB5\u0BBF\u0BB1\u0B95\u0BCD\u0B95 \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BBF\u0BA9\u0BCD \u0BA4\u0BA9\u0BBF\u0BA8\u0BAA\u0BB0\u0BCD \u0B85\u0B9A\u0BCD\u0B9A\u0BC1 \u0BAE\u0BC6\u0BA9\u0BC1\u0BB5\u0BC8\u0BAA\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.formFilled": "\u0BAA\u0B9F\u0BBF\u0BB5\u0BAE\u0BCD \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1. \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BBF\u0BB2\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0BA4\u0BCD\u0BA4\u0BC1 \u0B9A\u0BAE\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.fillError": "\u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0BA4\u0BB2\u0BCD \u0BAA\u0BBF\u0BB4\u0BC8: {message}",
  "popup.connectionFailed": "FRRO \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC8 \u0B85\u0BA3\u0BC1\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0B87\u0BA8\u0BCD\u0BA4 \u0B9F\u0BC7\u0BAA\u0BBF\u0BB2\u0BCD Form III \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.unknownError": "\u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8",
  "popup.apiBaseFallback": "\u0B8E\u0B9A\u0BCD\u0B9A\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BC8: \u0B9A\u0BC7\u0BAE\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F API URL \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9\u0BA4\u0BC1 \u2014 \u0B87\u0BAF\u0BB2\u0BCD\u0BAA\u0BC1\u0BA8\u0BBF\u0BB2\u0BC8 \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1. \u0B85\u0BAE\u0BC8\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0B85\u0BA4\u0BC8\u0BAA\u0BCD \u0BAA\u0BC1\u0BA4\u0BC1\u0BAA\u0BCD\u0BAA\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.mappingFallback": "\u0B8E\u0B9A\u0BCD\u0B9A\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BC8: \u0BAE\u0BC7\u0BAA\u0BCD\u0BAA\u0BBF\u0B99\u0BCD \u0B9A\u0BB0\u0BCD\u0BB5\u0BB0\u0BC8 \u0B85\u0BA3\u0BC1\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 \u2014 \u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B95\u0BCD\u0B95\u0BBF\u0BAF \u0BAA\u0BC1\u0BB2 \u0BB5\u0BB0\u0BC8\u0BAA\u0B9F\u0BAE\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1; \u0B85\u0BA4\u0BC1 \u0B95\u0BBE\u0BB2\u0BBE\u0BB5\u0BA4\u0BBF\u0BAF\u0BBE\u0B95\u0BBF\u0BAF\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BB2\u0BBE\u0BAE\u0BCD.",
  // settings
  "settings.title": "Cformly \u0B85\u0BAE\u0BC8\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD",
  "settings.eyebrow": "\u0B85\u0BAE\u0BC8\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD",
  "settings.bandSub": "\u0BAA\u0B9F\u0BBF\u0BB5 \u0BAE\u0BC7\u0BAA\u0BCD\u0BAA\u0BBF\u0B99\u0BCD \u0BB5\u0BB4\u0B99\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BAA\u0BBF\u0BA9\u0BCD\u0BA8\u0BBF\u0BB2\u0BC8 \u0B9A\u0BC7\u0BB5\u0BC8\u0BAF\u0BC8 \u0B89\u0BB3\u0BCD\u0BB3\u0BAE\u0BC8\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "\u0BAA\u0B9F\u0BBF\u0BB5 \u0BAE\u0BC7\u0BAA\u0BCD\u0BAA\u0BBF\u0B99\u0BCD \u0BB5\u0BB4\u0B99\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BAA\u0BBF\u0BA9\u0BCD\u0BA8\u0BBF\u0BB2\u0BC8 \u0B9A\u0BC7\u0BB5\u0BC8. HTTPS \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD; localhost \u0B89\u0BB0\u0BC1\u0BB5\u0BBE\u0B95\u0BCD\u0B95\u0B95\u0BCD \u0B95\u0B9F\u0BCD\u0B9F\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BC7 \u0BB5\u0BC7\u0BB2\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BC1\u0BAE\u0BCD.",
  "settings.save": "\u0B9A\u0BC7\u0BAE\u0BBF",
  "settings.back": "\u0BAA\u0BBF\u0BA9\u0BCD\u0B9A\u0BC6\u0BB2\u0BCD",
  "settings.backInTab": "\u0B85\u0BAE\u0BC8\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD \u0B92\u0BB0\u0BC1 \u0B9F\u0BC7\u0BAA\u0BBE\u0B95\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4\u0BC1\u0BB3\u0BCD\u0BB3\u0BA9 \u2014 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0BAE\u0BCD \u0BAA\u0BBE\u0BAA\u0BCD\u0B85\u0BAA\u0BCD\u0BAA\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0B95\u0BCD\u0B95 Cformly \u0B95\u0BB0\u0BC1\u0BB5\u0BBF\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BBF \u0B90\u0B95\u0BBE\u0BA9\u0BC8\u0BAA\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD.",
  "settings.urlEmpty": "URL \u0B95\u0BBE\u0BB2\u0BBF\u0BAF\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BBE\u0BA4\u0BC1.",
  "settings.httpsOnly": "\u0BAA\u0BBE\u0BA4\u0BC1\u0B95\u0BBE\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BCD\u0B95\u0BBE\u0B95 HTTPS URL \u0B95\u0BB3\u0BCD \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BC7 \u0B85\u0BA9\u0BC1\u0BAE\u0BA4\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BA9. \u0B89\u0BB1\u0BCD\u0BAA\u0BA4\u0BCD\u0BA4\u0BBF\u0B95\u0BCD\u0B95\u0BC1 https:// \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD.",
  "settings.hostNotAllowed": "URL \u0BB9\u0BCB\u0BB8\u0BCD\u0B9F\u0BCD\u0BAA\u0BC6\u0BAF\u0BB0\u0BCD localhost \u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 *.cformly.com \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD (\u0B95\u0BBF\u0B9F\u0BC8\u0BA4\u0BCD\u0BA4\u0BA4\u0BC1: {host}).",
  "settings.invalidUrl": "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 URL. https:// \u0B9A\u0BC7\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD",
  "settings.urlPathNotAllowed": "\u0BB5\u0BC6\u0BB1\u0BC1\u0BAE\u0BCD origin \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD \u2014 path, query \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD #fragment \u0B90 \u0B85\u0B95\u0BB1\u0BCD\u0BB1\u0BB5\u0BC1\u0BAE\u0BCD.",
  "settings.loopbackNotGranted": "Localhost API URL \u0B95\u0BB3\u0BCD \u0B89\u0BB0\u0BC1\u0BB5\u0BBE\u0B95\u0BCD\u0B95\u0B95\u0BCD \u0B95\u0B9F\u0BCD\u0B9F\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BC7 \u0BB5\u0BC7\u0BB2\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BC1\u0BAE\u0BCD. \u0B87\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0B9F\u0BCD\u0B9F\u0BAE\u0BBE\u0BA9\u0BA4\u0BC1 https:// \u0BB9\u0BCB\u0BB8\u0BCD\u0B9F\u0BCD\u0B95\u0BB3\u0BC8 \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BC7 \u0B85\u0BA3\u0BC1\u0B95\u0BC1\u0BAE\u0BCD.",
  "settings.saved": "\u0B9A\u0BC7\u0BAE\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
  "settings.saveError": "\u0B9A\u0BC7\u0BAE\u0BBF\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "settings.langLabel": "\u0BAE\u0BCA\u0BB4\u0BBF",
  "settings.langEnglish": "English",
  "settings.langHindi": "\u0939\u093F\u0928\u094D\u0926\u0940",
  "settings.langAuto": "\u0B89\u0BB2\u0BBE\u0BB5\u0BBF\u0BAF\u0BC8\u0BAA\u0BCD \u0BAA\u0BBF\u0BA9\u0BCD\u0BAA\u0BB1\u0BCD\u0BB1\u0BB5\u0BC1\u0BAE\u0BCD",
  "settings.langHint": "\u0BA8\u0BC0\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BA4\u0BC7\u0BB0\u0BCD\u0BB5\u0BC1 \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BC1\u0BAE\u0BCD \u0BB5\u0BB0\u0BC8 \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B89\u0BB2\u0BBE\u0BB5\u0BBF \u0BAE\u0BCA\u0BB4\u0BBF\u0BAF\u0BC7 \u0B87\u0BAF\u0BB2\u0BCD\u0BAA\u0BC1\u0BA8\u0BBF\u0BB2\u0BC8\u0BAF\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD.",
  // round-65: paste intake + in-page filing panel
  "popup.pasteLabel": "\u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0B87\u0B99\u0BCD\u0B95\u0BC7 \u0B92\u0B9F\u0BCD\u0B9F\u0BB5\u0BC1\u0BAE\u0BCD",
  "popup.pdfPick": "Cformly PDF \u0B90\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD",
  "popup.pdfLoaded": "\u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BCD Cformly PDF-\u0B87\u0BB2\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0B8F\u0BB1\u0BCD\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA9 \u2014 \u0B95\u0BC0\u0BB4\u0BC7 \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0BA4\u0BCD\u0BA4\u0BC1, \u0BAA\u0BBF\u0BA9\u0BCD Fill Form \u0B90 \u0B85\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.pdfRejected": "\u0B87\u0BA8\u0BCD\u0BA4 PDF-\u0B87\u0BB2\u0BCD Cformly \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8 \u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 \u0B85\u0BA4\u0BC8\u0BAA\u0BCD \u0BAA\u0B9F\u0BBF\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 \u2014 Cformly \u0B86\u0BAA\u0BCD \u0B8F\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BA4\u0BBF \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4 PDF-\u0B90\u0BAF\u0BC7 \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD.",
  "popup.pastePlaceholder": "\u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4 Cformly \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0B87\u0B99\u0BCD\u0B95\u0BC7 \u0B92\u0B9F\u0BCD\u0B9F\u0BB5\u0BC1\u0BAE\u0BCD",
  "popup.pasteHint": "\u0B95\u0BBF\u0BB3\u0BBF\u0BAA\u0BCD\u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BC1 \u0BAA\u0BCA\u0BA4\u0BCD\u0BA4\u0BBE\u0BA9\u0BCD \u0BB5\u0BC7\u0BB2\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BBE\u0BB5\u0BBF\u0B9F\u0BCD\u0B9F\u0BBE\u0BB2\u0BCD, \u0B87\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0BA3\u0BBF\u0BA9\u0BBF\u0B95\u0BCD\u0B95\u0BC1 \u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BBF\u0BAF \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0B87\u0B99\u0BCD\u0B95\u0BC7 \u0B92\u0B9F\u0BCD\u0B9F\u0BB5\u0BC1\u0BAE\u0BCD (\u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 \u0B89\u0BB0\u0BC8\u0B95\u0BCD \u0B95\u0BCB\u0BAA\u0BCD\u0BAA\u0BC8 \u0BB5\u0BBF\u0B9F\u0BB5\u0BC1\u0BAE\u0BCD), \u0BAA\u0BBF\u0BA9\u0BCD \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1 \u0B8E\u0BA9\u0BCD\u0BAA\u0BA4\u0BC8 \u0B85\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD.",
  "popup.payloadTooLarge": "\u0B92\u0B9F\u0BCD\u0B9F\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0B89\u0BB0\u0BC8 \u0BAE\u0BBF\u0B95\u0BAA\u0BCD \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1 \u2014 Cformly \u0B9A\u0BC6\u0BAF\u0BB2\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0B87\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4 \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0B92\u0B9F\u0BCD\u0B9F\u0BB5\u0BC1\u0BAE\u0BCD.",
  "panel.title": "Cformly \u2014 \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BBF\u0BB2\u0BCD \u0BAA\u0BA4\u0BBF\u0BB5\u0BC1 \u0BAE\u0BC1\u0B9F\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD",
  "panel.dismiss": "\u0BAE\u0BC2\u0B9F\u0BC1\u0B95",
  "panel.filled": "\u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BCD: {filledRequired} / {required} \u0B95\u0B9F\u0BCD\u0B9F\u0BBE\u0BAF\u0BAE\u0BCD",
  "panel.photoStep": "\u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BAA\u0BC1\u0B95\u0BC8\u0BAA\u0BCD\u0BAA\u0B9F\u0BA4\u0BCD\u0BA4\u0BC8 \u0B87\u0BA3\u0BC8\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD (\u0B95\u0BCB\u0BAA\u0BCD\u0BAA\u0BC8\u0BA4\u0BCD \u0BA4\u0BC7\u0BB0\u0BCD\u0BA8\u0BCD\u0BA4\u0BC6\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD \u2192 \u0BAA\u0BA4\u0BBF\u0BB5\u0BC7\u0BB1\u0BCD\u0BB1\u0BB5\u0BC1\u0BAE\u0BCD)",
  "panel.captchaStep": "\u0BAA\u0BBE\u0BA4\u0BC1\u0B95\u0BBE\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BCD\u0B9F\u0BC8 (CAPTCHA) \u0BA4\u0B9F\u0BCD\u0B9F\u0B9A\u0BCD\u0B9A\u0BC1 \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BB5\u0BC1\u0BAE\u0BCD",
  "panel.saveStep": "\u0B9A\u0BC7\u0BAE\u0BBF\u0BA4\u0BCD\u0BA4\u0BC1 \u0BA4\u0BCA\u0B9F\u0BB0\u0BB5\u0BC1\u0BAE\u0BCD \u0B8E\u0BA9\u0BCD\u0BAA\u0BA4\u0BC8 \u0B85\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD",
  "panel.warnSession": "Cformly \u0B8E\u0B9A\u0BCD\u0B9A\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BC8: \u0B87\u0BA8\u0BCD\u0BA4 FRRO \u0B85\u0BAE\u0BB0\u0BCD\u0BB5\u0BC1 \u0BB5\u0BC7\u0BB1\u0BC1 \u0B9A\u0BCA\u0BA4\u0BCD\u0BA4\u0BBF\u0BA9\u0BC1\u0B9F\u0BC8\u0BAF\u0BA4\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BB2\u0BBE\u0BAE\u0BCD ({reason}). \u0B9A\u0BC7\u0BAE\u0BBF\u0BAA\u0BCD\u0BAA\u0BA4\u0BB1\u0BCD\u0B95\u0BC1 \u0BAE\u0BC1\u0BA9\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "panel.warnUnverified": "Cformly \u0B8E\u0B9A\u0BCD\u0B9A\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BC8: \u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0BA9\u0BCD \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD \u0BA8\u0BBF\u0BB2\u0BC8\u0B95\u0BCD\u0B95\u0BBE\u0BAE\u0BB2\u0BCD \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BB2\u0BBE\u0BAE\u0BCD: {list}. \u0B9A\u0BC7\u0BAE\u0BBF\u0BAA\u0BCD\u0BAA\u0BA4\u0BB1\u0BCD\u0B95\u0BC1 \u0BAE\u0BC1\u0BA9\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "panel.saving": "\u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BCD \u0B89\u0BB1\u0BC1\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BB2\u0BC1\u0B95\u0BCD\u0B95\u0BBE\u0B95 \u0B95\u0BBE\u0BA4\u0BCD\u0BA4\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BBF\u0BB1\u0BA4\u0BC1\u2026",
  "panel.progress": "\u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BA9\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO \u0B85\u0BAE\u0BB0\u0BCD\u0BB5\u0BC1 \u0B95\u0BBE\u0BB2\u0BBE\u0BB5\u0BA4\u0BBF\u0BAF\u0BBE\u0BA9\u0BA4\u0BC1 \u2014 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0B89\u0BB3\u0BCD\u0BA8\u0BC1\u0BB4\u0BC8\u0BA8\u0BCD\u0BA4\u0BC1, \u0BAA\u0B9F\u0BBF\u0BB5\u0BA4\u0BCD\u0BA4\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4\u0BC1 Fill \u0B90 \u0B85\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD. \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BB5\u0BBF\u0BB5\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BCD Cformly \u0B86\u0BAA\u0BCD\u0BAA\u0BBF\u0BB2\u0BCD \u0B9A\u0BC7\u0BAE\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BC1\u0BB3\u0BCD\u0BB3\u0BA9.",
  "panel.portalError": "\u0B87\u0BA3\u0BC8\u0BAF\u0BA4\u0BB3\u0BAE\u0BCD \u0B9A\u0BBF\u0B95\u0BCD\u0B95\u0BB2\u0BC8\u0B95\u0BCD \u0B95\u0BBE\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF\u0BA4\u0BC1:",
  "panel.appIdFound": "\u0BB5\u0BC6\u0BB1\u0BCD\u0BB1\u0BBF\u0B95\u0BB0\u0BAE\u0BBE\u0B95\u0BAA\u0BCD \u0BAA\u0BA4\u0BBF\u0BB5\u0BC1 \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1. \u0BB5\u0BBF\u0BA3\u0BCD\u0BA3\u0BAA\u0BCD\u0BAA \u0B90\u0B9F\u0BBF:",
  "panel.scanHint": "Cformly \u0B9A\u0BC6\u0BAF\u0BB2\u0BBF\u0BAF\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD \u2192 \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BB5\u0BC1\u0BAE\u0BCD \u2192 \u0B95\u0BA3\u0BBF\u0BA9\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0B87\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BB8\u0BCD\u0B95\u0BC7\u0BA9\u0BCD \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BB5\u0BC1\u0BAE\u0BCD, \u0B87\u0BA8\u0BCD\u0BA4\u0B95\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BCD\u0B9F\u0BC8 \u0B95\u0BC7\u0BAE\u0BB0\u0BBE\u0BB5\u0BBE\u0BB2\u0BCD \u0B95\u0BBE\u0B9F\u0BCD\u0B9F\u0BB5\u0BC1\u0BAE\u0BCD \u2014 \u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 \u0B90\u0B9F\u0BBF\u0BAF\u0BC8 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD.",
  "panel.copy": "\u0BB5\u0BBF\u0BA3\u0BCD\u0BA3\u0BAA\u0BCD\u0BAA \u0B90\u0B9F\u0BBF\u0BAF\u0BC8 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD",
  "panel.copied": "\u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
  "panel.confirmNotDetected": "\u0B89\u0BB1\u0BC1\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BB2\u0BCD \u0B95\u0BA3\u0BCD\u0B9F\u0BB1\u0BBF\u0BAF\u0BAA\u0BCD\u0BAA\u0B9F\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 \u2014 \u0BA4\u0BB3\u0BAE\u0BCD \u0B9A\u0BC7\u0BAE\u0BBF\u0BA4\u0BCD\u0BA4\u0BA4\u0BBE \u0B8E\u0BA9\u0BCD\u0BB1\u0BC1 \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0BA4\u0BCD\u0BA4\u0BC1, \u0BAA\u0BBF\u0BA9\u0BCD \u0BA4\u0BCA\u0B9F\u0BB0\u0BB5\u0BC1\u0BAE\u0BCD.",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "\u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BAA\u0BC1\u0B95\u0BC8\u0BAA\u0BCD\u0BAA\u0B9F\u0BA4\u0BCD\u0BA4\u0BC8 \u0B87\u0BA3\u0BC8\u0B95\u0BCD\u0B95 \u0B87\u0B99\u0BCD\u0B95\u0BC7 \u0BB5\u0BBF\u0B9F\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD",
  "panel.photoBrowse": "\u0B89\u0BB2\u0BBE\u0BB5\u0BC1\u2026",
  "panel.photoAttachFailed": "\u0BA4\u0BBE\u0BA9\u0BBE\u0B95 \u0B87\u0BA3\u0BC8\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 \u2014 \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BBF\u0BA9\u0BCD \u0B9A\u0BCA\u0BA8\u0BCD\u0BA4 \u0B95\u0BCB\u0BAA\u0BCD\u0BAA\u0BC8\u0BA4\u0BCD \u0BA4\u0BC7\u0BB0\u0BCD\u0BA8\u0BCD\u0BA4\u0BC6\u0B9F\u0BC1 \u0BAA\u0BCA\u0BA4\u0BCD\u0BA4\u0BBE\u0BA9\u0BC8\u0BAA\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD.",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "\u0B87\u0BA8\u0BCD\u0BA4 \u0BAA\u0B9F\u0BBF\u0BB5\u0BA4\u0BCD\u0BA4\u0BC8 Cformly \u0BAE\u0BC2\u0BB2\u0BAE\u0BCD \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD",
  "chip.hint": "\u0B87\u0BA8\u0BCD\u0BA4 \u0B95\u0BA3\u0BBF\u0BA9\u0BBF\u0B95\u0BCD\u0B95\u0BC1 \u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BBF\u0BAF \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BB5\u0BBF\u0BB5\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0B87\u0B99\u0BCD\u0B95\u0BC7 \u0B92\u0B9F\u0BCD\u0B9F\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD (\u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 \u0B89\u0BB0\u0BC8\u0B95\u0BCD \u0B95\u0BCB\u0BAA\u0BCD\u0BAA\u0BC8 \u0B87\u0B99\u0BCD\u0B95\u0BC7 \u0BB5\u0BBF\u0B9F\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD), \u0BAA\u0BBF\u0BB1\u0B95\u0BC1 \u0BAA\u0B9F\u0BBF\u0BB5\u0BA4\u0BCD\u0BA4\u0BC8 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1 \u0B85\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD.",
  "chip.fill": "\u0BAA\u0B9F\u0BBF\u0BB5\u0BA4\u0BCD\u0BA4\u0BC8 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1",
  "chip.filling": "\u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1\u2026",
  "chip.empty": "\u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA \u0B8E\u0BA4\u0BC1\u0BB5\u0BC1\u0BAE\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8 \u2014 \u0BAE\u0BC1\u0BA4\u0BB2\u0BBF\u0BB2\u0BCD Cformly \u0B9A\u0BC6\u0BAF\u0BB2\u0BBF\u0BAF\u0BBF\u0BB2\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4 \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BB5\u0BBF\u0BB5\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0B92\u0B9F\u0BCD\u0B9F\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD.",
  "chip.tooLarge": "\u0B92\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF \u0B89\u0BB0\u0BC8 \u0BAE\u0BBF\u0B95\u0BAA\u0BCD \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1 \u2014 Cformly \u0B9A\u0BC6\u0BAF\u0BB2\u0BBF\u0BAF\u0BBF\u0BB2\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4 \u0BB5\u0BBF\u0BB5\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0B92\u0B9F\u0BCD\u0B9F\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD.",
  "chip.collapse": "\u0BAE\u0BC2\u0B9F\u0BC1",
  "chip.mappingFallback": "\u0B95\u0BC1\u0BB1\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1: \u0BAE\u0BC7\u0BAA\u0BCD\u0BAA\u0BBF\u0B99\u0BCD \u0B9A\u0BC7\u0BB5\u0BC8\u0BAF\u0B95\u0BAE\u0BCD \u0B8E\u0B9F\u0BCD\u0B9F\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 \u2014 \u0B89\u0BB3\u0BCD\u0BB3\u0BAE\u0BC8\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0BAA\u0BC1\u0BB2 \u0BB5\u0BB0\u0BC8\u0BAA\u0B9F\u0BAE\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1, \u0B85\u0BA4\u0BC1 \u0BAA\u0BB4\u0BC8\u0BAF\u0BA4\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BB2\u0BBE\u0BAE\u0BCD.",
  // round-66: popup first-run onboarding
  "onboarding.title": "\u0BAE\u0BC1\u0BA4\u0BB2\u0BCD \u0BAE\u0BC1\u0BB1\u0BC8\u0BAF\u0BBE? \u0BAE\u0BC2\u0BA9\u0BCD\u0BB1\u0BC1 \u0BAA\u0B9F\u0BBF\u0B95\u0BB3\u0BCD:",
  "onboarding.step1": "\u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BAA\u0BCB\u0BA9\u0BBF\u0BB2\u0BCD: \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BC8\u0BA4\u0BCD \u0BA4\u0BBF\u0BB1 \u2192 \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1 \u2192 \u0B95\u0BA3\u0BBF\u0BA9\u0BBF\u0B95\u0BCD\u0B95\u0BC1 \u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1.",
  "onboarding.step2": "\u0B87\u0BA8\u0BCD\u0BA4 \u0B95\u0BA3\u0BBF\u0BA9\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD: \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BBF\u0BAF \u0BB5\u0BBF\u0BB5\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0B95\u0BC0\u0BB4\u0BC7 \u0B89\u0BB3\u0BCD\u0BB3 \u0BAA\u0BC6\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0B92\u0B9F\u0BCD\u0B9F\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD (\u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 \u0BAA\u0B9F\u0BBF\u0BB5\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B89\u0BB3\u0BCD\u0BB3 \u0BA8\u0BC0\u0BB2 Cformly \u0BAA\u0BCA\u0BA4\u0BCD\u0BA4\u0BBE\u0BA9\u0BC8 \u0B85\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD).",
  "onboarding.step3": "\u0BAA\u0B9F\u0BBF\u0BB5\u0BA4\u0BCD\u0BA4\u0BC8 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1 \u0B85\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u2014 \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BCD \u0BAA\u0B9F\u0BBF\u0BB5\u0BAE\u0BCD \u0BA4\u0BBE\u0BA9\u0BBE\u0B95 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BAE\u0BCD. \u0BAA\u0BC1\u0B95\u0BC8\u0BAA\u0BCD\u0BAA\u0B9F\u0BAE\u0BCD, \u0BAA\u0BBE\u0BA4\u0BC1\u0B95\u0BBE\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1, \u0B9A\u0BC7\u0BAE\u0BBF \u0B86\u0B95\u0BBF\u0BAF\u0BB5\u0BB1\u0BCD\u0BB1\u0BC8 \u0BA8\u0BC0\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD.",
  "onboarding.done": "\u0BAA\u0BC1\u0BB0\u0BBF\u0BA8\u0BCD\u0BA4\u0BA4\u0BC1",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{total} \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0BB2\u0BCD {filled} {time} \u0B85\u0BA9\u0BCD\u0BB1\u0BC1 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA9. \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA \u0BA4\u0BCA\u0B9F\u0BB0\u0BB5\u0BC1\u0BAE\u0BCD.",
  "resume.button": "\u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "\u0B87\u0BA8\u0BCD\u0BA4 \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BAE\u0BCD Cformly \u0B85\u0BB1\u0BBF\u0BA8\u0BCD\u0BA4 Form III \u0BAA\u0BCB\u0BB2\u0BCD \u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 \u2014 \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BCD \u0BAE\u0BBE\u0BB1\u0BBF\u0BAF\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BB2\u0BBE\u0BAE\u0BCD. \u0B87\u0BA8\u0BCD\u0BA4 \u0BAE\u0BC1\u0BB1\u0BC8 Cformly \u0B9A\u0BC6\u0BAF\u0BB2\u0BBF\u0BAF\u0BBF\u0BB2\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0BA8\u0B95\u0BB2\u0BC6\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1 \u0BA8\u0BC0\u0B99\u0BCD\u0B95\u0BB3\u0BC7 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD; \u0BAA\u0BC1\u0BA4\u0BC1\u0BAA\u0BCD\u0BAA\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BC8 \u0BA8\u0BBE\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B95\u0BA3\u0BCD\u0B95\u0BBE\u0BA3\u0BBF\u0B95\u0BCD\u0B95\u0BBF\u0BB1\u0BCB\u0BAE\u0BCD.",
  "canary.detail": "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD Cformly \u0B85\u0BB1\u0BBF\u0BA8\u0BCD\u0BA4 {total} \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0BB2\u0BCD {found} \u0BAE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BC7 \u0B95\u0BBE\u0BA3\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA9.",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "\u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BB5\u0BB0\u0BBF\u0B9A\u0BC8",
  "queue.add": "\u0BB5\u0BB0\u0BBF\u0B9A\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD \u0B9A\u0BC7\u0BB0\u0BCD",
  "queue.fill": "\u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1",
  "queue.remove": "\u0B85\u0B95\u0BB1\u0BCD\u0BB1\u0BC1",
  "queue.unnamed": "\u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD",
  "queue.added": "{name} \u0BB5\u0BB0\u0BBF\u0B9A\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD \u0B9A\u0BC7\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
  "queue.duplicate": "\u0B87\u0BA8\u0BCD\u0BA4 \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0B8F\u0BB1\u0BCD\u0B95\u0BA9\u0BB5\u0BC7 \u0BB5\u0BB0\u0BBF\u0B9A\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD \u0B89\u0BB3\u0BCD\u0BB3\u0BBE\u0BB0\u0BCD.",
  "queue.full": "\u0BB5\u0BB0\u0BBF\u0B9A\u0BC8 \u0BA8\u0BBF\u0BB0\u0BAE\u0BCD\u0BAA\u0BBF\u0BAF\u0BA4\u0BC1 ({max} \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD). \u0BAE\u0BC1\u0BA4\u0BB2\u0BBF\u0BB2\u0BCD \u0B92\u0BB0\u0BC1 \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BC8 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 \u0B85\u0B95\u0BB1\u0BCD\u0BB1\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD.",
  "queue.hint": "\u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA \u0B95\u0BBE\u0BA4\u0BCD\u0BA4\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD. \u0BAE\u0BC1\u0BB4\u0BC1\u0BAE\u0BC8\u0BAF\u0BBE\u0BA9 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0BA4\u0BB2\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAA\u0BCD \u0BAA\u0BBF\u0BB1\u0B95\u0BC1 \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BB5\u0BB0\u0BBF\u0B9A\u0BC8\u0BAF\u0BBF\u0BB2\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BA8\u0BC0\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BB5\u0BBE\u0BB0\u0BCD; \u0B89\u0BB2\u0BBE\u0BB5\u0BBF \u0BAE\u0BC2\u0B9F\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BAE\u0BCD\u0BAA\u0BCB\u0BA4\u0BC1 \u0BB5\u0BB0\u0BBF\u0B9A\u0BC8 \u0B85\u0BB4\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BAE\u0BCD.",
  "queue.unavailable": "\u0B87\u0BA8\u0BCD\u0BA4 \u0B89\u0BB2\u0BBE\u0BB5\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0BB5\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BBF\u0BA9\u0BB0\u0BCD \u0BB5\u0BB0\u0BBF\u0B9A\u0BC8 \u0B95\u0BBF\u0B9F\u0BC8\u0B95\u0BCD\u0B95\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8.",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "\u0B87\u0BA8\u0BCD\u0BA4 FRRO \u0B9F\u0BC7\u0BAA\u0BCD Cformly \u0BA8\u0BBF\u0BB1\u0BC1\u0BB5\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BB5\u0BA4\u0BB1\u0BCD\u0B95\u0BC1 \u0B85\u0BB2\u0BCD\u0BB2\u0BA4\u0BC1 \u0BAA\u0BC1\u0BA4\u0BC1\u0BAA\u0BCD\u0BAA\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BB5\u0BA4\u0BB1\u0BCD\u0B95\u0BC1 \u0BAE\u0BC1\u0BA9\u0BCD \u0BA4\u0BBF\u0BB1\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1. \u0B87\u0BA8\u0BCD\u0BA4 \u0B9F\u0BC7\u0BAA\u0BC8 \u0B92\u0BB0\u0BC1\u0BAE\u0BC1\u0BB1\u0BC8 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0B8F\u0BB1\u0BCD\u0BB1\u0BB5\u0BC1\u0BAE\u0BCD (F5), \u0BAA\u0BBF\u0BB1\u0B95\u0BC1 Fill \u0B90 \u0B85\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD.",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "\u0BAA\u0B9F\u0BBF\u0BB5 \u0BAE\u0BC7\u0BAA\u0BCD\u0BAA\u0BBF\u0B99\u0BCD",
  "settings.mapVersion": "\u0BAA\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1",
  "settings.mapLastVerified": "\u0B95\u0B9F\u0BC8\u0B9A\u0BBF \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BC1",
  "settings.mapFetchedAt": "\u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1",
  "settings.mapSignature": "Ed25519 \u0B95\u0BC8\u0BAF\u0BCA\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD",
  "settings.mapRefresh": "\u0B87\u0BAA\u0BCD\u0BAA\u0BCB\u0BA4\u0BC1 \u0BAA\u0BC1\u0BA4\u0BC1\u0BAA\u0BCD\u0BAA\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BC1\u0BAE\u0BCD",
  "settings.mapRefreshed": "\u0BAE\u0BC7\u0BAA\u0BCD\u0BAA\u0BBF\u0B99\u0BCD \u0BAA\u0BC1\u0BA4\u0BC1\u0BAA\u0BCD\u0BAA\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
  "settings.mapRefreshFailed": "\u0BAE\u0BC7\u0BAA\u0BCD\u0BAA\u0BBF\u0B99\u0BCD\u0B95\u0BC8\u0BAA\u0BCD \u0BAA\u0BC1\u0BA4\u0BC1\u0BAA\u0BCD\u0BAA\u0BBF\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 - \u0B95\u0BBF\u0B9F\u0BC8\u0B95\u0BCD\u0B95\u0B95\u0BCD\u0B95\u0BC2\u0B9F\u0BBF\u0BAF \u0B9A\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4 \u0BA8\u0B95\u0BB2\u0BC8\u0BAA\u0BCD \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BBF\u0BB1\u0BCB\u0BAE\u0BCD.",
  "settings.mapStatusRemote": "\u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 - \u0BAE\u0BC7\u0BAA\u0BCD\u0BAA\u0BBF\u0B99\u0BCD \u0B9A\u0BC7\u0BB5\u0BC8\u0BAF\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BBF\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BC1 \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0BA8\u0B95\u0BB2\u0BCD.",
  "settings.mapStatusCached": "\u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 - \u0B9A\u0BAE\u0BC0\u0BAA\u0BA4\u0BCD\u0BA4\u0BBF\u0BAF \u0BA4\u0BB1\u0BCD\u0B95\u0BBE\u0BB2\u0BBF\u0B95 \u0BA8\u0B95\u0BB2\u0BCD.",
  "settings.mapStatusBundled": "\u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B99\u0BCD\u0B95\u0BBF\u0BAF \u0B85\u0B9F\u0BBF\u0BAA\u0BCD\u0BAA\u0B9F\u0BC8 \u0BA8\u0B95\u0BB2\u0BCD (\u0B9A\u0BC7\u0BB5\u0BC8\u0BAF\u0B95\u0BAE\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8). \u0B95\u0BC8\u0BAF\u0BCA\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD \u0B9A\u0BB0\u0BBF\u0BAF\u0BBE\u0B95 \u0B89\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1.",
  "settings.mapStatusTampered": "\u0B95\u0BC8\u0BAF\u0BCA\u0BAA\u0BCD\u0BAA\u0B9A\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BC1 \u0BA4\u0BCB\u0BB2\u0BCD\u0BB5\u0BBF - \u0B87\u0BA8\u0BCD\u0BA4 \u0BA8\u0B95\u0BB2\u0BCD \u0BA8\u0BBF\u0BB0\u0BBE\u0B95\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BC1\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1, \u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BBF\u0BB2\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8.",
  "chip.mappingUnavailable": "\u0BAA\u0B9F\u0BBF\u0BB5 \u0BB5\u0BB0\u0BC8\u0BAA\u0B9F\u0BA4\u0BCD\u0BA4\u0BC8 \u0B8F\u0BB1\u0BCD\u0BB1 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 \u2014 \u0BA8\u0BC0\u0B9F\u0BCD\u0B9F\u0BBF\u0BAA\u0BCD\u0BAA\u0BBF\u0BA9\u0BCD \u0BAA\u0BBF\u0BA9\u0BCD\u0BA9\u0BA3\u0BBF\u0BAA\u0BCD \u0BAA\u0BA3\u0BBF\u0BAF\u0BBE\u0BB3\u0BB0\u0BCD \u0BAA\u0BA4\u0BBF\u0BB2\u0BB3\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0BAA\u0BCB\u0BB0\u0BCD\u0B9F\u0BCD\u0B9F\u0BB2\u0BCD \u0BA4\u0BBE\u0BB5\u0BB2\u0BC8 \u0BAE\u0BC0\u0BB3\u0BCD\u0B8F\u0BB1\u0BCD\u0BB1\u0BAE\u0BCD \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB2\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD.",
  "popup.timeoutMapping": "\u0BAA\u0B9F\u0BBF\u0BB5 \u0BB5\u0BB0\u0BC8\u0BAA\u0B9F\u0BAE\u0BCD \u0B8F\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BA8\u0BCD\u0BA4\u0BA4\u0BC1 ({seconds} \u0BB5\u0BBF\u0BA8\u0BBE\u0B9F\u0BBF). \u0B87\u0BA3\u0BC8\u0BAA\u0BCD\u0BAA\u0BC8\u0B9A\u0BCD \u0B9A\u0BB0\u0BBF\u0BAA\u0BBE\u0BB0\u0BCD\u0BA4\u0BCD\u0BA4\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB2\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD.",
  "popup.timeoutNoProgress": "\u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0BA4\u0BB2\u0BCD {seconds} \u0BB5\u0BBF\u0BA8\u0BBE\u0B9F\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0BA4\u0BCA\u0B9F\u0B99\u0BCD\u0B95\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 \u2014 Form III \u0BAA\u0B95\u0BCD\u0B95\u0BAE\u0BCD \u0BAA\u0BA4\u0BBF\u0BB2\u0BB3\u0BBF\u0B95\u0BCD\u0B95\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0BA4\u0BBE\u0BB5\u0BB2\u0BC8 \u0BAE\u0BC0\u0BB3\u0BCD\u0B8F\u0BB1\u0BCD\u0BB1\u0BAE\u0BCD \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4\u0BC1 \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BAF\u0BB2\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD.",
  "popup.timeoutStalled": "\u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0BA4\u0BB2\u0BCD {seconds} \u0BB5\u0BBF\u0BA8\u0BBE\u0B9F\u0BBF\u0BAF\u0BBE\u0B95 \u0BA8\u0BBF\u0BA9\u0BCD\u0BB1\u0BC1\u0BB5\u0BBF\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 \u2014 Form III \u0BAA\u0B95\u0BCD\u0B95\u0BAE\u0BCD \u0BAA\u0BA4\u0BBF\u0BB2\u0BB3\u0BBF\u0BAA\u0BCD\u0BAA\u0BA4\u0BC8 \u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BBF\u0BB5\u0BBF\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
  "popup.timeoutCap": "\u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0BA4\u0BB2\u0BCD \u0BAE\u0BCA\u0BA4\u0BCD\u0BA4 \u0BA8\u0BC7\u0BB0 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC8 ({seconds} \u0BB5\u0BBF\u0BA8\u0BBE\u0B9F\u0BBF) \u0B95\u0B9F\u0BA8\u0BCD\u0BA4\u0BA4\u0BC1; \u0BA8\u0BBF\u0BB1\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1.",
  "popup.preview": "\u0BAE\u0BBE\u0BB1\u0BCD\u0BB1\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0BAE\u0BC1\u0BA9\u0BCD\u0BA9\u0BCB\u0B9F\u0BCD\u0B9F\u0BAE\u0BBF\u0B9F\u0BC1",
  "popup.previewApply": "\u0BAA\u0BAF\u0BA9\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1 \u2014 \u0BAA\u0B9F\u0BBF\u0BB5\u0BA4\u0BCD\u0BA4\u0BC8 \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1",
  "popup.undo": "\u0B95\u0B9F\u0BC8\u0B9A\u0BBF \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0BA4\u0BB2\u0BC8 \u0BAE\u0BC0\u0B9F\u0BCD\u0B9F\u0BAE\u0BC8",
  "popup.undoDone": "{total} \u0B87\u0BB2\u0BCD {restored} \u0BAA\u0BC1\u0BB2\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BAE\u0BC1\u0BA8\u0BCD\u0BA4\u0BC8\u0BAF \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0BAE\u0BC0\u0B9F\u0BCD\u0B9F\u0BAE\u0BC8\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA9.",
  "popup.undoPartial": "{total} \u0B87\u0BB2\u0BCD {restored} \u0BAE\u0BC0\u0B9F\u0BCD\u0B9F\u0BAE\u0BC8\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA9; {failed} \u0BAE\u0BC0\u0B9F\u0BCD\u0B9F\u0BAE\u0BC8\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8 (\u0BAA\u0B95\u0BCD\u0B95\u0BAE\u0BCD \u0BAE\u0BC0\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0B89\u0BB0\u0BC1\u0BB5\u0BBE\u0B95\u0BBF \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BB2\u0BBE\u0BAE\u0BCD).",
  "popup.undoStale": "\u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0BA4\u0BB2\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAA\u0BCD \u0BAA\u0BBF\u0BB1\u0B95\u0BC1 \u0BAA\u0B95\u0BCD\u0B95\u0BAE\u0BCD \u0BAE\u0BBE\u0BB1\u0BBF\u0BAF\u0BC1\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1 \u2014 \u0BAE\u0BC0\u0B9F\u0BCD\u0B9F\u0BAE\u0BC8\u0BAA\u0BCD\u0BAA\u0BC1 \u0BAE\u0BC1\u0BB4\u0BC1\u0BAE\u0BC8\u0BAF\u0BB1\u0BCD\u0BB1\u0BA4\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BB2\u0BBE\u0BAE\u0BCD.",
  "popup.undoNone": "\u0BAE\u0BC0\u0B9F\u0BCD\u0B9F\u0BAE\u0BC8\u0B95\u0BCD\u0B95 \u0B8E\u0BA4\u0BC1\u0BB5\u0BC1\u0BAE\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8 \u2014 \u0B87\u0BA8\u0BCD\u0BA4 \u0B85\u0BAE\u0BB0\u0BCD\u0BB5\u0BBF\u0BB2\u0BCD \u0B87\u0BA8\u0BCD\u0BA4 \u0B9F\u0BC7\u0BAA\u0BBF\u0BB2\u0BCD \u0BA8\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0BC1\u0BA4\u0BB2\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BC8.",
  "popup.previewUnresolved": "\u0B87\u0BA8\u0BCD\u0BA4\u0BAA\u0BCD \u0BAA\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B95\u0BBE\u0BA3\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8",
  "popup.previewManual": "\u0B95\u0BC8\u0BAE\u0BC1\u0BB1\u0BC8 \u0BAA\u0B9F\u0BBF",
  "popup.previewNoValue": "(\u0BB5\u0BB4\u0B99\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8)"
};

// src/i18n/te.ts
var te = {
  "popup.title": "Cformly \u0C06\u0C1F\u0C4B-\u0C2B\u0C3F\u0C32\u0C4D",
  "popup.eyebrow": "\u0C06\u0C1F\u0C4B-\u0C2B\u0C3F\u0C32\u0C4D",
  "popup.bandSub": "FRRO Form III \xB7 \u0C1A\u0C46\u0C15\u0C4D-\u0C07\u0C28\u0C4D \u0C24\u0C30\u0C4D\u0C35\u0C3E\u0C24 24 \u0C17\u0C02\u0C1F\u0C32\u0C4D\u0C32\u0C4B\u0C2A\u0C41",
  "popup.fillFromClipboard": "\u0C15\u0C4D\u0C32\u0C3F\u0C2A\u0C4D\u200C\u0C2C\u0C4B\u0C30\u0C4D\u0C21\u0C4D \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C28\u0C3F\u0C02\u0C2A\u0C02\u0C21\u0C3F",
  "popup.fillHint": "Cformly \u0C2F\u0C3E\u0C2A\u0C4D \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F, \u0C06\u0C2A\u0C48 \u0C08 \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C2B\u0C3E\u0C30\u0C2E\u0C4D\u200C\u0C28\u0C41 \u0C28\u0C3F\u0C02\u0C2A\u0C02\u0C21\u0C3F.",
  "popup.clipboardReadFailed": "\u0C15\u0C4D\u0C32\u0C3F\u0C2A\u0C4D\u200C\u0C2C\u0C4B\u0C30\u0C4D\u0C21\u0C4D\u200C\u0C28\u0C41 \u0C1A\u0C26\u0C35\u0C32\u0C47\u0C15\u0C2A\u0C4B\u0C2F\u0C3E\u0C2E\u0C41. \u0C2C\u0C4D\u0C30\u0C4C\u0C1C\u0C30\u0C4D \u0C15\u0C4D\u0C32\u0C3F\u0C2A\u0C4D\u200C\u0C2C\u0C4B\u0C30\u0C4D\u0C21\u0C4D \u0C05\u0C28\u0C41\u0C2E\u0C24\u0C41\u0C32\u0C28\u0C41 \u0C24\u0C28\u0C3F\u0C16\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  "popup.clipboardEmpty": "\u0C15\u0C4D\u0C32\u0C3F\u0C2A\u0C4D\u200C\u0C2C\u0C4B\u0C30\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C4B Cformly \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C41 \u0C32\u0C47\u0C35\u0C41. \u0C2E\u0C41\u0C02\u0C26\u0C41\u0C17\u0C3E Cformly \u0C2F\u0C3E\u0C2A\u0C4D \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  "popup.settings": "\u0C38\u0C46\u0C1F\u0C4D\u0C1F\u0C3F\u0C02\u0C17\u0C4D\u200C\u0C32\u0C41",
  "popup.loadingMapping": "\u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C3F\u0C02\u0C17\u0C4D \u0C32\u0C4B\u0C21\u0C4D \u0C05\u0C35\u0C41\u0C24\u0C4B\u0C02\u0C26\u0C3F...",
  "popup.filling": "\u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C28\u0C3F\u0C02\u0C2A\u0C41\u0C24\u0C4B\u0C02\u0C26\u0C3F...",
  "popup.fillingProgress": "\u0C28\u0C3F\u0C02\u0C2A\u0C2C\u0C21\u0C41\u0C24\u0C4B\u0C02\u0C26\u0C3F\u2026 \u0C16\u0C3E\u0C33\u0C40 {completed}/{total}",
  "popup.noTab": "\u0C2F\u0C3E\u0C15\u0C4D\u0C1F\u0C3F\u0C35\u0C4D \u0C1F\u0C4D\u0C2F\u0C3E\u0C2C\u0C4D \u0C15\u0C28\u0C41\u0C17\u0C4A\u0C28\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41.",
  "popup.filled": "\u0C05\u0C35\u0C38\u0C30\u0C2E\u0C48\u0C28 \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C41 \u0C28\u0C3F\u0C02\u0C2A\u0C2C\u0C21\u0C4D\u0C21\u0C3E\u0C2F\u0C3F: {required} \u0C32\u0C4B {filledRequired} ({filled} \u0C2E\u0C4A\u0C24\u0C4D\u0C24\u0C02 \u0C28\u0C3F\u0C02\u0C2A\u0C2C\u0C21\u0C4D\u0C21\u0C3E\u0C2F\u0C3F)",
  "popup.portalMismatch": "\u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C05\u0C38\u0C2E\u0C24\u0C41\u0C32\u0C4D\u0C2F\u0C24 \u0C17\u0C41\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F (DOM \u0C2E\u0C3E\u0C30\u0C3F\u0C02\u0C26\u0C3F). Cformly \u0C2F\u0C3E\u0C2A\u0C4D\u200C\u0C32\u0C4B \u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C38\u0C3F \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "popup.missingElements": "\u0C24\u0C2A\u0C4D\u0C2A\u0C3F\u0C2A\u0C4B\u0C2F\u0C3F\u0C28 \u0C05\u0C02\u0C36\u0C3E\u0C32\u0C41: {list}",
  "popup.missingValues": "\u0C24\u0C2A\u0C4D\u0C2A\u0C3F\u0C2A\u0C4B\u0C2F\u0C3F\u0C28 \u0C35\u0C3F\u0C32\u0C41\u0C35\u0C32\u0C41: {list}",
  "popup.manualFields": "\u0C2E\u0C3E\u0C28\u0C4D\u0C2F\u0C41\u0C35\u0C32\u0C4D \u0C26\u0C36\u0C32\u0C41 \u0C05\u0C35\u0C38\u0C30\u0C02: {list}",
  "popup.unsupportedFields": "\u0C06\u0C1F\u0C4B-\u0C2B\u0C3F\u0C32\u0C4D \u0C1A\u0C47\u0C2F\u0C32\u0C47\u0C28\u0C3F \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C41: {list}",
  "popup.tooLongFields": "\u0C08 \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C15\u0C41 \u0C35\u0C3F\u0C32\u0C41\u0C35\u0C32\u0C41 \u0C1A\u0C3E\u0C32\u0C3E \u0C2A\u0C4A\u0C21\u0C35\u0C41\u0C17\u0C3E \u0C09\u0C28\u0C4D\u0C28\u0C3E\u0C2F\u0C3F \u2014 \u0C0F\u0C2E\u0C40 \u0C35\u0C4D\u0C30\u0C3E\u0C2F\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41, \u0C24\u0C15\u0C4D\u0C15\u0C41\u0C35 \u0C35\u0C3F\u0C32\u0C41\u0C35\u0C28\u0C41 \u0C1F\u0C48\u0C2A\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F: {list}",
  "popup.unverifiedFields": "\u0C08 \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C24\u0C28\u0C3F\u0C16\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F \u2014 \u0C35\u0C3F\u0C32\u0C41\u0C35 \u0C28\u0C3F\u0C32\u0C3F\u0C1A\u0C3F \u0C09\u0C02\u0C21\u0C15\u0C2A\u0C4B\u0C35\u0C1A\u0C4D\u0C1A\u0C41: {list}",
  "popup.applicationId": "Application ID: {id}",
  "popup.accommodationMismatch": "\u0C39\u0C46\u0C1A\u0C4D\u0C1A\u0C30\u0C3F\u0C15: FRRO \u0C38\u0C46\u0C37\u0C28\u0C4D \u0C35\u0C47\u0C30\u0C47 \u0C2A\u0C4D\u0C30\u0C3E\u0C2A\u0C30\u0C4D\u0C1F\u0C40\u0C15\u0C3F \u0C1A\u0C46\u0C02\u0C26\u0C3F\u0C28\u0C26\u0C3F \u0C15\u0C3E\u0C35\u0C1A\u0C4D\u0C1A\u0C41. \u0C38\u0C2E\u0C30\u0C4D\u0C2A\u0C3F\u0C02\u0C1A\u0C47 \u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C27\u0C43\u0C35\u0C40\u0C15\u0C30\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "popup.attention": "\u0C15\u0C4A\u0C28\u0C4D\u0C28\u0C3F \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C15\u0C41 \u0C36\u0C4D\u0C30\u0C26\u0C4D\u0C27 \u0C05\u0C35\u0C38\u0C30\u0C02. Cformly \u0C2F\u0C3E\u0C2A\u0C4D\u200C\u0C32\u0C4B \u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C38\u0C3F \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "popup.openPrint": "\u0C35\u0C4D\u0C2F\u0C15\u0C4D\u0C24\u0C3F\u0C17\u0C24 \u0C2A\u0C4D\u0C30\u0C3F\u0C02\u0C1F\u0C4D \u0C24\u0C46\u0C30\u0C35\u0C02\u0C21\u0C3F",
  "popup.printNoId": "\u0C07\u0C02\u0C15\u0C3E Application ID \u0C15\u0C4D\u0C2F\u0C3E\u0C2A\u0C4D\u0C1A\u0C30\u0C4D \u0C1A\u0C47\u0C2F\u0C32\u0C47\u0C26\u0C41 \u2014 \u0C2E\u0C41\u0C02\u0C26\u0C41\u0C17\u0C3E \u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C28\u0C3F\u0C02\u0C2A\u0C02\u0C21\u0C3F.",
  "popup.printSent": "ID {id} \u0C15\u0C4B\u0C38\u0C02 \u0C26\u0C3E\u0C16\u0C32\u0C41 \u0C1A\u0C47\u0C38\u0C3F\u0C28 \u0C05\u0C2A\u0C4D\u0C32\u0C3F\u0C15\u0C47\u0C37\u0C28\u0C4D\u200C\u0C28\u0C41 \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C24\u0C46\u0C30\u0C3F\u0C1A\u0C3E\u0C2E\u0C41. PDF \u0C21\u0C4C\u0C28\u0C4D\u200C\u0C32\u0C4B\u0C21\u0C4D \u0C1A\u0C47\u0C2F\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C35\u0C4D\u0C2F\u0C15\u0C4D\u0C24\u0C3F\u0C17\u0C24 \u0C2A\u0C4D\u0C30\u0C3F\u0C02\u0C1F\u0C4D \u0C2E\u0C46\u0C28\u0C42\u0C28\u0C41 \u0C09\u0C2A\u0C2F\u0C4B\u0C17\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "popup.formFilled": "\u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C28\u0C3F\u0C02\u0C2A\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F. \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D\u200C\u0C32\u0C4B \u0C38\u0C2E\u0C40\u0C15\u0C4D\u0C37\u0C3F\u0C02\u0C1A\u0C3F \u0C38\u0C2E\u0C30\u0C4D\u0C2A\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "popup.fillError": "\u0C28\u0C3F\u0C02\u0C2A\u0C21\u0C02\u0C32\u0C4B \u0C32\u0C4B\u0C2A\u0C02: {message}",
  "popup.connectionFailed": "FRRO \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C2A\u0C47\u0C1C\u0C40\u0C28\u0C3F \u0C1A\u0C47\u0C30\u0C41\u0C15\u0C4B\u0C32\u0C47\u0C15\u0C2A\u0C4B\u0C2F\u0C3E\u0C2E\u0C41. \u0C08 \u0C1F\u0C4D\u0C2F\u0C3E\u0C2C\u0C4D\u200C\u0C32\u0C4B Form III \u0C2A\u0C47\u0C1C\u0C40\u0C28\u0C3F \u0C24\u0C46\u0C30\u0C3F\u0C1A\u0C3F \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "popup.unknownError": "\u0C24\u0C46\u0C32\u0C3F\u0C2F\u0C26\u0C41",
  "popup.apiBaseFallback": "\u0C39\u0C46\u0C1A\u0C4D\u0C1A\u0C30\u0C3F\u0C15: \u0C28\u0C3F\u0C32\u0C4D\u0C35 \u0C1A\u0C47\u0C38\u0C3F\u0C28 API URL \u0C1A\u0C46\u0C32\u0C4D\u0C32\u0C26\u0C41 \u2014 \u0C21\u0C3F\u0C2B\u0C3E\u0C32\u0C4D\u0C1F\u0C4D\u200C\u0C28\u0C41 \u0C09\u0C2A\u0C2F\u0C4B\u0C17\u0C3F\u0C38\u0C4D\u0C24\u0C41\u0C28\u0C4D\u0C28\u0C3E\u0C2E\u0C41. \u0C38\u0C46\u0C1F\u0C4D\u0C1F\u0C3F\u0C02\u0C17\u0C4D\u0C38\u0C4D\u200C\u0C32\u0C4B \u0C05\u0C2A\u0C4D\u200C\u0C21\u0C47\u0C1F\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  "popup.mappingFallback": "\u0C39\u0C46\u0C1A\u0C4D\u0C1A\u0C30\u0C3F\u0C15: \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C3F\u0C02\u0C17\u0C4D \u0C38\u0C30\u0C4D\u0C35\u0C30\u0C4D \u0C05\u0C02\u0C26\u0C41\u0C2C\u0C3E\u0C1F\u0C41\u0C32\u0C4B \u0C32\u0C47\u0C26\u0C41 \u2014 \u0C05\u0C02\u0C24\u0C30\u0C4D\u0C28\u0C3F\u0C30\u0C4D\u0C2E\u0C3F\u0C24 \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C4D\u200C\u0C28\u0C41 \u0C09\u0C2A\u0C2F\u0C4B\u0C17\u0C3F\u0C38\u0C4D\u0C24\u0C41\u0C28\u0C4D\u0C28\u0C3E\u0C2E\u0C41, \u0C05\u0C26\u0C3F \u0C2A\u0C3E\u0C24\u0C26\u0C3F \u0C15\u0C3E\u0C35\u0C1A\u0C4D\u0C1A\u0C41.",
  "settings.title": "Cformly \u0C38\u0C46\u0C1F\u0C4D\u0C1F\u0C3F\u0C02\u0C17\u0C4D\u200C\u0C32\u0C41",
  "settings.eyebrow": "\u0C38\u0C46\u0C1F\u0C4D\u0C1F\u0C3F\u0C02\u0C17\u0C4D\u200C\u0C32\u0C41",
  "settings.bandSub": "\u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C3F\u0C02\u0C17\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C05\u0C02\u0C26\u0C3F\u0C02\u0C1A\u0C47 \u0C2C\u0C4D\u0C2F\u0C3E\u0C15\u0C46\u0C02\u0C21\u0C4D\u200C\u0C28\u0C41 \u0C15\u0C3E\u0C28\u0C4D\u0C2B\u0C3F\u0C17\u0C30\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "\u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C3F\u0C02\u0C17\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C05\u0C02\u0C26\u0C3F\u0C02\u0C1A\u0C47 \u0C2C\u0C4D\u0C2F\u0C3E\u0C15\u0C46\u0C02\u0C21\u0C4D. HTTPS \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47; localhost \u0C21\u0C46\u0C35\u0C32\u0C2A\u0C4D\u200C\u0C2E\u0C46\u0C02\u0C1F\u0C4D \u0C2C\u0C3F\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C32\u0C4B \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47 \u0C2A\u0C28\u0C3F\u0C1A\u0C47\u0C38\u0C4D\u0C24\u0C41\u0C02\u0C26\u0C3F.",
  "settings.save": "\u0C38\u0C47\u0C35\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F",
  "settings.back": "\u0C35\u0C46\u0C28\u0C41\u0C15\u0C15\u0C41",
  "settings.backInTab": "\u0C38\u0C46\u0C1F\u0C4D\u0C1F\u0C3F\u0C02\u0C17\u0C4D\u200C\u0C32\u0C41 \u0C1F\u0C4D\u0C2F\u0C3E\u0C2C\u0C4D\u200C\u0C17\u0C3E \u0C24\u0C46\u0C30\u0C35\u0C2C\u0C21\u0C4D\u0C21\u0C3E\u0C2F\u0C3F \u2014 \u0C2B\u0C3F\u0C32\u0C4D \u0C2A\u0C3E\u0C2A\u0C2A\u0C4D \u0C24\u0C46\u0C30\u0C35\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F Cformly \u0C1F\u0C42\u0C32\u0C4D\u200C\u0C2C\u0C3E\u0C30\u0C4D \u0C10\u0C15\u0C3E\u0C28\u0C4D \u0C09\u0C2A\u0C2F\u0C4B\u0C17\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "settings.urlEmpty": "URL \u0C16\u0C3E\u0C33\u0C40\u0C17\u0C3E \u0C09\u0C02\u0C21\u0C15\u0C42\u0C21\u0C26\u0C41.",
  "settings.httpsOnly": "\u0C2D\u0C26\u0C4D\u0C30\u0C24 \u0C15\u0C4B\u0C38\u0C02 HTTPS URL \u0C32\u0C41 \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47 \u0C05\u0C28\u0C41\u0C2E\u0C24\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C24\u0C3E\u0C2F\u0C3F. \u0C2A\u0C4D\u0C30\u0C4A\u0C21\u0C15\u0C4D\u0C37\u0C28\u0C4D \u0C15\u0C4B\u0C38\u0C02 https:// \u0C09\u0C2A\u0C2F\u0C4B\u0C17\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "settings.hostNotAllowed": "URL \u0C39\u0C4B\u0C38\u0C4D\u0C1F\u0C4D\u200C\u0C28\u0C47\u0C2E\u0C4D localhost \u0C32\u0C47\u0C26\u0C3E *.cformly.com \u0C05\u0C2F\u0C3F \u0C09\u0C02\u0C21\u0C3E\u0C32\u0C3F ({host} \u0C35\u0C1A\u0C4D\u0C1A\u0C3F\u0C02\u0C26\u0C3F).",
  "settings.invalidUrl": "\u0C1A\u0C46\u0C32\u0C4D\u0C32\u0C28\u0C3F URL. https:// \u0C1A\u0C47\u0C30\u0C4D\u0C1A\u0C02\u0C21\u0C3F",
  "settings.urlPathNotAllowed": "\u0C2C\u0C47\u0C30\u0C4D \u0C06\u0C30\u0C3F\u0C1C\u0C3F\u0C28\u0C4D \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47 \u0C09\u0C2A\u0C2F\u0C4B\u0C17\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F \u2014 path, query \u0C2E\u0C30\u0C3F\u0C2F\u0C41 #fragment \u0C28\u0C41 \u0C24\u0C4A\u0C32\u0C17\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "settings.loopbackNotGranted": "Localhost API URL \u0C32\u0C41 \u0C21\u0C46\u0C35\u0C32\u0C2A\u0C4D\u200C\u0C2E\u0C46\u0C02\u0C1F\u0C4D \u0C2C\u0C3F\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C32\u0C4B \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47 \u0C2A\u0C28\u0C3F\u0C1A\u0C47\u0C38\u0C4D\u0C24\u0C3E\u0C2F\u0C3F. \u0C08 \u0C2C\u0C3F\u0C32\u0C4D\u0C21\u0C4D https:// \u0C39\u0C4B\u0C38\u0C4D\u0C1F\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47 \u0C1A\u0C47\u0C30\u0C41\u0C15\u0C4B\u0C17\u0C32\u0C26\u0C41.",
  "settings.saved": "\u0C38\u0C47\u0C35\u0C4D \u0C1A\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F.",
  "settings.saveError": "\u0C38\u0C47\u0C35\u0C4D \u0C1A\u0C47\u0C2F\u0C32\u0C47\u0C15\u0C2A\u0C4B\u0C2F\u0C3E\u0C2E\u0C41. \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "settings.langLabel": "\u0C2D\u0C3E\u0C37",
  "settings.langEnglish": "\u0C07\u0C02\u0C17\u0C4D\u0C32\u0C40\u0C37\u0C4D",
  "settings.langHindi": "\u0C39\u0C3F\u0C02\u0C26\u0C40",
  "settings.langAuto": "\u0C2C\u0C4D\u0C30\u0C4C\u0C1C\u0C30\u0C4D\u200C\u0C28\u0C41 \u0C05\u0C28\u0C41\u0C38\u0C30\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F",
  "settings.langHint": "\u0C2E\u0C40\u0C30\u0C41 \u0C0E\u0C02\u0C1A\u0C41\u0C15\u0C41\u0C28\u0C47 \u0C35\u0C30\u0C15\u0C41 \u0C2E\u0C40 \u0C2C\u0C4D\u0C30\u0C4C\u0C1C\u0C30\u0C4D \u0C2D\u0C3E\u0C37 \u0C09\u0C2A\u0C2F\u0C4B\u0C17\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C41\u0C24\u0C41\u0C02\u0C26\u0C3F.",
  // round-65: paste intake + in-page filing panel
  "popup.pasteLabel": "\u0C32\u0C47\u0C26\u0C3E \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C07\u0C15\u0C4D\u0C15\u0C21 \u0C2A\u0C47\u0C38\u0C4D\u0C1F\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F",
  "popup.pdfPick": "Cformly PDF \u0C24\u0C46\u0C30\u0C35\u0C02\u0C21\u0C3F",
  "popup.pdfLoaded": "\u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C41 Cformly PDF \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C32\u0C4B\u0C21\u0C4D \u0C05\u0C2F\u0C4D\u0C2F\u0C3E\u0C2F\u0C3F \u2014 \u0C15\u0C3F\u0C02\u0C26 \u0C38\u0C2E\u0C40\u0C15\u0C4D\u0C37\u0C3F\u0C02\u0C1A\u0C3F, \u0C06\u0C2A\u0C48 Fill Form \u0C28\u0C4A\u0C15\u0C4D\u0C15\u0C02\u0C21\u0C3F.",
  "popup.pdfRejected": "\u0C08 PDF\u0C32\u0C4B Cformly \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C41 \u0C32\u0C47\u0C35\u0C41 \u0C32\u0C47\u0C26\u0C3E \u0C26\u0C3E\u0C28\u0C4D\u0C28\u0C3F \u0C1A\u0C26\u0C35\u0C32\u0C47\u0C15\u0C2A\u0C4B\u0C2F\u0C3E\u0C02 \u2014 Cformly \u0C2F\u0C3E\u0C2A\u0C4D \u0C0E\u0C17\u0C41\u0C2E\u0C24\u0C3F \u0C1A\u0C47\u0C38\u0C3F\u0C28 PDF\u0C28\u0C47 \u0C35\u0C3E\u0C21\u0C02\u0C21\u0C3F.",
  "popup.pastePlaceholder": "\u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C38\u0C3F\u0C28 Cformly \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C07\u0C15\u0C4D\u0C15\u0C21 \u0C2A\u0C47\u0C38\u0C4D\u0C1F\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F",
  "popup.pasteHint": "\u0C15\u0C4D\u0C32\u0C3F\u0C2A\u0C4D\u200C\u0C2C\u0C4B\u0C30\u0C4D\u0C21\u0C4D \u0C2C\u0C1F\u0C28\u0C4D \u0C2A\u0C28\u0C3F \u0C1A\u0C47\u0C2F\u0C15\u0C2A\u0C4B\u0C24\u0C47, \u0C08 \u0C15\u0C02\u0C2A\u0C4D\u0C2F\u0C42\u0C1F\u0C30\u0C4D\u200C\u0C15\u0C41 \u0C2A\u0C02\u0C2A\u0C3F\u0C28 \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C07\u0C15\u0C4D\u0C15\u0C21 \u0C2A\u0C47\u0C38\u0C4D\u0C1F\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F (\u0C32\u0C47\u0C26\u0C3E \u0C1F\u0C46\u0C15\u0C4D\u0C38\u0C4D\u0C1F\u0C4D \u0C2B\u0C48\u0C32\u0C4D\u200C\u0C28\u0C41 \u0C35\u0C26\u0C32\u0C02\u0C21\u0C3F), \u0C06\u0C2A\u0C48 \u0C28\u0C3F\u0C02\u0C2A\u0C41 \u0C28\u0C4A\u0C15\u0C4D\u0C15\u0C02\u0C21\u0C3F.",
  "popup.payloadTooLarge": "\u0C2A\u0C47\u0C38\u0C4D\u0C1F\u0C4D \u0C1A\u0C47\u0C38\u0C3F\u0C28 \u0C1F\u0C46\u0C15\u0C4D\u0C38\u0C4D\u0C1F\u0C4D \u0C1A\u0C3E\u0C32\u0C3E \u0C2A\u0C46\u0C26\u0C4D\u0C26\u0C26\u0C3F \u2014 Cformly \u0C2F\u0C3E\u0C2A\u0C4D \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C38\u0C3F\u0C28 \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47 \u0C2A\u0C47\u0C38\u0C4D\u0C1F\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  "panel.title": "Cformly \u2014 \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D\u200C\u0C32\u0C4B \u0C2B\u0C48\u0C32\u0C3F\u0C02\u0C17\u0C4D \u0C2A\u0C42\u0C30\u0C4D\u0C24\u0C3F \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F",
  "panel.dismiss": "\u0C2E\u0C42\u0C38\u0C3F\u0C35\u0C47\u0C2F\u0C02\u0C21\u0C3F",
  "panel.filled": "\u0C28\u0C3F\u0C02\u0C2A\u0C2C\u0C21\u0C3F\u0C28 \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C41: {filledRequired} / {required} \u0C24\u0C2A\u0C4D\u0C2A\u0C28\u0C3F\u0C38\u0C30\u0C3F",
  "panel.photoStep": "\u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C2B\u0C4B\u0C1F\u0C4B\u0C28\u0C41 \u0C1C\u0C4B\u0C21\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F (\u0C2B\u0C48\u0C32\u0C4D \u0C0E\u0C02\u0C1A\u0C41\u0C15\u0C4B\u0C02\u0C21\u0C3F \u2192 \u0C05\u0C2A\u0C4D\u200C\u0C32\u0C4B\u0C21\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F)",
  "panel.captchaStep": "\u0C38\u0C46\u0C15\u0C4D\u0C2F\u0C42\u0C30\u0C3F\u0C1F\u0C40 \u0C15\u0C4B\u0C21\u0C4D (CAPTCHA) \u0C1F\u0C48\u0C2A\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F",
  "panel.saveStep": "\u0C38\u0C47\u0C35\u0C4D \u0C1A\u0C47\u0C38\u0C3F \u0C15\u0C4A\u0C28\u0C38\u0C3E\u0C17\u0C3F\u0C02\u0C1A\u0C41 \u0C28\u0C4A\u0C15\u0C4D\u0C15\u0C02\u0C21\u0C3F",
  "panel.warnSession": "Cformly \u0C39\u0C46\u0C1A\u0C4D\u0C1A\u0C30\u0C3F\u0C15: \u0C08 FRRO \u0C38\u0C46\u0C37\u0C28\u0C4D \u0C35\u0C47\u0C30\u0C47 \u0C2A\u0C4D\u0C30\u0C3E\u0C2A\u0C30\u0C4D\u0C1F\u0C40\u0C26\u0C3F \u0C15\u0C3E\u0C35\u0C1A\u0C4D\u0C1A\u0C41 ({reason}). \u0C38\u0C47\u0C35\u0C4D \u0C1A\u0C47\u0C38\u0C47 \u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C38\u0C30\u0C3F\u0C1A\u0C42\u0C21\u0C02\u0C21\u0C3F.",
  "panel.warnUnverified": "Cformly \u0C39\u0C46\u0C1A\u0C4D\u0C1A\u0C30\u0C3F\u0C15: \u0C08 \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32 \u0C35\u0C3F\u0C32\u0C41\u0C35\u0C32\u0C41 \u0C28\u0C3F\u0C32\u0C3F\u0C1A\u0C3F\u0C2A\u0C4B\u0C15\u0C2A\u0C4B\u0C35\u0C1A\u0C4D\u0C1A\u0C41: {list}. \u0C38\u0C47\u0C35\u0C4D \u0C1A\u0C47\u0C38\u0C47 \u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C38\u0C30\u0C3F\u0C1A\u0C42\u0C21\u0C02\u0C21\u0C3F.",
  "panel.saving": "\u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C27\u0C43\u0C35\u0C40\u0C15\u0C30\u0C23 \u0C15\u0C4B\u0C38\u0C02 \u0C35\u0C47\u0C1A\u0C3F \u0C09\u0C28\u0C4D\u0C28\u0C3E\u0C2E\u0C41\u2026",
  "panel.progress": "\u0C16\u0C3E\u0C33\u0C40\u0C32\u0C41 \u0C28\u0C3F\u0C02\u0C2A\u0C2C\u0C21\u0C41\u0C24\u0C41\u0C28\u0C4D\u0C28\u0C3E\u0C2F\u0C3F\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO \u0C38\u0C46\u0C37\u0C28\u0C4D \u0C17\u0C21\u0C41\u0C35\u0C41 \u0C2E\u0C41\u0C17\u0C3F\u0C02\u0C26\u0C3F \u2014 \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C32\u0C3E\u0C17\u0C3F\u0C28\u0C4D \u0C1A\u0C47\u0C38\u0C3F, \u0C2B\u0C3E\u0C30\u0C02 \u0C24\u0C46\u0C30\u0C3F\u0C1A\u0C3F Fill \u0C28\u0C4A\u0C15\u0C4D\u0C15\u0C02\u0C21\u0C3F. \u0C2E\u0C40 \u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C35\u0C3F\u0C35\u0C30\u0C3E\u0C32\u0C41 Cformly \u0C2F\u0C3E\u0C2A\u0C4D\u200C\u0C32\u0C4B \u0C2D\u0C26\u0C4D\u0C30\u0C02\u0C17\u0C3E \u0C09\u0C28\u0C4D\u0C28\u0C3E\u0C2F\u0C3F.",
  "panel.portalError": "\u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C38\u0C2E\u0C38\u0C4D\u0C2F\u0C28\u0C41 \u0C1A\u0C42\u0C2A\u0C3F\u0C02\u0C26\u0C3F:",
  "panel.appIdFound": "\u0C35\u0C3F\u0C1C\u0C2F\u0C35\u0C02\u0C24\u0C02\u0C17\u0C3E \u0C2B\u0C48\u0C32\u0C4D \u0C05\u0C2F\u0C3F\u0C02\u0C26\u0C3F. \u0C26\u0C30\u0C16\u0C3E\u0C38\u0C4D\u0C24\u0C41 \u0C10\u0C21\u0C3F:",
  "panel.scanHint": "Cformly \u0C2F\u0C3E\u0C2A\u0C4D \u0C24\u0C46\u0C30\u0C35\u0C02\u0C21\u0C3F \u2192 \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D\u200C\u0C15\u0C41 \u0C2A\u0C02\u0C2A\u0C02\u0C21\u0C3F \u2192 \u0C15\u0C02\u0C2A\u0C4D\u0C2F\u0C42\u0C1F\u0C30\u0C4D \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C38\u0C4D\u0C15\u0C3E\u0C28\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F, \u0C08 \u0C15\u0C4B\u0C21\u0C4D\u200C\u0C2A\u0C48 \u0C15\u0C46\u0C2E\u0C46\u0C30\u0C3E \u0C1A\u0C42\u0C2A\u0C02\u0C21\u0C3F \u2014 \u0C32\u0C47\u0C26\u0C3E \u0C10\u0C21\u0C3F\u0C28\u0C3F \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  "panel.copy": "\u0C26\u0C30\u0C16\u0C3E\u0C38\u0C4D\u0C24\u0C41 \u0C10\u0C21\u0C3F\u0C28\u0C3F \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F",
  "panel.copied": "\u0C15\u0C3E\u0C2A\u0C40 \u0C05\u0C2F\u0C3F\u0C02\u0C26\u0C3F.",
  "panel.confirmNotDetected": "\u0C27\u0C43\u0C35\u0C40\u0C15\u0C30\u0C23 \u0C17\u0C41\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41 \u2014 \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C38\u0C47\u0C35\u0C4D \u0C1A\u0C47\u0C38\u0C3F\u0C02\u0C26\u0C4B \u0C32\u0C47\u0C26\u0C4B \u0C24\u0C28\u0C3F\u0C16\u0C40 \u0C1A\u0C47\u0C38\u0C3F, \u0C06\u0C2A\u0C48 \u0C15\u0C4A\u0C28\u0C38\u0C3E\u0C17\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "\u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C2B\u0C4B\u0C1F\u0C4B\u0C28\u0C41 \u0C1C\u0C4B\u0C21\u0C3F\u0C02\u0C1A\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C07\u0C15\u0C4D\u0C15\u0C21 \u0C35\u0C26\u0C32\u0C02\u0C21\u0C3F",
  "panel.photoBrowse": "\u0C2C\u0C4D\u0C30\u0C4C\u0C1C\u0C4D\u2026",
  "panel.photoAttachFailed": "\u0C38\u0C4D\u0C35\u0C2F\u0C02\u0C17\u0C3E \u0C1C\u0C4B\u0C21\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41 \u2014 \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C38\u0C4A\u0C02\u0C24 \u0C2B\u0C48\u0C32\u0C4D \u0C0E\u0C02\u0C1A\u0C41\u0C15\u0C4B \u0C2C\u0C1F\u0C28\u0C4D \u0C35\u0C3E\u0C21\u0C02\u0C21\u0C3F.",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "\u0C08 \u0C2B\u0C3E\u0C30\u0C2E\u0C4D\u200C\u0C28\u0C41 Cformly \u0C24\u0C4B \u0C28\u0C3F\u0C02\u0C2A\u0C02\u0C21\u0C3F",
  "chip.hint": "\u0C08 \u0C15\u0C02\u0C2A\u0C4D\u0C2F\u0C42\u0C1F\u0C30\u0C4D\u200C\u0C15\u0C41 \u0C2A\u0C02\u0C2A\u0C3F\u0C28 \u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C35\u0C3F\u0C35\u0C30\u0C3E\u0C32\u0C28\u0C41 \u0C07\u0C15\u0C4D\u0C15\u0C21 \u0C05\u0C02\u0C1F\u0C15\u0C02\u0C21\u0C3F (\u0C32\u0C47\u0C26\u0C3E \u0C1F\u0C46\u0C15\u0C4D\u0C38\u0C4D\u0C1F\u0C4D \u0C2B\u0C48\u0C32\u0C4D\u200C\u0C28\u0C41 \u0C07\u0C15\u0C4D\u0C15\u0C21 \u0C35\u0C26\u0C32\u0C02\u0C21\u0C3F), \u0C06\u0C2A\u0C48 \u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C28\u0C3F\u0C02\u0C2A\u0C41 \u0C28\u0C4A\u0C15\u0C4D\u0C15\u0C02\u0C21\u0C3F.",
  "chip.fill": "\u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C28\u0C3F\u0C02\u0C2A\u0C41",
  "chip.filling": "\u0C28\u0C3F\u0C02\u0C2A\u0C41\u0C24\u0C4B\u0C02\u0C26\u0C3F\u2026",
  "chip.empty": "\u0C28\u0C3F\u0C02\u0C2A\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C0F\u0C2E\u0C40 \u0C32\u0C47\u0C26\u0C41 \u2014 \u0C2E\u0C41\u0C02\u0C26\u0C41\u0C17\u0C3E Cformly \u0C2F\u0C3E\u0C2A\u0C4D \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C38\u0C3F\u0C28 \u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C35\u0C3F\u0C35\u0C30\u0C3E\u0C32\u0C28\u0C41 \u0C05\u0C02\u0C1F\u0C15\u0C02\u0C21\u0C3F.",
  "chip.tooLarge": "\u0C05\u0C02\u0C1F\u0C3F\u0C02\u0C1A\u0C3F\u0C28 \u0C1F\u0C46\u0C15\u0C4D\u0C38\u0C4D\u0C1F\u0C4D \u0C1A\u0C3E\u0C32\u0C3E \u0C2A\u0C46\u0C26\u0C4D\u0C26\u0C26\u0C3F \u2014 Cformly \u0C2F\u0C3E\u0C2A\u0C4D \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C38\u0C3F\u0C28 \u0C35\u0C3F\u0C35\u0C30\u0C3E\u0C32\u0C28\u0C41 \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47 \u0C05\u0C02\u0C1F\u0C15\u0C02\u0C21\u0C3F.",
  "chip.collapse": "\u0C2E\u0C42\u0C38\u0C3F\u0C35\u0C47\u0C2F\u0C3F",
  "chip.mappingFallback": "\u0C17\u0C2E\u0C28\u0C3F\u0C15: \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C3F\u0C02\u0C17\u0C4D \u0C38\u0C30\u0C4D\u0C35\u0C30\u0C4D \u0C05\u0C02\u0C26\u0C41\u0C2C\u0C3E\u0C1F\u0C41\u0C32\u0C4B \u0C32\u0C47\u0C26\u0C41 \u2014 \u0C05\u0C02\u0C24\u0C30\u0C4D\u0C17\u0C24 \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C4D \u0C35\u0C3E\u0C21\u0C41\u0C24\u0C41\u0C28\u0C4D\u0C28\u0C3E\u0C2E\u0C41, \u0C05\u0C26\u0C3F \u0C2A\u0C3E\u0C24\u0C26\u0C3F \u0C15\u0C3E\u0C35\u0C1A\u0C4D\u0C1A\u0C41.",
  // round-66: popup first-run onboarding
  "onboarding.title": "\u0C2E\u0C4A\u0C26\u0C1F\u0C3F\u0C38\u0C3E\u0C30\u0C3F \u0C07\u0C15\u0C4D\u0C15\u0C21\u0C3E? \u0C2E\u0C42\u0C21\u0C41 \u0C05\u0C21\u0C41\u0C17\u0C41\u0C32\u0C41:",
  "onboarding.step1": "\u0C2E\u0C40 \u0C2B\u0C4B\u0C28\u0C4D\u200C\u0C32\u0C4B: \u0C05\u0C24\u0C3F\u0C25\u0C3F\u0C28\u0C3F \u0C24\u0C46\u0C30\u0C35\u0C02\u0C21\u0C3F \u2192 \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D\u200C\u0C15\u0C41 \u0C2A\u0C02\u0C2A\u0C02\u0C21\u0C3F \u2192 \u0C15\u0C02\u0C2A\u0C4D\u0C2F\u0C42\u0C1F\u0C30\u0C4D\u200C\u0C15\u0C41 \u0C2A\u0C02\u0C2A\u0C02\u0C21\u0C3F.",
  "onboarding.step2": "\u0C08 \u0C15\u0C02\u0C2A\u0C4D\u0C2F\u0C42\u0C1F\u0C30\u0C4D\u200C\u0C32\u0C4B: \u0C2E\u0C40\u0C15\u0C41 \u0C2A\u0C02\u0C2A\u0C3F\u0C28 \u0C35\u0C3F\u0C35\u0C30\u0C3E\u0C32\u0C28\u0C41 \u0C15\u0C3F\u0C02\u0C26\u0C3F \u0C2A\u0C46\u0C1F\u0C4D\u0C1F\u0C46\u0C32\u0C4B \u0C05\u0C02\u0C1F\u0C15\u0C02\u0C21\u0C3F (\u0C32\u0C47\u0C26\u0C3E \u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C4B\u0C28\u0C3F \u0C28\u0C40\u0C32\u0C3F Cformly \u0C2C\u0C1F\u0C28\u0C4D \u0C28\u0C4A\u0C15\u0C4D\u0C15\u0C02\u0C21\u0C3F).",
  "onboarding.step3": "\u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C28\u0C3F\u0C02\u0C2A\u0C41 \u0C28\u0C4A\u0C15\u0C4D\u0C15\u0C02\u0C21\u0C3F \u2014 \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C38\u0C4D\u0C35\u0C2F\u0C02\u0C17\u0C3E \u0C28\u0C3F\u0C02\u0C21\u0C41\u0C24\u0C41\u0C02\u0C26\u0C3F. \u0C2B\u0C4B\u0C1F\u0C4B, \u0C38\u0C46\u0C15\u0C4D\u0C2F\u0C42\u0C30\u0C3F\u0C1F\u0C40 \u0C15\u0C4B\u0C21\u0C4D, \u0C38\u0C47\u0C35\u0C4D \u0C2E\u0C40\u0C30\u0C41 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  "onboarding.done": "\u0C05\u0C30\u0C4D\u0C25\u0C2E\u0C48\u0C02\u0C26\u0C3F",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{total} \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C32\u0C4B {filled} {time}\u0C15\u0C3F \u0C28\u0C3F\u0C02\u0C2A\u0C2C\u0C21\u0C4D\u0C21\u0C3E\u0C2F\u0C3F. \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C28\u0C3F\u0C02\u0C2A\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C15\u0C4A\u0C28\u0C38\u0C3E\u0C17\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "resume.button": "\u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C28\u0C3F\u0C02\u0C2A\u0C41",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "\u0C08 \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C2A\u0C47\u0C1C\u0C40 Cformly \u0C15\u0C3F \u0C24\u0C46\u0C32\u0C3F\u0C38\u0C3F\u0C28 Form III \u0C32\u0C3E\u0C17\u0C3E \u0C15\u0C28\u0C3F\u0C2A\u0C3F\u0C02\u0C1A\u0C21\u0C02 \u0C32\u0C47\u0C26\u0C41 \u2014 \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C2E\u0C3E\u0C30\u0C3F \u0C09\u0C02\u0C21\u0C35\u0C1A\u0C4D\u0C1A\u0C41. \u0C08\u0C38\u0C3E\u0C30\u0C3F Cformly \u0C2F\u0C3E\u0C2A\u0C4D \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C28\u0C41 \u0C15\u0C3E\u0C2A\u0C40 \u0C1A\u0C47\u0C38\u0C3F \u0C2E\u0C40\u0C30\u0C47 \u0C28\u0C3F\u0C02\u0C2A\u0C02\u0C21\u0C3F; \u0C05\u0C2A\u0C4D\u200C\u0C21\u0C47\u0C1F\u0C4D\u200C\u0C32 \u0C15\u0C4B\u0C38\u0C02 \u0C2E\u0C47\u0C2E\u0C41 \u0C2A\u0C30\u0C3F\u0C36\u0C40\u0C32\u0C3F\u0C38\u0C4D\u0C24\u0C41\u0C28\u0C4D\u0C28\u0C3E\u0C2E\u0C41.",
  "canary.detail": "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C4B Cformly \u0C15\u0C3F \u0C24\u0C46\u0C32\u0C3F\u0C38\u0C3F\u0C28 {total} \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C32\u0C4B {found} \u0C2E\u0C3E\u0C24\u0C4D\u0C30\u0C2E\u0C47 \u0C15\u0C28\u0C2C\u0C21\u0C4D\u0C21\u0C3E\u0C2F\u0C3F.",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "\u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C15\u0C4D\u0C2F\u0C42",
  "queue.add": "\u0C15\u0C4D\u0C2F\u0C42\u0C32\u0C4B \u0C1A\u0C47\u0C30\u0C4D\u0C1A\u0C41",
  "queue.fill": "\u0C28\u0C3F\u0C02\u0C2A\u0C41",
  "queue.remove": "\u0C24\u0C40\u0C38\u0C3F\u0C35\u0C47\u0C2F\u0C3F",
  "queue.unnamed": "\u0C05\u0C24\u0C3F\u0C25\u0C3F",
  "queue.added": "{name} \u0C15\u0C4D\u0C2F\u0C42\u0C32\u0C4B \u0C1A\u0C47\u0C30\u0C4D\u0C1A\u0C2C\u0C21\u0C4D\u0C21\u0C3E\u0C30\u0C41.",
  "queue.duplicate": "\u0C08 \u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C07\u0C2A\u0C4D\u0C2A\u0C1F\u0C3F\u0C15\u0C47 \u0C15\u0C4D\u0C2F\u0C42\u0C32\u0C4B \u0C09\u0C28\u0C4D\u0C28\u0C3E\u0C30\u0C41.",
  "queue.full": "\u0C15\u0C4D\u0C2F\u0C42 \u0C28\u0C3F\u0C02\u0C21\u0C3F\u0C02\u0C26\u0C3F ({max} \u0C2E\u0C02\u0C26\u0C3F \u0C05\u0C24\u0C3F\u0C25\u0C41\u0C32\u0C41). \u0C2E\u0C41\u0C02\u0C26\u0C41\u0C17\u0C3E \u0C12\u0C15 \u0C05\u0C24\u0C3F\u0C25\u0C3F\u0C28\u0C3F \u0C28\u0C3F\u0C02\u0C2A\u0C02\u0C21\u0C3F \u0C32\u0C47\u0C26\u0C3E \u0C24\u0C40\u0C38\u0C3F\u0C35\u0C47\u0C2F\u0C02\u0C21\u0C3F.",
  "queue.hint": "\u0C28\u0C3F\u0C02\u0C2A\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C35\u0C47\u0C1A\u0C3F \u0C09\u0C28\u0C4D\u0C28 \u0C05\u0C24\u0C3F\u0C25\u0C41\u0C32\u0C41. \u0C2A\u0C42\u0C30\u0C4D\u0C24\u0C3F \u0C28\u0C3F\u0C02\u0C2A\u0C41\u0C21\u0C41 \u0C05\u0C2F\u0C3F\u0C28 \u0C24\u0C30\u0C4D\u0C35\u0C3E\u0C24 \u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C15\u0C4D\u0C2F\u0C42 \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C24\u0C4A\u0C32\u0C17\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C24\u0C3E\u0C30\u0C41; \u0C2C\u0C4D\u0C30\u0C4C\u0C1C\u0C30\u0C4D \u0C2E\u0C42\u0C38\u0C3F\u0C28\u0C2A\u0C4D\u0C2A\u0C41\u0C21\u0C41 \u0C15\u0C4D\u0C2F\u0C42 \u0C15\u0C4D\u0C32\u0C3F\u0C2F\u0C30\u0C4D \u0C05\u0C35\u0C41\u0C24\u0C41\u0C02\u0C26\u0C3F.",
  "queue.unavailable": "\u0C08 \u0C2C\u0C4D\u0C30\u0C4C\u0C1C\u0C30\u0C4D\u200C\u0C32\u0C4B \u0C05\u0C24\u0C3F\u0C25\u0C3F \u0C15\u0C4D\u0C2F\u0C42 \u0C05\u0C02\u0C26\u0C41\u0C2C\u0C3E\u0C1F\u0C41\u0C32\u0C4B \u0C32\u0C47\u0C26\u0C41.",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "\u0C08 FRRO \u0C1F\u0C4D\u0C2F\u0C3E\u0C2C\u0C4D\u200C\u0C28\u0C41 Cformly \u0C07\u0C28\u0C4D\u200C\u0C38\u0C4D\u0C1F\u0C3E\u0C32\u0C4D \u0C1A\u0C47\u0C2F\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C32\u0C47\u0C26\u0C3E \u0C05\u0C2A\u0C4D\u200C\u0C21\u0C47\u0C1F\u0C4D \u0C1A\u0C47\u0C2F\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C2E\u0C41\u0C02\u0C26\u0C41 \u0C24\u0C46\u0C30\u0C3F\u0C1A\u0C3E\u0C30\u0C41. \u0C08 \u0C1F\u0C4D\u0C2F\u0C3E\u0C2C\u0C4D\u200C\u0C28\u0C41 \u0C12\u0C15\u0C38\u0C3E\u0C30\u0C3F \u0C30\u0C40\u0C32\u0C4B\u0C21\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F (F5), \u0C24\u0C30\u0C4D\u0C35\u0C3E\u0C24 Fill \u0C28\u0C4A\u0C15\u0C4D\u0C15\u0C02\u0C21\u0C3F.",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "\u0C2B\u0C3E\u0C30\u0C2E\u0C4D \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C3F\u0C02\u0C17\u0C4D",
  "settings.mapVersion": "\u0C38\u0C02\u0C38\u0C4D\u0C15\u0C30\u0C23",
  "settings.mapLastVerified": "\u0C1A\u0C3F\u0C35\u0C30\u0C3F \u0C27\u0C43\u0C35\u0C40\u0C15\u0C30\u0C23",
  "settings.mapFetchedAt": "\u0C38\u0C47\u0C15\u0C30\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F",
  "settings.mapSignature": "Ed25519 \u0C38\u0C02\u0C24\u0C15\u0C02",
  "settings.mapRefresh": "\u0C07\u0C2A\u0C4D\u0C2A\u0C41\u0C21\u0C47 \u0C30\u0C3F\u0C2B\u0C4D\u0C30\u0C46\u0C37\u0C4D \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F",
  "settings.mapRefreshed": "\u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C3F\u0C02\u0C17\u0C4D \u0C30\u0C3F\u0C2B\u0C4D\u0C30\u0C46\u0C37\u0C4D \u0C05\u0C2F\u0C3F\u0C02\u0C26\u0C3F.",
  "settings.mapRefreshFailed": "\u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C3F\u0C02\u0C17\u0C4D\u200C\u0C28\u0C41 \u0C30\u0C3F\u0C2B\u0C4D\u0C30\u0C46\u0C37\u0C4D \u0C1A\u0C47\u0C2F\u0C21\u0C02 \u0C38\u0C3E\u0C27\u0C4D\u0C2F\u0C02 \u0C15\u0C3E\u0C32\u0C47\u0C26\u0C41 - \u0C05\u0C02\u0C26\u0C41\u0C2C\u0C3E\u0C1F\u0C41\u0C32\u0C4B \u0C09\u0C28\u0C4D\u0C28 \u0C2E\u0C46\u0C30\u0C41\u0C17\u0C48\u0C28 \u0C15\u0C3E\u0C2A\u0C40 \u0C09\u0C2A\u0C2F\u0C4B\u0C17\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C41\u0C24\u0C4B\u0C02\u0C26\u0C3F.",
  "settings.mapStatusRemote": "\u0C27\u0C43\u0C35\u0C40\u0C15\u0C30\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F - \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C3F\u0C02\u0C17\u0C4D \u0C38\u0C30\u0C4D\u0C35\u0C30\u0C4D \u0C28\u0C41\u0C02\u0C21\u0C3F \u0C24\u0C40\u0C38\u0C41\u0C15\u0C41\u0C28\u0C4D\u0C28 \u0C15\u0C3E\u0C2A\u0C40.",
  "settings.mapStatusCached": "\u0C27\u0C43\u0C35\u0C40\u0C15\u0C30\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F - \u0C07\u0C1F\u0C40\u0C35\u0C32\u0C3F \u0C15\u0C3E\u0C37\u0C4D \u0C15\u0C3E\u0C2A\u0C40.",
  "settings.mapStatusBundled": "\u0C05\u0C02\u0C24\u0C30\u0C4D\u0C28\u0C3F\u0C30\u0C4D\u0C2E\u0C3F\u0C24 \u0C2A\u0C4D\u0C30\u0C3E\u0C25\u0C2E\u0C3F\u0C15 \u0C15\u0C3E\u0C2A\u0C40 (\u0C38\u0C30\u0C4D\u0C35\u0C30\u0C4D \u0C05\u0C02\u0C26\u0C41\u0C2C\u0C3E\u0C1F\u0C41\u0C32\u0C4B \u0C32\u0C47\u0C26\u0C41). \u0C38\u0C02\u0C24\u0C15\u0C02 \u0C1A\u0C46\u0C15\u0C4D\u0C15\u0C41\u0C1A\u0C46\u0C26\u0C30\u0C32\u0C47\u0C26\u0C41.",
  "settings.mapStatusTampered": "\u0C38\u0C02\u0C24\u0C15\u0C02 \u0C24\u0C28\u0C3F\u0C16\u0C40 \u0C35\u0C3F\u0C2B\u0C32\u0C2E\u0C48\u0C02\u0C26\u0C3F - \u0C08 \u0C15\u0C3E\u0C2A\u0C40 \u0C24\u0C3F\u0C30\u0C38\u0C4D\u0C15\u0C30\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F, \u0C35\u0C3E\u0C21\u0C41\u0C15\u0C32\u0C4B \u0C32\u0C47\u0C26\u0C41.",
  "chip.mappingUnavailable": "\u0C2B\u0C3E\u0C30\u0C02 \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C3F\u0C02\u0C17\u0C4D \u0C32\u0C4B\u0C21\u0C4D \u0C15\u0C3E\u0C32\u0C47\u0C26\u0C41 \u2014 \u0C0E\u0C15\u0C4D\u0C38\u0C4D\u200C\u0C1F\u0C46\u0C28\u0C4D\u0C37\u0C28\u0C4D \u0C2C\u0C4D\u0C2F\u0C3E\u0C15\u0C4D\u200C\u0C17\u0C4D\u0C30\u0C4C\u0C02\u0C21\u0C4D \u0C35\u0C30\u0C4D\u0C15\u0C30\u0C4D \u0C38\u0C4D\u0C2A\u0C02\u0C26\u0C3F\u0C02\u0C1A\u0C32\u0C47\u0C26\u0C41. \u0C2A\u0C4B\u0C30\u0C4D\u0C1F\u0C32\u0C4D \u0C1F\u0C4D\u0C2F\u0C3E\u0C2C\u0C4D\u200C\u0C28\u0C41 \u0C30\u0C40\u0C32\u0C4B\u0C21\u0C4D \u0C1A\u0C47\u0C38\u0C3F \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "popup.timeoutMapping": "\u0C2B\u0C3E\u0C30\u0C02 \u0C2E\u0C4D\u0C2F\u0C3E\u0C2A\u0C3F\u0C02\u0C17\u0C4D \u0C32\u0C4B\u0C21\u0C4D \u0C05\u0C35\u0C41\u0C24\u0C41\u0C28\u0C4D\u0C28 \u0C38\u0C2E\u0C2F\u0C02 \u0C2E\u0C41\u0C17\u0C3F\u0C38\u0C3F\u0C02\u0C26\u0C3F ({seconds} \u0C38\u0C46\u0C15\u0C28\u0C4D\u0C32\u0C41). \u0C15\u0C28\u0C46\u0C15\u0C4D\u0C37\u0C28\u0C4D \u0C24\u0C28\u0C3F\u0C16\u0C40 \u0C1A\u0C47\u0C38\u0C3F \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "popup.timeoutNoProgress": "\u0C28\u0C3F\u0C02\u0C2A\u0C21\u0C02 {seconds} \u0C38\u0C46\u0C15\u0C28\u0C4D\u0C32\u0C32\u0C4B \u0C2A\u0C4D\u0C30\u0C3E\u0C30\u0C02\u0C2D\u0C02 \u0C15\u0C3E\u0C32\u0C47\u0C26\u0C41 \u2014 Form III \u0C2A\u0C47\u0C1C\u0C40 \u0C38\u0C4D\u0C2A\u0C02\u0C26\u0C3F\u0C02\u0C1A\u0C21\u0C02 \u0C32\u0C47\u0C26\u0C41. \u0C1F\u0C4D\u0C2F\u0C3E\u0C2C\u0C4D\u200C\u0C28\u0C41 \u0C30\u0C40\u0C32\u0C4B\u0C21\u0C4D \u0C1A\u0C47\u0C38\u0C3F \u0C2E\u0C33\u0C4D\u0C32\u0C40 \u0C2A\u0C4D\u0C30\u0C2F\u0C24\u0C4D\u0C28\u0C3F\u0C02\u0C1A\u0C02\u0C21\u0C3F.",
  "popup.timeoutStalled": "\u0C28\u0C3F\u0C02\u0C2A\u0C21\u0C02 {seconds} \u0C38\u0C46\u0C15\u0C28\u0C4D\u0C32\u0C41\u0C17\u0C3E \u0C06\u0C17\u0C3F\u0C2A\u0C4B\u0C2F\u0C3F\u0C02\u0C26\u0C3F \u2014 Form III \u0C2A\u0C47\u0C1C\u0C40 \u0C38\u0C4D\u0C2A\u0C02\u0C26\u0C3F\u0C02\u0C1A\u0C21\u0C02 \u0C06\u0C2A\u0C47\u0C38\u0C3F\u0C02\u0C26\u0C3F.",
  "popup.timeoutCap": "\u0C28\u0C3F\u0C02\u0C2A\u0C21\u0C02 \u0C2E\u0C4A\u0C24\u0C4D\u0C24\u0C02 \u0C38\u0C2E\u0C2F \u0C2A\u0C30\u0C3F\u0C2E\u0C3F\u0C24\u0C3F ({seconds} \u0C38\u0C46\u0C15\u0C28\u0C4D\u0C32\u0C41) \u0C26\u0C3E\u0C1F\u0C3F\u0C02\u0C26\u0C3F; \u0C06\u0C2A\u0C3F\u0C35\u0C47\u0C2F\u0C2C\u0C21\u0C3F\u0C02\u0C26\u0C3F.",
  "popup.preview": "\u0C2E\u0C3E\u0C30\u0C4D\u0C2A\u0C41\u0C32\u0C28\u0C41 \u0C1A\u0C42\u0C21\u0C02\u0C21\u0C3F",
  "popup.previewApply": "\u0C35\u0C30\u0C4D\u0C24\u0C3F\u0C02\u0C2A\u0C41 \u0C1A\u0C47\u0C2F\u0C02\u0C21\u0C3F \u2014 \u0C2B\u0C3E\u0C30\u0C02 \u0C28\u0C3F\u0C02\u0C2A\u0C02\u0C21\u0C3F",
  "popup.undo": "\u0C1A\u0C3F\u0C35\u0C30\u0C3F \u0C2B\u0C3F\u0C32\u0C4D\u200C\u0C28\u0C41 \u0C05\u0C28\u0C4D\u200C\u0C21\u0C42 \u0C1A\u0C47\u0C2F\u0C02",
  "popup.undoDone": "{total}\u0C32\u0C4B {restored} \u0C2B\u0C40\u0C32\u0C4D\u0C21\u0C4D\u200C\u0C32\u0C41 \u0C35\u0C3E\u0C1F\u0C3F \u0C2E\u0C41\u0C28\u0C41\u0C2A\u0C1F\u0C3F \u0C35\u0C3F\u0C32\u0C41\u0C35\u0C32\u0C15\u0C41 \u0C2A\u0C41\u0C28\u0C30\u0C41\u0C26\u0C4D\u0C27\u0C30\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C4D\u0C21\u0C3E\u0C2F\u0C3F.",
  "popup.undoPartial": "{total}\u0C32\u0C4B {restored} \u0C2A\u0C41\u0C28\u0C30\u0C41\u0C26\u0C4D\u0C27\u0C30\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C4D\u0C21\u0C3E\u0C2F\u0C3F; {failed} \u0C2A\u0C41\u0C28\u0C30\u0C41\u0C26\u0C4D\u0C27\u0C30\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C32\u0C47\u0C15\u0C2A\u0C4B\u0C2F\u0C3E\u0C2F\u0C3F (\u0C2A\u0C47\u0C1C\u0C40 \u0C24\u0C3F\u0C30\u0C3F\u0C17\u0C3F \u0C30\u0C42\u0C2A\u0C4A\u0C02\u0C26\u0C3F \u0C09\u0C02\u0C21\u0C35\u0C1A\u0C4D\u0C1A\u0C41).",
  "popup.undoStale": "\u0C2B\u0C3F\u0C32\u0C4D \u0C24\u0C30\u0C4D\u0C35\u0C3E\u0C24 \u0C2A\u0C47\u0C1C\u0C40 \u0C2E\u0C3E\u0C30\u0C3F\u0C02\u0C26\u0C3F \u2014 \u0C2A\u0C41\u0C28\u0C30\u0C41\u0C26\u0C4D\u0C27\u0C30\u0C23 \u0C05\u0C38\u0C02\u0C2A\u0C42\u0C30\u0C4D\u0C23\u0C02\u0C17\u0C3E \u0C09\u0C02\u0C21\u0C35\u0C1A\u0C4D\u0C1A\u0C41.",
  "popup.undoNone": "\u0C05\u0C28\u0C4D\u200C\u0C21\u0C42 \u0C1A\u0C47\u0C2F\u0C21\u0C3E\u0C28\u0C3F\u0C15\u0C3F \u0C0F\u0C2E\u0C40 \u0C32\u0C47\u0C26\u0C41 \u2014 \u0C08 \u0C38\u0C46\u0C37\u0C28\u0C4D\u200C\u0C32\u0C4B \u0C08 \u0C1F\u0C4D\u0C2F\u0C3E\u0C2C\u0C4D\u200C\u0C32\u0C4B \u0C2B\u0C3F\u0C32\u0C4D \u0C1C\u0C30\u0C17\u0C32\u0C47\u0C26\u0C41.",
  "popup.previewUnresolved": "\u0C08 \u0C2A\u0C47\u0C1C\u0C40\u0C32\u0C4B \u0C15\u0C28\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41",
  "popup.previewManual": "\u0C2E\u0C3E\u0C28\u0C4D\u0C2F\u0C41\u0C35\u0C32\u0C4D \u0C26\u0C36",
  "popup.previewNoValue": "(\u0C05\u0C02\u0C26\u0C3F\u0C02\u0C1A\u0C2C\u0C21\u0C32\u0C47\u0C26\u0C41)"
};

// src/i18n/ml.ts
var ml = {
  "popup.title": "Cformly \u0D13\u0D1F\u0D4D\u0D1F\u0D4B-\u0D2B\u0D3F\u0D7D",
  "popup.eyebrow": "\u0D13\u0D1F\u0D4D\u0D1F\u0D4B-\u0D2B\u0D3F\u0D7D",
  "popup.bandSub": "FRRO Form III \xB7 \u0D1A\u0D46\u0D15\u0D4D\u0D15\u0D4D-\u0D07\u0D28\u0D4D\u0D28\u0D3F\u0D28\u0D4D \u0D36\u0D47\u0D37\u0D02 24 \u0D2E\u0D23\u0D3F\u0D15\u0D4D\u0D15\u0D42\u0D31\u0D3F\u0D28\u0D41\u0D33\u0D4D\u0D33\u0D3F\u0D7D",
  "popup.fillFromClipboard": "\u0D15\u0D4D\u0D32\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D\u0D2C\u0D4B\u0D7C\u0D21\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D2B\u0D4B\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "popup.fillHint": "Cformly \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D2A\u0D15\u0D7C\u0D24\u0D4D\u0D24\u0D41\u0D15, \u0D24\u0D41\u0D1F\u0D7C\u0D28\u0D4D\u0D28\u0D4D \u0D08 \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D7D \u0D2B\u0D4B\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.clipboardReadFailed": "\u0D15\u0D4D\u0D32\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D\u0D2C\u0D4B\u0D7C\u0D21\u0D4D \u0D35\u0D3E\u0D2F\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D7B \u0D15\u0D34\u0D3F\u0D1E\u0D4D\u0D1E\u0D3F\u0D32\u0D4D\u0D32. \u0D2C\u0D4D\u0D30\u0D57\u0D38\u0D31\u0D3F\u0D28\u0D4D\u0D31\u0D46 \u0D15\u0D4D\u0D32\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D\u0D2C\u0D4B\u0D7C\u0D21\u0D4D \u0D05\u0D28\u0D41\u0D2E\u0D24\u0D3F\u0D15\u0D7E \u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.clipboardEmpty": "\u0D15\u0D4D\u0D32\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D\u0D2C\u0D4B\u0D7C\u0D21\u0D3F\u0D7D Cformly \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D07\u0D32\u0D4D\u0D32. \u0D06\u0D26\u0D4D\u0D2F\u0D02 Cformly \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D2A\u0D15\u0D7C\u0D24\u0D4D\u0D24\u0D41\u0D15.",
  "popup.settings": "\u0D15\u0D4D\u0D30\u0D2E\u0D40\u0D15\u0D30\u0D23\u0D19\u0D4D\u0D19\u0D7E",
  "popup.loadingMapping": "\u0D2B\u0D4B\u0D02 \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D02\u0D17\u0D4D \u0D32\u0D4B\u0D21\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D28\u0D4D\u0D28\u0D41...",
  "popup.filling": "\u0D2B\u0D4B\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D41...",
  "popup.fillingProgress": "\u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D41\u2026 \u0D2B\u0D40\u0D7D\u0D21\u0D4D {completed}/{total}",
  "popup.noTab": "\u0D38\u0D1C\u0D40\u0D35 \u0D1F\u0D3E\u0D2C\u0D4D \u0D15\u0D23\u0D4D\u0D1F\u0D46\u0D24\u0D4D\u0D24\u0D3F\u0D2F\u0D3F\u0D32\u0D4D\u0D32.",
  "popup.filled": "\u0D06\u0D35\u0D36\u0D4D\u0D2F\u0D2E\u0D3E\u0D2F \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D1A\u0D4D\u0D1A\u0D41: {required}-\u0D7D {filledRequired} ({filled} \u0D06\u0D15\u0D46 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D1A\u0D4D\u0D1A\u0D41)",
  "popup.portalMismatch": "\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D7D \u0D2A\u0D4A\u0D30\u0D41\u0D24\u0D4D\u0D24\u0D15\u0D4D\u0D15\u0D47\u0D1F\u0D4D \u0D15\u0D23\u0D4D\u0D1F\u0D46\u0D24\u0D4D\u0D24\u0D3F (DOM \u0D2E\u0D3E\u0D31\u0D3F). Cformly \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D2A\u0D15\u0D7C\u0D24\u0D4D\u0D24\u0D3F \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D36\u0D4D\u0D30\u0D2E\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.missingElements": "\u0D28\u0D37\u0D4D\u0D1F\u0D2E\u0D3E\u0D2F \u0D18\u0D1F\u0D15\u0D19\u0D4D\u0D19\u0D7E: {list}",
  "popup.missingValues": "\u0D28\u0D37\u0D4D\u0D1F\u0D2E\u0D3E\u0D2F \u0D2E\u0D42\u0D32\u0D4D\u0D2F\u0D19\u0D4D\u0D19\u0D7E: {list}",
  "popup.manualFields": "\u0D2E\u0D3E\u0D28\u0D41\u0D35\u0D7D \u0D18\u0D1F\u0D4D\u0D1F\u0D19\u0D4D\u0D19\u0D7E \u0D06\u0D35\u0D36\u0D4D\u0D2F\u0D2E\u0D3E\u0D23\u0D4D: {list}",
  "popup.unsupportedFields": "\u0D13\u0D1F\u0D4D\u0D1F\u0D4B-\u0D2B\u0D3F\u0D7D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D3E\u0D7B \u0D15\u0D34\u0D3F\u0D2F\u0D3E\u0D24\u0D4D\u0D24 \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E: {list}",
  "popup.tooLongFields": "\u0D08 \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E\u0D15\u0D4D\u0D15\u0D41\u0D33\u0D4D\u0D33 \u0D2E\u0D42\u0D32\u0D4D\u0D2F\u0D19\u0D4D\u0D19\u0D7E \u0D35\u0D33\u0D30\u0D46 \u0D28\u0D40\u0D33\u0D2E\u0D41\u0D33\u0D4D\u0D33\u0D24\u0D3E\u0D23\u0D4D \u2014 \u0D12\u0D28\u0D4D\u0D28\u0D41\u0D02 \u0D0E\u0D34\u0D41\u0D24\u0D3F\u0D2F\u0D3F\u0D32\u0D4D\u0D32, \u0D1A\u0D46\u0D31\u0D3F\u0D2F \u0D2E\u0D42\u0D32\u0D4D\u0D2F\u0D02 \u0D1F\u0D48\u0D2A\u0D4D\u0D2A\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15: {list}",
  "popup.unverifiedFields": "\u0D08 \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15 \u2014 \u0D2E\u0D42\u0D32\u0D4D\u0D2F\u0D02 \u0D09\u0D31\u0D1A\u0D4D\u0D1A\u0D3F\u0D1F\u0D4D\u0D1F\u0D41\u0D23\u0D4D\u0D1F\u0D3E\u0D15\u0D3F\u0D32\u0D4D\u0D32: {list}",
  "popup.applicationId": "Application ID: {id}",
  "popup.accommodationMismatch": "\u0D2E\u0D41\u0D28\u0D4D\u0D28\u0D31\u0D3F\u0D2F\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D: FRRO \u0D38\u0D46\u0D37\u0D7B \u0D2E\u0D31\u0D4D\u0D31\u0D4A\u0D30\u0D41 \u0D2A\u0D4D\u0D30\u0D4B\u0D2A\u0D4D\u0D2A\u0D7C\u0D1F\u0D4D\u0D1F\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D33\u0D4D\u0D33\u0D24\u0D3E\u0D2F\u0D3F\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D02. \u0D38\u0D2E\u0D7C\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D24\u0D3F\u0D28\u0D4D \u0D2E\u0D41\u0D2E\u0D4D\u0D2A\u0D4D \u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.attention": "\u0D1A\u0D3F\u0D32 \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E\u0D15\u0D4D\u0D15\u0D4D \u0D36\u0D4D\u0D30\u0D26\u0D4D\u0D27 \u0D06\u0D35\u0D36\u0D4D\u0D2F\u0D2E\u0D3E\u0D23\u0D4D. Cformly \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D2A\u0D15\u0D7C\u0D24\u0D4D\u0D24\u0D3F \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D36\u0D4D\u0D30\u0D2E\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.openPrint": "\u0D35\u0D4D\u0D2F\u0D15\u0D4D\u0D24\u0D3F\u0D17\u0D24 \u0D2A\u0D4D\u0D30\u0D3F\u0D28\u0D4D\u0D31\u0D4D \u0D24\u0D41\u0D31\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "popup.printNoId": "\u0D07\u0D24\u0D41\u0D35\u0D30\u0D46 Application ID \u0D15\u0D4D\u0D2F\u0D3E\u0D2A\u0D4D\u200C\u0D1A\u0D7C \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D3F\u0D1F\u0D4D\u0D1F\u0D3F\u0D32\u0D4D\u0D32 \u2014 \u0D06\u0D26\u0D4D\u0D2F\u0D02 \u0D2B\u0D4B\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.printSent": "ID {id}-\u0D28\u0D3E\u0D2F\u0D3F \u0D2B\u0D2F\u0D7D \u0D1A\u0D46\u0D2F\u0D4D\u0D24 \u0D05\u0D2A\u0D47\u0D15\u0D4D\u0D37 \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D24\u0D41\u0D31\u0D28\u0D4D\u0D28\u0D41. PDF \u0D21\u0D57\u0D7A\u0D32\u0D4B\u0D21\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D3E\u0D7B \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D32\u0D3F\u0D28\u0D4D\u0D31\u0D46 \u0D35\u0D4D\u0D2F\u0D15\u0D4D\u0D24\u0D3F\u0D17\u0D24 \u0D2A\u0D4D\u0D30\u0D3F\u0D28\u0D4D\u0D31\u0D4D \u0D2E\u0D46\u0D28\u0D41 \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.formFilled": "\u0D2B\u0D4B\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D1A\u0D4D\u0D1A\u0D41. \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D32\u0D3F\u0D7D \u0D05\u0D35\u0D32\u0D4B\u0D15\u0D28\u0D02 \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D4D \u0D38\u0D2E\u0D7C\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.fillError": "\u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D24\u0D3F\u0D7D \u0D2A\u0D3F\u0D36\u0D15\u0D4D: {message}",
  "popup.connectionFailed": "FRRO \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D7D \u0D2A\u0D47\u0D1C\u0D3F\u0D7D \u0D0E\u0D24\u0D4D\u0D24\u0D3E\u0D7B \u0D15\u0D34\u0D3F\u0D1E\u0D4D\u0D1E\u0D3F\u0D32\u0D4D\u0D32. \u0D08 \u0D1F\u0D3E\u0D2C\u0D3F\u0D7D Form III \u0D2A\u0D47\u0D1C\u0D4D \u0D24\u0D41\u0D31\u0D28\u0D4D\u0D28\u0D4D \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D36\u0D4D\u0D30\u0D2E\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.unknownError": "\u0D05\u0D1C\u0D4D\u0D1E\u0D3E\u0D24\u0D02",
  "popup.apiBaseFallback": "\u0D2E\u0D41\u0D28\u0D4D\u0D28\u0D31\u0D3F\u0D2F\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D: \u0D38\u0D02\u0D2D\u0D30\u0D3F\u0D1A\u0D4D\u0D1A API URL \u0D05\u0D38\u0D3E\u0D27\u0D41\u0D35\u0D3E\u0D23\u0D4D \u2014 \u0D21\u0D3F\u0D2B\u0D4B\u0D7E\u0D1F\u0D4D\u0D1F\u0D4D \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D41. \u0D15\u0D4D\u0D30\u0D2E\u0D40\u0D15\u0D30\u0D23\u0D19\u0D4D\u0D19\u0D33\u0D3F\u0D7D \u0D05\u0D2A\u0D4D\u200C\u0D21\u0D47\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15.",
  "popup.mappingFallback": "\u0D2E\u0D41\u0D28\u0D4D\u0D28\u0D31\u0D3F\u0D2F\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D: \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D02\u0D17\u0D4D \u0D38\u0D46\u0D7C\u0D35\u0D31\u0D3F\u0D7D \u0D0E\u0D24\u0D4D\u0D24\u0D3E\u0D7B \u0D15\u0D34\u0D3F\u0D2F\u0D41\u0D28\u0D4D\u0D28\u0D3F\u0D32\u0D4D\u0D32 \u2014 \u0D2C\u0D3F\u0D7D\u0D31\u0D4D\u0D31\u0D4D-\u0D07\u0D7B \u0D2B\u0D40\u0D7D\u0D21\u0D4D \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D4D \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D41, \u0D05\u0D24\u0D4D \u0D15\u0D3E\u0D32\u0D39\u0D30\u0D23\u0D2A\u0D4D\u0D2A\u0D46\u0D1F\u0D4D\u0D1F\u0D24\u0D3E\u0D2F\u0D3F\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D02.",
  "settings.title": "Cformly \u0D15\u0D4D\u0D30\u0D2E\u0D40\u0D15\u0D30\u0D23\u0D19\u0D4D\u0D19\u0D7E",
  "settings.eyebrow": "\u0D15\u0D4D\u0D30\u0D2E\u0D40\u0D15\u0D30\u0D23\u0D19\u0D4D\u0D19\u0D7E",
  "settings.bandSub": "\u0D2B\u0D4B\u0D02 \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D02\u0D17\u0D41\u0D15\u0D7E \u0D28\u0D7D\u0D15\u0D41\u0D28\u0D4D\u0D28 \u0D2C\u0D3E\u0D15\u0D4D\u0D15\u0D46\u0D7B\u0D21\u0D4D \u0D15\u0D4B\u0D7A\u0D2B\u0D3F\u0D17\u0D7C \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15.",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "\u0D2B\u0D4B\u0D02 \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D02\u0D17\u0D41\u0D15\u0D7E \u0D28\u0D7D\u0D15\u0D41\u0D28\u0D4D\u0D28 \u0D2C\u0D3E\u0D15\u0D4D\u0D15\u0D46\u0D7B\u0D21\u0D4D. HTTPS \u0D2E\u0D3E\u0D24\u0D4D\u0D30\u0D02; localhost \u0D21\u0D46\u0D35\u0D32\u0D2A\u0D4D\u200C\u0D2E\u0D46\u0D28\u0D4D\u0D31\u0D4D \u0D2C\u0D3F\u0D7D\u0D21\u0D41\u0D15\u0D33\u0D3F\u0D7D \u0D2E\u0D3E\u0D24\u0D4D\u0D30\u0D02 \u0D2A\u0D4D\u0D30\u0D35\u0D7C\u0D24\u0D4D\u0D24\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D41.",
  "settings.save": "\u0D38\u0D47\u0D35\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15",
  "settings.back": "\u0D24\u0D3F\u0D30\u0D3F\u0D15\u0D46",
  "settings.backInTab": "\u0D15\u0D4D\u0D30\u0D2E\u0D40\u0D15\u0D30\u0D23\u0D19\u0D4D\u0D19\u0D7E \u0D1F\u0D3E\u0D2C\u0D3E\u0D2F\u0D3F \u0D24\u0D41\u0D31\u0D28\u0D4D\u0D28\u0D3F\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D41 \u2014 \u0D2B\u0D3F\u0D7D \u0D2A\u0D4B\u0D2A\u0D4D\u0D2A\u0D2A\u0D4D\u0D2A\u0D4D \u0D24\u0D41\u0D31\u0D15\u0D4D\u0D15\u0D3E\u0D7B Cformly \u0D1F\u0D42\u0D7E\u0D2C\u0D3E\u0D7C \u0D10\u0D15\u0D4D\u0D15\u0D7A \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "settings.urlEmpty": "URL \u0D36\u0D42\u0D28\u0D4D\u0D2F\u0D2E\u0D3E\u0D2F\u0D3F\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D30\u0D41\u0D24\u0D4D.",
  "settings.httpsOnly": "\u0D38\u0D41\u0D30\u0D15\u0D4D\u0D37\u0D2F\u0D4D\u0D15\u0D4D\u0D15\u0D3E\u0D2F\u0D3F HTTPS URL-\u0D15\u0D7E \u0D2E\u0D3E\u0D24\u0D4D\u0D30\u0D2E\u0D47 \u0D05\u0D28\u0D41\u0D35\u0D26\u0D3F\u0D15\u0D4D\u0D15\u0D42. \u0D2A\u0D4D\u0D30\u0D4A\u0D21\u0D15\u0D4D\u0D37\u0D28\u0D4D https:// \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "settings.hostNotAllowed": "URL \u0D39\u0D4B\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D4D\u0D28\u0D46\u0D2F\u0D3F\u0D02 localhost \u0D05\u0D32\u0D4D\u0D32\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D7D *.cformly.com \u0D06\u0D2F\u0D3F\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D23\u0D02 ({host} \u0D32\u0D2D\u0D3F\u0D1A\u0D4D\u0D1A\u0D41).",
  "settings.invalidUrl": "\u0D05\u0D38\u0D3E\u0D27\u0D41\u0D35\u0D3E\u0D2F URL. https:// \u0D09\u0D7E\u0D2A\u0D4D\u0D2A\u0D46\u0D1F\u0D41\u0D24\u0D4D\u0D24\u0D41\u0D15",
  "settings.urlPathNotAllowed": "\u0D2C\u0D46\u0D2F\u0D7C \u0D12\u0D31\u0D3F\u0D1C\u0D3F\u0D7B \u0D2E\u0D3E\u0D24\u0D4D\u0D30\u0D02 \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15 \u2014 path, query, #fragment \u0D0E\u0D28\u0D4D\u0D28\u0D3F\u0D35 \u0D28\u0D40\u0D15\u0D4D\u0D15\u0D02 \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15.",
  "settings.loopbackNotGranted": "Localhost API URL-\u0D15\u0D7E \u0D21\u0D46\u0D35\u0D32\u0D2A\u0D4D\u200C\u0D2E\u0D46\u0D28\u0D4D\u0D31\u0D4D \u0D2C\u0D3F\u0D7D\u0D21\u0D41\u0D15\u0D33\u0D3F\u0D7D \u0D2E\u0D3E\u0D24\u0D4D\u0D30\u0D2E\u0D47 \u0D2A\u0D4D\u0D30\u0D35\u0D7C\u0D24\u0D4D\u0D24\u0D3F\u0D15\u0D4D\u0D15\u0D42. \u0D08 \u0D2C\u0D3F\u0D7D\u0D21\u0D3F\u0D28\u0D4D https:// \u0D39\u0D4B\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D41\u0D15\u0D33\u0D3F\u0D7D \u0D2E\u0D3E\u0D24\u0D4D\u0D30\u0D2E\u0D47 \u0D0E\u0D24\u0D4D\u0D24\u0D3E\u0D7B \u0D15\u0D34\u0D3F\u0D2F\u0D42.",
  "settings.saved": "\u0D38\u0D47\u0D35\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D41.",
  "settings.saveError": "\u0D38\u0D47\u0D35\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D3E\u0D7B \u0D15\u0D34\u0D3F\u0D1E\u0D4D\u0D1E\u0D3F\u0D32\u0D4D\u0D32. \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D36\u0D4D\u0D30\u0D2E\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "settings.langLabel": "\u0D2D\u0D3E\u0D37",
  "settings.langEnglish": "\u0D07\u0D02\u0D17\u0D4D\u0D32\u0D40\u0D37\u0D4D",
  "settings.langHindi": "\u0D39\u0D3F\u0D28\u0D4D\u0D26\u0D3F",
  "settings.langAuto": "\u0D2C\u0D4D\u0D30\u0D57\u0D38\u0D31\u0D3F\u0D28\u0D46 \u0D2A\u0D3F\u0D28\u0D4D\u0D24\u0D41\u0D1F\u0D30\u0D41\u0D15",
  "settings.langHint": "\u0D28\u0D3F\u0D19\u0D4D\u0D19\u0D7E \u0D24\u0D3F\u0D30\u0D1E\u0D4D\u0D1E\u0D46\u0D1F\u0D41\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D24\u0D41\u0D35\u0D30\u0D46 \u0D28\u0D3F\u0D19\u0D4D\u0D19\u0D33\u0D41\u0D1F\u0D46 \u0D2C\u0D4D\u0D30\u0D57\u0D38\u0D7C \u0D2D\u0D3E\u0D37 \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D02.",
  // round-65: paste intake + in-page filing panel
  "popup.pasteLabel": "\u0D05\u0D32\u0D4D\u0D32\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D7D \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D07\u0D35\u0D3F\u0D1F\u0D46 \u0D2A\u0D47\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15",
  "popup.pdfPick": "Cformly PDF \u0D24\u0D41\u0D31\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "popup.pdfLoaded": "\u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E Cformly PDF-\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D32\u0D4B\u0D21\u0D4D \u0D06\u0D2F\u0D3F \u2014 \u0D24\u0D3E\u0D34\u0D46 \u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D3F\u0D1A\u0D4D\u0D1A\u0D4D, \u0D2A\u0D3F\u0D28\u0D4D\u0D28\u0D46 Fill Form \u0D05\u0D2E\u0D7C\u0D24\u0D4D\u0D24\u0D41\u0D15.",
  "popup.pdfRejected": "\u0D08 PDF-\u0D7D Cformly \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D07\u0D32\u0D4D\u0D32 \u0D05\u0D32\u0D4D\u0D32\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D7D \u0D05\u0D24\u0D4D \u0D35\u0D3E\u0D2F\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D28\u0D3E\u0D2F\u0D3F\u0D32\u0D4D\u0D32 \u2014 Cformly \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D0E\u0D15\u0D4D\u0D38\u0D4D\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D24 PDF \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.pastePlaceholder": "\u0D15\u0D4B\u0D2A\u0D4D\u0D2A\u0D3F \u0D1A\u0D46\u0D2F\u0D4D\u0D24 Cformly \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D07\u0D35\u0D3F\u0D1F\u0D46 \u0D2A\u0D47\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15",
  "popup.pasteHint": "\u0D15\u0D4D\u0D32\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D\u0D2C\u0D4B\u0D7C\u0D21\u0D4D \u0D2C\u0D1F\u0D4D\u0D1F\u0D7A \u0D2A\u0D4D\u0D30\u0D35\u0D7C\u0D24\u0D4D\u0D24\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D24\u0D4D\u0D24\u0D2A\u0D15\u0D4D\u0D37\u0D02, \u0D08 \u0D15\u0D2E\u0D4D\u0D2A\u0D4D\u0D2F\u0D42\u0D1F\u0D4D\u0D1F\u0D31\u0D3F\u0D32\u0D47\u0D15\u0D4D\u0D15\u0D4D \u0D05\u0D2F\u0D1A\u0D4D\u0D1A \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D07\u0D35\u0D3F\u0D1F\u0D46 \u0D2A\u0D47\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15 (\u0D05\u0D32\u0D4D\u0D32\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D7D \u0D1F\u0D46\u0D15\u0D4D\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D4D \u0D2B\u0D2F\u0D7D \u0D07\u0D1F\u0D41\u0D15), \u0D2A\u0D3F\u0D28\u0D4D\u0D28\u0D46 \u0D2B\u0D3F\u0D7D \u0D05\u0D2E\u0D7C\u0D24\u0D4D\u0D24\u0D41\u0D15.",
  "popup.payloadTooLarge": "\u0D2A\u0D47\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D24 \u0D1F\u0D46\u0D15\u0D4D\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D4D \u0D35\u0D33\u0D30\u0D46 \u0D35\u0D32\u0D41\u0D24\u0D3E\u0D23\u0D4D \u2014 Cformly \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D15\u0D4B\u0D2A\u0D4D\u0D2A\u0D3F \u0D1A\u0D46\u0D2F\u0D4D\u0D24 \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D2E\u0D3E\u0D24\u0D4D\u0D30\u0D02 \u0D2A\u0D47\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15.",
  "panel.title": "Cformly \u2014 \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D32\u0D3F\u0D7D \u0D2B\u0D2F\u0D32\u0D3F\u0D02\u0D17\u0D4D \u0D2A\u0D42\u0D7C\u0D24\u0D4D\u0D24\u0D3F\u0D2F\u0D3E\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "panel.dismiss": "\u0D05\u0D1F\u0D2F\u0D4D\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "panel.filled": "\u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D1A\u0D4D\u0D1A \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E: {filledRequired} / {required} \u0D28\u0D3F\u0D7C\u0D2C\u0D28\u0D4D\u0D27\u0D02",
  "panel.photoStep": "\u0D05\u0D24\u0D3F\u0D25\u0D3F\u0D2F\u0D41\u0D1F\u0D46 \u0D2B\u0D4B\u0D1F\u0D4D\u0D1F\u0D4B \u0D05\u0D31\u0D4D\u0D31\u0D3E\u0D1A\u0D4D\u0D1A\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15 (\u0D2B\u0D2F\u0D7D \u0D24\u0D3F\u0D30\u0D1E\u0D4D\u0D1E\u0D46\u0D1F\u0D41\u0D15\u0D4D\u0D15\u0D41\u0D15 \u2192 \u0D05\u0D2A\u0D4D\u200C\u0D32\u0D4B\u0D21\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15)",
  "panel.captchaStep": "\u0D38\u0D41\u0D30\u0D15\u0D4D\u0D37\u0D3E \u0D15\u0D4B\u0D21\u0D4D (CAPTCHA) \u0D1F\u0D48\u0D2A\u0D4D\u0D2A\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15",
  "panel.saveStep": "\u0D38\u0D47\u0D35\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D4D \u0D24\u0D41\u0D1F\u0D30\u0D41\u0D15 \u0D05\u0D2E\u0D7C\u0D24\u0D4D\u0D24\u0D41\u0D15",
  "panel.warnSession": "Cformly \u0D2E\u0D41\u0D28\u0D4D\u0D28\u0D31\u0D3F\u0D2F\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D: \u0D08 FRRO \u0D38\u0D46\u0D37\u0D7B \u0D2E\u0D31\u0D4D\u0D31\u0D4A\u0D30\u0D41 \u0D2A\u0D4D\u0D30\u0D4B\u0D2A\u0D4D\u0D2A\u0D7C\u0D1F\u0D4D\u0D1F\u0D3F\u0D2F\u0D41\u0D1F\u0D47\u0D24\u0D3E\u0D15\u0D3E\u0D02 ({reason}). \u0D38\u0D47\u0D35\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D02 \u0D2E\u0D41\u0D7B\u0D2A\u0D4D \u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "panel.warnUnverified": "Cformly \u0D2E\u0D41\u0D28\u0D4D\u0D28\u0D31\u0D3F\u0D2F\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D: \u0D08 \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D33\u0D41\u0D1F\u0D46 \u0D2E\u0D42\u0D32\u0D4D\u0D2F\u0D19\u0D4D\u0D19\u0D7E \u0D09\u0D31\u0D1A\u0D4D\u0D1A\u0D3F\u0D32\u0D4D\u0D32\u0D3E\u0D2F\u0D3F\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D02: {list}. \u0D38\u0D47\u0D35\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D02 \u0D2E\u0D41\u0D7B\u0D2A\u0D4D \u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "panel.saving": "\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D32\u0D3F\u0D28\u0D4D\u0D31\u0D46 \u0D38\u0D4D\u0D25\u0D3F\u0D30\u0D40\u0D15\u0D30\u0D23\u0D24\u0D4D\u0D24\u0D3F\u0D28\u0D3E\u0D2F\u0D3F \u0D15\u0D3E\u0D24\u0D4D\u0D24\u0D3F\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D41\u2026",
  "panel.progress": "\u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D41\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO \u0D38\u0D46\u0D37\u0D7B \u0D15\u0D3E\u0D32\u0D39\u0D30\u0D23\u0D2A\u0D4D\u0D2A\u0D46\u0D1F\u0D4D\u0D1F\u0D41 \u2014 \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D32\u0D4B\u0D17\u0D3F\u0D7B \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D4D \u0D2B\u0D4B\u0D02 \u0D24\u0D41\u0D31\u0D28\u0D4D\u0D28\u0D4D Fill \u0D05\u0D2E\u0D7C\u0D24\u0D4D\u0D24\u0D41\u0D15. \u0D28\u0D3F\u0D19\u0D4D\u0D19\u0D33\u0D41\u0D1F\u0D46 \u0D05\u0D24\u0D3F\u0D25\u0D3F\u0D2F\u0D41\u0D1F\u0D46 \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E Cformly \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D38\u0D42\u0D15\u0D4D\u0D37\u0D3F\u0D1A\u0D4D\u0D1A\u0D3F\u0D1F\u0D4D\u0D1F\u0D41\u0D23\u0D4D\u0D1F\u0D4D.",
  "panel.portalError": "\u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D7D \u0D2A\u0D4D\u0D30\u0D36\u0D4D\u0D28\u0D02 \u0D15\u0D3E\u0D23\u0D3F\u0D1A\u0D4D\u0D1A\u0D41:",
  "panel.appIdFound": "\u0D35\u0D3F\u0D1C\u0D2F\u0D15\u0D30\u0D2E\u0D3E\u0D2F\u0D3F \u0D2B\u0D2F\u0D7D \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D41. \u0D05\u0D2A\u0D47\u0D15\u0D4D\u0D37\u0D3E \u0D10\u0D21\u0D3F:",
  "panel.scanHint": "Cformly \u0D06\u0D2A\u0D4D\u0D2A\u0D4D \u0D24\u0D41\u0D31\u0D15\u0D4D\u0D15\u0D41\u0D15 \u2192 \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D32\u0D3F\u0D32\u0D47\u0D15\u0D4D\u0D15\u0D4D \u0D05\u0D2F\u0D15\u0D4D\u0D15\u0D41\u0D15 \u2192 \u0D15\u0D2E\u0D4D\u0D2A\u0D4D\u0D2F\u0D42\u0D1F\u0D4D\u0D1F\u0D31\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D38\u0D4D\u0D15\u0D3E\u0D7B \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15, \u0D08 \u0D15\u0D4B\u0D21\u0D3F\u0D32\u0D47\u0D15\u0D4D\u0D15\u0D4D \u0D15\u0D4D\u0D2F\u0D3E\u0D2E\u0D31 \u0D24\u0D3F\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15 \u2014 \u0D05\u0D32\u0D4D\u0D32\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D7D \u0D10\u0D21\u0D3F \u0D15\u0D4B\u0D2A\u0D4D\u0D2A\u0D3F \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15.",
  "panel.copy": "\u0D05\u0D2A\u0D47\u0D15\u0D4D\u0D37\u0D3E \u0D10\u0D21\u0D3F \u0D15\u0D4B\u0D2A\u0D4D\u0D2A\u0D3F \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15",
  "panel.copied": "\u0D15\u0D4B\u0D2A\u0D4D\u0D2A\u0D3F \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D41.",
  "panel.confirmNotDetected": "\u0D38\u0D4D\u0D25\u0D3F\u0D30\u0D40\u0D15\u0D30\u0D23\u0D02 \u0D15\u0D23\u0D4D\u0D1F\u0D46\u0D24\u0D4D\u0D24\u0D3F\u0D2F\u0D3F\u0D32\u0D4D\u0D32 \u2014 \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D7D \u0D38\u0D47\u0D35\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D41\u0D35\u0D4B \u0D0E\u0D28\u0D4D\u0D28\u0D4D \u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D3F\u0D1A\u0D4D\u0D1A\u0D4D, \u0D24\u0D41\u0D1F\u0D30\u0D41\u0D15.",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "\u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D2B\u0D4B\u0D1F\u0D4D\u0D1F\u0D4B \u0D1A\u0D47\u0D7C\u0D15\u0D4D\u0D15\u0D3E\u0D7B \u0D07\u0D35\u0D3F\u0D1F\u0D46 \u0D07\u0D1F\u0D41\u0D15",
  "panel.photoBrowse": "\u0D2C\u0D4D\u0D30\u0D57\u0D38\u0D4D\u2026",
  "panel.photoAttachFailed": "\u0D38\u0D4D\u0D35\u0D2F\u0D2E\u0D47\u0D35 \u0D1A\u0D47\u0D7C\u0D15\u0D4D\u0D15\u0D3E\u0D28\u0D3E\u0D2F\u0D3F\u0D32\u0D4D\u0D32 \u2014 \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D32\u0D3F\u0D28\u0D4D\u0D31\u0D46 \u0D38\u0D4D\u0D35\u0D28\u0D4D\u0D24\u0D02 \u0D2B\u0D2F\u0D7D \u0D24\u0D3F\u0D30\u0D1E\u0D4D\u0D1E\u0D46\u0D1F\u0D41\u0D15\u0D4D\u0D15\u0D7D \u0D2C\u0D1F\u0D4D\u0D1F\u0D7A \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "\u0D08 \u0D2B\u0D4B\u0D02 Cformly \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D1A\u0D4D\u0D1A\u0D4D \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "chip.hint": "\u0D08 \u0D15\u0D2E\u0D4D\u0D2A\u0D4D\u0D2F\u0D42\u0D1F\u0D4D\u0D1F\u0D31\u0D3F\u0D32\u0D47\u0D15\u0D4D\u0D15\u0D4D \u0D05\u0D2F\u0D1A\u0D4D\u0D1A \u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D07\u0D35\u0D3F\u0D1F\u0D46 \u0D12\u0D1F\u0D4D\u0D1F\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15 (\u0D05\u0D32\u0D4D\u0D32\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D7D \u0D1F\u0D46\u0D15\u0D4D\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D4D \u0D2B\u0D2F\u0D7D \u0D07\u0D35\u0D3F\u0D1F\u0D46 \u0D07\u0D1F\u0D41\u0D15), \u0D2A\u0D3F\u0D28\u0D4D\u0D28\u0D46 \u0D2B\u0D4B\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15 \u0D05\u0D2E\u0D7C\u0D24\u0D4D\u0D24\u0D41\u0D15.",
  "chip.fill": "\u0D2B\u0D4B\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "chip.filling": "\u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D41\u2026",
  "chip.empty": "\u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D7B \u0D12\u0D28\u0D4D\u0D28\u0D41\u0D2E\u0D3F\u0D32\u0D4D\u0D32 \u2014 \u0D06\u0D26\u0D4D\u0D2F\u0D02 Cformly \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D2A\u0D15\u0D7C\u0D24\u0D4D\u0D24\u0D3F\u0D2F \u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D12\u0D1F\u0D4D\u0D1F\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "chip.tooLarge": "\u0D12\u0D1F\u0D4D\u0D1F\u0D3F\u0D1A\u0D4D\u0D1A \u0D1F\u0D46\u0D15\u0D4D\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D4D \u0D35\u0D33\u0D30\u0D46 \u0D35\u0D32\u0D41\u0D24\u0D3E\u0D23\u0D4D \u2014 Cformly \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D2A\u0D15\u0D7C\u0D24\u0D4D\u0D24\u0D3F\u0D2F \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D2E\u0D3E\u0D24\u0D4D\u0D30\u0D02 \u0D12\u0D1F\u0D4D\u0D1F\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "chip.collapse": "\u0D05\u0D1F\u0D2F\u0D4D\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "chip.mappingFallback": "\u0D36\u0D4D\u0D30\u0D26\u0D4D\u0D27\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15: \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D02\u0D17\u0D4D \u0D38\u0D46\u0D7C\u0D35\u0D7C \u0D32\u0D2D\u0D4D\u0D2F\u0D2E\u0D32\u0D4D\u0D32 \u2014 \u0D09\u0D7E\u0D1A\u0D4D\u0D1A\u0D47\u0D7C\u0D24\u0D4D\u0D24 \u0D2B\u0D40\u0D7D\u0D21\u0D4D \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D4D \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D41, \u0D05\u0D24\u0D4D \u0D2A\u0D34\u0D2F\u0D24\u0D3E\u0D15\u0D3E\u0D02.",
  // round-66: popup first-run onboarding
  "onboarding.title": "\u0D06\u0D26\u0D4D\u0D2F\u0D2E\u0D3E\u0D2F\u0D3F \u0D07\u0D35\u0D3F\u0D1F\u0D46? \u0D2E\u0D42\u0D28\u0D4D\u0D28\u0D4D \u0D1A\u0D41\u0D35\u0D1F\u0D41\u0D15\u0D7E:",
  "onboarding.step1": "\u0D28\u0D3F\u0D19\u0D4D\u0D19\u0D33\u0D41\u0D1F\u0D46 \u0D2B\u0D4B\u0D23\u0D3F\u0D7D: \u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D24\u0D41\u0D31\u0D15\u0D4D\u0D15\u0D41\u0D15 \u2192 \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D32\u0D3F\u0D32\u0D47\u0D15\u0D4D\u0D15\u0D4D \u0D05\u0D2F\u0D15\u0D4D\u0D15\u0D41\u0D15 \u2192 \u0D15\u0D2E\u0D4D\u0D2A\u0D4D\u0D2F\u0D42\u0D1F\u0D4D\u0D1F\u0D31\u0D3F\u0D32\u0D47\u0D15\u0D4D\u0D15\u0D4D \u0D05\u0D2F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "onboarding.step2": "\u0D08 \u0D15\u0D2E\u0D4D\u0D2A\u0D4D\u0D2F\u0D42\u0D1F\u0D4D\u0D1F\u0D31\u0D3F\u0D7D: \u0D38\u0D4D\u0D35\u0D2F\u0D02 \u0D05\u0D2F\u0D1A\u0D4D\u0D1A \u0D35\u0D3F\u0D35\u0D30\u0D19\u0D4D\u0D19\u0D7E \u0D24\u0D3E\u0D34\u0D46\u0D2F\u0D41\u0D33\u0D4D\u0D33 \u0D2A\u0D46\u0D1F\u0D4D\u0D1F\u0D3F\u0D2F\u0D3F\u0D7D \u0D12\u0D1F\u0D4D\u0D1F\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15 (\u0D05\u0D32\u0D4D\u0D32\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D7D \u0D2B\u0D4B\u0D02 \u0D2A\u0D47\u0D1C\u0D3F\u0D32\u0D46 \u0D28\u0D40\u0D32 Cformly \u0D2C\u0D1F\u0D4D\u0D1F\u0D7A \u0D05\u0D2E\u0D7C\u0D24\u0D4D\u0D24\u0D41\u0D15).",
  "onboarding.step3": "\u0D2B\u0D4B\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15 \u0D05\u0D2E\u0D7C\u0D24\u0D4D\u0D24\u0D41\u0D15 \u2014 \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D7D \u0D2B\u0D4B\u0D02 \u0D38\u0D4D\u0D35\u0D2F\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D02. \u0D2B\u0D4B\u0D1F\u0D4D\u0D1F\u0D4B, \u0D38\u0D41\u0D30\u0D15\u0D4D\u0D37\u0D3E \u0D15\u0D4B\u0D21\u0D4D, \u0D38\u0D47\u0D35\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D28\u0D4D\u0D28\u0D24\u0D4D \u0D28\u0D3F\u0D19\u0D4D\u0D19\u0D7E.",
  "onboarding.done": "\u0D2E\u0D28\u0D38\u0D4D\u0D38\u0D3F\u0D32\u0D3E\u0D2F\u0D3F",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{total} \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D33\u0D3F\u0D7D {filled} \u0D0E\u0D23\u0D4D\u0D23\u0D02 {time}-\u0D28\u0D4D \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D1A\u0D4D\u0D1A\u0D3F\u0D30\u0D41\u0D28\u0D4D\u0D28\u0D41. \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D7B \u0D24\u0D41\u0D1F\u0D30\u0D41\u0D15.",
  "resume.button": "\u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "\u0D08 \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D7D \u0D2A\u0D47\u0D1C\u0D4D Cformly \u0D05\u0D31\u0D3F\u0D2F\u0D41\u0D28\u0D4D\u0D28 Form III \u0D2A\u0D4B\u0D32\u0D46 \u0D24\u0D4B\u0D28\u0D4D\u0D28\u0D41\u0D28\u0D4D\u0D28\u0D3F\u0D32\u0D4D\u0D32 \u2014 \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D7D \u0D2E\u0D3E\u0D31\u0D3F\u0D2F\u0D3F\u0D1F\u0D4D\u0D1F\u0D41\u0D23\u0D4D\u0D1F\u0D3E\u0D15\u0D3E\u0D02. \u0D08 \u0D24\u0D35\u0D23 Cformly \u0D06\u0D2A\u0D4D\u0D2A\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D2A\u0D15\u0D7C\u0D24\u0D4D\u0D24\u0D3F \u0D38\u0D4D\u0D35\u0D2F\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15; \u0D05\u0D2A\u0D4D\u0D21\u0D47\u0D31\u0D4D\u0D31\u0D41\u0D15\u0D7E \u0D1E\u0D19\u0D4D\u0D19\u0D7E \u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D41.",
  "canary.detail": "\u0D08 \u0D2A\u0D47\u0D1C\u0D3F\u0D7D Cformly \u0D05\u0D31\u0D3F\u0D2F\u0D41\u0D28\u0D4D\u0D28 {total} \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D33\u0D3F\u0D7D {found} \u0D0E\u0D23\u0D4D\u0D23\u0D02 \u0D2E\u0D3E\u0D24\u0D4D\u0D30\u0D2E\u0D47 \u0D15\u0D23\u0D4D\u0D1F\u0D3F\u0D1F\u0D4D\u0D1F\u0D41\u0D33\u0D4D\u0D33\u0D42.",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "\u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D15\u0D4D\u0D2F\u0D42",
  "queue.add": "\u0D15\u0D4D\u0D2F\u0D42\u0D35\u0D3F\u0D7D \u0D1A\u0D47\u0D7C\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "queue.fill": "\u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "queue.remove": "\u0D28\u0D40\u0D15\u0D4D\u0D15\u0D02 \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15",
  "queue.unnamed": "\u0D05\u0D24\u0D3F\u0D25\u0D3F",
  "queue.added": "{name} \u0D15\u0D4D\u0D2F\u0D42\u0D35\u0D3F\u0D7D \u0D1A\u0D47\u0D7C\u0D24\u0D4D\u0D24\u0D41.",
  "queue.duplicate": "\u0D08 \u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D07\u0D24\u0D3F\u0D28\u0D15\u0D02 \u0D15\u0D4D\u0D2F\u0D42\u0D35\u0D3F\u0D32\u0D41\u0D23\u0D4D\u0D1F\u0D4D.",
  "queue.full": "\u0D15\u0D4D\u0D2F\u0D42 \u0D28\u0D3F\u0D31\u0D1E\u0D4D\u0D1E\u0D41 ({max} \u0D05\u0D24\u0D3F\u0D25\u0D3F\u0D15\u0D7E). \u0D06\u0D26\u0D4D\u0D2F\u0D02 \u0D12\u0D30\u0D41 \u0D05\u0D24\u0D3F\u0D25\u0D3F\u0D2F\u0D46 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15 \u0D05\u0D32\u0D4D\u0D32\u0D46\u0D19\u0D4D\u0D15\u0D3F\u0D7D \u0D28\u0D40\u0D15\u0D4D\u0D15\u0D02 \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15.",
  "queue.hint": "\u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D7B \u0D15\u0D3E\u0D24\u0D4D\u0D24\u0D3F\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28 \u0D05\u0D24\u0D3F\u0D25\u0D3F\u0D15\u0D7E. \u0D2A\u0D42\u0D7C\u0D23\u0D4D\u0D23\u0D2E\u0D3E\u0D2F \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D32\u0D3F\u0D28\u0D4D \u0D36\u0D47\u0D37\u0D02 \u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D15\u0D4D\u0D2F\u0D42\u0D35\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D28\u0D40\u0D15\u0D4D\u0D15\u0D02 \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D2A\u0D4D\u0D2A\u0D46\u0D1F\u0D41\u0D02; \u0D2C\u0D4D\u0D30\u0D57\u0D38\u0D7C \u0D05\u0D1F\u0D2F\u0D4D\u0D15\u0D4D\u0D15\u0D41\u0D2E\u0D4D\u0D2A\u0D4B\u0D7E \u0D15\u0D4D\u0D2F\u0D42 \u0D35\u0D46\u0D1F\u0D3F\u0D2A\u0D4D\u0D2A\u0D3E\u0D15\u0D41\u0D02.",
  "queue.unavailable": "\u0D08 \u0D2C\u0D4D\u0D30\u0D57\u0D38\u0D31\u0D3F\u0D7D \u0D05\u0D24\u0D3F\u0D25\u0D3F \u0D15\u0D4D\u0D2F\u0D42 \u0D32\u0D2D\u0D4D\u0D2F\u0D2E\u0D32\u0D4D\u0D32.",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "\u0D08 FRRO \u0D1F\u0D3E\u0D2C\u0D4D Cformly \u0D07\u0D7B\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D3E\u0D7E \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D28\u0D4D\u0D28\u0D24\u0D3F\u0D28\u0D4B \u0D05\u0D2A\u0D4D\u200C\u0D21\u0D47\u0D31\u0D4D\u0D31\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D28\u0D4D\u0D28\u0D24\u0D3F\u0D28\u0D4B \u0D2E\u0D41\u0D2E\u0D4D\u0D2A\u0D4D \u0D24\u0D41\u0D31\u0D28\u0D4D\u0D28\u0D24\u0D3E\u0D23\u0D4D. \u0D08 \u0D1F\u0D3E\u0D2C\u0D4D \u0D12\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D7D \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D32\u0D4B\u0D21\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D41\u0D15 (F5), \u0D2A\u0D3F\u0D28\u0D4D\u0D28\u0D46 Fill \u0D05\u0D2E\u0D7C\u0D24\u0D4D\u0D24\u0D41\u0D15.",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "\u0D2B\u0D4B\u0D02 \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D02\u0D17\u0D4D",
  "settings.mapVersion": "\u0D2A\u0D24\u0D3F\u0D2A\u0D4D\u0D2A\u0D4D",
  "settings.mapLastVerified": "\u0D05\u0D35\u0D38\u0D3E\u0D28 \u0D38\u0D4D\u0D25\u0D3F\u0D30\u0D40\u0D15\u0D30\u0D23\u0D02",
  "settings.mapFetchedAt": "\u0D36\u0D47\u0D16\u0D30\u0D3F\u0D1A\u0D4D\u0D1A\u0D24\u0D4D",
  "settings.mapSignature": "Ed25519 \u0D12\u0D2A\u0D4D\u0D2A\u0D4D",
  "settings.mapRefresh": "\u0D07\u0D2A\u0D4D\u0D2A\u0D4B\u0D7E \u0D2A\u0D41\u0D24\u0D41\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "settings.mapRefreshed": "\u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D02\u0D17\u0D4D \u0D2A\u0D41\u0D24\u0D41\u0D15\u0D4D\u0D15\u0D3F.",
  "settings.mapRefreshFailed": "\u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D02\u0D17\u0D4D \u0D2A\u0D41\u0D24\u0D41\u0D15\u0D4D\u0D15\u0D3E\u0D28\u0D3E\u0D2F\u0D3F\u0D32\u0D4D\u0D32 - \u0D32\u0D2D\u0D4D\u0D2F\u0D2E\u0D3E\u0D2F \u0D0F\u0D31\u0D4D\u0D31\u0D35\u0D41\u0D02 \u0D28\u0D32\u0D4D\u0D32 \u0D2A\u0D15\u0D7C\u0D2A\u0D4D\u0D2A\u0D3E\u0D23\u0D4D \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D24\u0D4D.",
  "settings.mapStatusRemote": "\u0D38\u0D4D\u0D25\u0D3F\u0D30\u0D40\u0D15\u0D30\u0D3F\u0D1A\u0D4D\u0D1A\u0D41 - \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D02\u0D17\u0D4D \u0D38\u0D46\u0D7C\u0D35\u0D31\u0D3F\u0D7D \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D4D \u0D32\u0D2D\u0D3F\u0D1A\u0D4D\u0D1A \u0D2A\u0D15\u0D7C\u0D2A\u0D4D\u0D2A\u0D4D.",
  "settings.mapStatusCached": "\u0D38\u0D4D\u0D25\u0D3F\u0D30\u0D40\u0D15\u0D30\u0D3F\u0D1A\u0D4D\u0D1A\u0D41 - \u0D05\u0D1F\u0D41\u0D24\u0D4D\u0D24\u0D15\u0D3E\u0D32\u0D24\u0D4D\u0D24\u0D46 \u0D15\u0D3E\u0D37\u0D46 \u0D2A\u0D15\u0D7C\u0D2A\u0D4D\u0D2A\u0D4D.",
  "settings.mapStatusBundled": "\u0D09\u0D7E\u0D2A\u0D4D\u0D2A\u0D46\u0D1F\u0D41\u0D24\u0D4D\u0D24\u0D3F\u0D2F \u0D05\u0D1F\u0D3F\u0D38\u0D4D\u0D25\u0D3E\u0D28 \u0D2A\u0D15\u0D7C\u0D2A\u0D4D\u0D2A\u0D4D (\u0D38\u0D46\u0D7C\u0D35\u0D7C \u0D32\u0D2D\u0D4D\u0D2F\u0D2E\u0D32\u0D4D\u0D32). \u0D12\u0D2A\u0D4D\u0D2A\u0D4D \u0D38\u0D41\u0D30\u0D15\u0D4D\u0D37\u0D3F\u0D24\u0D02.",
  "settings.mapStatusTampered": "\u0D12\u0D2A\u0D4D\u0D2A\u0D4D \u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D28 \u0D2A\u0D30\u0D3E\u0D1C\u0D2F\u0D2A\u0D4D\u0D2A\u0D46\u0D1F\u0D4D\u0D1F\u0D41 - \u0D08 \u0D2A\u0D15\u0D7C\u0D2A\u0D4D\u0D2A\u0D4D \u0D28\u0D3F\u0D30\u0D38\u0D3F\u0D15\u0D4D\u0D15\u0D2A\u0D4D\u0D2A\u0D46\u0D1F\u0D4D\u0D1F\u0D41, \u0D09\u0D2A\u0D2F\u0D4B\u0D17\u0D24\u0D4D\u0D24\u0D3F\u0D32\u0D3F\u0D32\u0D4D\u0D32.",
  "chip.mappingUnavailable": "\u0D2B\u0D4B\u0D02 \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D02\u0D17\u0D4D \u0D32\u0D4B\u0D21\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D3E\u0D28\u0D3E\u0D2F\u0D3F\u0D32\u0D4D\u0D32 \u2014 \u0D0E\u0D15\u0D4D\u0D38\u0D4D\u0D31\u0D4D\u0D31\u0D7B\u0D37\u0D28\u0D4D\u0D31\u0D46 \u0D2C\u0D3E\u0D15\u0D4D\u0D15\u0D4D\u0D17\u0D4D\u0D30\u0D57\u0D23\u0D4D\u0D1F\u0D4D \u0D35\u0D7C\u0D15\u0D4D\u0D15\u0D7C \u0D2E\u0D31\u0D41\u0D2A\u0D1F\u0D3F \u0D28\u0D7D\u0D15\u0D3F\u0D2F\u0D3F\u0D32\u0D4D\u0D32. \u0D2A\u0D4B\u0D7C\u0D1F\u0D4D\u0D1F\u0D7D \u0D1F\u0D3E\u0D2C\u0D4D \u0D31\u0D40\u0D32\u0D4B\u0D21\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D4D \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D36\u0D4D\u0D30\u0D2E\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.timeoutMapping": "\u0D2B\u0D4B\u0D02 \u0D2E\u0D3E\u0D2A\u0D4D\u0D2A\u0D3F\u0D02\u0D17\u0D4D \u0D32\u0D4B\u0D21\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D2F\u0D3E\u0D28\u0D41\u0D33\u0D4D\u0D33 \u0D38\u0D2E\u0D2F\u0D02 \u0D15\u0D34\u0D3F\u0D1E\u0D4D\u0D1E\u0D41 ({seconds} \u0D38\u0D46\u0D15\u0D4D\u0D15\u0D7B\u0D21\u0D4D). \u0D15\u0D23\u0D15\u0D4D\u0D37\u0D7B \u0D2A\u0D30\u0D3F\u0D36\u0D4B\u0D27\u0D3F\u0D1A\u0D4D\u0D1A\u0D4D \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D36\u0D4D\u0D30\u0D2E\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.timeoutNoProgress": "\u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D7D {seconds} \u0D38\u0D46\u0D15\u0D4D\u0D15\u0D7B\u0D21\u0D3F\u0D28\u0D41\u0D33\u0D4D\u0D33\u0D3F\u0D7D \u0D06\u0D30\u0D02\u0D2D\u0D3F\u0D1A\u0D4D\u0D1A\u0D3F\u0D32\u0D4D\u0D32 \u2014 Form III \u0D2A\u0D47\u0D1C\u0D4D \u0D2A\u0D4D\u0D30\u0D24\u0D3F\u0D15\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D3F\u0D32\u0D4D\u0D32. \u0D1F\u0D3E\u0D2C\u0D4D \u0D31\u0D40\u0D32\u0D4B\u0D21\u0D4D \u0D1A\u0D46\u0D2F\u0D4D\u0D24\u0D4D \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D36\u0D4D\u0D30\u0D2E\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15.",
  "popup.timeoutStalled": "\u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D7D {seconds} \u0D38\u0D46\u0D15\u0D4D\u0D15\u0D7B\u0D21\u0D3E\u0D2F\u0D3F \u0D28\u0D3F\u0D28\u0D4D\u0D28\u0D41\u0D2A\u0D4B\u0D2F\u0D3F \u2014 Form III \u0D2A\u0D47\u0D1C\u0D4D \u0D2A\u0D4D\u0D30\u0D24\u0D3F\u0D15\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D28\u0D4D\u0D28\u0D24\u0D4D \u0D28\u0D3F\u0D7C\u0D24\u0D4D\u0D24\u0D3F.",
  "popup.timeoutCap": "\u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D7D \u0D2E\u0D4A\u0D24\u0D4D\u0D24\u0D02 \u0D38\u0D2E\u0D2F \u0D2A\u0D30\u0D3F\u0D27\u0D3F ({seconds} \u0D38\u0D46\u0D15\u0D4D\u0D15\u0D7B\u0D21\u0D4D) \u0D15\u0D1F\u0D28\u0D4D\u0D28\u0D41; \u0D28\u0D3F\u0D7C\u0D24\u0D4D\u0D24\u0D3F.",
  "popup.preview": "\u0D2E\u0D3E\u0D31\u0D4D\u0D31\u0D19\u0D4D\u0D19\u0D7E \u0D15\u0D3E\u0D23\u0D41\u0D15",
  "popup.previewApply": "\u0D2A\u0D4D\u0D30\u0D2F\u0D4B\u0D17\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15 \u2014 \u0D2B\u0D4B\u0D02 \u0D2A\u0D42\u0D30\u0D3F\u0D2A\u0D4D\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "popup.undo": "\u0D05\u0D35\u0D38\u0D3E\u0D28 \u0D2B\u0D3F\u0D7D \u0D2A\u0D34\u0D2F\u0D2A\u0D1F\u0D3F\u0D2F\u0D3E\u0D15\u0D4D\u0D15\u0D41\u0D15",
  "popup.undoDone": "{total}\u0D7D {restored} \u0D2B\u0D40\u0D7D\u0D21\u0D41\u0D15\u0D7E \u0D2A\u0D34\u0D2F \u0D2E\u0D42\u0D32\u0D4D\u0D2F\u0D19\u0D4D\u0D19\u0D33\u0D3F\u0D32\u0D47\u0D15\u0D4D\u0D15\u0D4D \u0D2A\u0D41\u0D28\u0D03\u0D38\u0D4D\u0D25\u0D3E\u0D2A\u0D3F\u0D1A\u0D4D\u0D1A\u0D41.",
  "popup.undoPartial": "{total}\u0D7D {restored} \u0D2A\u0D41\u0D28\u0D03\u0D38\u0D4D\u0D25\u0D3E\u0D2A\u0D3F\u0D1A\u0D4D\u0D1A\u0D41; {failed} \u0D2A\u0D41\u0D28\u0D03\u0D38\u0D4D\u0D25\u0D3E\u0D2A\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D28\u0D3E\u0D2F\u0D3F\u0D32\u0D4D\u0D32 (\u0D2A\u0D47\u0D1C\u0D4D \u0D35\u0D40\u0D23\u0D4D\u0D1F\u0D41\u0D02 \u0D28\u0D3F\u0D7C\u0D2E\u0D4D\u0D2E\u0D3F\u0D1A\u0D4D\u0D1A\u0D3F\u0D30\u0D3F\u0D15\u0D4D\u0D15\u0D3E\u0D02).",
  "popup.undoStale": "\u0D2B\u0D3F\u0D32\u0D3F\u0D28\u0D4D \u0D36\u0D47\u0D37\u0D02 \u0D2A\u0D47\u0D1C\u0D4D \u0D2E\u0D3E\u0D31\u0D3F \u2014 \u0D2A\u0D41\u0D28\u0D03\u0D38\u0D4D\u0D25\u0D3E\u0D2A\u0D28\u0D02 \u0D2A\u0D42\u0D7C\u0D23\u0D4D\u0D23\u0D2E\u0D32\u0D4D\u0D32\u0D3E\u0D24\u0D3E\u0D15\u0D3E\u0D02.",
  "popup.undoNone": "\u0D2A\u0D34\u0D2F\u0D2A\u0D1F\u0D3F\u0D2F\u0D3E\u0D15\u0D4D\u0D15\u0D3E\u0D7B \u0D12\u0D28\u0D4D\u0D28\u0D41\u0D2E\u0D3F\u0D32\u0D4D\u0D32 \u2014 \u0D08 \u0D38\u0D46\u0D37\u0D28\u0D3F\u0D7D \u0D08 \u0D1F\u0D3E\u0D2C\u0D3F\u0D7D \u0D2B\u0D3F\u0D7D \u0D09\u0D23\u0D4D\u0D1F\u0D3E\u0D2F\u0D3F\u0D1F\u0D4D\u0D1F\u0D3F\u0D32\u0D4D\u0D32.",
  "popup.previewUnresolved": "\u0D08 \u0D2A\u0D47\u0D1C\u0D3F\u0D7D \u0D15\u0D23\u0D4D\u0D1F\u0D46\u0D24\u0D4D\u0D24\u0D3F\u0D2F\u0D3F\u0D32\u0D4D\u0D32",
  "popup.previewManual": "\u0D15\u0D48\u0D15\u0D4A\u0D23\u0D4D\u0D1F\u0D41\u0D33\u0D4D\u0D33 \u0D18\u0D1F\u0D4D\u0D1F\u0D02",
  "popup.previewNoValue": "(\u0D28\u0D7D\u0D15\u0D3F\u0D2F\u0D3F\u0D1F\u0D4D\u0D1F\u0D3F\u0D32\u0D4D\u0D32)"
};

// src/i18n/pa.ts
var pa = {
  // popup
  "popup.title": "Cformly \u0A06\u0A1F\u0A4B-\u0A2B\u0A3F\u0A32",
  "popup.eyebrow": "\u0A06\u0A1F\u0A4B-\u0A2B\u0A3F\u0A32",
  "popup.bandSub": "FRRO Form III \xB7 \u0A1A\u0A48\u0A71\u0A15-\u0A07\u0A28 \u0A24\u0A4B\u0A02 24 \u0A18\u0A70\u0A1F\u0A3F\u0A06\u0A02 \u0A26\u0A47 \u0A05\u0A70\u0A26\u0A30",
  "popup.fillFromClipboard": "\u0A15\u0A32\u0A3F\u0A71\u0A2A\u0A2C\u0A4B\u0A30\u0A21 \u0A24\u0A4B\u0A02 \u0A2B\u0A3E\u0A30\u0A2E \u0A2D\u0A30\u0A4B",
  "popup.fillHint": "\u0A2A\u0A39\u0A3F\u0A32\u0A3E\u0A02 Cformly \u0A10\u0A2A \u0A24\u0A4B\u0A02 \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A26\u0A47 \u0A16\u0A47\u0A24\u0A30 \u0A15\u0A3E\u0A2A\u0A40 \u0A15\u0A30\u0A4B, \u0A2B\u0A3F\u0A30 \u0A07\u0A39 \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A2B\u0A3E\u0A30\u0A2E \u0A2D\u0A30\u0A4B\u0964",
  "popup.clipboardReadFailed": "\u0A15\u0A32\u0A3F\u0A71\u0A2A\u0A2C\u0A4B\u0A30\u0A21 \u0A2A\u0A5C\u0A4D\u0A39\u0A3F\u0A06 \u0A28\u0A39\u0A40\u0A02 \u0A1C\u0A3E \u0A38\u0A15\u0A3F\u0A06\u0964 \u0A2C\u0A30\u0A3E\u0A0A\u0A1C\u0A3C\u0A30 \u0A26\u0A40\u0A06\u0A02 \u0A15\u0A32\u0A3F\u0A71\u0A2A\u0A2C\u0A4B\u0A30\u0A21 \u0A07\u0A1C\u0A3E\u0A1C\u0A3C\u0A24\u0A3E\u0A02 \u0A35\u0A47\u0A16\u0A4B\u0964",
  "popup.clipboardEmpty": "\u0A15\u0A32\u0A3F\u0A71\u0A2A\u0A2C\u0A4B\u0A30\u0A21 \u0A35\u0A3F\u0A71\u0A1A Cformly \u0A16\u0A47\u0A24\u0A30 \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A28\u0964 \u0A2A\u0A39\u0A3F\u0A32\u0A3E\u0A02 Cformly \u0A10\u0A2A \u0A24\u0A4B\u0A02 \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A26\u0A47 \u0A16\u0A47\u0A24\u0A30 \u0A15\u0A3E\u0A2A\u0A40 \u0A15\u0A30\u0A4B\u0964",
  "popup.settings": "\u0A38\u0A48\u0A1F\u0A3F\u0A70\u0A17\u0A3E\u0A02",
  "popup.loadingMapping": "\u0A2B\u0A3E\u0A30\u0A2E \u0A2E\u0A48\u0A2A\u0A3F\u0A70\u0A17 \u0A32\u0A4B\u0A21 \u0A39\u0A4B \u0A30\u0A39\u0A40 \u0A39\u0A48...",
  "popup.filling": "\u0A2B\u0A3E\u0A30\u0A2E \u0A2D\u0A30\u0A3F\u0A06 \u0A1C\u0A3E \u0A30\u0A3F\u0A39\u0A3E \u0A39\u0A48...",
  "popup.fillingProgress": "\u0A2D\u0A30\u0A3F\u0A06 \u0A1C\u0A3E \u0A30\u0A3F\u0A39\u0A3E \u0A39\u0A48\u2026 \u0A16\u0A47\u0A24\u0A30 {completed}/{total}",
  "popup.noTab": "\u0A15\u0A4B\u0A08 \u0A38\u0A30\u0A17\u0A30\u0A2E \u0A1F\u0A48\u0A2C \u0A28\u0A39\u0A40\u0A02 \u0A2E\u0A3F\u0A32\u0A40\u0964",
  "popup.filled": "\u0A32\u0A4B\u0A5C\u0A40\u0A02\u0A26\u0A47 \u0A16\u0A47\u0A24\u0A30 \u0A2D\u0A30\u0A47 \u0A17\u0A0F: {required} \u0A35\u0A3F\u0A71\u0A1A\u0A4B\u0A02 {filledRequired} ({filled} \u0A15\u0A41\u0A71\u0A32 \u0A2D\u0A30\u0A47)",
  "popup.portalMismatch": "\u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A2C\u0A26\u0A32\u0A3E\u0A05 \u0A26\u0A3E \u0A2A\u0A24\u0A3E \u0A32\u0A71\u0A17\u0A3E (DOM \u0A2C\u0A26\u0A32\u0A3F\u0A06 \u0A39\u0A4B\u0A07\u0A06 \u0A39\u0A48)\u0964 Cformly \u0A10\u0A2A \u0A35\u0A3F\u0A71\u0A1A \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A26\u0A47 \u0A16\u0A47\u0A24\u0A30 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A15\u0A3E\u0A2A\u0A40 \u0A15\u0A30\u0A4B \u0A05\u0A24\u0A47 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A15\u0A4B\u0A38\u0A3C\u0A3F\u0A38\u0A3C \u0A15\u0A30\u0A4B\u0964",
  "popup.missingElements": "\u0A17\u0A41\u0A70\u0A2E \u0A24\u0A71\u0A24: {list}",
  "popup.missingValues": "\u0A17\u0A41\u0A70\u0A2E \u0A2E\u0A41\u0A71\u0A32: {list}",
  "popup.manualFields": "\u0A26\u0A38\u0A24\u0A40 \u0A15\u0A26\u0A2E \u0A32\u0A4B\u0A5C\u0A40\u0A02\u0A26\u0A47: {list}",
  "popup.unsupportedFields": "\u0A16\u0A47\u0A24\u0A30 \u0A1C\u0A4B \u0A06\u0A1F\u0A4B-\u0A2D\u0A30\u0A47 \u0A28\u0A39\u0A40\u0A02 \u0A1C\u0A3E \u0A38\u0A15\u0A26\u0A47: {list}",
  "popup.tooLongFields": "\u0A07\u0A28\u0A4D\u0A39\u0A3E\u0A02 \u0A16\u0A47\u0A24\u0A30\u0A3E\u0A02 \u0A32\u0A08 \u0A2E\u0A41\u0A71\u0A32 \u0A2C\u0A39\u0A41\u0A24 \u0A32\u0A70\u0A2C\u0A47 \u0A39\u0A28 \u2014 \u0A15\u0A41\u0A1D \u0A35\u0A40 \u0A28\u0A39\u0A40\u0A02 \u0A32\u0A3F\u0A16\u0A3F\u0A06 \u0A17\u0A3F\u0A06, \u0A1B\u0A4B\u0A1F\u0A3E \u0A2E\u0A41\u0A71\u0A32 \u0A1F\u0A3E\u0A08\u0A2A \u0A15\u0A30\u0A4B: {list}",
  "popup.unverifiedFields": "\u0A07\u0A28\u0A4D\u0A39\u0A3E\u0A02 \u0A16\u0A47\u0A24\u0A30\u0A3E\u0A02 \u0A26\u0A40 \u0A1C\u0A3E\u0A02\u0A1A \u0A15\u0A30\u0A4B \u2014 \u0A2E\u0A41\u0A71\u0A32 \u0A38\u0A3C\u0A3E\u0A07\u0A26 \u0A28\u0A3E \u0A1A\u0A70\u0A2C\u0A5C\u0A47 \u0A39\u0A4B\u0A23: {list}",
  "popup.applicationId": "\u0A05\u0A30\u0A1C\u0A3C\u0A40 ID: {id}",
  "popup.accommodationMismatch": "\u0A1A\u0A3F\u0A24\u0A3E\u0A35\u0A28\u0A40: FRRO \u0A38\u0A48\u0A38\u0A3C\u0A28 \u0A15\u0A3F\u0A38\u0A47 \u0A39\u0A4B\u0A30 \u0A2A\u0A4D\u0A30\u0A3E\u0A2A\u0A30\u0A1F\u0A40 \u0A32\u0A08 \u0A39\u0A4B \u0A38\u0A15\u0A26\u0A3E \u0A39\u0A48\u0964 \u0A1C\u0A2E\u0A4D\u0A39\u0A3E\u0A02 \u0A15\u0A30\u0A28 \u0A24\u0A4B\u0A02 \u0A2A\u0A39\u0A3F\u0A32\u0A3E\u0A02 \u0A24\u0A38\u0A26\u0A40\u0A15 \u0A15\u0A30\u0A4B\u0964",
  "popup.attention": "\u0A15\u0A41\u0A1D \u0A16\u0A47\u0A24\u0A30\u0A3E\u0A02 \u0A09\u0A71\u0A24\u0A47 \u0A27\u0A3F\u0A06\u0A28 \u0A26\u0A47\u0A23 \u0A26\u0A40 \u0A32\u0A4B\u0A5C \u0A39\u0A48\u0964 Cformly \u0A10\u0A2A \u0A35\u0A3F\u0A71\u0A1A \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A26\u0A47 \u0A16\u0A47\u0A24\u0A30 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A15\u0A3E\u0A2A\u0A40 \u0A15\u0A30\u0A4B \u0A05\u0A24\u0A47 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A15\u0A4B\u0A38\u0A3C\u0A3F\u0A38\u0A3C \u0A15\u0A30\u0A4B\u0964",
  "popup.openPrint": "\u0A07\u0A70\u0A21\u0A40\u0A35\u0A3F\u0A1C\u0A3C\u0A41\u0A05\u0A32 \u0A2A\u0A4D\u0A30\u0A3F\u0A70\u0A1F \u0A16\u0A4B\u0A32\u0A4D\u0A39\u0A4B",
  "popup.printNoId": "\u0A39\u0A3E\u0A32\u0A47 \u0A15\u0A4B\u0A08 \u0A05\u0A30\u0A1C\u0A3C\u0A40 ID \u0A15\u0A48\u0A2A\u0A1A\u0A30 \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A4B\u0A08 \u2014 \u0A2A\u0A39\u0A3F\u0A32\u0A3E\u0A02 \u0A2B\u0A3E\u0A30\u0A2E \u0A2D\u0A30\u0A4B\u0964",
  "popup.printSent": "ID {id} \u0A32\u0A08 \u0A26\u0A3E\u0A16\u0A3C\u0A32 \u0A15\u0A40\u0A24\u0A40 \u0A05\u0A30\u0A1C\u0A3C\u0A40 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A16\u0A4B\u0A32\u0A4D\u0A39\u0A40 \u0A17\u0A08\u0964 PDF \u0A21\u0A3E\u0A0A\u0A28\u0A32\u0A4B\u0A21 \u0A15\u0A30\u0A28 \u0A32\u0A08 \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A26\u0A47 \u0A07\u0A70\u0A21\u0A40\u0A35\u0A3F\u0A1C\u0A3C\u0A41\u0A05\u0A32 \u0A2A\u0A4D\u0A30\u0A3F\u0A70\u0A1F \u0A2E\u0A40\u0A28\u0A42 \u0A26\u0A40 \u0A35\u0A30\u0A24\u0A4B\u0A02 \u0A15\u0A30\u0A4B\u0964",
  "popup.formFilled": "\u0A2B\u0A3E\u0A30\u0A2E \u0A2D\u0A30 \u0A26\u0A3F\u0A71\u0A24\u0A3E \u0A17\u0A3F\u0A06\u0964 \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A09\u0A71\u0A24\u0A47 \u0A38\u0A2E\u0A40\u0A16\u0A3F\u0A06 \u0A15\u0A30\u0A4B \u0A05\u0A24\u0A47 \u0A1C\u0A2E\u0A4D\u0A39\u0A3E\u0A02 \u0A15\u0A30\u0A4B\u0964",
  "popup.fillError": "\u0A2D\u0A30\u0A28 \u0A35\u0A3F\u0A71\u0A1A \u0A17\u0A32\u0A24\u0A40: {message}",
  "popup.connectionFailed": "FRRO \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A2A\u0A70\u0A28\u0A47 \u0A24\u0A71\u0A15 \u0A28\u0A39\u0A40\u0A02 \u0A2A\u0A39\u0A41\u0A70\u0A1A\u0A3F\u0A06 \u0A1C\u0A3E \u0A38\u0A15\u0A3F\u0A06\u0964 \u0A07\u0A38 \u0A1F\u0A48\u0A2C \u0A35\u0A3F\u0A71\u0A1A Form III \u0A2A\u0A70\u0A28\u0A3E \u0A16\u0A4B\u0A32\u0A4D\u0A39\u0A4B \u0A05\u0A24\u0A47 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A15\u0A4B\u0A38\u0A3C\u0A3F\u0A38\u0A3C \u0A15\u0A30\u0A4B\u0964",
  "popup.unknownError": "\u0A05\u0A23\u0A1C\u0A3E\u0A23",
  "popup.apiBaseFallback": "\u0A1A\u0A3F\u0A24\u0A3E\u0A35\u0A28\u0A40: \u0A38\u0A1F\u0A4B\u0A30 \u0A15\u0A40\u0A24\u0A3E API URL \u0A05\u0A35\u0A48\u0A27 \u0A39\u0A48 \u2014 \u0A21\u0A3F\u0A2B\u0A3C\u0A4C\u0A32\u0A1F \u0A35\u0A30\u0A24\u0A3F\u0A06 \u0A1C\u0A3E \u0A30\u0A3F\u0A39\u0A3E \u0A39\u0A48\u0964 \u0A38\u0A48\u0A1F\u0A3F\u0A70\u0A17\u0A3E\u0A02 \u0A35\u0A3F\u0A71\u0A1A \u0A07\u0A38\u0A28\u0A42\u0A70 \u0A05\u0A71\u0A2A\u0A21\u0A47\u0A1F \u0A15\u0A30\u0A4B\u0964",
  "popup.mappingFallback": "\u0A1A\u0A3F\u0A24\u0A3E\u0A35\u0A28\u0A40: \u0A2E\u0A48\u0A2A\u0A3F\u0A70\u0A17 \u0A38\u0A30\u0A35\u0A30 \u0A05\u0A23\u0A09\u0A2A\u0A32\u0A2C\u0A27 \u0A39\u0A48 \u2014 \u0A2C\u0A3F\u0A32\u0A1F-\u0A07\u0A28 \u0A2B\u0A3C\u0A40\u0A32\u0A21 \u0A2E\u0A48\u0A2A \u0A35\u0A30\u0A24\u0A3F\u0A06 \u0A1C\u0A3E \u0A30\u0A3F\u0A39\u0A3E \u0A39\u0A48, \u0A1C\u0A4B \u0A2A\u0A41\u0A30\u0A3E\u0A23\u0A3E \u0A39\u0A4B \u0A38\u0A15\u0A26\u0A3E \u0A39\u0A48\u0964",
  // settings
  "settings.title": "Cformly \u0A38\u0A48\u0A1F\u0A3F\u0A70\u0A17\u0A3E\u0A02",
  "settings.eyebrow": "\u0A38\u0A48\u0A1F\u0A3F\u0A70\u0A17\u0A3E\u0A02",
  "settings.bandSub": "\u0A2B\u0A3E\u0A30\u0A2E \u0A2E\u0A48\u0A2A\u0A3F\u0A70\u0A17 \u0A26\u0A47\u0A23 \u0A35\u0A3E\u0A32\u0A47 \u0A2C\u0A48\u0A15\u0A10\u0A02\u0A21 \u0A28\u0A42\u0A70 \u0A38\u0A70\u0A30\u0A1A\u0A3F\u0A24 \u0A15\u0A30\u0A4B\u0964",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "\u0A2C\u0A48\u0A15\u0A10\u0A02\u0A21 \u0A1C\u0A4B \u0A2B\u0A3E\u0A30\u0A2E \u0A2E\u0A48\u0A2A\u0A3F\u0A70\u0A17 \u0A2E\u0A41\u0A39\u0A71\u0A08\u0A06 \u0A15\u0A30\u0A3E\u0A09\u0A02\u0A26\u0A3E \u0A39\u0A48\u0964 \u0A38\u0A3F\u0A30\u0A2B\u0A3C HTTPS; localhost \u0A38\u0A3F\u0A30\u0A2B\u0A3C \u0A21\u0A3F\u0A35\u0A48\u0A32\u0A2A\u0A2E\u0A48\u0A02\u0A1F \u0A2C\u0A3F\u0A32\u0A21\u0A3E\u0A02 \u0A35\u0A3F\u0A71\u0A1A \u0A15\u0A70\u0A2E \u0A15\u0A30\u0A26\u0A3E \u0A39\u0A48\u0964",
  "settings.save": "\u0A38\u0A70\u0A2D\u0A3E\u0A32\u0A4B",
  "settings.back": "\u0A35\u0A3E\u0A2A\u0A38",
  "settings.backInTab": "\u0A38\u0A48\u0A1F\u0A3F\u0A70\u0A17\u0A3E\u0A02 \u0A1F\u0A48\u0A2C \u0A35\u0A1C\u0A4B\u0A02 \u0A16\u0A41\u0A71\u0A32\u0A4D\u0A39\u0A40\u0A06\u0A02 \u0A39\u0A28 \u2014 \u0A2B\u0A3F\u0A32 \u0A2A\u0A4C\u0A2A\u0A05\u0A71\u0A2A \u0A16\u0A4B\u0A32\u0A4D\u0A39\u0A23 \u0A32\u0A08 Cformly \u0A1F\u0A42\u0A32\u0A2C\u0A3E\u0A30 \u0A06\u0A08\u0A15\u0A28 \u0A26\u0A40 \u0A35\u0A30\u0A24\u0A4B\u0A02 \u0A15\u0A30\u0A4B\u0964",
  "settings.urlEmpty": "URL \u0A16\u0A3E\u0A32\u0A40 \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A4B \u0A38\u0A15\u0A26\u0A3E\u0964",
  "settings.httpsOnly": "\u0A38\u0A41\u0A30\u0A71\u0A16\u0A3F\u0A06 \u0A32\u0A08 \u0A38\u0A3F\u0A30\u0A2B\u0A3C HTTPS URLs \u0A26\u0A40 \u0A07\u0A1C\u0A3E\u0A1C\u0A3C\u0A24 \u0A39\u0A48\u0964 \u0A2A\u0A4D\u0A30\u0A4B\u0A21\u0A15\u0A38\u0A3C\u0A28 \u0A32\u0A08 https:// \u0A35\u0A30\u0A24\u0A4B\u0964",
  "settings.hostNotAllowed": "URL \u0A39\u0A4B\u0A38\u0A1F\u0A28\u0A3E\u0A2E localhost \u0A1C\u0A3E\u0A02 *.cformly.com \u0A39\u0A4B\u0A23\u0A3E \u0A1A\u0A3E\u0A39\u0A40\u0A26\u0A3E \u0A39\u0A48 (\u0A2E\u0A3F\u0A32\u0A3F\u0A06: {host})\u0964",
  "settings.invalidUrl": "\u0A05\u0A35\u0A48\u0A27 URL\u0964 https:// \u0A38\u0A3C\u0A3E\u0A2E\u0A32 \u0A15\u0A30\u0A4B",
  "settings.urlPathNotAllowed": "\u0A38\u0A3F\u0A30\u0A2B\u0A3C \u0A28\u0A70\u0A17\u0A3E origin \u0A35\u0A30\u0A24\u0A4B \u2014 path, query \u0A05\u0A24\u0A47 #fragment \u0A39\u0A1F\u0A3E\u0A13\u0964",
  "settings.loopbackNotGranted": "Localhost API URLs \u0A38\u0A3F\u0A30\u0A2B\u0A3C \u0A21\u0A3F\u0A35\u0A48\u0A32\u0A2A\u0A2E\u0A48\u0A02\u0A1F \u0A2C\u0A3F\u0A32\u0A21\u0A3E\u0A02 \u0A35\u0A3F\u0A71\u0A1A \u0A15\u0A70\u0A2E \u0A15\u0A30\u0A26\u0A47 \u0A39\u0A28\u0964 \u0A07\u0A39 \u0A2C\u0A3F\u0A32\u0A21 \u0A38\u0A3F\u0A30\u0A2B\u0A3C https:// \u0A39\u0A4B\u0A38\u0A1F\u0A3E\u0A02 \u0A24\u0A71\u0A15 \u0A2A\u0A39\u0A41\u0A70\u0A1A \u0A38\u0A15\u0A26\u0A3E \u0A39\u0A48\u0964",
  "settings.saved": "\u0A38\u0A70\u0A2D\u0A3E\u0A32 \u0A32\u0A3F\u0A06 \u0A17\u0A3F\u0A06\u0964",
  "settings.saveError": "\u0A38\u0A70\u0A2D\u0A3E\u0A32\u0A3F\u0A06 \u0A28\u0A39\u0A40\u0A02 \u0A1C\u0A3E \u0A38\u0A15\u0A3F\u0A06\u0964 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A15\u0A4B\u0A38\u0A3C\u0A3F\u0A38\u0A3C \u0A15\u0A30\u0A4B\u0964",
  "settings.langLabel": "\u0A2D\u0A3E\u0A38\u0A3C\u0A3E",
  "settings.langEnglish": "English",
  "settings.langHindi": "\u0939\u093F\u0928\u094D\u0926\u0940",
  "settings.langAuto": "\u0A2C\u0A30\u0A3E\u0A0A\u0A1C\u0A3C\u0A30 \u0A26\u0A40 \u0A2D\u0A3E\u0A38\u0A3C\u0A3E",
  "settings.langHint": "\u0A24\u0A41\u0A39\u0A3E\u0A21\u0A47 \u0A1A\u0A41\u0A23\u0A28 \u0A24\u0A71\u0A15 \u0A24\u0A41\u0A39\u0A3E\u0A21\u0A40 \u0A2C\u0A30\u0A3E\u0A0A\u0A1C\u0A3C\u0A30 \u0A2D\u0A3E\u0A38\u0A3C\u0A3E \u0A35\u0A30\u0A24\u0A40 \u0A1C\u0A3E\u0A35\u0A47\u0A17\u0A40\u0964",
  // round-65: paste intake + in-page filing panel
  "popup.pasteLabel": "\u0A1C\u0A3E\u0A02 \u0A2B\u0A40\u0A32\u0A21\u0A3E\u0A02 \u0A28\u0A42\u0A70 \u0A07\u0A71\u0A25\u0A47 \u0A2A\u0A47\u0A38\u0A1F \u0A15\u0A30\u0A4B",
  "popup.pdfPick": "Cformly PDF \u0A16\u0A4B\u0A32\u0A4D\u0A39\u0A4B",
  "popup.pdfLoaded": "\u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A26\u0A47 \u0A16\u0A47\u0A24\u0A30 Cformly PDF \u0A35\u0A3F\u0A71\u0A1A\u0A4B\u0A02 \u0A32\u0A4B\u0A21 \u0A39\u0A4B \u0A17\u0A0F \u2014 \u0A39\u0A47\u0A20\u0A3E\u0A02 \u0A1C\u0A3E\u0A02\u0A1A\u0A4B, \u0A2B\u0A3F\u0A30 Fill Form \u0A26\u0A2C\u0A3E\u0A13\u0964",
  "popup.pdfRejected": "\u0A07\u0A38 PDF \u0A35\u0A3F\u0A71\u0A1A Cformly \u0A16\u0A47\u0A24\u0A30 \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A28 \u0A1C\u0A3E\u0A02 \u0A2A\u0A5C\u0A4D\u0A39\u0A3F\u0A06 \u0A28\u0A39\u0A40\u0A02 \u0A1C\u0A3E \u0A38\u0A15\u0A3F\u0A06 \u2014 Cformly \u0A10\u0A2A \u0A35\u0A71\u0A32\u0A4B\u0A02 \u0A28\u0A3F\u0A30\u0A2F\u0A3E\u0A24 \u0A15\u0A40\u0A24\u0A40 PDF \u0A39\u0A40 \u0A35\u0A30\u0A24\u0A4B\u0964",
  "popup.pastePlaceholder": "\u0A15\u0A3E\u0A2A\u0A40 \u0A15\u0A40\u0A24\u0A40\u0A06\u0A02 Cformly \u0A2B\u0A40\u0A32\u0A21\u0A3E\u0A02 \u0A28\u0A42\u0A70 \u0A07\u0A71\u0A25\u0A47 \u0A2A\u0A47\u0A38\u0A1F \u0A15\u0A30\u0A4B",
  "popup.pasteHint": "\u0A1C\u0A47 \u0A15\u0A32\u0A3F\u0A71\u0A2A\u0A2C\u0A4B\u0A30\u0A21 \u0A2C\u0A1F\u0A28 \u0A15\u0A70\u0A2E \u0A28\u0A3E \u0A15\u0A30\u0A47, \u0A24\u0A3E\u0A02 \u0A07\u0A38 \u0A15\u0A70\u0A2A\u0A3F\u0A0A\u0A1F\u0A30 \u0A09\u0A71\u0A24\u0A47 \u0A2D\u0A47\u0A1C\u0A40\u0A06\u0A02 \u0A2B\u0A40\u0A32\u0A21\u0A3E\u0A02 \u0A28\u0A42\u0A70 \u0A07\u0A71\u0A25\u0A47 \u0A2A\u0A47\u0A38\u0A1F \u0A15\u0A30\u0A4B (\u0A1C\u0A3E\u0A02 \u0A1F\u0A48\u0A15\u0A38\u0A1F \u0A2B\u0A3E\u0A08\u0A32 \u0A1B\u0A71\u0A21\u0A4B), \u0A2B\u0A3F\u0A30 \u0A2D\u0A30\u0A4B \u0A26\u0A2C\u0A3E\u0A13\u0964",
  "popup.payloadTooLarge": "\u0A2A\u0A47\u0A38\u0A1F \u0A15\u0A40\u0A24\u0A3E \u0A1F\u0A48\u0A15\u0A38\u0A1F \u0A2C\u0A39\u0A41\u0A24 \u0A35\u0A71\u0A21\u0A3E \u0A39\u0A48 \u2014 \u0A38\u0A3F\u0A30\u0A2B\u0A3C Cformly \u0A10\u0A2A \u0A24\u0A4B\u0A02 \u0A15\u0A3E\u0A2A\u0A40 \u0A15\u0A40\u0A24\u0A40\u0A06\u0A02 \u0A2B\u0A40\u0A32\u0A21\u0A3E\u0A02 \u0A2A\u0A47\u0A38\u0A1F \u0A15\u0A30\u0A4B\u0964",
  "panel.title": "Cformly \u2014 \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A09\u0A71\u0A24\u0A47 \u0A2B\u0A3E\u0A08\u0A32\u0A3F\u0A70\u0A17 \u0A2A\u0A42\u0A30\u0A40 \u0A15\u0A30\u0A4B",
  "panel.dismiss": "\u0A2C\u0A70\u0A26 \u0A15\u0A30\u0A4B",
  "panel.filled": "\u0A2D\u0A30\u0A40\u0A06\u0A02 \u0A2B\u0A40\u0A32\u0A21\u0A3E\u0A02: {filledRequired} / {required} \u0A32\u0A3E\u0A1C\u0A3C\u0A2E\u0A40",
  "panel.photoStep": "\u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A26\u0A40 \u0A2B\u0A4B\u0A1F\u0A4B \u0A1C\u0A4B\u0A5C\u0A4B (\u0A2B\u0A3E\u0A08\u0A32 \u0A1A\u0A41\u0A23\u0A4B \u2192 \u0A05\u0A71\u0A2A\u0A32\u0A4B\u0A21 \u0A15\u0A30\u0A4B)",
  "panel.captchaStep": "\u0A38\u0A41\u0A30\u0A71\u0A16\u0A3F\u0A06 \u0A15\u0A4B\u0A21 (CAPTCHA) \u0A1F\u0A3E\u0A08\u0A2A \u0A15\u0A30\u0A4B",
  "panel.saveStep": "\u0A38\u0A47\u0A35 \u0A15\u0A30\u0A4B \u0A05\u0A24\u0A47 \u0A1C\u0A3E\u0A30\u0A40 \u0A30\u0A71\u0A16\u0A4B \u0A26\u0A2C\u0A3E\u0A13",
  "panel.warnSession": "Cformly \u0A1A\u0A47\u0A24\u0A3E\u0A35\u0A28\u0A40: \u0A07\u0A39 FRRO \u0A38\u0A48\u0A38\u0A3C\u0A28 \u0A15\u0A3F\u0A38\u0A47 \u0A39\u0A4B\u0A30 \u0A2A\u0A4D\u0A30\u0A3E\u0A2A\u0A30\u0A1F\u0A40 \u0A26\u0A3E \u0A39\u0A4B \u0A38\u0A15\u0A26\u0A3E \u0A39\u0A48 ({reason})\u0964 \u0A38\u0A47\u0A35 \u0A15\u0A30\u0A28 \u0A24\u0A4B\u0A02 \u0A2A\u0A39\u0A3F\u0A32\u0A3E\u0A02 \u0A1C\u0A3E\u0A02\u0A1A \u0A32\u0A35\u0A4B\u0964",
  "panel.warnUnverified": "Cformly \u0A1A\u0A47\u0A24\u0A3E\u0A35\u0A28\u0A40: \u0A07\u0A39\u0A28\u0A3E\u0A02 \u0A2B\u0A40\u0A32\u0A21\u0A3E\u0A02 \u0A26\u0A47 \u0A2E\u0A41\u0A71\u0A32 \u0A1F\u0A3F\u0A15 \u0A28\u0A39\u0A40\u0A02 \u0A38\u0A15\u0A26\u0A47: {list}\u0964 \u0A38\u0A47\u0A35 \u0A15\u0A30\u0A28 \u0A24\u0A4B\u0A02 \u0A2A\u0A39\u0A3F\u0A32\u0A3E\u0A02 \u0A1C\u0A3E\u0A02\u0A1A \u0A32\u0A35\u0A4B\u0964",
  "panel.saving": "\u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A26\u0A40 \u0A2A\u0A41\u0A38\u0A3C\u0A1F\u0A40 \u0A26\u0A40 \u0A09\u0A21\u0A40\u0A15\u2026",
  "panel.progress": "\u0A16\u0A47\u0A24\u0A30 \u0A2D\u0A30\u0A47 \u0A1C\u0A3E \u0A30\u0A39\u0A47 \u0A39\u0A28\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO \u0A38\u0A3C\u0A48\u0A38\u0A3C\u0A28 \u0A16\u0A24\u0A2E \u0A39\u0A4B \u0A17\u0A3F\u0A06 \u0A39\u0A48 \u2014 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A32\u0A4C\u0A17 \u0A07\u0A28 \u0A15\u0A30\u0A4B, \u0A2B\u0A3E\u0A30\u0A2E \u0A16\u0A4B\u0A32\u0A4D\u0A39 \u0A15\u0A47 Fill \u0A26\u0A2C\u0A3E\u0A13\u0964 \u0A24\u0A41\u0A39\u0A3E\u0A21\u0A47 \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A26\u0A47 \u0A35\u0A47\u0A30\u0A35\u0A47 Cformly \u0A10\u0A2A \u0A35\u0A3F\u0A71\u0A1A \u0A38\u0A41\u0A30\u0A71\u0A16\u0A3F\u0A05\u0A24 \u0A39\u0A28\u0964",
  "panel.portalError": "\u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A28\u0A47 \u0A38\u0A2E\u0A71\u0A38\u0A3F\u0A06 \u0A26\u0A71\u0A38\u0A40:",
  "panel.appIdFound": "\u0A38\u0A2B\u0A32\u0A24\u0A3E\u0A2A\u0A42\u0A30\u0A35\u0A15 \u0A2B\u0A3E\u0A08\u0A32 \u0A39\u0A4B \u0A17\u0A3F\u0A06\u0964 \u0A05\u0A30\u0A1C\u0A3C\u0A40 \u0A06\u0A08\u0A21\u0A40:",
  "panel.scanHint": "Cformly \u0A10\u0A2A \u0A16\u0A4B\u0A32\u0A4D\u0A39\u0A4B \u2192 \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A09\u0A71\u0A24\u0A47 \u0A2D\u0A47\u0A1C\u0A4B \u2192 \u0A15\u0A70\u0A2A\u0A3F\u0A0A\u0A1F\u0A30 \u0A24\u0A4B\u0A02 \u0A38\u0A15\u0A48\u0A28 \u0A15\u0A30\u0A4B \u0A05\u0A24\u0A47 \u0A07\u0A38 \u0A15\u0A4B\u0A21 \u0A35\u0A71\u0A32 \u0A15\u0A48\u0A2E\u0A30\u0A3E \u0A15\u0A30\u0A4B \u2014 \u0A1C\u0A3E\u0A02 \u0A06\u0A08\u0A21\u0A40 \u0A15\u0A3E\u0A2A\u0A40 \u0A15\u0A30\u0A4B\u0964",
  "panel.copy": "\u0A05\u0A30\u0A1C\u0A3C\u0A40 \u0A06\u0A08\u0A21\u0A40 \u0A15\u0A3E\u0A2A\u0A40 \u0A15\u0A30\u0A4B",
  "panel.copied": "\u0A15\u0A3E\u0A2A\u0A40 \u0A39\u0A4B \u0A17\u0A3F\u0A06\u0964",
  "panel.confirmNotDetected": "\u0A2A\u0A41\u0A38\u0A3C\u0A1F\u0A40 \u0A28\u0A39\u0A40\u0A02 \u0A2E\u0A3F\u0A32\u0A40 \u2014 \u0A1C\u0A3E\u0A02\u0A1A\u0A4B \u0A15\u0A3F \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A28\u0A47 \u0A38\u0A70\u0A2D\u0A3E\u0A32\u0A3F\u0A06 \u0A39\u0A48 \u0A1C\u0A3E\u0A02 \u0A28\u0A39\u0A40\u0A02, \u0A2B\u0A3F\u0A30 \u0A05\u0A71\u0A17\u0A47 \u0A35\u0A27\u0A4B\u0964",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "\u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A2B\u0A4B\u0A1F\u0A4B \u0A1C\u0A4B\u0A5C\u0A28 \u0A32\u0A08 \u0A07\u0A71\u0A25\u0A47 \u0A1B\u0A71\u0A21\u0A4B",
  "panel.photoBrowse": "\u0A2C\u0A30\u0A3E\u0A0A\u0A1C\u0A3C\u2026",
  "panel.photoAttachFailed": "\u0A06\u0A2A\u0A23\u0A47 \u0A06\u0A2A \u0A1C\u0A41\u0A5C \u0A28\u0A39\u0A40\u0A02 \u0A38\u0A15\u0A40 \u2014 \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A26\u0A3E \u0A06\u0A2A\u0A23\u0A3E \u0A2B\u0A3E\u0A08\u0A32 \u0A1A\u0A41\u0A23\u0A4B \u0A2C\u0A1F\u0A28 \u0A35\u0A30\u0A24\u0A4B\u0964",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "\u0A07\u0A39 \u0A2B\u0A3E\u0A30\u0A2E Cformly \u0A28\u0A3E\u0A32 \u0A2D\u0A30\u0A4B",
  "chip.hint": "\u0A07\u0A38 \u0A15\u0A70\u0A2A\u0A3F\u0A0A\u0A1F\u0A30 \u0A28\u0A42\u0A70 \u0A2D\u0A47\u0A1C\u0A47 \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A35\u0A47\u0A30\u0A35\u0A47 \u0A07\u0A71\u0A25\u0A47 \u0A2A\u0A47\u0A38\u0A1F \u0A15\u0A30\u0A4B (\u0A1C\u0A3E\u0A02 \u0A1F\u0A48\u0A15\u0A38\u0A1F \u0A2B\u0A3E\u0A08\u0A32 \u0A07\u0A71\u0A25\u0A47 \u0A1B\u0A71\u0A21\u0A4B), \u0A2B\u0A3F\u0A30 \u0A2B\u0A3E\u0A30\u0A2E \u0A2D\u0A30\u0A4B \u0A26\u0A2C\u0A3E\u0A13\u0964",
  "chip.fill": "\u0A2B\u0A3E\u0A30\u0A2E \u0A2D\u0A30\u0A4B",
  "chip.filling": "\u0A2D\u0A30\u0A3F\u0A06 \u0A1C\u0A3E \u0A30\u0A3F\u0A39\u0A3E \u0A39\u0A48\u2026",
  "chip.empty": "\u0A2D\u0A30\u0A28 \u0A32\u0A08 \u0A15\u0A41\u0A1D \u0A28\u0A39\u0A40\u0A02 \u2014 \u0A2A\u0A39\u0A3F\u0A32\u0A3E\u0A02 Cformly \u0A10\u0A2A \u0A24\u0A4B\u0A02 \u0A15\u0A3E\u0A2A\u0A40 \u0A15\u0A40\u0A24\u0A47 \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A35\u0A47\u0A30\u0A35\u0A47 \u0A2A\u0A47\u0A38\u0A1F \u0A15\u0A30\u0A4B\u0964",
  "chip.tooLarge": "\u0A2A\u0A47\u0A38\u0A1F \u0A15\u0A40\u0A24\u0A3E \u0A1F\u0A48\u0A15\u0A38\u0A1F \u0A2C\u0A39\u0A41\u0A24 \u0A35\u0A71\u0A21\u0A3E \u0A39\u0A48 \u2014 \u0A38\u0A3F\u0A30\u0A2B\u0A3C Cformly \u0A10\u0A2A \u0A24\u0A4B\u0A02 \u0A15\u0A3E\u0A2A\u0A40 \u0A15\u0A40\u0A24\u0A47 \u0A35\u0A47\u0A30\u0A35\u0A47 \u0A2A\u0A47\u0A38\u0A1F \u0A15\u0A30\u0A4B\u0964",
  "chip.collapse": "\u0A2C\u0A70\u0A26 \u0A15\u0A30\u0A4B",
  "chip.mappingFallback": "\u0A28\u0A4B\u0A1F: \u0A2E\u0A48\u0A2A\u0A3F\u0A70\u0A17 \u0A38\u0A30\u0A35\u0A30 \u0A28\u0A39\u0A40\u0A02 \u0A2E\u0A3F\u0A32\u0A3F\u0A06 \u2014 \u0A05\u0A70\u0A26\u0A30\u0A42\u0A28\u0A40 \u0A2B\u0A3C\u0A40\u0A32\u0A21 \u0A2E\u0A48\u0A2A \u0A35\u0A30\u0A24\u0A3F\u0A06 \u0A1C\u0A3E \u0A30\u0A3F\u0A39\u0A3E \u0A39\u0A48, \u0A1C\u0A4B \u0A2A\u0A41\u0A30\u0A3E\u0A23\u0A3E \u0A39\u0A4B \u0A38\u0A15\u0A26\u0A3E \u0A39\u0A48\u0964",
  // round-66: popup first-run onboarding
  "onboarding.title": "\u0A2A\u0A39\u0A3F\u0A32\u0A40 \u0A35\u0A3E\u0A30 \u0A07\u0A71\u0A25\u0A47? \u0A24\u0A3F\u0A70\u0A28 \u0A15\u0A26\u0A2E:",
  "onboarding.step1": "\u0A06\u0A2A\u0A23\u0A47 \u0A2B\u0A3C\u0A4B\u0A28 '\u0A24\u0A47: \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A16\u0A4B\u0A32\u0A4D\u0A39\u0A4B \u2192 \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A28\u0A42\u0A70 \u0A2D\u0A47\u0A1C\u0A4B \u2192 \u0A15\u0A70\u0A2A\u0A3F\u0A0A\u0A1F\u0A30 \u0A28\u0A42\u0A70 \u0A2D\u0A47\u0A1C\u0A4B\u0964",
  "onboarding.step2": "\u0A07\u0A38 \u0A15\u0A70\u0A2A\u0A3F\u0A0A\u0A1F\u0A30 '\u0A24\u0A47: \u0A06\u0A2A\u0A23\u0A47 \u0A06\u0A2A \u0A28\u0A42\u0A70 \u0A2D\u0A47\u0A1C\u0A47 \u0A35\u0A47\u0A30\u0A35\u0A47 \u0A39\u0A47\u0A20\u0A32\u0A47 \u0A21\u0A71\u0A2C\u0A47 \u0A35\u0A3F\u0A71\u0A1A \u0A2A\u0A47\u0A38\u0A1F \u0A15\u0A30\u0A4B (\u0A1C\u0A3E\u0A02 \u0A2B\u0A3E\u0A30\u0A2E \u0A2A\u0A70\u0A28\u0A47 '\u0A24\u0A47 \u0A28\u0A40\u0A32\u0A3E Cformly \u0A2C\u0A1F\u0A28 \u0A26\u0A2C\u0A3E\u0A13)\u0964",
  "onboarding.step3": "\u0A2B\u0A3E\u0A30\u0A2E \u0A2D\u0A30\u0A4B \u0A26\u0A2C\u0A3E\u0A13 \u2014 \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A2B\u0A3E\u0A30\u0A2E \u0A06\u0A2A\u0A23\u0A47 \u0A06\u0A2A \u0A2D\u0A30 \u0A1C\u0A3E\u0A35\u0A47\u0A17\u0A3E\u0964 \u0A2B\u0A4B\u0A1F\u0A4B, \u0A38\u0A41\u0A30\u0A71\u0A16\u0A3F\u0A06 \u0A15\u0A4B\u0A21 \u0A05\u0A24\u0A47 \u0A38\u0A47\u0A35 \u0A24\u0A41\u0A38\u0A40\u0A02 \u0A15\u0A30\u0A4B\u0964",
  "onboarding.done": "\u0A38\u0A2E\u0A1D \u0A17\u0A0F",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{total} \u0A35\u0A3F\u0A71\u0A1A\u0A4B\u0A02 {filled} \u0A2B\u0A40\u0A32\u0A21\u0A3E\u0A02 {time} \u0A35\u0A1C\u0A47 \u0A2D\u0A30\u0A40\u0A06\u0A02 \u0A17\u0A08\u0A06\u0A02 \u0A38\u0A40\u0964 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A2D\u0A30\u0A28 \u0A32\u0A08 \u0A2E\u0A41\u0A5C-\u0A38\u0A3C\u0A41\u0A30\u0A42 \u0A15\u0A30\u0A4B\u0964",
  "resume.button": "\u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A2D\u0A30\u0A4B",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "\u0A07\u0A39 \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A2A\u0A70\u0A28\u0A3E Cformly \u0A28\u0A42\u0A70 \u0A1C\u0A3E\u0A23 Form III \u0A35\u0A30\u0A17\u0A3E \u0A28\u0A39\u0A40\u0A02 \u0A32\u0A71\u0A17 \u0A30\u0A3F\u0A39\u0A3E \u2014 \u0A38\u0A3C\u0A3E\u0A07\u0A26 \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A2C\u0A26\u0A32 \u0A17\u0A3F\u0A06 \u0A39\u0A48\u0964 \u0A07\u0A38 \u0A35\u0A3E\u0A30 Cformly \u0A10\u0A2A \u0A24\u0A4B\u0A02 \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A2B\u0A40\u0A32\u0A21\u0A3E\u0A02 \u0A15\u0A3E\u0A2A\u0A40 \u0A15\u0A30\u0A15\u0A47 \u0A16\u0A41\u0A26 \u0A2D\u0A30\u0A4B; \u0A05\u0A38\u0A40\u0A02 \u0A05\u0A71\u0A2A\u0A21\u0A47\u0A1F \u0A26\u0A40 \u0A1C\u0A3E\u0A02\u0A1A \u0A15\u0A30 \u0A30\u0A39\u0A47 \u0A39\u0A3E\u0A02\u0964",
  "canary.detail": "\u0A07\u0A38 \u0A2A\u0A70\u0A28\u0A47 '\u0A24\u0A47 Cformly \u0A28\u0A42\u0A70 \u0A1C\u0A3E\u0A23 {total} \u0A2B\u0A40\u0A32\u0A21\u0A3E\u0A02 \u0A35\u0A3F\u0A71\u0A1A\u0A4B\u0A02 \u0A38\u0A3F\u0A30\u0A2B\u0A3C {found} \u0A2E\u0A3F\u0A32\u0A40\u0A06\u0A02\u0964",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "\u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A15\u0A24\u0A3E\u0A30",
  "queue.add": "\u0A15\u0A24\u0A3E\u0A30 \u0A35\u0A3F\u0A71\u0A1A \u0A1C\u0A4B\u0A5C\u0A4B",
  "queue.fill": "\u0A2D\u0A30\u0A4B",
  "queue.remove": "\u0A39\u0A1F\u0A3E\u0A13",
  "queue.unnamed": "\u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28",
  "queue.added": "{name} \u0A28\u0A42\u0A70 \u0A15\u0A24\u0A3E\u0A30 \u0A35\u0A3F\u0A71\u0A1A \u0A1C\u0A4B\u0A5C\u0A3F\u0A06 \u0A17\u0A3F\u0A06\u0964",
  "queue.duplicate": "\u0A07\u0A39 \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A2A\u0A39\u0A3F\u0A32\u0A3E\u0A02 \u0A39\u0A40 \u0A15\u0A24\u0A3E\u0A30 \u0A35\u0A3F\u0A71\u0A1A \u0A39\u0A48\u0964",
  "queue.full": "\u0A15\u0A24\u0A3E\u0A30 \u0A2D\u0A30\u0A40 \u0A39\u0A4B\u0A08 \u0A39\u0A48 ({max} \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28)\u0964 \u0A2A\u0A39\u0A3F\u0A32\u0A3E\u0A02 \u0A15\u0A3F\u0A38\u0A47 \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A26\u0A3E \u0A2B\u0A3C\u0A3E\u0A30\u0A2E \u0A2D\u0A30\u0A4B \u0A1C\u0A3E\u0A02 \u0A09\u0A38\u0A28\u0A42\u0A70 \u0A39\u0A1F\u0A3E\u0A13\u0964",
  "queue.hint": "\u0A2D\u0A30\u0A28 \u0A26\u0A40 \u0A09\u0A21\u0A40\u0A15 \u0A35\u0A3F\u0A71\u0A1A \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28\u0964 \u0A2A\u0A42\u0A30\u0A40 \u0A2D\u0A30\u0A3E\u0A08 \u0A24\u0A4B\u0A02 \u0A2C\u0A3E\u0A05\u0A26 \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A15\u0A24\u0A3E\u0A30 \u0A24\u0A4B\u0A02 \u0A39\u0A1F \u0A1C\u0A3E\u0A02\u0A26\u0A3E \u0A39\u0A48; \u0A2C\u0A30\u0A3E\u0A0A\u0A1C\u0A3C\u0A30 \u0A2C\u0A70\u0A26 \u0A39\u0A4B\u0A23 '\u0A24\u0A47 \u0A15\u0A24\u0A3E\u0A30 \u0A38\u0A3E\u0A2B\u0A3C \u0A39\u0A4B \u0A1C\u0A3E\u0A02\u0A26\u0A40 \u0A39\u0A48\u0964",
  "queue.unavailable": "\u0A07\u0A38 \u0A2C\u0A30\u0A3E\u0A0A\u0A1C\u0A3C\u0A30 \u0A35\u0A3F\u0A71\u0A1A \u0A2E\u0A39\u0A3F\u0A2E\u0A3E\u0A28 \u0A15\u0A24\u0A3E\u0A30 \u0A09\u0A2A\u0A32\u0A2C\u0A27 \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A48\u0964",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "\u0A07\u0A39 FRRO \u0A1F\u0A48\u0A2C Cformly \u0A07\u0A70\u0A38\u0A1F\u0A3E\u0A32 \u0A1C\u0A3E\u0A02 \u0A05\u0A71\u0A2A\u0A21\u0A47\u0A1F \u0A39\u0A4B\u0A23 \u0A24\u0A4B\u0A02 \u0A2A\u0A39\u0A3F\u0A32\u0A3E\u0A02 \u0A16\u0A4B\u0A32\u0A4D\u0A39\u0A3F\u0A06 \u0A17\u0A3F\u0A06 \u0A38\u0A40\u0964 \u0A07\u0A38 \u0A1F\u0A48\u0A2C \u0A28\u0A42\u0A70 \u0A07\u0A71\u0A15 \u0A35\u0A3E\u0A30\u0A40 \u0A2E\u0A41\u0A5C-\u0A32\u0A4B\u0A21 \u0A15\u0A30\u0A4B (F5), \u0A2B\u0A3F\u0A30 Fill \u0A26\u0A2C\u0A3E\u0A13\u0964",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "\u0A2B\u0A3C\u0A3E\u0A30\u0A2E \u0A2E\u0A48\u0A2A\u0A3F\u0A70\u0A17",
  "settings.mapVersion": "\u0A38\u0A70\u0A38\u0A15\u0A30\u0A23",
  "settings.mapLastVerified": "\u0A06\u0A16\u0A30\u0A40 \u0A24\u0A38\u0A26\u0A40\u0A15",
  "settings.mapFetchedAt": "\u0A2A\u0A4D\u0A30\u0A3E\u0A2A\u0A24 \u0A15\u0A40\u0A24\u0A3E",
  "settings.mapSignature": "Ed25519 \u0A26\u0A38\u0A24\u0A16\u0A3C\u0A24",
  "settings.mapRefresh": "\u0A39\u0A41\u0A23\u0A47 \u0A30\u0A40\u0A2B\u0A30\u0A48\u0A38\u0A3C \u0A15\u0A30\u0A4B",
  "settings.mapRefreshed": "\u0A2E\u0A48\u0A2A\u0A3F\u0A70\u0A17 \u0A30\u0A40\u0A2B\u0A30\u0A48\u0A38\u0A3C \u0A39\u0A4B \u0A17\u0A08\u0964",
  "settings.mapRefreshFailed": "\u0A2E\u0A48\u0A2A\u0A3F\u0A70\u0A17 \u0A30\u0A40\u0A2B\u0A30\u0A48\u0A38\u0A3C \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A4B \u0A38\u0A15\u0A40 - \u0A09\u0A2A\u0A32\u0A2C\u0A27 \u0A38\u0A2D \u0A24\u0A4B\u0A02 \u0A35\u0A27\u0A40\u0A06 \u0A15\u0A3E\u0A2A\u0A40 \u0A35\u0A30\u0A24\u0A40 \u0A1C\u0A3E \u0A30\u0A39\u0A40 \u0A39\u0A48\u0964",
  "settings.mapStatusRemote": "\u0A24\u0A38\u0A26\u0A40\u0A15 \u0A38\u0A3C\u0A41\u0A26\u0A3E - \u0A2E\u0A48\u0A2A\u0A3F\u0A70\u0A17 \u0A38\u0A30\u0A35\u0A30 \u0A24\u0A4B\u0A02 \u0A32\u0A08 \u0A17\u0A08 \u0A24\u0A3E\u0A1C\u0A3C\u0A3E \u0A15\u0A3E\u0A2A\u0A40\u0964",
  "settings.mapStatusCached": "\u0A24\u0A38\u0A26\u0A40\u0A15 \u0A38\u0A3C\u0A41\u0A26\u0A3E - \u0A39\u0A3E\u0A32\u0A40\u0A06 \u0A15\u0A48\u0A38\u0A3C \u0A15\u0A3E\u0A2A\u0A40\u0964",
  "settings.mapStatusBundled": "\u0A38\u0A3C\u0A3E\u0A2E\u0A32 \u0A2C\u0A47\u0A38\u0A32\u0A3E\u0A08\u0A28 \u0A15\u0A3E\u0A2A\u0A40 (\u0A38\u0A30\u0A35\u0A30 \u0A09\u0A2A\u0A32\u0A2C\u0A27 \u0A28\u0A39\u0A40\u0A02)\u0964 \u0A26\u0A38\u0A24\u0A16\u0A3C\u0A24 \u0A38\u0A39\u0A40 \u0A39\u0A48\u0964",
  "settings.mapStatusTampered": "\u0A26\u0A38\u0A24\u0A16\u0A3C\u0A24 \u0A1C\u0A3E\u0A02\u0A1A \u0A2B\u0A47\u0A32 - \u0A07\u0A39 \u0A15\u0A3E\u0A2A\u0A40 \u0A30\u0A71\u0A26 \u0A15\u0A40\u0A24\u0A40 \u0A17\u0A08 \u0A39\u0A48 \u0A05\u0A24\u0A47 \u0A35\u0A30\u0A24\u0A4B\u0A02 \u0A35\u0A3F\u0A71\u0A1A \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A48\u0964",
  "chip.mappingUnavailable": "\u0A2B\u0A3E\u0A30\u0A2E \u0A2E\u0A48\u0A2A\u0A3F\u0A70\u0A17 \u0A32\u0A4B\u0A21 \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A4B \u0A38\u0A15\u0A40 \u2014 \u0A10\u0A15\u0A38\u0A1F\u0A48\u0A02\u0A38\u0A3C\u0A28 \u0A26\u0A47 \u0A2C\u0A48\u0A15\u0A17\u0A4D\u0A30\u0A3E\u0A0A\u0A02\u0A21 \u0A35\u0A30\u0A15\u0A30 \u0A28\u0A47 \u0A1C\u0A35\u0A3E\u0A2C \u0A28\u0A39\u0A40\u0A02 \u0A26\u0A3F\u0A71\u0A24\u0A3E\u0964 \u0A2A\u0A4B\u0A30\u0A1F\u0A32 \u0A1F\u0A48\u0A2C \u0A28\u0A42\u0A70 \u0A2E\u0A41\u0A5C-\u0A32\u0A4B\u0A21 \u0A15\u0A30\u0A15\u0A47 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A15\u0A4B\u0A38\u0A3C\u0A3F\u0A38\u0A3C \u0A15\u0A30\u0A4B\u0964",
  "popup.timeoutMapping": "\u0A2B\u0A3E\u0A30\u0A2E \u0A2E\u0A48\u0A2A\u0A3F\u0A70\u0A17 \u0A32\u0A4B\u0A21 \u0A39\u0A4B\u0A23 \u0A26\u0A3E \u0A38\u0A2E\u0A3E\u0A02 \u0A38\u0A2E\u0A3E\u0A2A\u0A24 ({seconds} \u0A38\u0A15\u0A3F\u0A70\u0A1F)\u0964 \u0A15\u0A41\u0A28\u0A48\u0A15\u0A38\u0A3C\u0A28 \u0A1C\u0A3E\u0A02\u0A1A \u0A15\u0A47 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A15\u0A4B\u0A38\u0A3C\u0A3F\u0A38\u0A3C \u0A15\u0A30\u0A4B\u0964",
  "popup.timeoutNoProgress": "\u0A2D\u0A30\u0A3E\u0A08 {seconds} \u0A38\u0A15\u0A3F\u0A70\u0A1F\u0A3E\u0A02 \u0A35\u0A3F\u0A71\u0A1A \u0A38\u0A3C\u0A41\u0A30\u0A42 \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A4B\u0A08 \u2014 Form III \u0A2A\u0A70\u0A28\u0A3E \u0A1C\u0A35\u0A3E\u0A2C \u0A28\u0A39\u0A40\u0A02 \u0A26\u0A47 \u0A30\u0A3F\u0A39\u0A3E\u0964 \u0A1F\u0A48\u0A2C \u0A28\u0A42\u0A70 \u0A2E\u0A41\u0A5C-\u0A32\u0A4B\u0A21 \u0A15\u0A30\u0A15\u0A47 \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A15\u0A4B\u0A38\u0A3C\u0A3F\u0A38\u0A3C \u0A15\u0A30\u0A4B\u0964",
  "popup.timeoutStalled": "\u0A2D\u0A30\u0A3E\u0A08 {seconds} \u0A38\u0A15\u0A3F\u0A70\u0A1F\u0A3E\u0A02 \u0A24\u0A4B\u0A02 \u0A30\u0A41\u0A15\u0A40 \u0A39\u0A4B\u0A08 \u0A39\u0A48 \u2014 Form III \u0A2A\u0A70\u0A28\u0A3E \u0A1C\u0A35\u0A3E\u0A2C \u0A26\u0A47\u0A23\u0A3E \u0A2C\u0A70\u0A26 \u0A15\u0A30 \u0A1A\u0A41\u0A71\u0A15\u0A3E \u0A39\u0A48\u0964",
  "popup.timeoutCap": "\u0A2D\u0A30\u0A3E\u0A08 \u0A15\u0A41\u0A71\u0A32 \u0A38\u0A2E\u0A3E\u0A02 \u0A38\u0A40\u0A2E\u0A3E ({seconds} \u0A38\u0A15\u0A3F\u0A70\u0A1F) \u0A2A\u0A3E\u0A30 \u0A15\u0A30 \u0A17\u0A08 \u0A05\u0A24\u0A47 \u0A30\u0A4B\u0A15 \u0A26\u0A3F\u0A71\u0A24\u0A40 \u0A17\u0A08 \u0A39\u0A48\u0964",
  "popup.preview": "\u0A2C\u0A26\u0A32\u0A3E\u0A05 \u0A35\u0A47\u0A16\u0A4B",
  "popup.previewApply": "\u0A32\u0A3E\u0A17\u0A42 \u0A15\u0A30\u0A4B \u2014 \u0A2B\u0A3E\u0A30\u0A2E \u0A2D\u0A30\u0A4B",
  "popup.undo": "\u0A2A\u0A3F\u0A1B\u0A32\u0A40 \u0A2B\u0A3F\u0A71\u0A32 \u0A05\u0A28\u0A21\u0A42 \u0A15\u0A30\u0A4B",
  "popup.undoDone": "{total} \u0A35\u0A3F\u0A71\u0A1A\u0A4B\u0A02 {restored} \u0A16\u0A47\u0A24\u0A30 \u0A09\u0A39\u0A28\u0A3E\u0A02 \u0A2A\u0A41\u0A30\u0A3E\u0A23\u0A47 \u0A2E\u0A41\u0A71\u0A32\u0A3E\u0A02 '\u0A24\u0A47 \u0A2E\u0A41\u0A5C \u0A38\u0A25\u0A3E\u0A2A\u0A3F\u0A24 \u0A15\u0A40\u0A24\u0A47 \u0A17\u0A0F \u0A39\u0A28\u0964",
  "popup.undoPartial": "{total} \u0A35\u0A3F\u0A71\u0A1A\u0A4B\u0A02 {restored} \u0A2E\u0A41\u0A5C \u0A38\u0A25\u0A3E\u0A2A\u0A3F\u0A24; {failed} \u0A2E\u0A41\u0A5C \u0A38\u0A25\u0A3E\u0A2A\u0A3F\u0A24 \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A4B \u0A38\u0A15\u0A47 (\u0A38\u0A2B\u0A3C\u0A3E \u0A26\u0A41\u0A2C\u0A3E\u0A30\u0A3E \u0A2C\u0A23\u0A3F\u0A06 \u0A39\u0A4B \u0A38\u0A15\u0A26\u0A3E \u0A39\u0A48)\u0964",
  "popup.undoStale": "\u0A2B\u0A3F\u0A71\u0A32 \u0A24\u0A4B\u0A02 \u0A2C\u0A3E\u0A05\u0A26 \u0A38\u0A2B\u0A3C\u0A3E \u0A2C\u0A26\u0A32 \u0A17\u0A3F\u0A06 \u2014 \u0A2E\u0A41\u0A5C \u0A38\u0A25\u0A3E\u0A2A\u0A28\u0A3E \u0A05\u0A27\u0A42\u0A30\u0A40 \u0A39\u0A4B \u0A38\u0A15\u0A26\u0A40 \u0A39\u0A48\u0964",
  "popup.undoNone": "\u0A05\u0A28\u0A21\u0A42 \u0A15\u0A30\u0A28 \u0A32\u0A08 \u0A15\u0A41\u0A1D \u0A28\u0A39\u0A40\u0A02 \u2014 \u0A07\u0A38 \u0A38\u0A48\u0A38\u0A3C\u0A28 \u0A35\u0A3F\u0A71\u0A1A \u0A07\u0A38 \u0A1F\u0A48\u0A2C '\u0A24\u0A47 \u0A15\u0A4B\u0A08 \u0A2B\u0A3F\u0A71\u0A32 \u0A28\u0A39\u0A40\u0A02 \u0A39\u0A4B\u0A08\u0964",
  "popup.previewUnresolved": "\u0A07\u0A38 \u0A2A\u0A70\u0A28\u0A47 \u0A09\u0A71\u0A24\u0A47 \u0A28\u0A39\u0A40\u0A02 \u0A2E\u0A3F\u0A32\u0A3F\u0A06",
  "popup.previewManual": "\u0A26\u0A38\u0A24\u0A40 \u0A2A\u0A5C\u0A3E\u0A05",
  "popup.previewNoValue": "(\u0A28\u0A39\u0A40\u0A02 \u0A26\u0A3F\u0A71\u0A24\u0A3E \u0A17\u0A3F\u0A06)"
};

// src/i18n/mr.ts
var mr = {
  // popup
  "popup.title": "Cformly \u0911\u091F\u094B-\u092B\u093F\u0932",
  "popup.eyebrow": "\u0911\u091F\u094B-\u092B\u093F\u0932",
  "popup.bandSub": "FRRO Form III \xB7 \u091A\u0947\u0915-\u0907\u0928\u0928\u0902\u0924\u0930 \u0968\u096A \u0924\u093E\u0938\u093E\u0902\u091A\u094D\u092F\u093E \u0906\u0924",
  "popup.fillFromClipboard": "\u0915\u094D\u0932\u093F\u092A\u092C\u094B\u0930\u094D\u0921\u0935\u0930\u0942\u0928 \u092B\u0949\u0930\u094D\u092E \u092D\u0930\u093E",
  "popup.fillHint": "\u092A\u094D\u0930\u0925\u092E Cformly \u0972\u092A\u092E\u0927\u0942\u0928 \u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u091A\u0940 \u092B\u0940\u0932\u094D\u0921 \u0915\u0949\u092A\u0940 \u0915\u0930\u093E, \u0928\u0902\u0924\u0930 \u0939\u093E \u092A\u094B\u0930\u094D\u091F\u0932 \u092B\u0949\u0930\u094D\u092E \u092D\u0930\u093E.",
  "popup.clipboardReadFailed": "\u0915\u094D\u0932\u093F\u092A\u092C\u094B\u0930\u094D\u0921 \u0935\u093E\u091A\u0924\u093E \u0906\u0932\u0947 \u0928\u093E\u0939\u0940. \u092C\u094D\u0930\u093E\u0909\u091D\u0930\u091A\u094D\u092F\u093E \u0915\u094D\u0932\u093F\u092A\u092C\u094B\u0930\u094D\u0921 \u092A\u0930\u0935\u093E\u0928\u0917\u094D\u092F\u093E \u0924\u092A\u093E\u0938\u093E.",
  "popup.clipboardEmpty": "\u0915\u094D\u0932\u093F\u092A\u092C\u094B\u0930\u094D\u0921\u0935\u0930 Cformly \u092B\u0940\u0932\u094D\u0921 \u0928\u093E\u0939\u0940\u0924. \u092A\u094D\u0930\u0925\u092E Cformly \u0972\u092A\u092E\u0927\u0942\u0928 \u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u091A\u0940 \u092B\u0940\u0932\u094D\u0921 \u0915\u0949\u092A\u0940 \u0915\u0930\u093E.",
  "popup.settings": "\u0938\u0947\u091F\u093F\u0902\u0917\u094D\u091C",
  "popup.loadingMapping": "\u092B\u0949\u0930\u094D\u092E \u092E\u0945\u092A\u093F\u0902\u0917 \u0932\u094B\u0921 \u0939\u094B\u0924 \u0906\u0939\u0947...",
  "popup.filling": "\u092B\u0949\u0930\u094D\u092E \u092D\u0930\u0932\u093E \u091C\u093E\u0924 \u0906\u0939\u0947...",
  "popup.fillingProgress": "\u092D\u0930\u0932\u0947 \u091C\u093E\u0924 \u0906\u0939\u0947\u2026 \u092B\u0940\u0932\u094D\u0921 {completed}/{total}",
  "popup.noTab": "\u0915\u094B\u0923\u0924\u0940\u0939\u0940 \u0938\u0915\u094D\u0930\u093F\u092F \u091F\u0945\u092C \u0938\u093E\u092A\u0921\u0932\u0940 \u0928\u093E\u0939\u0940.",
  "popup.filled": "\u0906\u0935\u0936\u094D\u092F\u0915 \u092B\u0940\u0932\u094D\u0921 \u092D\u0930\u0932\u0947\u0932\u0947: {required} \u092A\u0948\u0915\u0940 {filledRequired} ({filled} \u090F\u0915\u0942\u0923 \u092D\u0930\u0932\u0947\u0932\u0947)",
  "popup.portalMismatch": "\u092A\u094B\u0930\u094D\u091F\u0932 \u092C\u0926\u0932 \u0906\u0922\u0933\u0932\u093E (DOM \u092C\u0926\u0932\u0932\u0947 \u0906\u0939\u0947). Cformly \u0972\u092A\u092E\u0927\u094D\u092F\u0947 \u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u091A\u0940 \u092B\u0940\u0932\u094D\u0921 \u092A\u0941\u0928\u094D\u0939\u093E \u0915\u0949\u092A\u0940 \u0915\u0930\u093E \u0906\u0923\u093F \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
  "popup.missingElements": "\u0917\u0939\u093E\u0933 \u0918\u091F\u0915: {list}",
  "popup.missingValues": "\u0917\u0939\u093E\u0933 \u092E\u0942\u0932\u094D\u092F\u0947: {list}",
  "popup.manualFields": "\u092E\u0945\u0928\u094D\u092F\u0941\u0905\u0932 \u092A\u093E\u092F\u0931\u094D\u092F\u093E \u0906\u0935\u0936\u094D\u092F\u0915: {list}",
  "popup.unsupportedFields": "\u0911\u091F\u094B-\u092D\u0930\u0924\u093E \u092F\u0947\u0923\u093E\u0930 \u0928\u093E\u0939\u0940 \u0905\u0936\u0940 \u092B\u0940\u0932\u094D\u0921: {list}",
  "popup.tooLongFields": "\u092F\u093E \u092B\u0940\u0932\u094D\u0921\u0938\u093E\u0920\u0940 \u092E\u0942\u0932\u094D\u092F\u0947 \u0916\u0942\u092A \u0932\u093E\u0902\u092C \u0906\u0939\u0947\u0924 \u2014 \u0915\u093E\u0939\u0940\u0939\u0940 \u0932\u093F\u0939\u093F\u0932\u0947 \u0917\u0947\u0932\u0947 \u0928\u093E\u0939\u0940, \u0932\u0939\u093E\u0928 \u092E\u0942\u0932\u094D\u092F \u091F\u093E\u0907\u092A \u0915\u0930\u093E: {list}",
  "popup.unverifiedFields": "\u092F\u093E \u092B\u0940\u0932\u094D\u0921 \u0924\u092A\u093E\u0938\u093E \u2014 \u092E\u0942\u0932\u094D\u092F \u092C\u0938\u0932\u0947 \u0928\u0938\u0947\u0932: {list}",
  "popup.applicationId": "\u0905\u0930\u094D\u091C ID: {id}",
  "popup.accommodationMismatch": "\u0938\u0942\u091A\u0928\u093E: FRRO \u0938\u0947\u0936\u0928 \u0935\u0947\u0917\u0933\u094D\u092F\u093E \u092A\u094D\u0930\u0949\u092A\u0930\u094D\u091F\u0940\u0938\u093E\u0920\u0940 \u0905\u0938\u0942 \u0936\u0915\u0924\u094B. \u0938\u092C\u092E\u093F\u091F \u0915\u0930\u0923\u094D\u092F\u093E\u092A\u0942\u0930\u094D\u0935\u0940 \u092A\u0921\u0924\u093E\u0933\u093E.",
  "popup.attention": "\u0915\u093E\u0939\u0940 \u092B\u0940\u0932\u094D\u0921\u0935\u0930 \u0932\u0915\u094D\u0937 \u0926\u0947\u0923\u0947 \u0906\u0935\u0936\u094D\u092F\u0915 \u0906\u0939\u0947. Cformly \u0972\u092A\u092E\u0927\u094D\u092F\u0947 \u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u091A\u0940 \u092B\u0940\u0932\u094D\u0921 \u092A\u0941\u0928\u094D\u0939\u093E \u0915\u0949\u092A\u0940 \u0915\u0930\u093E \u0906\u0923\u093F \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
  "popup.openPrint": "\u0907\u0928\u0921\u093F\u0935\u094D\u0939\u093F\u091C\u094D\u092F\u0941\u0905\u0932 \u092A\u094D\u0930\u093F\u0902\u091F \u0909\u0918\u0921\u093E",
  "popup.printNoId": "\u0905\u091C\u0942\u0928 \u0905\u0930\u094D\u091C ID \u0915\u0945\u092A\u094D\u091A\u0930 \u091D\u093E\u0932\u0947\u0932\u093E \u0928\u093E\u0939\u0940 \u2014 \u092A\u094D\u0930\u0925\u092E \u092B\u0949\u0930\u094D\u092E \u092D\u0930\u093E.",
  "popup.printSent": "ID {id} \u0938\u093E\u0920\u0940 \u0926\u093E\u0916\u0932 \u0905\u0930\u094D\u091C \u092A\u0941\u0928\u094D\u0939\u093E \u0909\u0918\u0921\u0932\u093E. PDF \u0921\u093E\u0909\u0928\u0932\u094B\u0921 \u0915\u0930\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u092A\u094B\u0930\u094D\u091F\u0932\u091A\u0947 \u0907\u0928\u0921\u093F\u0935\u094D\u0939\u093F\u091C\u094D\u092F\u0941\u0905\u0932 \u092A\u094D\u0930\u093F\u0902\u091F \u092E\u0947\u0928\u0942 \u0935\u093E\u092A\u0930\u093E.",
  "popup.formFilled": "\u092B\u0949\u0930\u094D\u092E \u092D\u0930\u0932\u093E. \u092A\u094B\u0930\u094D\u091F\u0932\u0935\u0930 \u0924\u092A\u093E\u0938\u093E \u0906\u0923\u093F \u0938\u092C\u092E\u093F\u091F \u0915\u0930\u093E.",
  "popup.fillError": "\u092D\u0930\u0923\u094D\u092F\u093E\u0924 \u0924\u094D\u0930\u0941\u091F\u0940: {message}",
  "popup.connectionFailed": "FRRO \u092A\u094B\u0930\u094D\u091F\u0932 \u092A\u0943\u0937\u094D\u0920\u093E\u092A\u0930\u094D\u092F\u0902\u0924 \u092A\u094B\u0939\u094B\u091A\u0924\u093E \u0906\u0932\u0947 \u0928\u093E\u0939\u0940. \u092F\u093E \u091F\u0945\u092C\u092E\u0927\u094D\u092F\u0947 Form III \u092A\u0943\u0937\u094D\u0920 \u0909\u0918\u0921\u093E \u0906\u0923\u093F \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
  "popup.unknownError": "\u0905\u091C\u094D\u091E\u093E\u0924",
  "popup.apiBaseFallback": "\u0938\u0942\u091A\u0928\u093E: \u0938\u093E\u0920\u0935\u0932\u0947\u0932\u093E API URL \u0905\u0935\u0948\u0927 \u0906\u0939\u0947 \u2014 \u0921\u0940\u092B\u0949\u0932\u094D\u091F \u0935\u093E\u092A\u0930\u0924 \u0906\u0939\u094B\u0924. \u0938\u0947\u091F\u093F\u0902\u0917\u094D\u091C\u092E\u0927\u094D\u092F\u0947 \u0905\u092A\u0921\u0947\u091F \u0915\u0930\u093E.",
  "popup.mappingFallback": "\u0938\u0942\u091A\u0928\u093E: \u092E\u0945\u092A\u093F\u0902\u0917 \u0938\u0930\u094D\u0935\u094D\u0939\u0930 \u0905\u0928\u0941\u092A\u0932\u092C\u094D\u0927 \u0906\u0939\u0947 \u2014 \u092C\u093F\u0932\u094D\u091F-\u0907\u0928 \u092B\u0940\u0932\u094D\u0921 \u092E\u0945\u092A \u0935\u093E\u092A\u0930\u0924 \u0906\u0939\u094B\u0924, \u091C\u094B \u091C\u0941\u0928\u093E \u0905\u0938\u0942 \u0936\u0915\u0924\u094B.",
  // settings
  "settings.title": "Cformly \u0938\u0947\u091F\u093F\u0902\u0917\u094D\u091C",
  "settings.eyebrow": "\u0938\u0947\u091F\u093F\u0902\u0917\u094D\u091C",
  "settings.bandSub": "\u092B\u0949\u0930\u094D\u092E \u092E\u0945\u092A\u093F\u0902\u0917 \u092A\u0941\u0930\u0935\u0923\u093E\u0930\u0947 \u092C\u0945\u0915\u090F\u0902\u0921 \u0938\u0902\u0930\u091A\u093F\u0924 \u0915\u0930\u093E.",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "\u092B\u0949\u0930\u094D\u092E \u092E\u0945\u092A\u093F\u0902\u0917 \u092A\u0941\u0930\u0935\u0923\u093E\u0930\u0947 \u092C\u0945\u0915\u090F\u0902\u0921. \u092B\u0915\u094D\u0924 HTTPS; localhost \u092B\u0915\u094D\u0924 \u0921\u0947\u0935\u094D\u0939\u0932\u092A\u092E\u0947\u0902\u091F \u092C\u093F\u0932\u094D\u0921\u092E\u0927\u094D\u092F\u0947 \u091A\u093E\u0932\u0924\u0947.",
  "settings.save": "\u091C\u0924\u0928 \u0915\u0930\u093E",
  "settings.back": "\u092E\u093E\u0917\u0947",
  "settings.backInTab": "\u0938\u0947\u091F\u093F\u0902\u0917\u094D\u091C \u091F\u0945\u092C \u092E\u094D\u0939\u0923\u0942\u0928 \u0909\u0918\u0921\u0932\u094D\u092F\u093E \u0906\u0939\u0947\u0924 \u2014 \u092B\u093F\u0932 \u092A\u0949\u092A\u0905\u092A \u0909\u0918\u0921\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 Cformly \u091F\u0942\u0932\u092C\u093E\u0930 \u0906\u092F\u0915\u0949\u0928 \u0935\u093E\u092A\u0930\u093E.",
  "settings.urlEmpty": "URL \u0930\u093F\u0915\u093E\u092E\u093E \u0905\u0938\u0942 \u0936\u0915\u0924 \u0928\u093E\u0939\u0940.",
  "settings.httpsOnly": "\u0938\u0941\u0930\u0915\u094D\u0937\u0947\u0938\u093E\u0920\u0940 \u092B\u0915\u094D\u0924 HTTPS URLs \u0905\u0928\u0941\u092E\u0924 \u0906\u0939\u0947\u0924. \u092A\u094D\u0930\u094B\u0921\u0915\u094D\u0936\u0928\u0938\u093E\u0920\u0940 https:// \u0935\u093E\u092A\u0930\u093E.",
  "settings.hostNotAllowed": "URL \u0939\u094B\u0938\u094D\u091F\u0928\u093E\u0935 localhost \u0915\u093F\u0902\u0935\u093E *.cformly.com \u0905\u0938\u093E\u0935\u0947 (\u092E\u093F\u0933\u093E\u0932\u0947: {host}).",
  "settings.invalidUrl": "\u0905\u0935\u0948\u0927 URL. https:// \u0938\u092E\u093E\u0935\u093F\u0937\u094D\u091F \u0915\u0930\u093E",
  "settings.urlPathNotAllowed": "\u092B\u0915\u094D\u0924 \u0928\u093E\u0917\u0926\u0940 origin \u0935\u093E\u092A\u0930\u093E \u2014 path, query \u0906\u0923\u093F #fragment \u0915\u093E\u0922\u093E.",
  "settings.loopbackNotGranted": "Localhost API URLs \u092B\u0915\u094D\u0924 \u0921\u0947\u0935\u094D\u0939\u0932\u092A\u092E\u0947\u0902\u091F \u092C\u093F\u0932\u094D\u0921\u092E\u0927\u094D\u092F\u0947 \u091A\u093E\u0932\u0924\u093E\u0924. \u0939\u093E \u092C\u093F\u0932\u094D\u0921 \u092B\u0915\u094D\u0924 https:// \u0939\u094B\u0938\u094D\u091F\u092A\u0930\u094D\u092F\u0902\u0924 \u092A\u094B\u0939\u094B\u091A\u0942 \u0936\u0915\u0924\u094B.",
  "settings.saved": "\u091C\u0924\u0928 \u091D\u093E\u0932\u0947.",
  "settings.saveError": "\u091C\u0924\u0928 \u0915\u0930\u0924\u093E \u0906\u0932\u0947 \u0928\u093E\u0939\u0940. \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
  "settings.langLabel": "\u092D\u093E\u0937\u093E",
  "settings.langEnglish": "English",
  "settings.langHindi": "\u0939\u093F\u0928\u094D\u0926\u0940",
  "settings.langAuto": "\u092C\u094D\u0930\u093E\u0909\u091D\u0930 \u092D\u093E\u0937\u093E",
  "settings.langHint": "\u0924\u0941\u092E\u094D\u0939\u0940 \u0928\u093F\u0935\u0921\u0947\u092A\u0930\u094D\u092F\u0902\u0924 \u0924\u0941\u092E\u091A\u0940 \u092C\u094D\u0930\u093E\u0909\u091D\u0930 \u092D\u093E\u0937\u093E \u0935\u093E\u092A\u0930\u0932\u0940 \u091C\u093E\u0908\u0932.",
  // round-65: paste intake + in-page filing panel
  "popup.pasteLabel": "\u0915\u093F\u0902\u0935\u093E \u092B\u0940\u0932\u094D\u0921 \u092F\u0947\u0925\u0947 \u092A\u0947\u0938\u094D\u091F \u0915\u0930\u093E",
  "popup.pdfPick": "Cformly PDF \u0909\u0918\u0921\u093E",
  "popup.pdfLoaded": "\u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u091A\u0940 \u092B\u0940\u0932\u094D\u0921 Cformly PDF \u092E\u0927\u0942\u0928 \u0932\u094B\u0921 \u091D\u093E\u0932\u0940 \u2014 \u0916\u093E\u0932\u0940 \u0924\u092A\u093E\u0938\u093E \u0906\u0923\u093F \u092E\u0917 Fill Form \u0926\u093E\u092C\u093E.",
  "popup.pdfRejected": "\u092F\u093E PDF \u092E\u0927\u094D\u092F\u0947 Cformly \u092B\u0940\u0932\u094D\u0921 \u0928\u093E\u0939\u0940\u0924 \u0915\u093F\u0902\u0935\u093E \u0924\u0940 \u0935\u093E\u091A\u0924\u093E \u0906\u0932\u0940 \u0928\u093E\u0939\u0940 \u2014 Cformly \u0972\u092A\u092E\u0927\u0942\u0928 \u0928\u093F\u0930\u094D\u092F\u093E\u0924 \u0915\u0947\u0932\u0947\u0932\u0940 PDF\u091A \u0935\u093E\u092A\u0930\u093E.",
  "popup.pastePlaceholder": "\u0915\u0949\u092A\u0940 \u0915\u0947\u0932\u0947\u0932\u094D\u092F\u093E Cformly \u092B\u0940\u0932\u094D\u0921 \u092F\u0947\u0925\u0947 \u092A\u0947\u0938\u094D\u091F \u0915\u0930\u093E",
  "popup.pasteHint": "\u0915\u094D\u0932\u093F\u092A\u092C\u094B\u0930\u094D\u0921 \u092C\u091F\u0923 \u0915\u093E\u092E \u0915\u0930\u0924 \u0928\u0938\u0932\u094D\u092F\u093E\u0938, \u092F\u093E \u0938\u0902\u0917\u0923\u0915\u093E\u0935\u0930 \u092A\u093E\u0920\u0935\u0932\u0947\u0932\u094D\u092F\u093E \u092B\u0940\u0932\u094D\u0921 \u092F\u0947\u0925\u0947 \u092A\u0947\u0938\u094D\u091F \u0915\u0930\u093E (\u0915\u093F\u0902\u0935\u093E \u092E\u091C\u0915\u0942\u0930 \u092B\u093E\u0908\u0932 \u091F\u093E\u0915\u093E), \u0928\u0902\u0924\u0930 \u092D\u0930\u093E \u0926\u093E\u092C\u093E.",
  "popup.payloadTooLarge": "\u092A\u0947\u0938\u094D\u091F \u0915\u0947\u0932\u0947\u0932\u093E \u092E\u091C\u0915\u0942\u0930 \u0916\u0942\u092A \u092E\u094B\u0920\u093E \u0906\u0939\u0947 \u2014 \u092B\u0915\u094D\u0924 Cformly \u0972\u092A\u092E\u0927\u0942\u0928 \u0915\u0949\u092A\u0940 \u0915\u0947\u0932\u0947\u0932\u094D\u092F\u093E \u092B\u0940\u0932\u094D\u0921 \u092A\u0947\u0938\u094D\u091F \u0915\u0930\u093E.",
  "panel.title": "Cformly \u2014 \u092A\u094B\u0930\u094D\u091F\u0932\u0935\u0930 \u092B\u093E\u0907\u0932\u093F\u0902\u0917 \u092A\u0942\u0930\u094D\u0923 \u0915\u0930\u093E",
  "panel.dismiss": "\u092C\u0902\u0926 \u0915\u0930\u093E",
  "panel.filled": "\u092D\u0930\u0932\u0947\u0932\u094D\u092F\u093E \u092B\u0940\u0932\u094D\u0921: {filledRequired} / {required} \u0906\u0935\u0936\u094D\u092F\u0915",
  "panel.photoStep": "\u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u091A\u093E \u092B\u094B\u091F\u094B \u091C\u094B\u0921\u093E (\u092B\u093E\u0908\u0932 \u0928\u093F\u0935\u0921\u093E \u2192 \u0905\u092A\u0932\u094B\u0921 \u0915\u0930\u093E)",
  "panel.captchaStep": "\u0938\u0941\u0930\u0915\u094D\u0937\u093E \u0915\u094B\u0921 (CAPTCHA) \u091F\u093E\u0907\u092A \u0915\u0930\u093E",
  "panel.saveStep": "\u0938\u0947\u0935\u094D\u0939 \u0915\u0930\u093E \u0906\u0923\u093F \u092A\u0941\u0922\u0947 \u091C\u093E \u0926\u093E\u092C\u093E",
  "panel.warnSession": "Cformly \u0907\u0936\u093E\u0930\u093E: \u0939\u0947 FRRO \u0938\u0924\u094D\u0930 \u0926\u0941\u0938\u0931\u094D\u092F\u093E \u092E\u093E\u0932\u092E\u0924\u094D\u0924\u0947\u091A\u0947 \u0905\u0938\u0942 \u0936\u0915\u0924\u0947 ({reason}). \u0938\u0947\u0935\u094D\u0939 \u0915\u0930\u0923\u094D\u092F\u093E\u092A\u0942\u0930\u094D\u0935\u0940 \u0924\u092A\u093E\u0938\u093E.",
  "panel.warnUnverified": "Cformly \u0907\u0936\u093E\u0930\u093E: \u092F\u093E \u092B\u0940\u0932\u094D\u0921\u091A\u094D\u092F\u093E \u092E\u0942\u0932\u094D\u092F\u093E\u0902\u0928\u0940 \u091F\u093F\u0915\u0932\u0947\u0932\u0947 \u0928\u093E\u0939\u0940\u0924: {list}. \u0938\u0947\u0935\u094D\u0939 \u0915\u0930\u0923\u094D\u092F\u093E\u092A\u0942\u0930\u094D\u0935\u0940 \u0924\u092A\u093E\u0938\u093E.",
  "panel.saving": "\u092A\u094B\u0930\u094D\u091F\u0932\u091A\u094D\u092F\u093E \u0916\u093E\u0924\u094D\u0930\u0940\u091A\u0940 \u092A\u094D\u0930\u0924\u0940\u0915\u094D\u0937\u093E\u2026",
  "panel.progress": "\u092B\u0940\u0932\u094D\u0921 \u092D\u0930\u0932\u0947 \u091C\u093E\u0924 \u0906\u0939\u0947\u0924\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO \u0938\u0924\u094D\u0930 \u0938\u0902\u092A\u0932\u0947 \u2014 \u092A\u0941\u0928\u094D\u0939\u093E \u0932\u0949\u0917 \u0907\u0928 \u0915\u0930\u093E, \u092B\u0949\u0930\u094D\u092E \u0909\u0918\u0921\u0942\u0928 Fill \u0926\u093E\u092C\u093E. \u0924\u0941\u092E\u091A\u094D\u092F\u093E \u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u091A\u093E \u0924\u092A\u0936\u0940\u0932 Cformly \u0972\u092A\u092E\u0927\u094D\u092F\u0947 \u091C\u0924\u0928 \u0906\u0939\u0947.",
  "panel.portalError": "\u092A\u094B\u0930\u094D\u091F\u0932\u0928\u0947 \u0938\u092E\u0938\u094D\u092F\u093E \u0926\u0930\u094D\u0936\u0935\u093F\u0932\u0940:",
  "panel.appIdFound": "\u092F\u0936\u0938\u094D\u0935\u0940\u0930\u093F\u0924\u094D\u092F\u093E \u092B\u093E\u0907\u0932 \u091D\u093E\u0932\u0947. \u0905\u0930\u094D\u091C \u0906\u092F\u0921\u0940:",
  "panel.scanHint": "Cformly \u0972\u092A \u0909\u0918\u0921\u093E \u2192 \u092A\u094B\u0930\u094D\u091F\u0932\u0935\u0930 \u092A\u093E\u0920\u0935\u093E \u2192 \u0938\u0902\u0917\u0923\u0915\u093E\u0935\u0930\u0942\u0928 \u0938\u094D\u0915\u0945\u0928 \u0915\u0930\u093E \u0906\u0923\u093F \u092F\u093E \u0915\u094B\u0921\u0915\u0921\u0947 \u0915\u0945\u092E\u0947\u0930\u093E \u0927\u0930\u093E \u2014 \u0915\u093F\u0902\u0935\u093E \u0906\u092F\u0921\u0940 \u0915\u0949\u092A\u0940 \u0915\u0930\u093E.",
  "panel.copy": "\u0905\u0930\u094D\u091C \u0906\u092F\u0921\u0940 \u0915\u0949\u092A\u0940 \u0915\u0930\u093E",
  "panel.copied": "\u0915\u0949\u092A\u0940 \u091D\u093E\u0932\u0947.",
  "panel.confirmNotDetected": "\u092A\u0941\u0937\u094D\u091F\u0940 \u0938\u093E\u092A\u0921\u0932\u0940 \u0928\u093E\u0939\u0940 \u2014 \u092A\u094B\u0930\u094D\u091F\u0932\u0928\u0947 \u091C\u0924\u0928 \u0915\u0947\u0932\u0947 \u0906\u0939\u0947 \u0915\u093E \u0924\u0947 \u0924\u092A\u093E\u0938\u093E \u0906\u0923\u093F \u092E\u0917 \u092A\u0941\u0922\u0947 \u091C\u093E.",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "\u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u091A\u093E \u092B\u094B\u091F\u094B \u091C\u094B\u0921\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u092F\u0947\u0925\u0947 \u091F\u093E\u0915\u093E",
  "panel.photoBrowse": "\u092C\u094D\u0930\u093E\u0909\u091D\u2026",
  "panel.photoAttachFailed": "\u0906\u092A\u094B\u0906\u092A \u091C\u094B\u0921\u0924\u093E \u0906\u0932\u093E \u0928\u093E\u0939\u0940 \u2014 \u092A\u094B\u0930\u094D\u091F\u0932\u091A\u0947 \u0938\u094D\u0935\u0924\u0903\u091A\u0947 \u092B\u093E\u0908\u0932 \u0928\u093F\u0935\u0921\u093E \u092C\u091F\u0923 \u0935\u093E\u092A\u0930\u093E.",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "\u0939\u0947 \u092B\u0949\u0930\u094D\u092E Cformly \u0938\u0939 \u092D\u0930\u093E",
  "chip.hint": "\u092F\u093E \u0938\u0902\u0917\u0923\u0915\u093E\u0935\u0930 \u092A\u093E\u0920\u0935\u0932\u0947\u0932\u0947 \u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u091A\u0947 \u0924\u092A\u0936\u0940\u0932 \u092F\u0947\u0925\u0947 \u091A\u093F\u091F\u0915\u0935\u093E (\u0915\u093F\u0902\u0935\u093E \u092E\u091C\u0915\u0942\u0930 \u092B\u093E\u0908\u0932 \u092F\u0947\u0925\u0947 \u091F\u093E\u0915\u093E), \u0928\u0902\u0924\u0930 \u092B\u0949\u0930\u094D\u092E \u092D\u0930\u093E \u0926\u093E\u092C\u093E.",
  "chip.fill": "\u092B\u0949\u0930\u094D\u092E \u092D\u0930\u093E",
  "chip.filling": "\u092D\u0930\u0924 \u0906\u0939\u0947\u2026",
  "chip.empty": "\u092D\u0930\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u0915\u093E\u0939\u0940\u0939\u0940 \u0928\u093E\u0939\u0940 \u2014 \u0906\u0927\u0940 Cformly \u0972\u092A\u092E\u0927\u0942\u0928 \u0915\u0949\u092A\u0940 \u0915\u0947\u0932\u0947\u0932\u0947 \u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u091A\u0947 \u0924\u092A\u0936\u0940\u0932 \u091A\u093F\u091F\u0915\u0935\u093E.",
  "chip.tooLarge": "\u091A\u093F\u091F\u0915\u0935\u0932\u0947\u0932\u093E \u092E\u091C\u0915\u0942\u0930 \u0916\u0942\u092A \u092E\u094B\u0920\u093E \u0906\u0939\u0947 \u2014 \u092B\u0915\u094D\u0924 Cformly \u0972\u092A\u092E\u0927\u0942\u0928 \u0915\u0949\u092A\u0940 \u0915\u0947\u0932\u0947\u0932\u0947 \u0924\u092A\u0936\u0940\u0932 \u091A\u093F\u091F\u0915\u0935\u093E.",
  "chip.collapse": "\u092C\u0902\u0926 \u0915\u0930\u093E",
  "chip.mappingFallback": "\u091F\u0940\u092A: \u092E\u0945\u092A\u093F\u0902\u0917 \u0938\u0930\u094D\u0935\u094D\u0939\u0930 \u0909\u092A\u0932\u092C\u094D\u0927 \u0928\u093E\u0939\u0940 \u2014 \u0905\u0902\u0924\u0930\u094D\u092D\u0942\u0924 \u092B\u0940\u0932\u094D\u0921 \u0928\u0915\u093E\u0936\u093E \u0935\u093E\u092A\u0930\u0932\u093E \u091C\u093E\u0924 \u0906\u0939\u0947, \u091C\u094B \u091C\u0941\u0928\u093E \u0905\u0938\u0942 \u0936\u0915\u0924\u094B.",
  // round-66: popup first-run onboarding
  "onboarding.title": "\u092A\u0939\u093F\u0932\u094D\u092F\u093E\u0902\u0926\u093E\u091A \u092F\u0947\u0925\u0947? \u0924\u0940\u0928 \u092A\u093E\u092F\u0931\u094D\u092F\u093E:",
  "onboarding.step1": "\u0924\u0941\u092E\u091A\u094D\u092F\u093E \u092B\u094B\u0928\u0935\u0930: \u092A\u093E\u0939\u0941\u0923\u093E \u0909\u0918\u0921\u093E \u2192 \u092A\u094B\u0930\u094D\u091F\u0932\u0935\u0930 \u092A\u093E\u0920\u0935\u093E \u2192 \u0938\u0902\u0917\u0923\u0915\u093E\u0935\u0930 \u092A\u093E\u0920\u0935\u093E.",
  "onboarding.step2": "\u092F\u093E \u0938\u0902\u0917\u0923\u0915\u093E\u0935\u0930: \u0938\u094D\u0935\u0924\u0903\u0932\u093E \u092A\u093E\u0920\u0935\u0932\u0947\u0932\u0947 \u0924\u092A\u0936\u0940\u0932 \u0916\u093E\u0932\u0940\u0932 \u091A\u094C\u0915\u091F\u0940\u0924 \u091A\u093F\u091F\u0915\u0935\u093E (\u0915\u093F\u0902\u0935\u093E \u092B\u0949\u0930\u094D\u092E \u092A\u093E\u0928\u093E\u0935\u0930\u0940\u0932 \u0928\u093F\u0933\u0947 Cformly \u092C\u091F\u0923 \u0926\u093E\u092C\u093E).",
  "onboarding.step3": "\u092B\u0949\u0930\u094D\u092E \u092D\u0930\u093E \u0926\u093E\u092C\u093E \u2014 \u092A\u094B\u0930\u094D\u091F\u0932 \u092B\u0949\u0930\u094D\u092E \u0906\u092A\u094B\u0906\u092A \u092D\u0930\u0947\u0932. \u092B\u094B\u091F\u094B, \u0938\u0941\u0930\u0915\u094D\u0937\u093E \u0915\u094B\u0921 \u0906\u0923\u093F \u0938\u0947\u0935\u094D\u0939 \u0924\u0941\u092E\u094D\u0939\u0940 \u0915\u0930\u093E.",
  "onboarding.done": "\u0938\u092E\u091C\u0932\u0947",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{total} \u092A\u0948\u0915\u0940 {filled} \u092B\u0940\u0932\u094D\u0921 {time} \u0935\u093E\u091C\u0924\u093E \u092D\u0930\u0932\u0940 \u0939\u094B\u0924\u0940. \u092A\u0941\u0928\u094D\u0939\u093E \u092D\u0930\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u092A\u0941\u0928\u094D\u0939\u093E \u0938\u0941\u0930\u0942 \u0915\u0930\u093E.",
  "resume.button": "\u092A\u0941\u0928\u094D\u0939\u093E \u092D\u0930\u093E",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "\u0939\u0947 \u092A\u094B\u0930\u094D\u091F\u0932 \u092A\u0943\u0937\u094D\u0920 Cformly \u0932\u093E \u092E\u093E\u0939\u0940\u0924 \u0905\u0938\u0932\u0947\u0932\u094D\u092F\u093E Form III \u0938\u093E\u0930\u0916\u0947 \u0926\u093F\u0938\u0924 \u0928\u093E\u0939\u0940 \u2014 \u0915\u0926\u093E\u091A\u093F\u0924 \u092A\u094B\u0930\u094D\u091F\u0932 \u092C\u0926\u0932\u0932\u0947 \u0905\u0938\u0947\u0932. \u092F\u0902\u0926\u093E Cformly \u0905\u200D\u0945\u092A\u092E\u0927\u0942\u0928 \u092A\u093E\u0939\u0941\u0923\u0947 \u092B\u0940\u0932\u094D\u0921 \u0915\u0949\u092A\u0940 \u0915\u0930\u0942\u0928 \u0938\u094D\u0935\u0924\u0903 \u092D\u0930\u093E; \u0906\u092E\u094D\u0939\u0940 \u0905\u092A\u0921\u0947\u091F\u094D\u0938 \u0924\u092A\u093E\u0938\u0924 \u0906\u0939\u094B\u0924.",
  "canary.detail": "\u092F\u093E \u092A\u0943\u0937\u094D\u0920\u093E\u0935\u0930 Cformly \u0932\u093E \u092E\u093E\u0939\u0940\u0924 \u0905\u0938\u0932\u0947\u0932\u094D\u092F\u093E {total} \u092B\u0940\u0932\u094D\u0921\u092A\u0948\u0915\u0940 \u092B\u0915\u094D\u0924 {found} \u0938\u093E\u092A\u0921\u0932\u094D\u092F\u093E.",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "\u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u0902\u091A\u0940 \u0930\u093E\u0902\u0917",
  "queue.add": "\u0930\u093E\u0902\u0917\u0947\u0924 \u091C\u094B\u0921\u093E",
  "queue.fill": "\u092D\u0930\u093E",
  "queue.remove": "\u0915\u093E\u0922\u093E",
  "queue.unnamed": "\u092A\u093E\u0939\u0941\u0923\u093E",
  "queue.added": "{name} \u0930\u093E\u0902\u0917\u0947\u0924 \u091C\u094B\u0921\u0932\u0947.",
  "queue.duplicate": "\u0939\u093E \u092A\u093E\u0939\u0941\u0923\u093E \u0906\u0927\u0940\u091A \u0930\u093E\u0902\u0917\u0947\u0924 \u0906\u0939\u0947.",
  "queue.full": "\u0930\u093E\u0902\u0917 \u092D\u0930\u0932\u0940 \u0906\u0939\u0947 ({max} \u092A\u093E\u0939\u0941\u0923\u0947). \u0906\u0927\u0940 \u090F\u0915\u093E \u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u091A\u093E \u092B\u0949\u0930\u094D\u092E \u092D\u0930\u093E \u0915\u093F\u0902\u0935\u093E \u0924\u094D\u092F\u093E\u0932\u093E \u0915\u093E\u0922\u093E.",
  "queue.hint": "\u092D\u0930\u0923\u094D\u092F\u093E\u091A\u0940 \u092A\u094D\u0930\u0924\u0940\u0915\u094D\u0937\u093E \u0905\u0938\u0932\u0947\u0932\u0940 \u092A\u093E\u0939\u0941\u0923\u0940. \u092A\u0942\u0930\u094D\u0923 \u092D\u0930\u0932\u094D\u092F\u093E\u0935\u0930 \u092A\u093E\u0939\u0941\u0923\u093E \u0930\u093E\u0902\u0917\u0947\u0924\u0942\u0928 \u0915\u093E\u0922\u0932\u093E \u091C\u093E\u0924\u094B; \u092C\u094D\u0930\u093E\u0909\u091D\u0930 \u092C\u0902\u0926 \u091D\u093E\u0932\u094D\u092F\u093E\u0935\u0930 \u0930\u093E\u0902\u0917 \u092A\u0941\u0938\u0932\u0940 \u091C\u093E\u0924\u0947.",
  "queue.unavailable": "\u092F\u093E \u092C\u094D\u0930\u093E\u0909\u091D\u0930\u092E\u0927\u094D\u092F\u0947 \u092A\u093E\u0939\u0941\u0923\u094D\u092F\u093E\u0902\u091A\u0940 \u0930\u093E\u0902\u0917 \u0909\u092A\u0932\u092C\u094D\u0927 \u0928\u093E\u0939\u0940.",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "\u0939\u093E FRRO \u091F\u0945\u092C Cformly \u0907\u0902\u0938\u094D\u091F\u0949\u0932 \u0915\u093F\u0902\u0935\u093E \u0905\u092A\u0921\u0947\u091F \u0939\u094B\u0923\u094D\u092F\u093E\u092A\u0942\u0930\u094D\u0935\u0940 \u0909\u0918\u0921\u0932\u093E \u0939\u094B\u0924\u093E. \u092F\u093E \u091F\u0945\u092C\u0932\u093E \u090F\u0915\u0926\u093E \u0930\u0940\u0932\u094B\u0921 \u0915\u0930\u093E (F5), \u0928\u0902\u0924\u0930 Fill \u0926\u093E\u092C\u093E.",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "\u092B\u0949\u0930\u094D\u092E \u092E\u0945\u092A\u093F\u0902\u0917",
  "settings.mapVersion": "\u0906\u0935\u0943\u0924\u094D\u0924\u0940",
  "settings.mapLastVerified": "\u0936\u0947\u0935\u091F\u091A\u0947 \u0938\u0924\u094D\u092F\u093E\u092A\u0928",
  "settings.mapFetchedAt": "\u092E\u093F\u0933\u0935\u0932\u0947",
  "settings.mapSignature": "Ed25519 \u0938\u094D\u0935\u093E\u0915\u094D\u0937\u0930\u0940",
  "settings.mapRefresh": "\u0906\u0924\u093E \u0930\u093F\u092B\u094D\u0930\u0947\u0936 \u0915\u0930\u093E",
  "settings.mapRefreshed": "\u092E\u0945\u092A\u093F\u0902\u0917 \u0930\u093F\u092B\u094D\u0930\u0947\u0936 \u091D\u093E\u0932\u0947.",
  "settings.mapRefreshFailed": "\u092E\u0945\u092A\u093F\u0902\u0917 \u0930\u093F\u092B\u094D\u0930\u0947\u0936 \u0915\u0930\u0924\u093E \u0906\u0932\u0947 \u0928\u093E\u0939\u0940 - \u0909\u092A\u0932\u092C\u094D\u0927 \u0905\u0938\u0932\u0947\u0932\u0940 \u0938\u0930\u094D\u0935\u094B\u0924\u094D\u0924\u092E \u092A\u094D\u0930\u0924 \u0935\u093E\u092A\u0930\u0924 \u0906\u0939\u094B\u0924.",
  "settings.mapStatusRemote": "\u0938\u0924\u094D\u092F\u093E\u092A\u093F\u0924 - \u092E\u0945\u092A\u093F\u0902\u0917 \u0938\u0930\u094D\u0935\u094D\u0939\u0930\u0935\u0930\u0942\u0928 \u0906\u0923\u0932\u0947\u0932\u0940 \u0924\u093E\u091C\u0940 \u092A\u094D\u0930\u0924.",
  "settings.mapStatusCached": "\u0938\u0924\u094D\u092F\u093E\u092A\u093F\u0924 - \u0905\u0932\u0940\u0915\u0921\u091A\u0940 \u0915\u0945\u0936\u0947 \u092A\u094D\u0930\u0924.",
  "settings.mapStatusBundled": "\u0905\u0902\u0924\u0930\u094D\u092D\u0942\u0924 \u092E\u0942\u0933 \u092A\u094D\u0930\u0924 (\u0938\u0930\u094D\u0935\u094D\u0939\u0930 \u0909\u092A\u0932\u092C\u094D\u0927 \u0928\u093E\u0939\u0940). \u0938\u094D\u0935\u093E\u0915\u094D\u0937\u0930\u0940 \u0924\u0936\u0940\u091A \u0906\u0939\u0947.",
  "settings.mapStatusTampered": "\u0938\u094D\u0935\u093E\u0915\u094D\u0937\u0930\u0940 \u0924\u092A\u093E\u0938\u0923\u0940 \u0905\u092F\u0936\u0938\u094D\u0935\u0940 - \u0939\u0940 \u092A\u094D\u0930\u0924 \u0928\u093E\u0915\u093E\u0930\u0932\u0940 \u0917\u0908 \u0906\u0939\u0947 \u0906\u0923\u093F \u0935\u093E\u092A\u0930\u093E\u0924 \u0928\u093E\u0939\u0940.",
  "chip.mappingUnavailable": "\u092B\u0949\u0930\u094D\u092E \u092E\u0945\u092A\u093F\u0902\u0917 \u0932\u094B\u0921 \u0939\u094B\u090A \u0936\u0915\u0932\u0947 \u0928\u093E\u0939\u0940 \u2014 \u090F\u0915\u094D\u0938\u091F\u0947\u0928\u094D\u0936\u0928\u091A\u094D\u092F\u093E \u092C\u0945\u0915\u0917\u094D\u0930\u093E\u0909\u0902\u0921 \u0935\u0930\u094D\u0915\u0930\u0928\u0947 \u0909\u0924\u094D\u0924\u0930 \u0926\u093F\u0932\u0947 \u0928\u093E\u0939\u0940. \u092A\u094B\u0930\u094D\u091F\u0932 \u091F\u0945\u092C \u0930\u0940\u0932\u094B\u0921 \u0915\u0930\u0942\u0928 \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
  "popup.timeoutMapping": "\u092B\u0949\u0930\u094D\u092E \u092E\u0945\u092A\u093F\u0902\u0917 \u0932\u094B\u0921 \u0939\u094B\u0923\u094D\u092F\u093E\u091A\u093E \u0935\u0947\u0933 \u0938\u0902\u092A\u0932\u093E ({seconds} \u0938\u0947\u0915\u0902\u0926). \u0915\u0928\u0947\u0915\u094D\u0936\u0928 \u0924\u092A\u093E\u0938\u0942\u0928 \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
  "popup.timeoutNoProgress": "\u092D\u0930\u0923\u0940 {seconds} \u0938\u0947\u0915\u0902\u0926\u093E\u0902\u0924 \u0938\u0941\u0930\u0942 \u091D\u093E\u0932\u0940 \u0928\u093E\u0939\u0940 \u2014 Form III \u092A\u0943\u0937\u094D\u0920 \u092A\u094D\u0930\u0924\u093F\u0938\u093E\u0926 \u0926\u0947\u0924 \u0928\u093E\u0939\u0940. \u091F\u0945\u092C \u0930\u0940\u0932\u094B\u0921 \u0915\u0930\u0942\u0928 \u092A\u0941\u0928\u094D\u0939\u093E \u092A\u094D\u0930\u092F\u0924\u094D\u0928 \u0915\u0930\u093E.",
  "popup.timeoutStalled": "\u092D\u0930\u0923\u0940 {seconds} \u0938\u0947\u0915\u0902\u0926\u093E\u0902\u092A\u093E\u0938\u0942\u0928 \u0925\u093E\u0902\u092C\u0932\u0940 \u0906\u0939\u0947 \u2014 Form III \u092A\u0943\u0937\u094D\u0920\u093E\u0928\u0947 \u092A\u094D\u0930\u0924\u093F\u0938\u093E\u0926 \u0926\u0947\u0923\u0947 \u092C\u0902\u0926 \u0915\u0947\u0932\u0947 \u0906\u0939\u0947.",
  "popup.timeoutCap": "\u092D\u0930\u0923\u0940\u0928\u0947 \u090F\u0915\u0942\u0923 \u0935\u0947\u0933 \u092E\u0930\u094D\u092F\u093E\u0926\u093E ({seconds} \u0938\u0947\u0915\u0902\u0926) \u0913\u0932\u093E\u0902\u0921\u0932\u0940 \u0906\u0923\u093F \u0925\u093E\u0902\u092C\u0935\u0932\u0940 \u0917\u0947\u0932\u0940.",
  "popup.preview": "\u092C\u0926\u0932 \u092A\u0939\u093E",
  "popup.previewApply": "\u0932\u093E\u0917\u0942 \u0915\u0930\u093E \u2014 \u092B\u0949\u0930\u094D\u092E \u092D\u0930\u093E",
  "popup.undo": "\u0936\u0947\u0935\u091F\u091A\u0940 \u092B\u093F\u0932 \u092A\u0942\u0930\u094D\u0935\u0935\u0924 \u0915\u0930\u093E",
  "popup.undoDone": "{total} \u092A\u0948\u0915\u0940 {restored} \u092B\u0940\u0932\u094D\u0921 \u0924\u094D\u092F\u093E\u0902\u091A\u094D\u092F\u093E \u091C\u0941\u0928\u094D\u092F\u093E \u092E\u0942\u0932\u094D\u092F\u093E\u0902\u0935\u0930 \u092A\u0941\u0928\u0930\u094D\u0938\u094D\u0925\u093E\u092A\u093F\u0924 \u0915\u0947\u0932\u0947.",
  "popup.undoPartial": "{total} \u092A\u0948\u0915\u0940 {restored} \u092A\u0941\u0928\u0930\u094D\u0938\u094D\u0925\u093E\u092A\u093F\u0924; {failed} \u092A\u0941\u0928\u0930\u094D\u0938\u094D\u0925\u093E\u092A\u093F\u0924 \u0915\u0930\u0924\u093E \u0906\u0932\u0947 \u0928\u093E\u0939\u0940 (\u092A\u093E\u0928 \u092A\u0941\u0928\u094D\u0939\u093E \u0924\u092F\u093E\u0930 \u091D\u093E\u0932\u0947 \u0905\u0938\u0942 \u0936\u0915\u0924\u0947).",
  "popup.undoStale": "\u092B\u093F\u0932\u0928\u0902\u0924\u0930 \u092A\u093E\u0928 \u092C\u0926\u0932\u0932\u0947 \u2014 \u092A\u0941\u0928\u0930\u094D\u0938\u094D\u0925\u093E\u092A\u0928\u093E \u0905\u092A\u0942\u0930\u094D\u0923 \u0905\u0938\u0942 \u0936\u0915\u0924\u0947.",
  "popup.undoNone": "\u092A\u0942\u0930\u094D\u0935\u0935\u0924 \u0915\u0930\u0923\u094D\u092F\u093E\u0938\u093E\u0920\u0940 \u0915\u093E\u0939\u0940 \u0928\u093E\u0939\u0940 \u2014 \u092F\u093E \u0938\u0924\u094D\u0930\u093E\u0924 \u092F\u093E \u091F\u0945\u092C\u0935\u0930 \u0915\u094B\u0923\u0924\u0940\u0939\u0940 \u092B\u093F\u0932 \u091D\u093E\u0932\u0940 \u0928\u093E\u0939\u0940.",
  "popup.previewUnresolved": "\u092F\u093E \u092A\u0943\u0937\u094D\u0920\u093E\u0935\u0930 \u0938\u093E\u092A\u0921\u0932\u0947 \u0928\u093E\u0939\u0940",
  "popup.previewManual": "\u092E\u0945\u0928\u094D\u092F\u0941\u0905\u0932 \u091F\u092A\u094D\u092A\u093E",
  "popup.previewNoValue": "(\u092A\u094D\u0930\u0926\u093E\u0928 \u0915\u0947\u0932\u0947 \u0928\u093E\u0939\u0940)"
};

// src/i18n/ur.ts
var ur = {
  // popup
  "popup.title": "Cformly \u0622\u0679\u0648 \u0641\u0644",
  "popup.eyebrow": "\u0622\u0679\u0648 \u0641\u0644",
  "popup.bandSub": "FRRO Form III \xB7 \u0686\u06CC\u06A9 \u0627\u0650\u0646 \u06A9\u06D2 24 \u06AF\u06BE\u0646\u0679\u0648\u06BA \u06A9\u06D2 \u0627\u0646\u062F\u0631",
  "popup.fillFromClipboard": "\u06A9\u0644\u067E \u0628\u0648\u0631\u0688 \u0633\u06D2 \u0641\u0627\u0631\u0645 \u0628\u06BE\u0631\u06CC\u06BA",
  "popup.fillHint": "\u067E\u06C1\u0644\u06D2 Cformly \u0627\u06CC\u067E \u0633\u06D2 \u0645\u06C1\u0645\u0627\u0646 \u06A9\u06D2 \u0641\u06CC\u0644\u0688\u0632 \u06A9\u0627\u067E\u06CC \u06A9\u0631\u06CC\u06BA\u060C \u067E\u06BE\u0631 \u06CC\u06C1 \u067E\u0648\u0631\u0679\u0644 \u0641\u0627\u0631\u0645 \u0628\u06BE\u0631\u06CC\u06BA\u06D4",
  "popup.clipboardReadFailed": "\u06A9\u0644\u067E \u0628\u0648\u0631\u0688 \u067E\u0691\u06BE\u0627 \u0646\u06C1\u06CC\u06BA \u062C\u0627 \u0633\u06A9\u0627\u06D4 \u0628\u0631\u0627\u0624\u0632\u0631 \u06A9\u06CC \u06A9\u0644\u067E \u0628\u0648\u0631\u0688 \u0627\u062C\u0627\u0632\u062A\u06CC\u06BA \u062F\u06CC\u06A9\u06BE\u06CC\u06BA\u06D4",
  "popup.clipboardEmpty": "\u06A9\u0644\u067E \u0628\u0648\u0631\u0688 \u0645\u06CC\u06BA Cformly \u06A9\u06D2 \u0641\u06CC\u0644\u0688\u0632 \u0646\u06C1\u06CC\u06BA \u06C1\u06CC\u06BA\u06D4 \u067E\u06C1\u0644\u06D2 Cformly \u0627\u06CC\u067E \u0633\u06D2 \u0645\u06C1\u0645\u0627\u0646 \u06A9\u06D2 \u0641\u06CC\u0644\u0688\u0632 \u06A9\u0627\u067E\u06CC \u06A9\u0631\u06CC\u06BA\u06D4",
  "popup.settings": "\u062A\u0631\u062A\u06CC\u0628\u0627\u062A",
  "popup.loadingMapping": "\u0641\u0627\u0631\u0645 \u0645\u06CC\u067E\u0646\u06AF \u0644\u0648\u0688 \u06C1\u0648 \u0631\u06C1\u06CC \u06C1\u06D2...",
  "popup.filling": "\u0641\u0627\u0631\u0645 \u0628\u06BE\u0631\u0627 \u062C\u0627 \u0631\u06C1\u0627 \u06C1\u06D2...",
  "popup.fillingProgress": "\u0628\u06BE\u0631\u0627 \u062C\u0627 \u0631\u06C1\u0627 \u06C1\u06D2\u2026 \u062E\u0627\u0646\u06C1 {completed}/{total}",
  "popup.noTab": "\u06A9\u0648\u0626\u06CC \u0641\u0639\u0627\u0644 \u0679\u06CC\u0628 \u0646\u06C1\u06CC\u06BA \u0645\u0644\u0627\u06D4",
  "popup.filled": "\u0636\u0631\u0648\u0631\u06CC \u0641\u06CC\u0644\u0688\u0632 \u0628\u06BE\u0631\u06D2 \u06AF\u0626\u06D2: {required} \u0645\u06CC\u06BA \u0633\u06D2 {filledRequired} ({filled} \u06A9\u0644 \u0628\u06BE\u0631\u06D2 \u06AF\u0626\u06D2)",
  "popup.portalMismatch": "\u067E\u0648\u0631\u0679\u0644 \u0628\u062F\u0644\u0646\u06D2 \u06A9\u0627 \u067E\u062A\u06C1 \u0686\u0644\u0627 (DOM \u0628\u062F\u0644\u0627 \u06C1\u0648\u0627 \u06C1\u06D2)\u06D4 Cformly \u0627\u06CC\u067E \u0645\u06CC\u06BA \u0645\u06C1\u0645\u0627\u0646 \u06A9\u06D2 \u0641\u06CC\u0644\u0688\u0632 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0627\u067E\u06CC \u06A9\u0631\u06CC\u06BA \u0627\u0648\u0631 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4",
  "popup.missingElements": "\u063A\u0627\u0626\u0628 \u0639\u0646\u0627\u0635\u0631: {list}",
  "popup.missingValues": "\u063A\u0627\u0626\u0628 \u0645\u0627\u0646\u06CC\u06BA: {list}",
  "popup.manualFields": "\u062F\u0633\u062A\u06CC \u0645\u0631\u0627\u062D\u0644 \u062F\u0631\u06A9\u0627\u0631: {list}",
  "popup.unsupportedFields": "\u062E\u0648\u062F\u06A9\u0627\u0631 \u0628\u06BE\u0631\u0627\u0626\u06CC \u0633\u06D2 \u0628\u0627\u06C1\u0631 \u0641\u06CC\u0644\u0688\u0632: {list}",
  "popup.tooLongFields": "\u0627\u0646 \u0641\u06CC\u0644\u0688\u0632 \u06A9\u06D2 \u0644\u06CC\u06D2 \u0645\u0627\u0646\u06CC\u06BA \u0628\u06C1\u062A \u0644\u0645\u0628\u06CC \u06C1\u06CC\u06BA \u2014 \u06A9\u0686\u06BE \u0646\u06C1\u06CC\u06BA \u0644\u06A9\u06BE\u0627 \u06AF\u06CC\u0627\u060C \u0645\u062E\u062A\u0635\u0631 \u0648\u06CC\u0644\u06CC\u0648 \u0644\u06A9\u06BE\u06CC\u06BA: {list}",
  "popup.unverifiedFields": "\u0627\u0646 \u0641\u06CC\u0644\u0688\u0632 \u06A9\u06CC \u062C\u0627\u0646\u0686 \u06A9\u0631\u06CC\u06BA \u2014 \u0648\u06CC\u0644\u06CC\u0648 \u0634\u0627\u06CC\u062F \u0646\u06C1\u06CC\u06BA \u0686\u067E\u06A9\u06CC: {list}",
  "popup.applicationId": "\u062F\u0631\u062E\u0648\u0627\u0633\u062A ID: {id}",
  "popup.accommodationMismatch": "\u0627\u0646\u062A\u0628\u0627\u06C1: FRRO \u0633\u06CC\u0634\u0646 \u06A9\u0633\u06CC \u0627\u0648\u0631 \u067E\u0631\u0627\u067E\u0631\u0679\u06CC \u06A9\u0627 \u06C1\u0648 \u0633\u06A9\u062A\u0627 \u06C1\u06D2\u06D4 \u062C\u0645\u0639 \u06A9\u0631\u0627\u0646\u06D2 \u0633\u06D2 \u067E\u06C1\u0644\u06D2 \u062A\u0635\u062F\u06CC\u0642 \u06A9\u0631\u06CC\u06BA\u06D4",
  "popup.attention": "\u06A9\u0686\u06BE \u0641\u06CC\u0644\u0688\u0632 \u067E\u0631 \u062A\u0648\u062C\u06C1 \u062F\u0631\u06A9\u0627\u0631 \u06C1\u06D2\u06D4 Cformly \u0627\u06CC\u067E \u0645\u06CC\u06BA \u0645\u06C1\u0645\u0627\u0646 \u06A9\u06D2 \u0641\u06CC\u0644\u0688\u0632 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0627\u067E\u06CC \u06A9\u0631\u06CC\u06BA \u0627\u0648\u0631 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4",
  "popup.openPrint": "\u0627\u0646\u0641\u0631\u0627\u062F\u06CC \u067E\u0631\u0646\u0679 \u06A9\u06BE\u0648\u0644\u06CC\u06BA",
  "popup.printNoId": "\u0627\u0628\u06BE\u06CC \u06A9\u0648\u0626\u06CC \u062F\u0631\u062E\u0648\u0627\u0633\u062A ID \u06A9\u06CC\u067E\u0686\u0631 \u0646\u06C1\u06CC\u06BA \u06C1\u0648\u0626\u06CC \u2014 \u067E\u06C1\u0644\u06D2 \u0641\u0627\u0631\u0645 \u0628\u06BE\u0631\u06CC\u06BA\u06D4",
  "popup.printSent": "ID {id} \u06A9\u06CC \u062C\u0645\u0639 \u0634\u062F\u06C1 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u06BE\u0648\u0644 \u062F\u06CC \u06AF\u0626\u06CC\u06D4 PDF \u0688\u0627\u0624\u0646 \u0644\u0648\u0688 \u06A9\u0631\u0646\u06D2 \u06A9\u06D2 \u0644\u06CC\u06D2 \u067E\u0648\u0631\u0679\u0644 \u06A9\u06D2 Individual Print \u0645\u06CC\u0646\u0648 \u06A9\u0627 \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06A9\u0631\u06CC\u06BA\u06D4",
  "popup.formFilled": "\u0641\u0627\u0631\u0645 \u0628\u06BE\u0631 \u06AF\u06CC\u0627\u06D4 \u067E\u0648\u0631\u0679\u0644 \u067E\u0631 \u062C\u0627\u0626\u0632\u06C1 \u0644\u06CC\u06BA \u0627\u0648\u0631 \u062C\u0645\u0639 \u06A9\u0631\u0648\u0627\u0626\u06CC\u06BA\u06D4",
  "popup.fillError": "\u0628\u06BE\u0631\u0627\u0626\u06CC \u0645\u06CC\u06BA \u062E\u0631\u0627\u0628\u06CC: {message}",
  "popup.connectionFailed": "FRRO \u067E\u0648\u0631\u0679\u0644 \u0635\u0641\u062D\u06D2 \u062A\u06A9 \u0631\u0633\u0627\u0626\u06CC \u0646\u06C1\u06CC\u06BA \u0645\u0644 \u0633\u06A9\u06CC\u06D4 \u0627\u0633 \u0679\u06CC\u0628 \u0645\u06CC\u06BA Form III \u06A9\u0627 \u0635\u0641\u062D\u06C1 \u06A9\u06BE\u0648\u0644\u06CC\u06BA \u0627\u0648\u0631 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4",
  "popup.unknownError": "\u0646\u0627\u0645\u0639\u0644\u0648\u0645",
  "popup.apiBaseFallback": "\u0627\u0646\u062A\u0628\u0627\u06C1: \u0645\u062D\u0641\u0648\u0638 \u0634\u062F\u06C1 API URL \u063A\u0644\u0637 \u06C1\u06D2 \u2014 \u0688\u06CC\u0641\u0627\u0644\u0679 \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06C1\u0648 \u0631\u06C1\u0627 \u06C1\u06D2\u06D4 Settings \u0645\u06CC\u06BA \u0627\u0633\u06D2 \u0627\u067E \u0688\u06CC\u0679 \u06A9\u0631\u06CC\u06BA\u06D4",
  "popup.mappingFallback": "\u0627\u0646\u062A\u0628\u0627\u06C1: \u0645\u06CC\u067E\u0646\u06AF \u0633\u0631\u0648\u0631 \u062F\u0633\u062A\u06CC\u0627\u0628 \u0646\u06C1\u06CC\u06BA \u2014 \u0628\u0644\u0679 \u0627\u0650\u0646 \u0641\u06CC\u0644\u0688 \u0645\u06CC\u067E \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06C1\u0648 \u0631\u06C1\u0627 \u06C1\u06D2\u060C \u062C\u0648 \u067E\u0631\u0627\u0646\u0627 \u06C1\u0648 \u0633\u06A9\u062A\u0627 \u06C1\u06D2\u06D4",
  // settings
  "settings.title": "Cformly \u062A\u0631\u062A\u06CC\u0628\u0627\u062A",
  "settings.eyebrow": "\u062A\u0631\u062A\u06CC\u0628\u0627\u062A",
  "settings.bandSub": "\u0641\u0627\u0631\u0645 \u0645\u06CC\u067E\u0646\u06AF \u0641\u0631\u0627\u06C1\u0645 \u06A9\u0631\u0646\u06D2 \u0648\u0627\u0644\u06D2 \u0628\u06CC\u06A9 \u0627\u06CC\u0646\u0688 \u06A9\u0648 \u062A\u0631\u062A\u06CC\u0628 \u062F\u06CC\u06BA\u06D4",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "\u0641\u0627\u0631\u0645 \u0645\u06CC\u067E\u0646\u06AF \u0641\u0631\u0627\u06C1\u0645 \u06A9\u0631\u0646\u06D2 \u0648\u0627\u0644\u0627 \u0628\u06CC\u06A9 \u0627\u06CC\u0646\u0688\u06D4 \u0635\u0631\u0641 HTTPS\u061B localhost \u0635\u0631\u0641 \u0688\u06CC\u0648\u06CC\u0644\u067E\u0645\u0646\u0679 \u0628\u0644\u0688 \u0645\u06CC\u06BA \u06A9\u0627\u0645 \u06A9\u0631\u062A\u0627 \u06C1\u06D2\u06D4",
  "settings.save": "\u0645\u062D\u0641\u0648\u0638 \u06A9\u0631\u06CC\u06BA",
  "settings.back": "\u0648\u0627\u067E\u0633",
  "settings.backInTab": "\u062A\u0631\u062A\u06CC\u0628\u0627\u062A \u0628\u0637\u0648\u0631 \u0679\u06CC\u0628 \u06A9\u06BE\u0644\u06CC \u06C1\u06CC\u06BA \u2014 \u0641\u0644 \u067E\u0627\u067E \u0627\u067E \u06A9\u06D2 \u0644\u06CC\u06D2 Cformly \u0679\u0648\u0644 \u0628\u0627\u0631 \u0622\u0626\u06CC\u06A9\u0646 \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06A9\u0631\u06CC\u06BA\u06D4",
  "settings.urlEmpty": "URL \u062E\u0627\u0644\u06CC \u0646\u06C1\u06CC\u06BA \u0631\u06C1 \u0633\u06A9\u062A\u0627\u06D4",
  "settings.httpsOnly": "\u0633\u06CC\u06A9\u06CC\u0648\u0631\u0679\u06CC \u06A9\u06D2 \u0644\u06CC\u06D2 \u0635\u0631\u0641 HTTPS URLs \u06A9\u06CC \u0627\u062C\u0627\u0632\u062A \u06C1\u06D2\u06D4 \u067E\u0631\u0648\u0688\u06A9\u0634\u0646 \u06A9\u06D2 \u0644\u06CC\u06D2 https:// \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06A9\u0631\u06CC\u06BA\u06D4",
  "settings.hostNotAllowed": "URL hostname \u0644\u0627\u0632\u0645\u06CC \u0637\u0648\u0631 \u067E\u0631 localhost \u06CC\u0627 *.cformly.com \u06C1\u0648 (\u0645\u0644\u06CC: {host})\u06D4",
  "settings.invalidUrl": "\u063A\u0644\u0637 URL\u06D4 https:// \u0634\u0627\u0645\u0644 \u06A9\u0631\u06CC\u06BA",
  "settings.urlPathNotAllowed": "\u0635\u0631\u0641 \u0628\u0646\u06CC\u0627\u062F\u06CC origin \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06A9\u0631\u06CC\u06BA \u2014 path\u060C query \u0627\u0648\u0631 #fragment \u06C1\u0679\u0627 \u062F\u06CC\u06BA\u06D4",
  "settings.loopbackNotGranted": "Localhost API URLs \u0635\u0631\u0641 \u0688\u06CC\u0648\u06CC\u0644\u067E\u0645\u0646\u0679 \u0628\u0644\u0688 \u0645\u06CC\u06BA \u06A9\u0627\u0645 \u06A9\u0631\u062A\u06D2 \u06C1\u06CC\u06BA\u06D4 \u06CC\u06C1 \u0628\u0644\u0688 \u0635\u0631\u0641 https:// \u06C1\u0648\u0633\u0679\u0633 \u062A\u06A9 \u067E\u06C1\u0646\u0686 \u0633\u06A9\u062A\u0627 \u06C1\u06D2\u06D4",
  "settings.saved": "\u0645\u062D\u0641\u0648\u0638 \u06C1\u0648 \u06AF\u06CC\u0627\u06D4",
  "settings.saveError": "\u0645\u062D\u0641\u0648\u0638 \u0646\u06C1\u06CC\u06BA \u06C1\u0648 \u0633\u06A9\u0627\u06D4 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4",
  "settings.langLabel": "\u0632\u0628\u0627\u0646",
  "settings.langEnglish": "English",
  "settings.langHindi": "\u0939\u093F\u0928\u094D\u0926\u0940",
  "settings.langAuto": "\u0628\u0631\u0627\u0624\u0632\u0631 \u06A9\u06CC \u067E\u06CC\u0631\u0648\u06CC \u06A9\u0631\u06CC\u06BA",
  "settings.langHint": "\u0622\u067E \u06A9\u06D2 \u0627\u0646\u062A\u062E\u0627\u0628 \u062A\u06A9 \u0622\u067E \u06A9\u06CC \u0628\u0631\u0627\u0624\u0632\u0631 \u0632\u0628\u0627\u0646 \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06C1\u0648\u06AF\u06CC\u06D4",
  // round-65: paste intake + in-page filing panel
  "popup.pasteLabel": "\u06CC\u0627 \u0641\u06CC\u0644\u0688\u0632 \u06CC\u06C1\u0627\u06BA \u067E\u06CC\u0633\u0679 \u06A9\u0631\u06CC\u06BA",
  "popup.pdfPick": "Cformly PDF \u06A9\u06BE\u0648\u0644\u06CC\u06BA",
  "popup.pdfLoaded": "\u0645\u06C1\u0645\u0627\u0646 \u06A9\u06D2 \u0641\u06CC\u0644\u0688\u0632 Cformly PDF \u0633\u06D2 \u0644\u0648\u0688 \u06C1\u0648 \u06AF\u0626\u06D2 \u2014 \u0646\u06CC\u0686\u06D2 \u062C\u0627\u0646\u0686\u06CC\u06BA\u060C \u067E\u06BE\u0631 Fill Form \u062F\u0628\u0627\u0626\u06CC\u06BA\u06D4",
  "popup.pdfRejected": "\u0627\u0633 PDF \u0645\u06CC\u06BA Cformly \u0641\u06CC\u0644\u0688\u0632 \u0646\u06C1\u06CC\u06BA \u06C1\u06CC\u06BA \u06CC\u0627 \u0627\u0633\u06D2 \u067E\u0691\u06BE\u0627 \u0646\u06C1\u06CC\u06BA \u062C\u0627 \u0633\u06A9\u0627 \u2014 Cformly \u0627\u06CC\u067E \u0633\u06D2 \u0627\u06CC\u06A9\u0633\u067E\u0648\u0631\u0679 \u06A9\u06CC \u06AF\u0626\u06CC PDF \u06C1\u06CC \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06A9\u0631\u06CC\u06BA\u06D4",
  "popup.pastePlaceholder": "\u06A9\u0627\u067E\u06CC \u06A9\u06CC \u06AF\u0626\u06CC Cformly \u0641\u06CC\u0644\u0688\u0632 \u06CC\u06C1\u0627\u06BA \u067E\u06CC\u0633\u0679 \u06A9\u0631\u06CC\u06BA",
  "popup.pasteHint": "\u0627\u06AF\u0631 \u06A9\u0644\u067E \u0628\u0648\u0631\u0688 \u0628\u0679\u0646 \u06A9\u0627\u0645 \u0646\u06C1 \u06A9\u0631\u06D2\u060C \u062A\u0648 \u0627\u0633 \u06A9\u0645\u067E\u06CC\u0648\u0679\u0631 \u067E\u0631 \u0628\u06BE\u06CC\u062C\u06CC \u06AF\u0626\u06CC \u0641\u06CC\u0644\u0688\u0632 \u06CC\u06C1\u0627\u06BA \u067E\u06CC\u0633\u0679 \u06A9\u0631\u06CC\u06BA (\u06CC\u0627 \u0679\u06CC\u06A9\u0633\u0679 \u0641\u0627\u0626\u0644 \u0686\u06BE\u0648\u0691\u06CC\u06BA)\u060C \u067E\u06BE\u0631 \u0628\u06BE\u0631\u06CC\u06BA \u062F\u0628\u0627\u0626\u06CC\u06BA\u06D4",
  "popup.payloadTooLarge": "\u067E\u06CC\u0633\u0679 \u06A9\u06CC\u0627 \u06AF\u06CC\u0627 \u0645\u062A\u0646 \u0628\u06C1\u062A \u0628\u0691\u0627 \u06C1\u06D2 \u2014 \u0635\u0631\u0641 Cformly \u0627\u06CC\u067E \u0633\u06D2 \u06A9\u0627\u067E\u06CC \u06A9\u06CC \u06AF\u0626\u06CC \u0641\u06CC\u0644\u0688\u0632 \u067E\u06CC\u0633\u0679 \u06A9\u0631\u06CC\u06BA\u06D4",
  "panel.title": "Cformly \u2014 \u067E\u0648\u0631\u0679\u0644 \u067E\u0631 \u0641\u0627\u0626\u0644\u0646\u06AF \u0645\u06A9\u0645\u0644 \u06A9\u0631\u06CC\u06BA",
  "panel.dismiss": "\u0628\u0646\u062F \u06A9\u0631\u06CC\u06BA",
  "panel.filled": "\u0628\u06BE\u0631\u06CC \u06AF\u0626\u06CC \u0641\u06CC\u0644\u0688\u0632: {filledRequired} / {required} \u0644\u0627\u0632\u0645\u06CC",
  "panel.photoStep": "\u0645\u06C1\u0645\u0627\u0646 \u06A9\u06CC \u062A\u0635\u0648\u06CC\u0631 \u0644\u06AF\u0627\u0626\u06CC\u06BA (\u0641\u0627\u0626\u0644 \u0645\u0646\u062A\u062E\u0628 \u06A9\u0631\u06CC\u06BA \u2192 \u0627\u067E\u0644\u0648\u0688 \u06A9\u0631\u06CC\u06BA)",
  "panel.captchaStep": "\u0633\u06CC\u06A9\u06CC\u0648\u0631\u0679\u06CC \u06A9\u0648\u0688 (CAPTCHA) \u0679\u0627\u0626\u067E \u06A9\u0631\u06CC\u06BA",
  "panel.saveStep": "\u0645\u062D\u0641\u0648\u0638 \u06A9\u0631\u06CC\u06BA \u0627\u0648\u0631 \u062C\u0627\u0631\u06CC \u0631\u06A9\u06BE\u06CC\u06BA \u062F\u0628\u0627\u0626\u06CC\u06BA",
  "panel.warnSession": "Cformly \u062A\u0646\u0628\u06CC\u06C1: \u06CC\u06C1 FRRO \u0633\u06CC\u0634\u0646 \u06A9\u0633\u06CC \u0627\u0648\u0631 \u067E\u0631\u0627\u067E\u0631\u0679\u06CC \u06A9\u0627 \u06C1\u0648 \u0633\u06A9\u062A\u0627 \u06C1\u06D2 ({reason})\u06D4 \u0645\u062D\u0641\u0648\u0638 \u06A9\u0631\u0646\u06D2 \u0633\u06D2 \u067E\u06C1\u0644\u06D2 \u062C\u0627\u0646\u0686 \u0644\u06CC\u06BA\u06D4",
  "panel.warnUnverified": "Cformly \u062A\u0646\u0628\u06CC\u06C1: \u0627\u0646 \u0641\u06CC\u0644\u0688\u0632 \u06A9\u06CC \u0642\u062F\u0631\u06CC\u06BA \u0642\u0627\u0626\u0645 \u0646\u06C1\u06CC\u06BA \u0631\u06C1 \u0633\u06A9\u062A\u06CC\u06BA: {list}\u06D4 \u0645\u062D\u0641\u0648\u0638 \u06A9\u0631\u0646\u06D2 \u0633\u06D2 \u067E\u06C1\u0644\u06D2 \u062C\u0627\u0646\u0686 \u0644\u06CC\u06BA\u06D4",
  "panel.saving": "\u067E\u0648\u0631\u0679\u0644 \u06A9\u06CC \u062A\u0635\u062F\u06CC\u0642 \u06A9\u0627 \u0627\u0646\u062A\u0638\u0627\u0631\u2026",
  "panel.progress": "\u062E\u0627\u0646\u06D2 \u0628\u06BE\u0631\u06D2 \u062C\u0627 \u0631\u06C1\u06D2 \u06C1\u06CC\u06BA\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO \u0633\u06CC\u0634\u0646 \u062E\u062A\u0645 \u06C1\u0648 \u06AF\u06CC\u0627 \u06C1\u06D2 \u2014 \u062F\u0648\u0628\u0627\u0631\u06C1 \u0644\u0627\u06AF \u0627\u0650\u0646 \u06A9\u0631\u06CC\u06BA\u060C \u0641\u0627\u0631\u0645 \u06A9\u06BE\u0648\u0644 \u06A9\u0631 Fill \u062F\u0628\u0627\u0626\u06CC\u06BA\u06D4 \u0622\u067E \u06A9\u06D2 \u0645\u06C1\u0645\u0627\u0646 \u06A9\u06CC \u062A\u0641\u0635\u06CC\u0644\u0627\u062A Cformly \u0627\u06CC\u067E \u0645\u06CC\u06BA \u0645\u062D\u0641\u0648\u0638 \u06C1\u06CC\u06BA\u06D4",
  "panel.portalError": "\u067E\u0648\u0631\u0679\u0644 \u0646\u06D2 \u0645\u0633\u0626\u0644\u06C1 \u0628\u062A\u0627\u06CC\u0627:",
  "panel.appIdFound": "\u06A9\u0627\u0645\u06CC\u0627\u0628\u06CC \u0633\u06D2 \u0641\u0627\u0626\u0644 \u06C1\u0648 \u06AF\u0626\u06CC\u06D4 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0622\u0626\u06CC \u0688\u06CC:",
  "panel.scanHint": "Cformly \u0627\u06CC\u067E \u06A9\u06BE\u0648\u0644\u06CC\u06BA \u2192 \u067E\u0648\u0631\u0679\u0644 \u067E\u0631 \u0628\u06BE\u06CC\u062C\u06CC\u06BA \u2192 \u06A9\u0645\u067E\u06CC\u0648\u0679\u0631 \u0633\u06D2 \u0627\u0633\u06A9\u06CC\u0646 \u06A9\u0631\u06CC\u06BA \u0627\u0648\u0631 \u0627\u0633 \u06A9\u0648\u0688 \u067E\u0631 \u06A9\u06CC\u0645\u0631\u06C1 \u0631\u06A9\u06BE\u06CC\u06BA \u2014 \u06CC\u0627 \u0622\u0626\u06CC \u0688\u06CC \u06A9\u0627\u067E\u06CC \u06A9\u0631\u06CC\u06BA\u06D4",
  "panel.copy": "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0622\u0626\u06CC \u0688\u06CC \u06A9\u0627\u067E\u06CC \u06A9\u0631\u06CC\u06BA",
  "panel.copied": "\u06A9\u0627\u067E\u06CC \u06C1\u0648 \u06AF\u06CC\u0627\u06D4",
  "panel.confirmNotDetected": "\u062A\u0635\u062F\u06CC\u0642 \u0646\u06C1\u06CC\u06BA \u0645\u0644\u06CC \u2014 \u0686\u06CC\u06A9 \u06A9\u0631\u06CC\u06BA \u06A9\u06C1 \u067E\u0648\u0631\u0679\u0644 \u0646\u06D2 \u0645\u062D\u0641\u0648\u0638 \u06A9\u06CC\u0627 \u06C1\u06D2 \u06CC\u0627 \u0646\u06C1\u06CC\u06BA\u060C \u067E\u06BE\u0631 \u0622\u06AF\u06D2 \u0628\u0691\u06BE\u06CC\u06BA\u06D4",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "\u0645\u06C1\u0645\u0627\u0646 \u06A9\u06CC \u062A\u0635\u0648\u06CC\u0631 \u0645\u0646\u0633\u0644\u06A9 \u06A9\u0631\u0646\u06D2 \u06A9\u06D2 \u0644\u06CC\u06D2 \u06CC\u06C1\u0627\u06BA \u0686\u06BE\u0648\u0691\u06CC\u06BA",
  "panel.photoBrowse": "\u0628\u0631\u0627\u0624\u0632\u2026",
  "panel.photoAttachFailed": "\u062E\u0648\u062F\u06A9\u0627\u0631 \u0645\u0646\u0633\u0644\u06A9 \u0646\u06C1\u06CC\u06BA \u06C1\u0648 \u0633\u06A9\u06CC \u2014 \u067E\u0648\u0631\u0679\u0644 \u06A9\u0627 \u0627\u067E\u0646\u0627 \u0641\u0627\u0626\u0644 \u0645\u0646\u062A\u062E\u0628 \u06A9\u0631\u06CC\u06BA \u0628\u0679\u0646 \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06A9\u0631\u06CC\u06BA\u06D4",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "\u06CC\u06C1 \u0641\u0627\u0631\u0645 Cformly \u0633\u06D2 \u0628\u06BE\u0631\u06CC\u06BA",
  "chip.hint": "\u0627\u0633 \u06A9\u0645\u067E\u06CC\u0648\u0679\u0631 \u067E\u0631 \u0628\u06BE\u06CC\u062C\u06D2 \u06AF\u0626\u06D2 \u0645\u06C1\u0645\u0627\u0646 \u06A9\u06CC \u062A\u0641\u0635\u06CC\u0644\u0627\u062A \u06CC\u06C1\u0627\u06BA \u067E\u06CC\u0633\u0679 \u06A9\u0631\u06CC\u06BA (\u06CC\u0627 \u0679\u06CC\u06A9\u0633\u0679 \u0641\u0627\u0626\u0644 \u06CC\u06C1\u0627\u06BA \u0686\u06BE\u0648\u0691\u06CC\u06BA)\u060C \u067E\u06BE\u0631 \u0641\u0627\u0631\u0645 \u0628\u06BE\u0631\u06CC\u06BA \u062F\u0628\u0627\u0626\u06CC\u06BA\u06D4",
  "chip.fill": "\u0641\u0627\u0631\u0645 \u0628\u06BE\u0631\u06CC\u06BA",
  "chip.filling": "\u0628\u06BE\u0631\u0627 \u062C\u0627 \u0631\u06C1\u0627 \u06C1\u06D2\u2026",
  "chip.empty": "\u0628\u06BE\u0631\u0646\u06D2 \u06A9\u06D2 \u0644\u06CC\u06D2 \u06A9\u0686\u06BE \u0646\u06C1\u06CC\u06BA \u2014 \u067E\u06C1\u0644\u06D2 Cformly \u0627\u06CC\u067E \u0633\u06D2 \u06A9\u0627\u067E\u06CC \u06A9\u06CC \u06AF\u0626\u06CC \u0645\u06C1\u0645\u0627\u0646 \u06A9\u06CC \u062A\u0641\u0635\u06CC\u0644\u0627\u062A \u067E\u06CC\u0633\u0679 \u06A9\u0631\u06CC\u06BA\u06D4",
  "chip.tooLarge": "\u067E\u06CC\u0633\u0679 \u06A9\u06CC\u0627 \u06AF\u06CC\u0627 \u0679\u06CC\u06A9\u0633\u0679 \u0628\u06C1\u062A \u0628\u0691\u0627 \u06C1\u06D2 \u2014 \u0635\u0631\u0641 Cformly \u0627\u06CC\u067E \u0633\u06D2 \u06A9\u0627\u067E\u06CC \u06A9\u06CC \u06AF\u0626\u06CC \u062A\u0641\u0635\u06CC\u0644\u0627\u062A \u067E\u06CC\u0633\u0679 \u06A9\u0631\u06CC\u06BA\u06D4",
  "chip.collapse": "\u0628\u0646\u062F \u06A9\u0631\u06CC\u06BA",
  "chip.mappingFallback": "\u0646\u0648\u0679: \u0645\u06CC\u067E\u0646\u06AF \u0633\u0631\u0648\u0631 \u062A\u06A9 \u0631\u0633\u0627\u0626\u06CC \u0646\u06C1\u06CC\u06BA \u06C1\u0648 \u0633\u06A9\u06CC \u2014 \u0628\u0644\u0679 \u0627\u0646 \u0641\u06CC\u0644\u0688 \u0645\u06CC\u067E \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06C1\u0648 \u0631\u06C1\u0627 \u06C1\u06D2\u060C \u062C\u0648 \u067E\u0631\u0627\u0646\u0627 \u06C1\u0648 \u0633\u06A9\u062A\u0627 \u06C1\u06D2\u06D4",
  // round-66: popup first-run onboarding
  "onboarding.title": "\u067E\u06C1\u0644\u06CC \u0628\u0627\u0631 \u06CC\u06C1\u0627\u06BA\u061F \u062A\u06CC\u0646 \u0627\u0642\u062F\u0627\u0645:",
  "onboarding.step1": "\u0627\u067E\u0646\u06D2 \u0641\u0648\u0646 \u067E\u0631: \u0645\u06C1\u0645\u0627\u0646 \u06A9\u06BE\u0648\u0644\u06CC\u06BA \u2192 \u067E\u0648\u0631\u0679\u0644 \u067E\u0631 \u0628\u06BE\u06CC\u062C\u06CC\u06BA \u2192 \u06A9\u0645\u067E\u06CC\u0648\u0679\u0631 \u067E\u0631 \u0628\u06BE\u06CC\u062C\u06CC\u06BA\u06D4",
  "onboarding.step2": "\u0627\u0633 \u06A9\u0645\u067E\u06CC\u0648\u0679\u0631 \u067E\u0631: \u0627\u067E\u0646\u06D2 \u0622\u067E \u06A9\u0648 \u0628\u06BE\u06CC\u062C\u06CC \u06AF\u0626\u06CC \u062A\u0641\u0635\u06CC\u0644\u0627\u062A \u0646\u06CC\u0686\u06D2 \u0648\u0627\u0644\u06D2 \u062E\u0627\u0646\u06D2 \u0645\u06CC\u06BA \u067E\u06CC\u0633\u0679 \u06A9\u0631\u06CC\u06BA (\u06CC\u0627 \u0641\u0627\u0631\u0645 \u0635\u0641\u062D\u06D2 \u067E\u0631 \u0646\u06CC\u0644\u0627 Cformly \u0628\u0679\u0646 \u062F\u0628\u0627\u0626\u06CC\u06BA)\u06D4",
  "onboarding.step3": "\u0641\u0627\u0631\u0645 \u0628\u06BE\u0631\u06CC\u06BA \u062F\u0628\u0627\u0626\u06CC\u06BA \u2014 \u067E\u0648\u0631\u0679\u0644 \u0641\u0627\u0631\u0645 \u062E\u0648\u062F \u0628\u06BE\u0631 \u062C\u0627\u0626\u06D2 \u06AF\u0627\u06D4 \u062A\u0635\u0648\u06CC\u0631\u060C \u0633\u06CC\u06A9\u06CC\u0648\u0631\u0679\u06CC \u06A9\u0648\u0688 \u0627\u0648\u0631 \u0645\u062D\u0641\u0648\u0638 \u06A9\u0631\u06CC\u06BA \u0622\u067E \u06A9\u0631\u06CC\u06BA\u06D4",
  "onboarding.done": "\u0633\u0645\u062C\u06BE \u0644\u06CC\u0627",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{total} \u0645\u06CC\u06BA \u0633\u06D2 {filled} \u0641\u06CC\u0644\u0688\u0632 {time} \u067E\u0631 \u0628\u06BE\u0631\u06CC \u06AF\u0626\u06CC \u062A\u06BE\u06CC\u06BA\u06D4 \u062F\u0648\u0628\u0627\u0631\u06C1 \u0628\u06BE\u0631\u0646\u06D2 \u06A9\u06D2 \u0644\u06CC\u06D2 \u062F\u0648\u0628\u0627\u0631\u06C1 \u0634\u0631\u0648\u0639 \u06A9\u0631\u06CC\u06BA\u06D4",
  "resume.button": "\u062F\u0648\u0628\u0627\u0631\u06C1 \u0628\u06BE\u0631\u06CC\u06BA",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "\u06CC\u06C1 \u067E\u0648\u0631\u0679\u0644 \u0635\u0641\u062D\u06C1 Cformly \u06A9\u0648 \u0645\u0639\u0644\u0648\u0645 Form III \u062C\u06CC\u0633\u0627 \u0646\u06C1\u06CC\u06BA \u0644\u06AF \u0631\u06C1\u0627 \u2014 \u0645\u0645\u06A9\u0646 \u06C1\u06D2 \u067E\u0648\u0631\u0679\u0644 \u0628\u062F\u0644 \u06AF\u06CC\u0627 \u06C1\u0648\u06D4 \u0627\u0633 \u0628\u0627\u0631 Cformly \u0627\u06CC\u067E \u0633\u06D2 \u0645\u06C1\u0645\u0627\u0646 \u0641\u06CC\u0644\u0688\u0632 \u06A9\u0627\u067E\u06CC \u06A9\u0631 \u06A9\u06D2 \u062E\u0648\u062F \u0628\u06BE\u0631\u06CC\u06BA\u061B \u06C1\u0645 \u0627\u067E \u0688\u06CC\u0679\u0633 \u06A9\u06CC \u062C\u0627\u0646\u0686 \u06A9\u0631 \u0631\u06C1\u06D2 \u06C1\u06CC\u06BA\u06D4",
  "canary.detail": "\u0627\u0633 \u0635\u0641\u062D\u06D2 \u067E\u0631 Cformly \u06A9\u0648 \u0645\u0639\u0644\u0648\u0645 {total} \u0641\u06CC\u0644\u0688\u0632 \u0645\u06CC\u06BA \u0633\u06D2 \u0635\u0631\u0641 {found} \u0645\u0644\u06CC\u06BA\u06D4",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "\u0645\u06C1\u0645\u0627\u0646\u0648\u06BA \u06A9\u06CC \u0642\u0637\u0627\u0631",
  "queue.add": "\u0642\u0637\u0627\u0631 \u0645\u06CC\u06BA \u0634\u0627\u0645\u0644 \u06A9\u0631\u06CC\u06BA",
  "queue.fill": "\u0628\u06BE\u0631\u06CC\u06BA",
  "queue.remove": "\u06C1\u0679\u0627\u0626\u06CC\u06BA",
  "queue.unnamed": "\u0645\u06C1\u0645\u0627\u0646",
  "queue.added": "{name} \u06A9\u0648 \u0642\u0637\u0627\u0631 \u0645\u06CC\u06BA \u0634\u0627\u0645\u0644 \u06A9\u0631 \u062F\u06CC\u0627 \u06AF\u06CC\u0627\u06D4",
  "queue.duplicate": "\u06CC\u06C1 \u0645\u06C1\u0645\u0627\u0646 \u067E\u06C1\u0644\u06D2 \u06C1\u06CC \u0642\u0637\u0627\u0631 \u0645\u06CC\u06BA \u06C1\u06D2\u06D4",
  "queue.full": "\u0642\u0637\u0627\u0631 \u0628\u06BE\u0631 \u0686\u06A9\u06CC \u06C1\u06D2 ({max} \u0645\u06C1\u0645\u0627\u0646)\u06D4 \u067E\u06C1\u0644\u06D2 \u06A9\u0633\u06CC \u0645\u06C1\u0645\u0627\u0646 \u06A9\u0627 \u0641\u0627\u0631\u0645 \u0628\u06BE\u0631\u06CC\u06BA \u06CC\u0627 \u0627\u0633\u06D2 \u06C1\u0679\u0627\u0626\u06CC\u06BA\u06D4",
  "queue.hint": "\u0628\u06BE\u0631\u0646\u06D2 \u06A9\u06D2 \u0627\u0646\u062A\u0638\u0627\u0631 \u0645\u06CC\u06BA \u0645\u06C1\u0645\u0627\u0646\u06D4 \u0645\u06A9\u0645\u0644 \u0628\u06BE\u0631\u0627\u0626\u06CC \u06A9\u06D2 \u0628\u0639\u062F \u0645\u06C1\u0645\u0627\u0646 \u0642\u0637\u0627\u0631 \u0633\u06D2 \u06C1\u0679\u0627 \u062F\u06CC\u0627 \u062C\u0627\u062A\u0627 \u06C1\u06D2\u061B \u0628\u0631\u0627\u0624\u0632\u0631 \u0628\u0646\u062F \u06C1\u0648\u0646\u06D2 \u067E\u0631 \u0642\u0637\u0627\u0631 \u0635\u0627\u0641 \u06C1\u0648 \u062C\u0627\u062A\u06CC \u06C1\u06D2\u06D4",
  "queue.unavailable": "\u0627\u0633 \u0628\u0631\u0627\u0624\u0632\u0631 \u0645\u06CC\u06BA \u0645\u06C1\u0645\u0627\u0646\u0648\u06BA \u06A9\u06CC \u0642\u0637\u0627\u0631 \u062F\u0633\u062A\u06CC\u0627\u0628 \u0646\u06C1\u06CC\u06BA \u06C1\u06D2\u06D4",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "\u06CC\u06C1 FRRO \u0679\u06CC\u0628 Cformly \u06A9\u06D2 \u0627\u0646\u0633\u0679\u0627\u0644 \u06CC\u0627 \u0627\u067E\u0688\u06CC\u0679 \u06C1\u0648\u0646\u06D2 \u0633\u06D2 \u067E\u06C1\u0644\u06D2 \u06A9\u06BE\u0648\u0644\u0627 \u06AF\u06CC\u0627 \u062A\u06BE\u0627\u06D4 \u0627\u0633 \u0679\u06CC\u0628 \u06A9\u0648 \u0627\u06CC\u06A9 \u0628\u0627\u0631 \u062F\u0648\u0628\u0627\u0631\u06C1 \u0644\u0648\u0688 \u06A9\u0631\u06CC\u06BA (F5)\u060C \u067E\u06BE\u0631 Fill \u062F\u0628\u0627\u0626\u06CC\u06BA\u06D4",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "\u0641\u0627\u0631\u0645 \u0645\u06CC\u067E\u0646\u06AF",
  "settings.mapVersion": "\u0648\u0631\u0698\u0646",
  "settings.mapLastVerified": "\u0622\u062E\u0631\u06CC \u062A\u0635\u062F\u06CC\u0642",
  "settings.mapFetchedAt": "\u062D\u0627\u0635\u0644 \u06A9\u06CC\u0627 \u06AF\u06CC\u0627",
  "settings.mapSignature": "Ed25519 \u062F\u0633\u062A\u062E\u0637",
  "settings.mapRefresh": "\u0627\u0628 \u0631\u06CC\u0641\u0631\u06CC\u0634 \u06A9\u0631\u06CC\u06BA",
  "settings.mapRefreshed": "\u0645\u06CC\u067E\u0646\u06AF \u0631\u06CC\u0641\u0631\u06CC\u0634 \u06C1\u0648 \u06AF\u0626\u06CC\u06D4",
  "settings.mapRefreshFailed": "\u0645\u06CC\u067E\u0646\u06AF \u0631\u06CC\u0641\u0631\u06CC\u0634 \u0646\u06C1\u06CC\u06BA \u06C1\u0648 \u0633\u06A9\u06CC - \u062F\u0633\u062A\u06CC\u0627\u0628 \u0628\u06C1\u062A\u0631\u06CC\u0646 \u06A9\u0627\u067E\u06CC \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u06A9\u06CC \u062C\u0627 \u0631\u06C1\u06CC \u06C1\u06D2\u06D4",
  "settings.mapStatusRemote": "\u062A\u0635\u062F\u06CC\u0642 \u0634\u062F\u06C1 - \u0645\u06CC\u067E\u0646\u06AF \u0633\u0631\u0648\u0631 \u0633\u06D2 \u062D\u0627\u0635\u0644 \u06A9\u0631\u062F\u06C1 \u062A\u0627\u0632\u06C1 \u06A9\u0627\u067E\u06CC\u06D4",
  "settings.mapStatusCached": "\u062A\u0635\u062F\u06CC\u0642 \u0634\u062F\u06C1 - \u062D\u0627\u0644\u06CC\u06C1 \u06A9\u06CC\u0634 \u06A9\u0627\u067E\u06CC\u06D4",
  "settings.mapStatusBundled": "\u0634\u0627\u0645\u0644 \u0628\u0646\u06CC\u0627\u062F\u06CC \u06A9\u0627\u067E\u06CC (\u0633\u0631\u0648\u0631 \u062F\u0633\u062A\u06CC\u0627\u0628 \u0646\u06C1\u06CC\u06BA)\u06D4 \u062F\u0633\u062A\u062E\u0637 \u0645\u062D\u0641\u0648\u0638 \u06C1\u06D2\u06D4",
  "settings.mapStatusTampered": "\u062F\u0633\u062A\u062E\u0637 \u062C\u0627\u0646\u0686 \u0646\u0627\u06A9\u0627\u0645 - \u06CC\u06C1 \u06A9\u0627\u067E\u06CC \u0645\u0633\u062A\u0631\u062F \u06A9\u0631 \u062F\u06CC \u06AF\u0626\u06CC \u06C1\u06D2 \u0627\u0648\u0631 \u0627\u0633\u062A\u0639\u0645\u0627\u0644 \u0645\u06CC\u06BA \u0646\u06C1\u06CC\u06BA\u06D4",
  "chip.mappingUnavailable": "\u0641\u0627\u0631\u0645 \u0645\u06CC\u067E\u0646\u06AF \u0644\u0648\u0688 \u0646\u06C1\u06CC\u06BA \u06C1\u0648 \u0633\u06A9\u06CC \u2014 \u0627\u06CC\u06A9\u0633\u0679\u06CC\u0646\u0634\u0646 \u06A9\u0627 \u0628\u06CC\u06A9 \u06AF\u0631\u0627\u0624\u0646\u0688 \u0648\u0631\u06A9\u0631 \u062C\u0648\u0627\u0628 \u0646\u06C1\u06CC\u06BA \u062F\u06D2 \u0631\u06C1\u0627\u06D4 \u067E\u0648\u0631\u0679\u0644 \u0679\u06CC\u0628 \u062F\u0648\u0628\u0627\u0631\u06C1 \u0644\u0648\u0688 \u06A9\u0631 \u06A9\u06D2 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4",
  "popup.timeoutMapping": "\u0641\u0627\u0631\u0645 \u0645\u06CC\u067E\u0646\u06AF \u0644\u0648\u0688 \u06C1\u0648\u0646\u06D2 \u06A9\u0627 \u0648\u0642\u062A \u062E\u062A\u0645 \u06C1\u0648 \u06AF\u06CC\u0627 ({seconds} \u0633\u06CC\u06A9\u0646\u0688)\u06D4 \u06A9\u0646\u06A9\u0634\u0646 \u0686\u06CC\u06A9 \u06A9\u0631 \u06A9\u06D2 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4",
  "popup.timeoutNoProgress": "\u0628\u06BE\u0631\u0627\u0626\u06CC {seconds} \u0633\u06CC\u06A9\u0646\u0688 \u0645\u06CC\u06BA \u0634\u0631\u0648\u0639 \u0646\u06C1\u06CC\u06BA \u06C1\u0648\u0626\u06CC \u2014 Form III \u0635\u0641\u062D\u06C1 \u062C\u0648\u0627\u0628 \u0646\u06C1\u06CC\u06BA \u062F\u06D2 \u0631\u06C1\u0627\u06D4 \u0679\u06CC\u0628 \u062F\u0648\u0628\u0627\u0631\u06C1 \u0644\u0648\u0688 \u06A9\u0631 \u06A9\u06D2 \u062F\u0648\u0628\u0627\u0631\u06C1 \u06A9\u0648\u0634\u0634 \u06A9\u0631\u06CC\u06BA\u06D4",
  "popup.timeoutStalled": "\u0628\u06BE\u0631\u0627\u0626\u06CC {seconds} \u0633\u06CC\u06A9\u0646\u0688 \u0633\u06D2 \u0631\u06A9 \u06AF\u0626\u06CC \u06C1\u06D2 \u2014 Form III \u0635\u0641\u062D\u06D2 \u0646\u06D2 \u062C\u0648\u0627\u0628 \u062F\u06CC\u0646\u0627 \u0628\u0646\u062F \u06A9\u0631 \u062F\u06CC\u0627 \u06C1\u06D2\u06D4",
  "popup.timeoutCap": "\u0628\u06BE\u0631\u0627\u0626\u06CC \u06A9\u0644 \u0648\u0642\u062A \u06A9\u06CC \u062D\u062F ({seconds} \u0633\u06CC\u06A9\u0646\u0688) \u0633\u06D2 \u0628\u0691\u06BE \u06AF\u0626\u06CC \u0627\u0648\u0631 \u0631\u0648\u06A9 \u062F\u06CC \u06AF\u0626\u06CC \u06C1\u06D2\u06D4",
  "popup.preview": "\u062A\u0628\u062F\u06CC\u0644\u06CC\u0627\u06BA \u062F\u06CC\u06A9\u06BE\u06CC\u06BA",
  "popup.previewApply": "\u0644\u0627\u06AF\u0648 \u06A9\u0631\u06CC\u06BA \u2014 \u0641\u0627\u0631\u0645 \u0628\u06BE\u0631\u06CC\u06BA",
  "popup.undo": "\u067E\u0686\u06BE\u0644\u06CC \u0641\u0644 \u0648\u0627\u067E\u0633 \u0644\u06CC\u06BA",
  "popup.undoDone": "{total} \u0645\u06CC\u06BA \u0633\u06D2 {restored} \u0641\u06CC\u0644\u0688\u0632 \u0627\u067E\u0646\u06CC \u067E\u0631\u0627\u0646\u06CC \u0642\u062F\u0631\u06CC\u06BA \u0628\u062D\u0627\u0644 \u06A9\u0631 \u062F\u06CC \u06AF\u0626\u06CC \u06C1\u06CC\u06BA\u06D4",
  "popup.undoPartial": "{total} \u0645\u06CC\u06BA \u0633\u06D2 {restored} \u0628\u062D\u0627\u0644 \u06C1\u0648\u0626\u06D2\u061B {failed} \u0628\u062D\u0627\u0644 \u0646\u06C1\u06CC\u06BA \u06C1\u0648 \u0633\u06A9\u06D2 (\u0635\u0641\u062D\u06C1 \u062F\u0648\u0628\u0627\u0631\u06C1 \u0628\u0646 \u0686\u06A9\u0627 \u06C1\u0648 \u06AF\u0627)\u06D4",
  "popup.undoStale": "\u0641\u0644 \u06A9\u06D2 \u0628\u0639\u062F \u0635\u0641\u062D\u06C1 \u0628\u062F\u0644 \u06AF\u06CC\u0627 \u2014 \u0628\u062D\u0627\u0644\u06CC \u0646\u0627\u0645\u06A9\u0645\u0644 \u06C1\u0648 \u0633\u06A9\u062A\u06CC \u06C1\u06D2\u06D4",
  "popup.undoNone": "\u0648\u0627\u067E\u0633 \u0644\u06CC\u0646\u06D2 \u06A9\u06D2 \u0644\u06CC\u06D2 \u06A9\u0686\u06BE \u0646\u06C1\u06CC\u06BA \u2014 \u0627\u0633 \u0633\u06CC\u0634\u0646 \u0645\u06CC\u06BA \u0627\u0633 \u0679\u06CC\u0628 \u067E\u0631 \u06A9\u0648\u0626\u06CC \u0641\u0644 \u0646\u06C1\u06CC\u06BA \u06C1\u0648\u0626\u06CC\u06D4",
  "popup.previewUnresolved": "\u0627\u0633 \u0635\u0641\u062D\u06D2 \u067E\u0631 \u0646\u06C1\u06CC\u06BA \u0645\u0644\u0627",
  "popup.previewManual": "\u062F\u0633\u062A\u06CC \u0645\u0631\u062D\u0644\u06C1",
  "popup.previewNoValue": "(\u0641\u0631\u0627\u06C1\u0645 \u0646\u06C1\u06CC\u06BA \u06A9\u06CC\u0627 \u06AF\u06CC\u0627)"
};

// src/i18n/bn.ts
var bn = {
  // popup
  "popup.title": "Cformly \u0985\u099F\u09CB-\u09AB\u09BF\u09B2",
  "popup.eyebrow": "\u0985\u099F\u09CB-\u09AB\u09BF\u09B2",
  "popup.bandSub": "FRRO Form III \xB7 \u099A\u09C7\u0995-\u0987\u09A8\u09C7\u09B0 \u09E8\u09EA \u0998\u09A3\u09CD\u099F\u09BE\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7",
  "popup.fillFromClipboard": "\u0995\u09CD\u09B2\u09BF\u09AA\u09AC\u09CB\u09B0\u09CD\u09A1 \u09A5\u09C7\u0995\u09C7 \u09AB\u09B0\u09CD\u09AE \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8",
  "popup.fillHint": "\u09AA\u09CD\u09B0\u09A5\u09AE\u09C7 Cformly \u0985\u09CD\u09AF\u09BE\u09AA \u09A5\u09C7\u0995\u09C7 \u0985\u09A4\u09BF\u09A5\u09BF\u09B0 \u0998\u09B0\u0997\u09C1\u09B2\u09BF \u0995\u09AA\u09BF \u0995\u09B0\u09C1\u09A8, \u09A4\u09BE\u09B0\u09AA\u09B0 \u098F\u0987 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2 \u09AB\u09B0\u09CD\u09AE\u099F\u09BF \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.clipboardReadFailed": "\u0995\u09CD\u09B2\u09BF\u09AA\u09AC\u09CB\u09B0\u09CD\u09A1 \u09AA\u09A1\u09BC\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF\u0964 \u09AC\u09CD\u09B0\u09BE\u0989\u099C\u09BE\u09B0\u09C7\u09B0 \u0995\u09CD\u09B2\u09BF\u09AA\u09AC\u09CB\u09B0\u09CD\u09A1 \u0985\u09A8\u09C1\u09AE\u09A4\u09BF\u0997\u09C1\u09B2\u09BF \u09A6\u09C7\u0996\u09C1\u09A8\u0964",
  "popup.clipboardEmpty": "\u0995\u09CD\u09B2\u09BF\u09AA\u09AC\u09CB\u09B0\u09CD\u09A1\u09C7 Cformly-\u09B0 \u0998\u09B0\u0997\u09C1\u09B2\u09BF \u09A8\u09C7\u0987\u0964 \u09AA\u09CD\u09B0\u09A5\u09AE\u09C7 Cformly \u0985\u09CD\u09AF\u09BE\u09AA \u09A5\u09C7\u0995\u09C7 \u0985\u09A4\u09BF\u09A5\u09BF\u09B0 \u0998\u09B0\u0997\u09C1\u09B2\u09BF \u0995\u09AA\u09BF \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.settings": "\u09B8\u09C7\u099F\u09BF\u0982\u09B8",
  "popup.loadingMapping": "\u09AB\u09B0\u09CD\u09AE \u09AE\u09CD\u09AF\u09BE\u09AA\u09BF\u0982 \u09B2\u09CB\u09A1 \u09B9\u099A\u09CD\u099B\u09C7...",
  "popup.filling": "\u09AB\u09B0\u09CD\u09AE \u09AA\u09C2\u09B0\u09A3 \u09B9\u099A\u09CD\u099B\u09C7...",
  "popup.fillingProgress": "\u09AA\u09C2\u09B0\u09A3 \u09B9\u099A\u09CD\u099B\u09C7\u2026 \u09AB\u09BF\u09B2\u09CD\u09A1 {completed}/{total}",
  "popup.noTab": "\u0995\u09CB\u09A8\u09CB \u09B8\u0995\u09CD\u09B0\u09BF\u09AF\u09BC \u099F\u09CD\u09AF\u09BE\u09AC \u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF\u0964",
  "popup.filled": "\u09AA\u09CD\u09B0\u09AF\u09BC\u09CB\u099C\u09A8\u09C0\u09AF\u09BC \u0998\u09B0 \u09AA\u09C2\u09B0\u09A3 \u09B9\u09AF\u09BC\u09C7\u099B\u09C7: {required}-\u098F\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 {filledRequired} ({filled} \u09AE\u09CB\u099F \u09AA\u09C2\u09B0\u09A3)",
  "popup.portalMismatch": "\u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2 \u09AC\u09A6\u09B2\u09C7\u09B0 \u09B2\u0995\u09CD\u09B7\u09A3 \u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u0997\u09C7\u099B\u09C7 (DOM \u09AC\u09A6\u09B2\u09C7\u099B\u09C7)\u0964 Cformly \u0985\u09CD\u09AF\u09BE\u09AA\u09C7 \u0985\u09A4\u09BF\u09A5\u09BF\u09B0 \u0998\u09B0\u0997\u09C1\u09B2\u09BF \u0986\u09AC\u09BE\u09B0 \u0995\u09AA\u09BF \u0995\u09B0\u09C7 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.missingElements": "\u0985\u09A8\u09C1\u09AA\u09B8\u09CD\u09A5\u09BF\u09A4 \u0989\u09AA\u09BE\u09A6\u09BE\u09A8: {list}",
  "popup.missingValues": "\u0985\u09A8\u09C1\u09AA\u09B8\u09CD\u09A5\u09BF\u09A4 \u09AE\u09BE\u09A8: {list}",
  "popup.manualFields": "\u09AE\u09CD\u09AF\u09BE\u09A8\u09C1\u09AF\u09BC\u09BE\u09B2 \u09A7\u09BE\u09AA \u09AA\u09CD\u09B0\u09AF\u09BC\u09CB\u099C\u09A8: {list}",
  "popup.unsupportedFields": "\u09AF\u09C7 \u0998\u09B0\u0997\u09C1\u09B2\u09BF \u09B8\u09CD\u09AC\u09AF\u09BC\u0982\u0995\u09CD\u09B0\u09BF\u09AF\u09BC\u09AD\u09BE\u09AC\u09C7 \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09BE \u09AF\u09BE\u09AC\u09C7 \u09A8\u09BE: {list}",
  "popup.tooLongFields": "\u098F\u0987 \u0998\u09B0\u0997\u09C1\u09B2\u09BF\u09B0 \u099C\u09A8\u09CD\u09AF \u09AE\u09BE\u09A8\u0997\u09C1\u09B2\u09BF \u0996\u09C1\u09AC \u09B2\u09AE\u09CD\u09AC\u09BE \u2014 \u0995\u09BF\u099B\u09C1\u0987 \u09B2\u09C7\u0996\u09BE \u09B9\u09AF\u09BC\u09A8\u09BF, \u099B\u09CB\u099F \u09AE\u09BE\u09A8 \u099F\u09BE\u0987\u09AA \u0995\u09B0\u09C1\u09A8: {list}",
  "popup.unverifiedFields": "\u098F\u0987 \u0998\u09B0\u0997\u09C1\u09B2\u09BF \u09A6\u09C7\u0996\u09C7 \u09A8\u09BF\u09A8 \u2014 \u09AE\u09BE\u09A8\u099F\u09BF \u09B8\u09AE\u09CD\u09AD\u09AC\u09A4 \u09AC\u09B8\u09C7\u09A8\u09BF: {list}",
  "popup.applicationId": "\u0986\u09AC\u09C7\u09A6\u09A8 ID: {id}",
  "popup.accommodationMismatch": "\u09B8\u09A4\u09B0\u09CD\u0995\u09A4\u09BE: FRRO \u09B8\u09C7\u09B6\u09A8\u099F\u09BF \u0985\u09A8\u09CD\u09AF \u0995\u09CB\u09A8\u09CB \u09AA\u09CD\u09B0\u09AA\u09BE\u09B0\u09CD\u099F\u09BF\u09B0 \u09B9\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7\u0964 \u099C\u09AE\u09BE \u09A6\u09C7\u0993\u09AF\u09BC\u09BE\u09B0 \u0986\u0997\u09C7 \u09AF\u09BE\u099A\u09BE\u0987 \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.attention": "\u0995\u09BF\u099B\u09C1 \u0998\u09B0\u09C7 \u09AE\u09A8\u09CB\u09AF\u09CB\u0997 \u09A6\u09B0\u0995\u09BE\u09B0\u0964 Cformly \u0985\u09CD\u09AF\u09BE\u09AA\u09C7 \u0985\u09A4\u09BF\u09A5\u09BF\u09B0 \u0998\u09B0\u0997\u09C1\u09B2\u09BF \u0986\u09AC\u09BE\u09B0 \u0995\u09AA\u09BF \u0995\u09B0\u09C7 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.openPrint": "Individual Print \u0996\u09C1\u09B2\u09C1\u09A8",
  "popup.printNoId": "\u098F\u0996\u09A8\u0993 \u0995\u09CB\u09A8\u09CB \u0986\u09AC\u09C7\u09A6\u09A8 ID \u0995\u09CD\u09AF\u09BE\u09AA\u099A\u09BE\u09B0 \u09B9\u09AF\u09BC\u09A8\u09BF \u2014 \u09AA\u09CD\u09B0\u09A5\u09AE\u09C7 \u09AB\u09B0\u09CD\u09AE\u099F\u09BF \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.printSent": "ID {id}-\u098F\u09B0 \u09AB\u09BE\u0987\u09B2 \u0995\u09B0\u09BE \u0986\u09AC\u09C7\u09A6\u09A8\u099F\u09BF \u0986\u09AC\u09BE\u09B0 \u0996\u09CB\u09B2\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964 PDF \u09A1\u09BE\u0989\u09A8\u09B2\u09CB\u09A1 \u0995\u09B0\u09A4\u09C7 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2\u09C7\u09B0 Individual Print \u09AE\u09C7\u09A8\u09C1 \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.formFilled": "\u09AB\u09B0\u09CD\u09AE \u09AA\u09C2\u09B0\u09A3 \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2\u09C7 \u09AA\u09B0\u09CD\u09AF\u09BE\u09B2\u09CB\u099A\u09A8\u09BE \u0995\u09B0\u09C7 \u099C\u09AE\u09BE \u09A6\u09BF\u09A8\u0964",
  "popup.fillError": "\u09AA\u09C2\u09B0\u09A3\u09C7 \u09A4\u09CD\u09B0\u09C1\u099F\u09BF: {message}",
  "popup.connectionFailed": "FRRO \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2 \u09AA\u09C7\u099C\u09C7 \u09AA\u09CC\u0981\u099B\u09BE\u09A8\u09CB \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF\u0964 \u098F\u0987 \u099F\u09CD\u09AF\u09BE\u09AC\u09C7 Form III \u09AA\u09C7\u099C\u099F\u09BF \u0996\u09C1\u09B2\u09C7 \u0986\u09AC\u09BE\u09B0 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.unknownError": "\u0985\u099C\u09BE\u09A8\u09BE",
  "popup.apiBaseFallback": "\u09B8\u09A4\u09B0\u09CD\u0995\u09A4\u09BE: \u09B8\u0982\u09B0\u0995\u09CD\u09B7\u09BF\u09A4 API URL \u0985\u09AC\u09C8\u09A7 \u2014 \u09A1\u09BF\u09AB\u09B2\u09CD\u099F \u09AC\u09CD\u09AF\u09AC\u09B9\u09C3\u09A4 \u09B9\u099A\u09CD\u099B\u09C7\u0964 Settings-\u098F \u098F\u099F\u09BF \u0986\u09AA\u09A1\u09C7\u099F \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.mappingFallback": "\u09B8\u09A4\u09B0\u09CD\u0995\u09A4\u09BE: \u09AE\u09CD\u09AF\u09BE\u09AA\u09BF\u0982 \u09B8\u09BE\u09B0\u09CD\u09AD\u09BE\u09B0\u09C7 \u09AA\u09CC\u0981\u099B\u09BE\u09A8\u09CB \u09AF\u09BE\u099A\u09CD\u099B\u09C7 \u09A8\u09BE \u2014 \u09AC\u09BF\u09B2\u09CD\u099F-\u0987\u09A8 \u09AB\u09BF\u09B2\u09CD\u09A1 \u09AE\u09CD\u09AF\u09BE\u09AA \u09AC\u09CD\u09AF\u09AC\u09B9\u09C3\u09A4 \u09B9\u099A\u09CD\u099B\u09C7, \u09AF\u09BE \u09AA\u09C1\u09B0\u09CB\u09A8\u09CB \u09B9\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7\u0964",
  // settings
  "settings.title": "Cformly \u09B8\u09C7\u099F\u09BF\u0982\u09B8",
  "settings.eyebrow": "\u09B8\u09C7\u099F\u09BF\u0982\u09B8",
  "settings.bandSub": "\u09AB\u09B0\u09CD\u09AE \u09AE\u09CD\u09AF\u09BE\u09AA\u09BF\u0982 \u09B8\u09B0\u09AC\u09B0\u09BE\u09B9\u0995\u09BE\u09B0\u09C0 \u09AC\u09CD\u09AF\u09BE\u0995\u098F\u09A8\u09CD\u09A1 \u0995\u09A8\u09AB\u09BF\u0997\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "\u09AB\u09B0\u09CD\u09AE \u09AE\u09CD\u09AF\u09BE\u09AA\u09BF\u0982 \u09B8\u09B0\u09AC\u09B0\u09BE\u09B9\u0995\u09BE\u09B0\u09C0 \u09AC\u09CD\u09AF\u09BE\u0995\u098F\u09A8\u09CD\u09A1\u0964 \u09B6\u09C1\u09A7\u09C1 HTTPS; localhost \u09B6\u09C1\u09A7\u09C1 \u09A1\u09C7\u09AD\u09C7\u09B2\u09AA\u09AE\u09C7\u09A8\u09CD\u099F \u09AC\u09BF\u09B2\u09CD\u09A1\u09C7 \u0995\u09BE\u099C \u0995\u09B0\u09C7\u0964",
  "settings.save": "\u09B8\u0982\u09B0\u0995\u09CD\u09B7\u09A3 \u0995\u09B0\u09C1\u09A8",
  "settings.back": "\u09AB\u09BF\u09B0\u09C7 \u09AF\u09BE\u09A8",
  "settings.backInTab": "\u09B8\u09C7\u099F\u09BF\u0982\u09B8 \u098F\u0995\u099F\u09BF \u099F\u09CD\u09AF\u09BE\u09AC \u09B9\u09BF\u09B8\u09C7\u09AC\u09C7 \u0996\u09CB\u09B2\u09BE \u2014 \u09AB\u09BF\u09B2 \u09AA\u09AA\u0986\u09AA\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF Cformly \u099F\u09C1\u09B2\u09AC\u09BE\u09B0 \u0986\u0987\u0995\u09A8 \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964",
  "settings.urlEmpty": "URL \u0996\u09BE\u09B2\u09BF \u09B0\u09BE\u0996\u09BE \u09AF\u09BE\u09AC\u09C7 \u09A8\u09BE\u0964",
  "settings.httpsOnly": "\u09A8\u09BF\u09B0\u09BE\u09AA\u09A4\u09CD\u09A4\u09BE\u09B0 \u099C\u09A8\u09CD\u09AF \u09B6\u09C1\u09A7\u09C1 HTTPS URL \u0985\u09A8\u09C1\u09AE\u09CB\u09A6\u09BF\u09A4\u0964 \u09AA\u09CD\u09B0\u09CB\u09A1\u09BE\u0995\u09B6\u09A8\u09C7 https:// \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964",
  "settings.hostNotAllowed": "URL hostname \u0985\u09AC\u09B6\u09CD\u09AF\u0987 localhost \u09AC\u09BE *.cformly.com \u09B9\u09AC\u09C7 (\u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u0997\u09C7\u099B\u09C7: {host})\u0964",
  "settings.invalidUrl": "\u0985\u09AC\u09C8\u09A7 URL\u0964 https:// \u0985\u09A8\u09CD\u09A4\u09B0\u09CD\u09AD\u09C1\u0995\u09CD\u09A4 \u0995\u09B0\u09C1\u09A8",
  "settings.urlPathNotAllowed": "\u09B6\u09C1\u09A7\u09C1 \u09AE\u09C2\u09B2 origin \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8 \u2014 path, query \u0993 #fragment \u09B8\u09B0\u09BE\u09A8\u0964",
  "settings.loopbackNotGranted": "Localhost API URL \u09B6\u09C1\u09A7\u09C1 \u09A1\u09C7\u09AD\u09C7\u09B2\u09AA\u09AE\u09C7\u09A8\u09CD\u099F \u09AC\u09BF\u09B2\u09CD\u09A1\u09C7 \u0995\u09BE\u099C \u0995\u09B0\u09C7\u0964 \u098F\u0987 \u09AC\u09BF\u09B2\u09CD\u09A1 \u09B6\u09C1\u09A7\u09C1 https:// \u09B9\u09CB\u09B8\u09CD\u099F\u09C7 \u09AA\u09CC\u0981\u099B\u09BE\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7\u0964",
  "settings.saved": "\u09B8\u0982\u09B0\u0995\u09CD\u09B7\u09BF\u09A4\u0964",
  "settings.saveError": "\u09B8\u0982\u09B0\u0995\u09CD\u09B7\u09A3 \u0995\u09B0\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF\u0964 \u0986\u09AC\u09BE\u09B0 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8\u0964",
  "settings.langLabel": "\u09AD\u09BE\u09B7\u09BE",
  "settings.langEnglish": "English",
  "settings.langHindi": "\u0939\u093F\u0928\u094D\u0926\u0940",
  "settings.langAuto": "\u09AC\u09CD\u09B0\u09BE\u0989\u099C\u09BE\u09B0 \u0985\u09A8\u09C1\u09B8\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8",
  "settings.langHint": "\u0986\u09AA\u09A8\u09BE\u09B0 \u09AA\u099B\u09A8\u09CD\u09A6 \u09A8\u09BE \u09B9\u0993\u09AF\u09BC\u09BE \u09AA\u09B0\u09CD\u09AF\u09A8\u09CD\u09A4 \u09AC\u09CD\u09B0\u09BE\u0989\u099C\u09BE\u09B0\u09C7\u09B0 \u09AD\u09BE\u09B7\u09BE \u09AC\u09CD\u09AF\u09AC\u09B9\u09C3\u09A4 \u09B9\u09AC\u09C7\u0964",
  // round-65: paste intake + in-page filing panel
  "popup.pasteLabel": "\u0985\u09A5\u09AC\u09BE \u09AB\u09BF\u09B2\u09CD\u09A1\u0997\u09C1\u09B2\u09BF \u098F\u0996\u09BE\u09A8\u09C7 \u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09C1\u09A8",
  "popup.pdfPick": "Cformly PDF \u0996\u09C1\u09B2\u09C1\u09A8",
  "popup.pdfLoaded": "\u0985\u09A4\u09BF\u09A5\u09BF\u09B0 \u09AB\u09BF\u09B2\u09CD\u09A1 Cformly PDF \u09A5\u09C7\u0995\u09C7 \u09B2\u09CB\u09A1 \u09B9\u09AF\u09BC\u09C7\u099B\u09C7 \u2014 \u09A8\u09BF\u099A\u09C7 \u09A6\u09C7\u0996\u09C7 \u09A8\u09BF\u09A8, \u09A4\u09BE\u09B0\u09AA\u09B0 Fill Form \u099A\u09BE\u09AA\u09C1\u09A8\u0964",
  "popup.pdfRejected": "\u098F\u0987 PDF-\u098F Cformly \u09AB\u09BF\u09B2\u09CD\u09A1 \u09A8\u09C7\u0987 \u09AC\u09BE \u09B8\u09C7\u099F\u09BF \u09AA\u09A1\u09BC\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF \u2014 Cformly \u0985\u09CD\u09AF\u09BE\u09AA \u09A5\u09C7\u0995\u09C7 \u098F\u0995\u09CD\u09B8\u09AA\u09CB\u09B0\u09CD\u099F \u0995\u09B0\u09BE PDF-\u0987 \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.pastePlaceholder": "\u0995\u09AA\u09BF \u0995\u09B0\u09BE Cformly \u09AB\u09BF\u09B2\u09CD\u09A1\u0997\u09C1\u09B2\u09BF \u098F\u0996\u09BE\u09A8\u09C7 \u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09C1\u09A8",
  "popup.pasteHint": "\u0995\u09CD\u09B2\u09BF\u09AA\u09AC\u09CB\u09B0\u09CD\u09A1 \u09AC\u09CB\u09A4\u09BE\u09AE \u0995\u09BE\u099C \u09A8\u09BE \u0995\u09B0\u09B2\u09C7, \u098F\u0987 \u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09B0\u09C7 \u09AA\u09BE\u09A0\u09BE\u09A8\u09CB \u09AB\u09BF\u09B2\u09CD\u09A1\u0997\u09C1\u09B2\u09BF \u098F\u0996\u09BE\u09A8\u09C7 \u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09C1\u09A8 (\u09AC\u09BE \u099F\u09C7\u0995\u09CD\u09B8\u099F \u09AB\u09BE\u0987\u09B2 \u099B\u09C7\u09A1\u09BC\u09C7 \u09A6\u09BF\u09A8), \u09A4\u09BE\u09B0\u09AA\u09B0 \u09AB\u09BF\u09B2 \u099A\u09BE\u09AA\u09C1\u09A8\u0964",
  "popup.payloadTooLarge": "\u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09BE \u099F\u09C7\u0995\u09CD\u09B8\u099F \u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC \u2014 \u09B6\u09C1\u09A7\u09C1\u09AE\u09BE\u09A4\u09CD\u09B0 Cformly \u0985\u09CD\u09AF\u09BE\u09AA \u09A5\u09C7\u0995\u09C7 \u0995\u09AA\u09BF \u0995\u09B0\u09BE \u09AB\u09BF\u09B2\u09CD\u09A1 \u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09C1\u09A8\u0964",
  "panel.title": "Cformly \u2014 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2\u09C7 \u09AB\u09BE\u0987\u09B2\u09BF\u0982 \u09B8\u09AE\u09CD\u09AA\u09C2\u09B0\u09CD\u09A3 \u0995\u09B0\u09C1\u09A8",
  "panel.dismiss": "\u09AC\u09A8\u09CD\u09A7 \u0995\u09B0\u09C1\u09A8",
  "panel.filled": "\u09AA\u09C2\u09B0\u09A3 \u09B9\u0993\u09AF\u09BC\u09BE \u09AB\u09BF\u09B2\u09CD\u09A1: {filledRequired} / {required} \u09AC\u09BE\u09A7\u09CD\u09AF\u09A4\u09BE\u09AE\u09C2\u09B2\u0995",
  "panel.photoStep": "\u0985\u09A4\u09BF\u09A5\u09BF\u09B0 \u099B\u09AC\u09BF \u09B8\u0982\u09AF\u09C1\u0995\u09CD\u09A4 \u0995\u09B0\u09C1\u09A8 (\u09AB\u09BE\u0987\u09B2 \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8 \u2192 \u0986\u09AA\u09B2\u09CB\u09A1 \u0995\u09B0\u09C1\u09A8)",
  "panel.captchaStep": "\u09B8\u09BF\u0995\u09BF\u0989\u09B0\u09BF\u099F\u09BF \u0995\u09CB\u09A1 (CAPTCHA) \u099F\u09BE\u0987\u09AA \u0995\u09B0\u09C1\u09A8",
  "panel.saveStep": "\u09B8\u09C7\u09AD \u0995\u09B0\u09C7 \u099A\u09BE\u09B2\u09BF\u09AF\u09BC\u09C7 \u09AF\u09BE\u09A8 \u099A\u09BE\u09AA\u09C1\u09A8",
  "panel.warnSession": "Cformly \u09B8\u09A4\u09B0\u09CD\u0995\u09A4\u09BE: \u098F\u0987 FRRO \u09B8\u09C7\u09B6\u09A8 \u0985\u09A8\u09CD\u09AF \u098F\u0995\u099F\u09BF \u09B8\u09AE\u09CD\u09AA\u09A4\u09CD\u09A4\u09BF\u09B0 \u09B9\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7 ({reason})\u0964 \u09B8\u09C7\u09AD \u0995\u09B0\u09BE\u09B0 \u0986\u0997\u09C7 \u09AF\u09BE\u099A\u09BE\u0987 \u0995\u09B0\u09C1\u09A8\u0964",
  "panel.warnUnverified": "Cformly \u09B8\u09A4\u09B0\u09CD\u0995\u09A4\u09BE: \u098F\u0987 \u09AB\u09BF\u09B2\u09CD\u09A1\u0997\u09C1\u09B2\u09BF\u09B0 \u09AE\u09BE\u09A8 \u09A5\u09C7\u0995\u09C7 \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF \u098F\u09AE\u09A8 \u09B9\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7: {list}\u0964 \u09B8\u09C7\u09AD \u0995\u09B0\u09BE\u09B0 \u0986\u0997\u09C7 \u09AF\u09BE\u099A\u09BE\u0987 \u0995\u09B0\u09C1\u09A8\u0964",
  "panel.saving": "\u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2\u09C7\u09B0 \u09A8\u09BF\u09B6\u09CD\u099A\u09BF\u09A4\u0995\u09B0\u09A3\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF \u0985\u09AA\u09C7\u0995\u09CD\u09B7\u09BE\u2026",
  "panel.progress": "\u09AB\u09BF\u09B2\u09CD\u09A1 \u09AA\u09C2\u09B0\u09A3 \u09B9\u099A\u09CD\u099B\u09C7\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO \u09B8\u09C7\u09B6\u09A8 \u09B6\u09C7\u09B7 \u09B9\u09AF\u09BC\u09C7 \u0997\u09C7\u099B\u09C7 \u2014 \u0986\u09AC\u09BE\u09B0 \u09B2\u0997 \u0987\u09A8 \u0995\u09B0\u09C7, \u09AB\u09B0\u09CD\u09AE \u0996\u09C1\u09B2\u09C7 Fill \u099A\u09BE\u09AA\u09C1\u09A8\u0964 \u0986\u09AA\u09A8\u09BE\u09B0 \u0985\u09A4\u09BF\u09A5\u09BF\u09B0 \u09A4\u09A5\u09CD\u09AF Cformly \u0985\u09CD\u09AF\u09BE\u09AA\u09C7 \u09B8\u0982\u09B0\u0995\u09CD\u09B7\u09BF\u09A4 \u0986\u099B\u09C7\u0964",
  "panel.portalError": "\u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2 \u09B8\u09AE\u09B8\u09CD\u09AF\u09BE \u09A6\u09C7\u0996\u09BF\u09AF\u09BC\u09C7\u099B\u09C7:",
  "panel.appIdFound": "\u09B8\u09AB\u09B2\u09AD\u09BE\u09AC\u09C7 \u09AB\u09BE\u0987\u09B2 \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964 \u0986\u09AC\u09C7\u09A6\u09A8 \u0986\u0987\u09A1\u09BF:",
  "panel.scanHint": "Cformly \u0985\u09CD\u09AF\u09BE\u09AA \u0996\u09C1\u09B2\u09C1\u09A8 \u2192 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2\u09C7 \u09AA\u09BE\u09A0\u09BE\u09A8 \u2192 \u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09B0 \u09A5\u09C7\u0995\u09C7 \u09B8\u09CD\u0995\u09CD\u09AF\u09BE\u09A8 \u0995\u09B0\u09C1\u09A8 \u098F\u09AC\u0982 \u098F\u0987 \u0995\u09CB\u09A1\u09C7\u09B0 \u09A6\u09BF\u0995\u09C7 \u0995\u09CD\u09AF\u09BE\u09AE\u09C7\u09B0\u09BE \u09A7\u09B0\u09C1\u09A8 \u2014 \u0985\u09A5\u09AC\u09BE \u0986\u0987\u09A1\u09BF \u0995\u09AA\u09BF \u0995\u09B0\u09C1\u09A8\u0964",
  "panel.copy": "\u0986\u09AC\u09C7\u09A6\u09A8 \u0986\u0987\u09A1\u09BF \u0995\u09AA\u09BF \u0995\u09B0\u09C1\u09A8",
  "panel.copied": "\u0995\u09AA\u09BF \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964",
  "panel.confirmNotDetected": "\u09A8\u09BF\u09B6\u09CD\u099A\u09BF\u09A4\u0995\u09B0\u09A3 \u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF \u2014 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2 \u09B8\u0982\u09B0\u0995\u09CD\u09B7\u09A3 \u0995\u09B0\u09C7\u099B\u09C7 \u0995\u09BF \u09A8\u09BE \u09A6\u09C7\u0996\u09C7 \u09A8\u09BF\u09A8, \u09A4\u09BE\u09B0\u09AA\u09B0 \u098F\u0997\u09BF\u09AF\u09BC\u09C7 \u09AF\u09BE\u09A8\u0964",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "\u0985\u09A4\u09BF\u09A5\u09BF\u09B0 \u099B\u09AC\u09BF \u09B8\u0982\u09AF\u09C1\u0995\u09CD\u09A4 \u0995\u09B0\u09A4\u09C7 \u098F\u0996\u09BE\u09A8\u09C7 \u099B\u09BE\u09A1\u09BC\u09C1\u09A8",
  "panel.photoBrowse": "\u09AC\u09CD\u09B0\u09BE\u0989\u099C\u2026",
  "panel.photoAttachFailed": "\u09B8\u09CD\u09AC\u09AF\u09BC\u0982\u0995\u09CD\u09B0\u09BF\u09AF\u09BC\u09AD\u09BE\u09AC\u09C7 \u09B8\u0982\u09AF\u09C1\u0995\u09CD\u09A4 \u09B9\u09AF\u09BC\u09A8\u09BF \u2014 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2\u09C7\u09B0 \u09A8\u09BF\u099C\u09B8\u09CD\u09AC \u09AB\u09BE\u0987\u09B2 \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u09AC\u09CB\u09A4\u09BE\u09AE \u09AC\u09CD\u09AF\u09AC\u09B9\u09BE\u09B0 \u0995\u09B0\u09C1\u09A8\u0964",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "\u098F\u0987 \u09AB\u09B0\u09CD\u09AE Cformly \u09A6\u09BF\u09AF\u09BC\u09C7 \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8",
  "chip.hint": "\u098F\u0987 \u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09B0\u09C7 \u09AA\u09BE\u09A0\u09BE\u09A8\u09CB \u0985\u09A4\u09BF\u09A5\u09BF\u09B0 \u09A4\u09A5\u09CD\u09AF\u0997\u09C1\u09B2\u09BF \u098F\u0996\u09BE\u09A8\u09C7 \u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09C1\u09A8 (\u09AC\u09BE \u099F\u09C7\u0995\u09CD\u09B8\u099F \u09AB\u09BE\u0987\u09B2 \u098F\u0996\u09BE\u09A8\u09C7 \u099B\u09BE\u09A1\u09BC\u09C1\u09A8), \u09A4\u09BE\u09B0\u09AA\u09B0 \u09AB\u09B0\u09CD\u09AE \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8 \u099A\u09BE\u09AA\u09C1\u09A8\u0964",
  "chip.fill": "\u09AB\u09B0\u09CD\u09AE \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8",
  "chip.filling": "\u09AA\u09C2\u09B0\u09A3 \u09B9\u099A\u09CD\u099B\u09C7\u2026",
  "chip.empty": "\u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09BE\u09B0 \u0995\u09BF\u099B\u09C1 \u09A8\u09C7\u0987 \u2014 \u0986\u0997\u09C7 Cformly \u0985\u09CD\u09AF\u09BE\u09AA \u09A5\u09C7\u0995\u09C7 \u0995\u09AA\u09BF \u0995\u09B0\u09BE \u0985\u09A4\u09BF\u09A5\u09BF\u09B0 \u09A4\u09A5\u09CD\u09AF \u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09C1\u09A8\u0964",
  "chip.tooLarge": "\u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09BE \u099F\u09C7\u0995\u09CD\u09B8\u099F \u0996\u09C1\u09AC \u09AC\u09A1\u09BC \u2014 \u09B6\u09C1\u09A7\u09C1\u09AE\u09BE\u09A4\u09CD\u09B0 Cformly \u0985\u09CD\u09AF\u09BE\u09AA \u09A5\u09C7\u0995\u09C7 \u0995\u09AA\u09BF \u0995\u09B0\u09BE \u09A4\u09A5\u09CD\u09AF \u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09C1\u09A8\u0964",
  "chip.collapse": "\u09AC\u09A8\u09CD\u09A7 \u0995\u09B0\u09C1\u09A8",
  "chip.mappingFallback": "\u09A6\u09CD\u09B0\u09B7\u09CD\u099F\u09AC\u09CD\u09AF: \u09AE\u09CD\u09AF\u09BE\u09AA\u09BF\u0982 \u09B8\u09BE\u09B0\u09CD\u09AD\u09BE\u09B0\u09C7 \u09AA\u09CC\u0981\u099B\u09BE\u09A8\u09CB \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF \u2014 \u09AC\u09BF\u09B2\u09CD\u099F-\u0987\u09A8 \u09AB\u09BF\u09B2\u09CD\u09A1 \u09AE\u09CD\u09AF\u09BE\u09AA \u09AC\u09CD\u09AF\u09AC\u09B9\u09C3\u09A4 \u09B9\u099A\u09CD\u099B\u09C7, \u09AF\u09BE \u09AA\u09C1\u09B0\u09CB\u09A8\u09CB \u09B9\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7\u0964",
  // round-66: popup first-run onboarding
  "onboarding.title": "\u09AA\u09CD\u09B0\u09A5\u09AE\u09AC\u09BE\u09B0 \u098F\u0996\u09BE\u09A8\u09C7? \u09A4\u09BF\u09A8\u099F\u09BF \u09A7\u09BE\u09AA:",
  "onboarding.step1": "\u0986\u09AA\u09A8\u09BE\u09B0 \u09AB\u09CB\u09A8\u09C7: \u0985\u09A4\u09BF\u09A5\u09BF \u0996\u09C1\u09B2\u09C1\u09A8 \u2192 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2\u09C7 \u09AA\u09BE\u09A0\u09BE\u09A8 \u2192 \u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09B0\u09C7 \u09AA\u09BE\u09A0\u09BE\u09A8\u0964",
  "onboarding.step2": "\u098F\u0987 \u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09B0\u09C7: \u09A8\u09BF\u099C\u09C7\u0995\u09C7 \u09AA\u09BE\u09A0\u09BE\u09A8\u09CB \u09A4\u09A5\u09CD\u09AF \u09A8\u09BF\u099A\u09C7\u09B0 \u09AC\u09BE\u0995\u09CD\u09B8\u09C7 \u09AA\u09C7\u09B8\u09CD\u099F \u0995\u09B0\u09C1\u09A8 (\u09AC\u09BE \u09AB\u09B0\u09CD\u09AE \u09AA\u09BE\u09A4\u09BE\u09B0 \u09A8\u09C0\u09B2 Cformly \u09AC\u09CB\u09A4\u09BE\u09AE \u099A\u09BE\u09AA\u09C1\u09A8)\u0964",
  "onboarding.step3": "\u09AB\u09B0\u09CD\u09AE \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8 \u099A\u09BE\u09AA\u09C1\u09A8 \u2014 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2 \u09AB\u09B0\u09CD\u09AE \u09A8\u09BF\u099C\u09C7 \u09A5\u09C7\u0995\u09C7\u0987 \u09AA\u09C2\u09B0\u09A3 \u09B9\u09AF\u09BC\u09C7 \u09AF\u09BE\u09AC\u09C7\u0964 \u099B\u09AC\u09BF, \u09B8\u09BF\u0995\u09BF\u0989\u09B0\u09BF\u099F\u09BF \u0995\u09CB\u09A1 \u098F\u09AC\u0982 \u09B8\u09C7\u09AD \u0986\u09AA\u09A8\u09BF \u0995\u09B0\u09C1\u09A8\u0964",
  "onboarding.done": "\u09AC\u09C1\u099D\u09C7\u099B\u09BF",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{total}\u099F\u09BF\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 {filled}\u099F\u09BF \u09AB\u09BF\u09B2\u09CD\u09A1 {time} \u09B8\u09AE\u09AF\u09BC\u09C7 \u09AA\u09C2\u09B0\u09A3 \u09B9\u09AF\u09BC\u09C7\u099B\u09BF\u09B2\u0964 \u0986\u09AC\u09BE\u09B0 \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09A4\u09C7 \u09AA\u09C1\u09A8\u09B0\u09BE\u09AF\u09BC \u09B6\u09C1\u09B0\u09C1 \u0995\u09B0\u09C1\u09A8\u0964",
  "resume.button": "\u0986\u09AC\u09BE\u09B0 \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "\u098F\u0987 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2 \u09AA\u09C7\u099C\u099F\u09BF Cformly-\u09B0 \u09AA\u09B0\u09BF\u099A\u09BF\u09A4 Form III-\u098F\u09B0 \u09AE\u09A4\u09CB \u09A6\u09C7\u0996\u09BE\u099A\u09CD\u099B\u09C7 \u09A8\u09BE \u2014 \u09B8\u09AE\u09CD\u09AD\u09AC\u09A4 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2 \u09AC\u09A6\u09B2\u09C7 \u0997\u09C7\u099B\u09C7\u0964 \u098F\u09AC\u09BE\u09B0 Cformly \u0985\u09CD\u09AF\u09BE\u09AA \u09A5\u09C7\u0995\u09C7 \u0985\u09A4\u09BF\u09A5\u09BF \u09AB\u09BF\u09B2\u09CD\u09A1\u0997\u09C1\u09B2\u09BF \u0995\u09AA\u09BF \u0995\u09B0\u09C7 \u09A8\u09BF\u099C\u09C7\u0987 \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8; \u0986\u09AE\u09B0\u09BE \u0986\u09AA\u09A1\u09C7\u099F \u09AA\u09B0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09B0\u099B\u09BF\u0964",
  "canary.detail": "\u098F\u0987 \u09AA\u09C7\u099C\u09C7 Cformly-\u09B0 \u09AA\u09B0\u09BF\u099A\u09BF\u09A4 {total}\u099F\u09BF \u09AB\u09BF\u09B2\u09CD\u09A1\u09C7\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u09AE\u09BE\u09A4\u09CD\u09B0 {found}\u099F\u09BF \u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u0997\u09C7\u099B\u09C7\u0964",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "\u0985\u09A4\u09BF\u09A5\u09BF \u09B8\u09BE\u09B0\u09BF",
  "queue.add": "\u09B8\u09BE\u09B0\u09BF\u09A4\u09C7 \u09AF\u09CB\u0997 \u0995\u09B0\u09C1\u09A8",
  "queue.fill": "\u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8",
  "queue.remove": "\u09B8\u09B0\u09BE\u09A8",
  "queue.unnamed": "\u0985\u09A4\u09BF\u09A5\u09BF",
  "queue.added": "{name} \u09B8\u09BE\u09B0\u09BF\u09A4\u09C7 \u09AF\u09CB\u0997 \u0995\u09B0\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964",
  "queue.duplicate": "\u098F\u0987 \u0985\u09A4\u09BF\u09A5\u09BF \u0987\u09A4\u09BF\u09AE\u09A7\u09CD\u09AF\u09C7 \u09B8\u09BE\u09B0\u09BF\u09A4\u09C7 \u0986\u099B\u09C7\u0964",
  "queue.full": "\u09B8\u09BE\u09B0\u09BF \u09AA\u09C2\u09B0\u09CD\u09A3 ({max} \u099C\u09A8 \u0985\u09A4\u09BF\u09A5\u09BF)\u0964 \u0986\u0997\u09C7 \u098F\u0995\u099C\u09A8 \u0985\u09A4\u09BF\u09A5\u09BF\u09B0 \u09AB\u09B0\u09CD\u09AE \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8 \u09AC\u09BE \u09B8\u09B0\u09BF\u09AF\u09BC\u09C7 \u09A6\u09BF\u09A8\u0964",
  "queue.hint": "\u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09BE\u09B0 \u0985\u09AA\u09C7\u0995\u09CD\u09B7\u09BE\u09AF\u09BC \u0985\u09A4\u09BF\u09A5\u09BF\u09B0\u09BE\u0964 \u09B8\u09AE\u09CD\u09AA\u09C2\u09B0\u09CD\u09A3 \u09AA\u09C2\u09B0\u09A3\u09C7\u09B0 \u09AA\u09B0\u09C7 \u0985\u09A4\u09BF\u09A5\u09BF \u09B8\u09BE\u09B0\u09BF \u09A5\u09C7\u0995\u09C7 \u09B8\u09B0\u09BF\u09AF\u09BC\u09C7 \u09A6\u09C7\u0993\u09AF\u09BC\u09BE \u09B9\u09AF\u09BC; \u09AC\u09CD\u09B0\u09BE\u0989\u099C\u09BE\u09B0 \u09AC\u09A8\u09CD\u09A7 \u0995\u09B0\u09B2\u09C7 \u09B8\u09BE\u09B0\u09BF \u0996\u09BE\u09B2\u09BF \u09B9\u09AF\u09BC\u09C7 \u09AF\u09BE\u09AF\u09BC\u0964",
  "queue.unavailable": "\u098F\u0987 \u09AC\u09CD\u09B0\u09BE\u0989\u099C\u09BE\u09B0\u09C7 \u0985\u09A4\u09BF\u09A5\u09BF \u09B8\u09BE\u09B0\u09BF \u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u09AF\u09BE\u09AF\u09BC \u09A8\u09BE\u0964",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "\u098F\u0987 FRRO \u099F\u09CD\u09AF\u09BE\u09AC\u099F\u09BF Cformly \u0987\u09A8\u09B8\u09CD\u099F\u09B2 \u09AC\u09BE \u0986\u09AA\u09A1\u09C7\u099F \u09B9\u0993\u09AF\u09BC\u09BE\u09B0 \u0986\u0997\u09C7 \u0996\u09CB\u09B2\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09BF\u09B2\u0964 \u098F\u0987 \u099F\u09CD\u09AF\u09BE\u09AC\u099F\u09BF \u098F\u0995\u09AC\u09BE\u09B0 \u09B0\u09BF\u09B2\u09CB\u09A1 \u0995\u09B0\u09C1\u09A8 (F5), \u09A4\u09BE\u09B0\u09AA\u09B0 Fill \u099A\u09BE\u09AA\u09C1\u09A8\u0964",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "\u09AB\u09B0\u09CD\u09AE \u09AE\u09CD\u09AF\u09BE\u09AA\u09BF\u0982",
  "settings.mapVersion": "\u09B8\u0982\u09B8\u09CD\u0995\u09B0\u09A3",
  "settings.mapLastVerified": "\u09B8\u09B0\u09CD\u09AC\u09B6\u09C7\u09B7 \u09AF\u09BE\u099A\u09BE\u0987\u0995\u09C3\u09A4",
  "settings.mapFetchedAt": "\u09B8\u0982\u0997\u09CD\u09B0\u09B9 \u0995\u09B0\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7",
  "settings.mapSignature": "Ed25519 \u09B8\u09CD\u09AC\u09BE\u0995\u09CD\u09B7\u09B0",
  "settings.mapRefresh": "\u098F\u0996\u09A8\u0987 \u09B0\u09BF\u09AB\u09CD\u09B0\u09C7\u09B6 \u0995\u09B0\u09C1\u09A8",
  "settings.mapRefreshed": "\u09AE\u09CD\u09AF\u09BE\u09AA\u09BF\u0982 \u09B0\u09BF\u09AB\u09CD\u09B0\u09C7\u09B6 \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964",
  "settings.mapRefreshFailed": "\u09AE\u09CD\u09AF\u09BE\u09AA\u09BF\u0982 \u09B0\u09BF\u09AB\u09CD\u09B0\u09C7\u09B6 \u0995\u09B0\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF - \u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u09B8\u09C7\u09B0\u09BE \u0995\u09AA\u09BF\u099F\u09BF \u09AC\u09CD\u09AF\u09AC\u09B9\u09C3\u09A4 \u09B9\u099A\u09CD\u099B\u09C7\u0964",
  "settings.mapStatusRemote": "\u09AF\u09BE\u099A\u09BE\u0987\u0995\u09C3\u09A4 - \u09AE\u09CD\u09AF\u09BE\u09AA\u09BF\u0982 \u09B8\u09BE\u09B0\u09CD\u09AD\u09BE\u09B0 \u09A5\u09C7\u0995\u09C7 \u0986\u09A8\u09BE \u09B8\u09A6\u09CD\u09AF \u0995\u09AA\u09BF\u0964",
  "settings.mapStatusCached": "\u09AF\u09BE\u099A\u09BE\u0987\u0995\u09C3\u09A4 - \u09B8\u09BE\u09AE\u09CD\u09AA\u09CD\u09B0\u09A4\u09BF\u0995 \u0995\u09CD\u09AF\u09BE\u09B6\u09C7 \u0995\u09AA\u09BF\u0964",
  "settings.mapStatusBundled": "\u0985\u09A8\u09CD\u09A4\u09B0\u09CD\u09AD\u09C1\u0995\u09CD\u09A4 \u09AC\u09C7\u09B8\u09B2\u09BE\u0987\u09A8 \u0995\u09AA\u09BF (\u09B8\u09BE\u09B0\u09CD\u09AD\u09BE\u09B0 \u09A8\u09C7\u0987)\u0964 \u09B8\u09CD\u09AC\u09BE\u0995\u09CD\u09B7\u09B0 \u0985\u0995\u09CD\u09B7\u09A4\u0964",
  "settings.mapStatusTampered": "\u09B8\u09CD\u09AC\u09BE\u0995\u09CD\u09B7\u09B0 \u09AF\u09BE\u099A\u09BE\u0987 \u09AC\u09CD\u09AF\u09B0\u09CD\u09A5 - \u098F\u0987 \u0995\u09AA\u09BF\u099F\u09BF \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u0996\u09CD\u09AF\u09BE\u09A4 \u098F\u09AC\u0982 \u09AC\u09CD\u09AF\u09AC\u09B9\u09C3\u09A4 \u09B9\u099A\u09CD\u099B\u09C7 \u09A8\u09BE\u0964",
  "chip.mappingUnavailable": "\u09AB\u09B0\u09CD\u09AE \u09AE\u09CD\u09AF\u09BE\u09AA\u09BF\u0982 \u09B2\u09CB\u09A1 \u0995\u09B0\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF \u2014 \u098F\u0995\u09CD\u09B8\u099F\u09C7\u09A8\u09B6\u09A8\u09C7\u09B0 \u09AC\u09CD\u09AF\u09BE\u0995\u0997\u09CD\u09B0\u09BE\u0989\u09A8\u09CD\u09A1 \u0995\u09B0\u09CD\u09AE\u09C0 \u09B8\u09BE\u09A1\u09BC\u09BE \u09A6\u09C7\u09AF\u09BC\u09A8\u09BF\u0964 \u09AA\u09CB\u09B0\u09CD\u099F\u09BE\u09B2 \u099F\u09CD\u09AF\u09BE\u09AC \u09B0\u09BF\u09B2\u09CB\u09A1 \u0995\u09B0\u09C7 \u0986\u09AC\u09BE\u09B0 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.timeoutMapping": "\u09AB\u09B0\u09CD\u09AE \u09AE\u09CD\u09AF\u09BE\u09AA\u09BF\u0982 \u09B2\u09CB\u09A1 \u09B9\u0993\u09AF\u09BC\u09BE\u09B0 \u09B8\u09AE\u09AF\u09BC \u09B6\u09C7\u09B7 ({seconds} \u09B8\u09C7\u0995\u09C7\u09A8\u09CD\u09A1)\u0964 \u09B8\u0982\u09AF\u09CB\u0997 \u09AA\u09B0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09B0\u09C7 \u0986\u09AC\u09BE\u09B0 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.timeoutNoProgress": "\u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09BE {seconds} \u09B8\u09C7\u0995\u09C7\u09A8\u09CD\u09A1\u09C7 \u09B6\u09C1\u09B0\u09C1 \u09B9\u09AF\u09BC\u09A8\u09BF \u2014 Form III \u09AA\u09BE\u09A4\u09BE \u09B8\u09BE\u09A1\u09BC\u09BE \u09A6\u09BF\u099A\u09CD\u099B\u09C7 \u09A8\u09BE\u0964 \u099F\u09CD\u09AF\u09BE\u09AC \u09B0\u09BF\u09B2\u09CB\u09A1 \u0995\u09B0\u09C7 \u0986\u09AC\u09BE\u09B0 \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8\u0964",
  "popup.timeoutStalled": "\u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09BE {seconds} \u09B8\u09C7\u0995\u09C7\u09A8\u09CD\u09A1 \u09A7\u09B0\u09C7 \u09A5\u09C7\u09AE\u09C7 \u0986\u099B\u09C7 \u2014 Form III \u09AA\u09BE\u09A4\u09BE \u09B8\u09BE\u09A1\u09BC\u09BE \u09A6\u09C7\u0993\u09AF\u09BC\u09BE \u09AC\u09A8\u09CD\u09A7 \u0995\u09B0\u09C7\u099B\u09C7\u0964",
  "popup.timeoutCap": "\u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09BE \u09AE\u09CB\u099F \u09B8\u09AE\u09AF\u09BC \u09B8\u09C0\u09AE\u09BE ({seconds} \u09B8\u09C7\u0995\u09C7\u09A8\u09CD\u09A1) \u099B\u09BE\u09A1\u09BC\u09BF\u09AF\u09BC\u09C7 \u0997\u09C7\u099B\u09C7 \u098F\u09AC\u0982 \u09A5\u09BE\u09AE\u09BE\u09A8\u09CB \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964",
  "popup.preview": "\u09AA\u09B0\u09BF\u09AC\u09B0\u09CD\u09A4\u09A8 \u09A6\u09C7\u0996\u09C1\u09A8",
  "popup.previewApply": "\u09AA\u09CD\u09B0\u09AF\u09BC\u09CB\u0997 \u0995\u09B0\u09C1\u09A8 \u2014 \u09AB\u09B0\u09CD\u09AE \u09AA\u09C2\u09B0\u09A3 \u0995\u09B0\u09C1\u09A8",
  "popup.undo": "\u09B6\u09C7\u09B7 \u09AB\u09BF\u09B2 \u0986\u09A8\u09A1\u09C1 \u0995\u09B0\u09C1\u09A8",
  "popup.undoDone": "{total}\u099F\u09BF\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 {restored}\u099F\u09BF \u09AB\u09BF\u09B2\u09CD\u09A1 \u0986\u0997\u09C7\u09B0 \u09AE\u09BE\u09A8\u09C7 \u09AB\u09BF\u09B0\u09BF\u09AF\u09BC\u09C7 \u0986\u09A8\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964",
  "popup.undoPartial": "{total}\u099F\u09BF\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 {restored}\u099F\u09BF \u09AB\u09BF\u09B0\u09C7\u099B\u09C7; {failed}\u099F\u09BF \u09AB\u09C7\u09B0\u09BE\u09A8\u09CB \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF (\u09AA\u09C3\u09B7\u09CD\u09A0\u09BE \u09AA\u09C1\u09A8\u09B0\u09BE\u09AF\u09BC \u09A4\u09C8\u09B0\u09BF \u09B9\u09AF\u09BC\u09C7\u099B\u09C7)\u0964",
  "popup.undoStale": "\u09AB\u09BF\u09B2\u09C7\u09B0 \u09AA\u09B0\u09C7 \u09AA\u09C3\u09B7\u09CD\u09A0\u09BE \u09AC\u09A6\u09B2\u09C7\u099B\u09C7 \u2014 \u09AA\u09C1\u09A8\u09B0\u09C1\u09A6\u09CD\u09A7\u09BE\u09B0 \u0985\u09B8\u09AE\u09CD\u09AA\u09C2\u09B0\u09CD\u09A3 \u09B9\u09A4\u09C7 \u09AA\u09BE\u09B0\u09C7\u0964",
  "popup.undoNone": "\u0986\u09A8\u09A1\u09C1 \u0995\u09B0\u09BE\u09B0 \u0995\u09BF\u099B\u09C1 \u09A8\u09C7\u0987 \u2014 \u098F\u0987 \u09B8\u09C7\u09B6\u09A8\u09C7 \u098F\u0987 \u099F\u09CD\u09AF\u09BE\u09AC\u09C7 \u0995\u09CB\u09A8\u09CB \u09AB\u09BF\u09B2 \u09B9\u09AF\u09BC\u09A8\u09BF\u0964",
  "popup.previewUnresolved": "\u098F\u0987 \u09AA\u09BE\u09A4\u09BE\u09AF\u09BC \u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF",
  "popup.previewManual": "\u09AE\u09CD\u09AF\u09BE\u09A8\u09C1\u09AF\u09BC\u09BE\u09B2 \u09A7\u09BE\u09AA",
  "popup.previewNoValue": "(\u09A6\u09C7\u0993\u09AF\u09BC\u09BE \u09B9\u09AF\u09BC\u09A8\u09BF)"
};

// src/i18n/gu.ts
var gu = {
  // popup
  "popup.title": "Cformly \u0AB8\u0ACD\u0AB5\u0AAF\u0A82-\u0AAD\u0AB0\u0AA3",
  "popup.eyebrow": "\u0AB8\u0ACD\u0AB5\u0AAF\u0A82-\u0AAD\u0AB0\u0AA3",
  "popup.bandSub": "FRRO Form III \xB7 \u0A9A\u0AC7\u0A95-\u0A87\u0AA8\u0AA8\u0ABE 24 \u0A95\u0AB2\u0ABE\u0A95\u0AA8\u0AC0 \u0A85\u0A82\u0AA6\u0AB0",
  "popup.fillFromClipboard": "Clipboard \u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAD\u0AB0\u0ACB",
  "popup.fillHint": "Cformly \u0A90\u0AAA\u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0AA8\u0AC0 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0ACD\u0AB8 \u0A95\u0ACB\u0AAA\u0AC0 \u0A95\u0AB0\u0ACB, \u0AAA\u0A9B\u0AC0 \u0A86 \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2 \u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAD\u0AB0\u0ACB.",
  "popup.clipboardReadFailed": "Clipboard \u0AB5\u0ABE\u0A82\u0A9A\u0AC0 \u0AB6\u0A95\u0ABE\u0AAF\u0AC1\u0A82 \u0AA8\u0AB9\u0AC0\u0A82. \u0AAC\u0ACD\u0AB0\u0ABE\u0A89\u0A9D\u0AB0\u0AA8\u0AC0 clipboard permissions \u0A9A\u0AC7\u0A95 \u0A95\u0AB0\u0ACB.",
  "popup.clipboardEmpty": "Clipboard \u0AAE\u0ABE\u0A82 Cformly \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0ACD\u0AB8 \u0AA8\u0AA5\u0AC0. \u0AAA\u0AB9\u0AC7\u0AB2\u0ABE Cformly \u0A90\u0AAA\u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0AA8\u0AC0 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0ACD\u0AB8 \u0A95\u0ACB\u0AAA\u0AC0 \u0A95\u0AB0\u0ACB.",
  "popup.settings": "Settings",
  "popup.loadingMapping": "\u0AAB\u0ACB\u0AB0\u0ACD\u0AAE mapping \u0AB2\u0ACB\u0AA1 \u0AA5\u0A88 \u0AB0\u0AB9\u0ACD\u0AAF\u0AC1\u0A82 \u0A9B\u0AC7...",
  "popup.filling": "\u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAD\u0AB0\u0ABE\u0A88 \u0AB0\u0AB9\u0ACD\u0AAF\u0AC1\u0A82 \u0A9B\u0AC7...",
  "popup.fillingProgress": "\u0AAD\u0AB0\u0ABE\u0A88 \u0AB0\u0AB9\u0ACD\u0AAF\u0AC1\u0A82 \u0A9B\u0AC7\u2026 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 {completed}/{total}",
  "popup.noTab": "\u0A95\u0ACB\u0A88 \u0AB8\u0A95\u0ACD\u0AB0\u0ABF\u0AAF \u0A9F\u0AC5\u0AAC \u0AAE\u0AB3\u0ACD\u0AAF\u0AC1\u0A82 \u0AA8\u0AA5\u0AC0.",
  "popup.filled": "\u0A9C\u0AB0\u0AC2\u0AB0\u0AC0 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0ACD\u0AB8 \u0AAD\u0AB0\u0ABE\u0A88: {required} \u0AAE\u0ABE\u0A82\u0AA5\u0AC0 {filledRequired} (\u0A95\u0AC1\u0AB2 {filled} \u0AAD\u0AB0\u0ABE\u0A88)",
  "popup.portalMismatch": "\u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2 \u0AAC\u0AA6\u0AB2\u0ABE\u0AB5 \u0AA8\u0ACB\u0A82\u0AA7\u0ABE\u0AAF\u0ACB (DOM \u0AAC\u0AA6\u0AB2\u0ABE\u0AAF\u0AC1\u0A82). Cformly \u0A90\u0AAA\u0AAE\u0ABE\u0A82 \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0AA8\u0AC0 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0ACD\u0AB8 \u0AAB\u0AB0\u0AC0 \u0A95\u0ACB\u0AAA\u0AC0 \u0A95\u0AB0\u0AC0 \u0AAB\u0AB0\u0AC0 \u0AAA\u0ACD\u0AB0\u0AAF\u0ABE\u0AB8 \u0A95\u0AB0\u0ACB.",
  "popup.missingElements": "\u0A97\u0AC7\u0AB0\u0AB9\u0ABE\u0A9C\u0AB0 \u0AA4\u0AA4\u0ACD\u0AB5\u0ACB: {list}",
  "popup.missingValues": "\u0A97\u0AC7\u0AB0\u0AB9\u0ABE\u0A9C\u0AB0 \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF\u0ACB: {list}",
  "popup.manualFields": "\u0A9C\u0ABE\u0AA4\u0AC7 \u0AAD\u0AB0\u0AB5\u0ABE\u0AA8\u0ABE\u0A82 \u0AAA\u0A97\u0AB2\u0ABE\u0A82 \u0A9C\u0AB0\u0AC2\u0AB0\u0AC0: {list}",
  "popup.unsupportedFields": "\u0AB8\u0ACD\u0AB5\u0AAF\u0A82-\u0AAD\u0AB0\u0AA3 \u0AB6\u0A95\u0ACD\u0AAF \u0AA8\u0AB9\u0AC0\u0A82 \u0AA4\u0AC7\u0AB5\u0AC0 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0ACD\u0AB8: {list}",
  "popup.tooLongFields": "\u0A86 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0ACD\u0AB8 \u0AAE\u0ABE\u0A9F\u0AC7 \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF\u0ACB \u0A96\u0AC2\u0AAC \u0AB2\u0ABE\u0A82\u0AAC\u0ABE \u2014 \u0A95\u0A82\u0A88 \u0AB2\u0A96\u0ABE\u0AAF\u0AC1\u0A82 \u0AA8\u0AA5\u0AC0, \u0A9F\u0AC2\u0A82\u0A95\u0AC1\u0A82 \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF \u0A9F\u0ABE\u0A88\u0AAA \u0A95\u0AB0\u0ACB: {list}",
  "popup.unverifiedFields": "\u0A86 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0ACD\u0AB8 \u0AA4\u0AAA\u0ABE\u0AB8\u0ACB \u2014 \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF \u0A95\u0AA6\u0ABE\u0A9A \u0A85\u0A9F\u0A95\u0ACD\u0AAF\u0AC1\u0A82 \u0AA8 \u0AB9\u0ACB\u0A88 \u0AB6\u0A95\u0AC7: {list}",
  "popup.applicationId": "Application ID: {id}",
  "popup.accommodationMismatch": "\u0A9A\u0AC7\u0AA4\u0AB5\u0AA3\u0AC0: FRRO \u0AB8\u0AA4\u0ACD\u0AB0 \u0A95\u0AA6\u0ABE\u0A9A \u0AAC\u0AC0\u0A9C\u0AC0 \u0AAA\u0ACD\u0AB0\u0ACB\u0AAA\u0AB0\u0ACD\u0A9F\u0AC0 \u0AAE\u0ABE\u0A9F\u0AC7 \u0AB9\u0ACB\u0A88 \u0AB6\u0A95\u0AC7. \u0AB8\u0AAC\u0AAE\u0ABF\u0A9F \u0A95\u0AB0\u0AA4\u0ABE\u0A82 \u0AAA\u0AB9\u0AC7\u0AB2\u0ABE\u0A82 \u0A9A\u0A95\u0ABE\u0AB8\u0ACB.",
  "popup.attention": "\u0A95\u0AC7\u0A9F\u0AB2\u0AC0\u0A95 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0ACD\u0AB8\u0AA8\u0AC7 \u0AA7\u0ACD\u0AAF\u0ABE\u0AA8 \u0A9C\u0AB0\u0AC2\u0AB0\u0AC0 \u0A9B\u0AC7. Cformly \u0A90\u0AAA\u0AAE\u0ABE\u0A82 \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0AA8\u0AC0 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0ACD\u0AB8 \u0AAB\u0AB0\u0AC0 \u0A95\u0ACB\u0AAA\u0AC0 \u0A95\u0AB0\u0AC0 \u0AAB\u0AB0\u0AC0 \u0AAA\u0ACD\u0AB0\u0AAF\u0ABE\u0AB8 \u0A95\u0AB0\u0ACB.",
  "popup.openPrint": "Individual Print \u0A96\u0ACB\u0AB2\u0ACB",
  "popup.printNoId": "\u0AB9\u0A9C\u0AC1 Application ID \u0A95\u0AC5\u0AAA\u0ACD\u0A9A\u0AB0 \u0AA5\u0A88 \u0AA8\u0AA5\u0AC0 \u2014 \u0AAA\u0AB9\u0AC7\u0AB2\u0ABE \u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAD\u0AB0\u0ACB.",
  "popup.printSent": "ID {id} \u0AAE\u0ABE\u0A9F\u0AC7 \u0AA6\u0ABE\u0A96\u0AB2 \u0AA5\u0AAF\u0AC7\u0AB2\u0AC0 \u0A85\u0AB0\u0A9C\u0AC0 \u0AAB\u0AB0\u0AC0 \u0A96\u0ACB\u0AB2\u0AB5\u0ABE\u0A88. PDF \u0AA1\u0ABE\u0A89\u0AA8\u0AB2\u0ACB\u0AA1 \u0A95\u0AB0\u0AB5\u0ABE \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2\u0AA8\u0ABE Individual Print \u0AAE\u0AC7\u0AA8\u0AC2\u0AA8\u0ACB \u0A89\u0AAA\u0AAF\u0ACB\u0A97 \u0A95\u0AB0\u0ACB.",
  "popup.formFilled": "\u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAD\u0AB0\u0ABE\u0A88 \u0A97\u0AAF\u0AC1\u0A82. \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2 \u0AAA\u0AB0 \u0AB0\u0ABF\u0AB5\u0ACD\u0AAF\u0AC2 \u0A95\u0AB0\u0AC0 \u0AB8\u0AAC\u0AAE\u0ABF\u0A9F \u0A95\u0AB0\u0ACB.",
  "popup.fillError": "\u0AAD\u0AB0\u0AA3\u0AAE\u0ABE\u0A82 \u0AAD\u0AC2\u0AB2: {message}",
  "popup.connectionFailed": "FRRO \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2 \u0AAA\u0AC7\u0A9C \u0AB8\u0AC1\u0AA7\u0AC0 \u0AAA\u0AB9\u0ACB\u0A82\u0A9A \u0AA8\u0AB9\u0AC0\u0A82. \u0A86 \u0A9F\u0AC5\u0AAC\u0AAE\u0ABE\u0A82 Form III \u0AAA\u0AC7\u0A9C \u0A96\u0ACB\u0AB2\u0AC0 \u0AAB\u0AB0\u0AC0 \u0AAA\u0ACD\u0AB0\u0AAF\u0ABE\u0AB8 \u0A95\u0AB0\u0ACB.",
  "popup.unknownError": "\u0A85\u0A9C\u0ACD\u0A9E\u0ABE\u0AA4",
  "popup.apiBaseFallback": "\u0A9A\u0AC7\u0AA4\u0AB5\u0AA3\u0AC0: \u0AB8\u0A82\u0A97\u0ACD\u0AB0\u0AB9\u0ABF\u0AA4 API URL \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A9B\u0AC7 \u2014 \u0AA1\u0ABF\u0AAB\u0AC9\u0AB2\u0ACD\u0A9F \u0AB5\u0AAA\u0AB0\u0ABE\u0AAF \u0A9B\u0AC7. Settings \u0AAE\u0ABE\u0A82 \u0A85\u0AAA\u0AA1\u0AC7\u0A9F \u0A95\u0AB0\u0ACB.",
  "popup.mappingFallback": "\u0A9A\u0AC7\u0AA4\u0AB5\u0AA3\u0AC0: mapping \u0AB8\u0AB0\u0ACD\u0AB5\u0AB0 \u0A85\u0AAA\u0ACD\u0AB0\u0ABE\u0AAA\u0ACD\u0AAF \u0A9B\u0AC7 \u2014 \u0AAC\u0ABF\u0AB2\u0ACD\u0A9F-\u0A87\u0AA8 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 \u0AAE\u0AC7\u0AAA \u0AB5\u0AAA\u0AB0\u0ABE\u0AAF \u0A9B\u0AC7, \u0A9C\u0AC7 \u0A9C\u0AC2\u0AA8\u0AC1\u0A82 \u0AB9\u0ACB\u0A88 \u0AB6\u0A95\u0AC7.",
  // settings
  "settings.title": "Cformly Settings",
  "settings.eyebrow": "Settings",
  "settings.bandSub": "\u0AAB\u0ACB\u0AB0\u0ACD\u0AAE mappings \u0A86\u0AAA\u0AA8\u0ABE\u0AB0 backend \u0A97\u0ACB\u0AA0\u0AB5\u0ACB.",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "\u0AAB\u0ACB\u0AB0\u0ACD\u0AAE mappings \u0A86\u0AAA\u0AA8\u0ABE\u0AB0 backend. \u0AAB\u0A95\u0ACD\u0AA4 HTTPS; localhost \u0AAB\u0A95\u0ACD\u0AA4 development builds \u0AAE\u0ABE\u0A82 \u0A9A\u0ABE\u0AB2\u0AC7.",
  "settings.save": "\u0AB8\u0ABE\u0A9A\u0AB5\u0ACB",
  "settings.back": "\u0AAA\u0ABE\u0A9B\u0AB3",
  "settings.backInTab": "Settings \u0A9F\u0AC5\u0AAC \u0AA4\u0AB0\u0AC0\u0A95\u0AC7 \u0A96\u0AC2\u0AB2\u0AC0 \u2014 fill popup \u0AAE\u0ABE\u0A9F\u0AC7 Cformly toolbar icon \u0AB5\u0ABE\u0AAA\u0AB0\u0ACB.",
  "settings.urlEmpty": "URL \u0A96\u0ABE\u0AB2\u0AC0 \u0AA8 \u0AB9\u0ACB\u0A88 \u0AB6\u0A95\u0AC7.",
  "settings.httpsOnly": "\u0AB8\u0AC1\u0AB0\u0A95\u0ACD\u0AB7\u0ABE \u0AAE\u0ABE\u0A9F\u0AC7 \u0AAB\u0A95\u0ACD\u0AA4 HTTPS URLs \u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A9B\u0AC7. production \u0AAE\u0ABE\u0A9F\u0AC7 https:// \u0AB5\u0ABE\u0AAA\u0AB0\u0ACB.",
  "settings.hostNotAllowed": "URL hostname localhost \u0A95\u0AC7 *.cformly.com \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F (\u0AAE\u0AB3\u0ACD\u0AAF\u0AC1\u0A82: {host}).",
  "settings.invalidUrl": "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF URL. https:// \u0AB8\u0ABE\u0AAE\u0AC7\u0AB2 \u0A95\u0AB0\u0ACB",
  "settings.urlPathNotAllowed": "\u0AAB\u0A95\u0ACD\u0AA4 bare origin \u0AB5\u0ABE\u0AAA\u0AB0\u0ACB \u2014 path, query \u0A85\u0AA8\u0AC7 #fragment \u0AA6\u0AC2\u0AB0 \u0A95\u0AB0\u0ACB.",
  "settings.loopbackNotGranted": "Localhost API URLs \u0AAB\u0A95\u0ACD\u0AA4 development builds \u0AAE\u0ABE\u0A82 \u0A9A\u0ABE\u0AB2\u0AC7. \u0A86 build \u0AAB\u0A95\u0ACD\u0AA4 https:// hosts \u0AB8\u0AC1\u0AA7\u0AC0 \u0AAA\u0AB9\u0ACB\u0A82\u0A9A\u0AC0 \u0AB6\u0A95\u0AC7.",
  "settings.saved": "\u0AB8\u0ABE\u0A9A\u0AB5\u0ABE\u0AAF\u0AC1\u0A82.",
  "settings.saveError": "\u0AB8\u0ABE\u0A9A\u0AB5\u0AC0 \u0AB6\u0A95\u0ABE\u0AAF\u0AC1\u0A82 \u0AA8\u0AB9\u0AC0\u0A82. \u0AAB\u0AB0\u0AC0 \u0AAA\u0ACD\u0AB0\u0AAF\u0ABE\u0AB8 \u0A95\u0AB0\u0ACB.",
  "settings.langLabel": "\u0AAD\u0ABE\u0AB7\u0ABE",
  "settings.langEnglish": "English",
  "settings.langHindi": "\u0939\u093F\u0928\u094D\u0926\u0940",
  "settings.langAuto": "\u0AAC\u0ACD\u0AB0\u0ABE\u0A89\u0A9D\u0AB0 \u0A85\u0AA8\u0AC1\u0AB8\u0AB0\u0ACB",
  "settings.langHint": "\u0AA4\u0AAE\u0AC7 \u0AAA\u0AB8\u0A82\u0AA6 \u0AA8 \u0A95\u0AB0\u0ACB \u0AA4\u0ACD\u0AAF\u0ABE\u0A82 \u0AB8\u0AC1\u0AA7\u0AC0 \u0AAC\u0ACD\u0AB0\u0ABE\u0A89\u0A9D\u0AB0\u0AA8\u0AC0 \u0AAD\u0ABE\u0AB7\u0ABE \u0AB5\u0AAA\u0AB0\u0ABE\u0AB6\u0AC7.",
  // round-65: paste intake + in-page filing panel
  "popup.pasteLabel": "\u0A85\u0AA5\u0AB5\u0ABE \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 \u0A85\u0AB9\u0AC0\u0A82 \u0AAA\u0AC7\u0AB8\u0ACD\u0A9F \u0A95\u0AB0\u0ACB",
  "popup.pdfPick": "Cformly PDF \u0A96\u0ACB\u0AB2\u0ACB",
  "popup.pdfLoaded": "\u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0AA8\u0ABE\u0A82 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 Cformly PDF \u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0AB2\u0ACB\u0AA1 \u0AA5\u0AAF\u0ABE\u0A82 \u2014 \u0AA8\u0AC0\u0A9A\u0AC7 \u0A9A\u0A95\u0ABE\u0AB8\u0ACB, \u0AAA\u0A9B\u0AC0 Fill Form \u0AA6\u0AAC\u0ABE\u0AB5\u0ACB.",
  "popup.pdfRejected": "\u0A86 PDF \u0AAE\u0ABE\u0A82 Cformly \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 \u0AA8\u0AA5\u0AC0 \u0A85\u0AA5\u0AB5\u0ABE \u0AA4\u0AC7 \u0AB5\u0ABE\u0A82\u0A9A\u0AC0 \u0AB6\u0A95\u0ABE\u0A88 \u0AA8\u0AA5\u0AC0 \u2014 Cformly \u0A8F\u0AAA\u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0AA8\u0ABF\u0A95\u0ABE\u0AB8 \u0A95\u0AB0\u0AC7\u0AB2\u0AC0 PDF \u0A9C \u0AB5\u0ABE\u0AAA\u0AB0\u0ACB.",
  "popup.pastePlaceholder": "\u0A95\u0AC9\u0AAA\u0ABF \u0A95\u0AB0\u0AC7\u0AB2\u0AC0 Cformly \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 \u0A85\u0AB9\u0AC0\u0A82 \u0AAA\u0AC7\u0AB8\u0ACD\u0A9F \u0A95\u0AB0\u0ACB",
  "popup.pasteHint": "\u0A95\u0ACD\u0AB2\u0ABF\u0AAA\u0AAC\u0ACB\u0AB0\u0ACD\u0AA1 \u0AAC\u0A9F\u0AA8 \u0A95\u0ABE\u0AAE \u0AA8 \u0A95\u0AB0\u0AC7 \u0AA4\u0ACB, \u0A86 \u0A95\u0AAE\u0ACD\u0AAA\u0ACD\u0AAF\u0AC1\u0A9F\u0AB0 \u0AAA\u0AB0 \u0AAE\u0ACB\u0A95\u0AB2\u0AC7\u0AB2\u0AC0 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 \u0A85\u0AB9\u0AC0\u0A82 \u0AAA\u0AC7\u0AB8\u0ACD\u0A9F \u0A95\u0AB0\u0ACB (\u0A85\u0AA5\u0AB5\u0ABE \u0A9F\u0AC7\u0A95\u0ACD\u0AB8\u0ACD\u0A9F \u0AAB\u0ABE\u0A87\u0AB2 \u0A9B\u0ACB\u0AA1\u0ACB), \u0AAA\u0A9B\u0AC0 \u0AAD\u0AB0\u0ACB \u0AA6\u0AAC\u0ABE\u0AB5\u0ACB.",
  "popup.payloadTooLarge": "\u0AAA\u0AC7\u0AB8\u0ACD\u0A9F \u0A95\u0AB0\u0AC7\u0AB2\u0AC1\u0A82 \u0AB2\u0A96\u0ABE\u0AA3 \u0AAC\u0AB9\u0AC1 \u0AAE\u0ACB\u0A9F\u0AC1\u0A82 \u0A9B\u0AC7 \u2014 \u0AAB\u0A95\u0ACD\u0AA4 Cformly \u0A8D\u0AAA\u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0A95\u0AC9\u0AAA\u0ABF \u0A95\u0AB0\u0AC7\u0AB2\u0AC0 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 \u0AAA\u0AC7\u0AB8\u0ACD\u0A9F \u0A95\u0AB0\u0ACB.",
  "panel.title": "Cformly \u2014 \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2 \u0AAA\u0AB0 \u0AAB\u0ABE\u0A87\u0AB2\u0ABF\u0A82\u0A97 \u0AAA\u0AC2\u0AB0\u0ACD\u0AA3 \u0A95\u0AB0\u0ACB",
  "panel.dismiss": "\u0AAC\u0A82\u0AA7 \u0A95\u0AB0\u0ACB",
  "panel.filled": "\u0AAD\u0AB0\u0ABE\u0AAF\u0AC7\u0AB2\u0AC0 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1: {filledRequired} / {required} \u0AAB\u0AB0\u0A9C\u0ABF\u0AAF\u0ABE\u0AA4",
  "panel.photoStep": "\u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0AA8\u0ACB \u0AAB\u0ACB\u0A9F\u0ACB \u0A9C\u0ACB\u0AA1\u0ACB (\u0AAB\u0ABE\u0A87\u0AB2 \u0AAA\u0AB8\u0A82\u0AA6 \u0A95\u0AB0\u0ACB \u2192 \u0A85\u0AAA\u0AB2\u0ACB\u0AA1 \u0A95\u0AB0\u0ACB)",
  "panel.captchaStep": "\u0AB8\u0AC1\u0AB0\u0A95\u0ACD\u0AB7\u0ABE \u0A95\u0ACB\u0AA1 (CAPTCHA) \u0A9F\u0ABE\u0A87\u0AAA \u0A95\u0AB0\u0ACB",
  "panel.saveStep": "\u0AB8\u0AC7\u0AB5 \u0A95\u0AB0\u0AC0 \u0A86\u0A97\u0AB3 \u0AB5\u0AA7\u0ACB \u0AA6\u0AAC\u0ABE\u0AB5\u0ACB",
  "panel.warnSession": "Cformly \u0A9A\u0AC7\u0AA4\u0AB5\u0AA3\u0AC0: \u0A86 FRRO \u0AB8\u0AC7\u0AB6\u0AA8 \u0AAC\u0AC0\u0A9C\u0AC0 \u0AAA\u0ACD\u0AB0\u0ACB\u0AAA\u0AB0\u0ACD\u0A9F\u0AC0\u0AA8\u0AC1\u0A82 \u0AB9\u0ACB\u0A88 \u0AB6\u0A95\u0AC7 ({reason}). \u0AB8\u0AC7\u0AB5 \u0A95\u0AB0\u0AA4\u0ABE \u0AAA\u0AB9\u0AC7\u0AB2\u0ABE\u0A82 \u0AA4\u0AAA\u0ABE\u0AB8\u0ACB.",
  "panel.warnUnverified": "Cformly \u0A9A\u0AC7\u0AA4\u0AB5\u0AA3\u0AC0: \u0A86 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0AA8\u0ABE \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF\u0ACB \u0A9F\u0A95\u0AC0 \u0AA8 \u0AB6\u0A95\u0AC7: {list}. \u0AB8\u0AC7\u0AB5 \u0A95\u0AB0\u0AA4\u0ABE \u0AAA\u0AB9\u0AC7\u0AB2\u0ABE\u0A82 \u0AA4\u0AAA\u0ABE\u0AB8\u0ACB.",
  "panel.saving": "\u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2\u0AA8\u0AC0 \u0AAA\u0AC1\u0AB7\u0ACD\u0A9F\u0ABF\u0AA8\u0AC0 \u0AB0\u0ABE\u0AB9\u2026",
  "panel.progress": "\u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 \u0AAD\u0AB0\u0ABE\u0A88 \u0AB0\u0AB9\u0ACD\u0AAF\u0ABE\u0A82 \u0A9B\u0AC7\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO \u0AB8\u0AA4\u0ACD\u0AB0 \u0AB8\u0AAE\u0ABE\u0AAA\u0ACD\u0AA4 \u0AA5\u0AAF\u0AC1\u0A82 \u2014 \u0AAB\u0AB0\u0AC0 \u0AB2\u0ACB\u0A97 \u0A87\u0AA8 \u0A95\u0AB0\u0ACB, \u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0A96\u0ACB\u0AB2\u0AC0\u0AA8\u0AC7 Fill \u0AA6\u0AAC\u0ABE\u0AB5\u0ACB. \u0AA4\u0AAE\u0ABE\u0AB0\u0ABE \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0AA8\u0AC0 \u0AB5\u0ABF\u0A97\u0AA4\u0ACB Cformly \u0A8D\u0AAA\u0AAE\u0ABE\u0A82 \u0AB8\u0AB2\u0ABE\u0AAE\u0AA4 \u0A9B\u0AC7.",
  "panel.portalError": "\u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2\u0AC7 \u0AB8\u0AAE\u0AB8\u0ACD\u0AAF\u0ABE \u0AAC\u0AA4\u0ABE\u0AB5\u0AC0:",
  "panel.appIdFound": "\u0AB8\u0AAB\u0AB3\u0AA4\u0ABE\u0AAA\u0AC2\u0AB0\u0ACD\u0AB5\u0A95 \u0AAB\u0ABE\u0A87\u0AB2 \u0AA5\u0AAF\u0AC1\u0A82. \u0A85\u0AB0\u0A9C\u0AC0 \u0A86\u0A88\u0AA1\u0AC0:",
  "panel.scanHint": "Cformly \u0A8D\u0AAA \u0A96\u0ACB\u0AB2\u0ACB \u2192 \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2 \u0AAA\u0AB0 \u0AAE\u0ACB\u0A95\u0AB2\u0ACB \u2192 \u0A95\u0AAE\u0ACD\u0AAA\u0ACD\u0AAF\u0AC1\u0A9F\u0AB0\u0AA5\u0AC0 \u0AB8\u0ACD\u0A95\u0AC7\u0AA8 \u0A95\u0AB0\u0ACB \u0A85\u0AA8\u0AC7 \u0A86 \u0A95\u0ACB\u0AA1 \u0AA4\u0AB0\u0AAB \u0A95\u0AC5\u0AAE\u0AC7\u0AB0\u0ABE \u0A95\u0AB0\u0ACB \u2014 \u0A85\u0AA5\u0AB5\u0ABE \u0A86\u0A88\u0AA1\u0AC0 \u0A95\u0AC9\u0AAA\u0ABF \u0A95\u0AB0\u0ACB.",
  "panel.copy": "\u0A85\u0AB0\u0A9C\u0AC0 \u0A86\u0A88\u0AA1\u0AC0 \u0A95\u0AC9\u0AAA\u0ABF \u0A95\u0AB0\u0ACB",
  "panel.copied": "\u0A95\u0AC9\u0AAA\u0ABF \u0AA5\u0AAF\u0AC1\u0A82.",
  "panel.confirmNotDetected": "\u0AAA\u0AC1\u0AB7\u0ACD\u0A9F\u0ABF \u0AAE\u0AB3\u0AC0 \u0AA8\u0AA5\u0AC0 \u2014 \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2\u0AC7 \u0AB8\u0ABE\u0A9A\u0AB5\u0ACD\u0AAF\u0AC1\u0A82 \u0A9B\u0AC7 \u0A95\u0AC7 \u0AA8\u0AB9\u0AC0\u0A82 \u0AA4\u0AC7 \u0AA4\u0AAA\u0ABE\u0AB8\u0ACB, \u0AAA\u0A9B\u0AC0 \u0A86\u0A97\u0AB3 \u0AB5\u0AA7\u0ACB.",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "\u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0AA8\u0ACB \u0AAB\u0ACB\u0A9F\u0ACB \u0A9C\u0ACB\u0AA1\u0AB5\u0ABE \u0A85\u0AB9\u0AC0\u0A82 \u0AAE\u0AC2\u0A95\u0ACB",
  "panel.photoBrowse": "\u0AAC\u0ACD\u0AB0\u0ABE\u0A89\u0A9D\u2026",
  "panel.photoAttachFailed": "\u0A9C\u0ABE\u0AA4\u0AC7 \u0A9C\u0ACB\u0AA1\u0ABE\u0A88 \u0AB6\u0A95\u0ACD\u0AAF\u0ACB \u0AA8\u0AA5\u0AC0 \u2014 \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2\u0AA8\u0AC1\u0A82 \u0AAA\u0ACB\u0AA4\u0ABE\u0AA8\u0AC1\u0A82 \u0AAB\u0ABE\u0A87\u0AB2 \u0AAA\u0AB8\u0A82\u0AA6 \u0A95\u0AB0\u0ACB \u0AAC\u0A9F\u0AA8 \u0AB5\u0ABE\u0AAA\u0AB0\u0ACB.",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "\u0A86 \u0AAB\u0ACB\u0AB0\u0ACD\u0AAE Cformly \u0AA5\u0AC0 \u0AAD\u0AB0\u0ACB",
  "chip.hint": "\u0A86 \u0A95\u0AAE\u0ACD\u0AAA\u0ACD\u0AAF\u0AC1\u0A9F\u0AB0 \u0AAA\u0AB0 \u0AAE\u0ACB\u0A95\u0AB2\u0AC7\u0AB2\u0ABE \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0AA8\u0AC0 \u0AB5\u0ABF\u0A97\u0AA4\u0ACB \u0A85\u0AB9\u0AC0\u0A82 \u0AAA\u0AC7\u0AB8\u0ACD\u0A9F \u0A95\u0AB0\u0ACB (\u0A85\u0AA5\u0AB5\u0ABE \u0A9F\u0AC7\u0A95\u0ACD\u0AB8\u0ACD\u0A9F \u0AAB\u0ABE\u0A87\u0AB2 \u0A85\u0AB9\u0AC0\u0A82 \u0AAE\u0AC2\u0A95\u0ACB), \u0AAA\u0A9B\u0AC0 \u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAD\u0AB0\u0ACB \u0AA6\u0AAC\u0ABE\u0AB5\u0ACB.",
  "chip.fill": "\u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAD\u0AB0\u0ACB",
  "chip.filling": "\u0AAD\u0AB0\u0ABE\u0A88 \u0AB0\u0AB9\u0ACD\u0AAF\u0AC1\u0A82 \u0A9B\u0AC7\u2026",
  "chip.empty": "\u0AAD\u0AB0\u0AB5\u0ABE \u0AAE\u0ABE\u0A9F\u0AC7 \u0A95\u0A82\u0A88 \u0AA8\u0AA5\u0AC0 \u2014 \u0AAA\u0AB9\u0AC7\u0AB2\u0ABE Cformly \u0A8F\u0AAA\u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0A95\u0AC9\u0AAA\u0ABF \u0A95\u0AB0\u0AC7\u0AB2\u0AC0 \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0AA8\u0AC0 \u0AB5\u0ABF\u0A97\u0AA4\u0ACB \u0AAA\u0AC7\u0AB8\u0ACD\u0A9F \u0A95\u0AB0\u0ACB.",
  "chip.tooLarge": "\u0AAA\u0AC7\u0AB8\u0ACD\u0A9F \u0A95\u0AB0\u0AC7\u0AB2\u0AC1\u0A82 \u0AB2\u0A96\u0ABE\u0AA3 \u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82 \u0A9B\u0AC7 \u2014 \u0AAB\u0A95\u0ACD\u0AA4 Cformly \u0A8F\u0AAA\u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0A95\u0AC9\u0AAA\u0ABF \u0A95\u0AB0\u0AC7\u0AB2\u0AC0 \u0AB5\u0ABF\u0A97\u0AA4\u0ACB \u0AAA\u0AC7\u0AB8\u0ACD\u0A9F \u0A95\u0AB0\u0ACB.",
  "chip.collapse": "\u0AAC\u0A82\u0AA7 \u0A95\u0AB0\u0ACB",
  "chip.mappingFallback": "\u0AA8\u0ACB\u0A82\u0AA7: \u0AAE\u0AC7\u0AAA\u0ABF\u0A82\u0A97 \u0AB8\u0AB0\u0ACD\u0AB5\u0AB0 \u0AB8\u0AC1\u0AA7\u0AC0 \u0AAA\u0AB9\u0ACB\u0A82\u0A9A\u0AC0 \u0AB6\u0A95\u0ABE\u0AAF\u0AC1\u0A82 \u0AA8\u0AA5\u0AC0 \u2014 \u0A87\u0AA8\u0AAC\u0ABF\u0AB2\u0ACD\u0A9F \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 \u0AAE\u0AC7\u0AAA \u0AB5\u0AAA\u0AB0\u0ABE\u0A88 \u0AB0\u0AB9\u0ACD\u0AAF\u0AC1\u0A82 \u0A9B\u0AC7, \u0A9C\u0AC7 \u0A9C\u0AC2\u0AA8\u0AC1\u0A82 \u0AB9\u0ACB\u0A88 \u0AB6\u0A95\u0AC7.",
  // round-66: popup first-run onboarding
  "onboarding.title": "\u0AAA\u0AB9\u0AC7\u0AB2\u0AC0 \u0AB5\u0ABE\u0AB0 \u0A85\u0AB9\u0AC0\u0A82? \u0AA4\u0ACD\u0AB0\u0AA3 \u0AAA\u0A97\u0AB2\u0ABE\u0A82:",
  "onboarding.step1": "\u0AA4\u0AAE\u0ABE\u0AB0\u0ABE \u0AAB\u0ACB\u0AA8 \u0AAA\u0AB0: \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8 \u0A96\u0ACB\u0AB2\u0ACB \u2192 \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2 \u0AAA\u0AB0 \u0AAE\u0ACB\u0A95\u0AB2\u0ACB \u2192 \u0A95\u0AAE\u0ACD\u0AAA\u0ACD\u0AAF\u0AC1\u0A9F\u0AB0 \u0AAA\u0AB0 \u0AAE\u0ACB\u0A95\u0AB2\u0ACB.",
  "onboarding.step2": "\u0A86 \u0A95\u0AAE\u0ACD\u0AAA\u0ACD\u0AAF\u0AC1\u0A9F\u0AB0 \u0AAA\u0AB0: \u0AAA\u0ACB\u0AA4\u0ABE\u0AA8\u0AC7 \u0AAE\u0ACB\u0A95\u0AB2\u0AC7\u0AB2\u0AC0 \u0AB5\u0ABF\u0A97\u0AA4\u0ACB \u0AA8\u0AC0\u0A9A\u0AC7\u0AA8\u0ABE \u0AAC\u0ACB\u0A95\u0ACD\u0AB8\u0AAE\u0ABE\u0A82 \u0AAA\u0AC7\u0AB8\u0ACD\u0A9F \u0A95\u0AB0\u0ACB (\u0A85\u0AA5\u0AB5\u0ABE \u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAA\u0AC7\u0A9C \u0AAA\u0AB0\u0AA8\u0AC1\u0A82 \u0AB5\u0ABE\u0AA6\u0AB3\u0AC0 Cformly \u0AAC\u0A9F\u0AA8 \u0AA6\u0AAC\u0ABE\u0AB5\u0ACB).",
  "onboarding.step3": "\u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAD\u0AB0\u0ACB \u0AA6\u0AAC\u0ABE\u0AB5\u0ACB \u2014 \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2 \u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0A9C\u0ABE\u0AA4\u0AC7 \u0AAD\u0AB0\u0ABE\u0A88 \u0A9C\u0AB6\u0AC7. \u0AAB\u0ACB\u0A9F\u0ACB, \u0AB8\u0AC1\u0AB0\u0A95\u0ACD\u0AB7\u0ABE \u0A95\u0ACB\u0AA1 \u0A85\u0AA8\u0AC7 \u0AB8\u0AC7\u0AB5 \u0AA4\u0AAE\u0AC7 \u0A95\u0AB0\u0ACB.",
  "onboarding.done": "\u0AB8\u0AAE\u0A9C\u0ABE\u0A88 \u0A97\u0AAF\u0AC1\u0A82",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{total}\u0AAE\u0ABE\u0A82\u0AA5\u0AC0 {filled} \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 {time} \u0AB5\u0ABE\u0A97\u0ACD\u0AAF\u0AC7 \u0AAD\u0AB0\u0ABE\u0A88 \u0AB9\u0AA4\u0AC0. \u0AAB\u0AB0\u0AC0 \u0AAD\u0AB0\u0AB5\u0ABE \u0AAB\u0AB0\u0AC0 \u0AB6\u0AB0\u0AC2 \u0A95\u0AB0\u0ACB.",
  "resume.button": "\u0AAB\u0AB0\u0AC0 \u0AAD\u0AB0\u0ACB",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "\u0A86 \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2 \u0AAA\u0AC7\u0A9C Cformly \u0AA8\u0AC7 \u0A9C\u0ABE\u0AA3\u0AC0\u0AA4\u0ABE Form III \u0A9C\u0AC7\u0AB5\u0AC1\u0A82 \u0AB2\u0ABE\u0A97\u0AA4\u0AC1\u0A82 \u0AA8\u0AA5\u0AC0 \u2014 \u0A95\u0AA6\u0ABE\u0A9A \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2 \u0AAC\u0AA6\u0AB2\u0ABE\u0AAF\u0AC1\u0A82 \u0A9B\u0AC7. \u0A86 \u0AB5\u0ABE\u0AB0 Cformly \u0A8F\u0AAA\u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8 \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 \u0A95\u0AC9\u0AAA\u0AC0 \u0A95\u0AB0\u0AC0\u0AA8\u0AC7 \u0A9C\u0ABE\u0AA4\u0AC7 \u0AAD\u0AB0\u0ACB; \u0A85\u0AAE\u0AC7 \u0A85\u0AAA\u0AA1\u0AC7\u0A9F\u0AA8\u0AC0 \u0AA4\u0AAA\u0ABE\u0AB8 \u0A95\u0AB0\u0AC0 \u0AB0\u0AB9\u0ACD\u0AAF\u0ABE \u0A9B\u0AC0\u0A8F.",
  "canary.detail": "\u0A86 \u0AAA\u0AC7\u0A9C \u0AAA\u0AB0 Cformly \u0AA8\u0AC7 \u0A9C\u0ABE\u0AA3\u0AC0\u0AA4\u0ABE {total} \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1\u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0AAB\u0A95\u0ACD\u0AA4 {found} \u0A9C \u0AAE\u0AB3\u0ACD\u0AAF\u0ABE.",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "\u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8 \u0A95\u0AA4\u0ABE\u0AB0",
  "queue.add": "\u0A95\u0AA4\u0ABE\u0AB0\u0AAE\u0ABE\u0A82 \u0A89\u0AAE\u0AC7\u0AB0\u0ACB",
  "queue.fill": "\u0AAD\u0AB0\u0ACB",
  "queue.remove": "\u0AA6\u0AC2\u0AB0 \u0A95\u0AB0\u0ACB",
  "queue.unnamed": "\u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8",
  "queue.added": "{name} \u0AA8\u0AC7 \u0A95\u0AA4\u0ABE\u0AB0\u0AAE\u0ABE\u0A82 \u0A89\u0AAE\u0AC7\u0AB0\u0ACD\u0AAF\u0ABE.",
  "queue.duplicate": "\u0A86 \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8 \u0AAA\u0AB9\u0AC7\u0AB2\u0AC7\u0AA5\u0AC0 \u0A95\u0AA4\u0ABE\u0AB0\u0AAE\u0ABE\u0A82 \u0A9B\u0AC7.",
  "queue.full": "\u0A95\u0AA4\u0ABE\u0AB0 \u0AAD\u0AB0\u0AC7\u0AB2\u0AC0 \u0A9B\u0AC7 ({max} \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0ACB). \u0AAA\u0AB9\u0AC7\u0AB2\u0ABE \u0A8F\u0A95 \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0AA8\u0AC1\u0A82 \u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAD\u0AB0\u0ACB \u0A85\u0AA5\u0AB5\u0ABE \u0AA4\u0AC7\u0AAE\u0AA8\u0AC7 \u0AA6\u0AC2\u0AB0 \u0A95\u0AB0\u0ACB.",
  "queue.hint": "\u0AAD\u0AB0\u0AB5\u0ABE\u0AA8\u0AC0 \u0AB0\u0ABE\u0AB9\u0AAE\u0ABE\u0A82 \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8\u0ACB. \u0AB8\u0A82\u0AAA\u0AC2\u0AB0\u0ACD\u0AA3 \u0AAD\u0AB0\u0ABE\u0A88 \u0AAA\u0A9B\u0AC0 \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8 \u0A95\u0AA4\u0ABE\u0AB0\u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0AA6\u0AC2\u0AB0 \u0AA5\u0A88 \u0A9C\u0ABE\u0AAF \u0A9B\u0AC7; \u0AAC\u0ACD\u0AB0\u0ABE\u0A89\u0A9D\u0AB0 \u0AAC\u0A82\u0AA7 \u0AA5\u0AA4\u0ABE\u0A82 \u0A95\u0AA4\u0ABE\u0AB0 \u0AB8\u0ABE\u0AAB \u0AA5\u0A88 \u0A9C\u0ABE\u0AAF \u0A9B\u0AC7.",
  "queue.unavailable": "\u0A86 \u0AAC\u0ACD\u0AB0\u0ABE\u0A89\u0A9D\u0AB0\u0AAE\u0ABE\u0A82 \u0AAE\u0AB9\u0AC7\u0AAE\u0ABE\u0AA8 \u0A95\u0AA4\u0ABE\u0AB0 \u0A89\u0AAA\u0AB2\u0AAC\u0ACD\u0AA7 \u0AA8\u0AA5\u0AC0.",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "\u0A86 FRRO \u0A9F\u0AC5\u0AAC Cformly \u0A87\u0AA8\u0ACD\u0AB8\u0ACD\u0A9F\u0ACB\u0AB2 \u0A95\u0AB0\u0ACD\u0AAF\u0ABE \u0A85\u0AA5\u0AB5\u0ABE \u0A85\u0AAA\u0AA1\u0AC7\u0A9F \u0A95\u0AB0\u0ACD\u0AAF\u0ABE \u0AAA\u0AB9\u0AC7\u0AB2\u0ABE\u0A82 \u0A96\u0ACB\u0AB2\u0AB5\u0ABE\u0AAE\u0ABE\u0A82 \u0A86\u0AB5\u0ACD\u0AAF\u0AC1\u0A82 \u0AB9\u0AA4\u0AC1\u0A82. \u0A86 \u0A9F\u0AC5\u0AAC\u0AA8\u0AC7 \u0A8F\u0A95 \u0AB5\u0ABE\u0AB0 \u0AAB\u0AB0\u0AC0 \u0AB2\u0ACB\u0AA1 \u0A95\u0AB0\u0ACB (F5), \u0AAA\u0A9B\u0AC0 Fill \u0AA6\u0AAC\u0ABE\u0AB5\u0ACB.",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "\u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAE\u0AC7\u0AAA\u0ABF\u0A82\u0A97",
  "settings.mapVersion": "\u0A86\u0AB5\u0AC3\u0AA4\u0ACD\u0AA4\u0ABF",
  "settings.mapLastVerified": "\u0A9B\u0AC7\u0AB2\u0ACD\u0AB2\u0AC1\u0A82 \u0A9A\u0A95\u0ABE\u0AB8\u0ABE\u0AAF\u0AC1\u0A82",
  "settings.mapFetchedAt": "\u0AAE\u0AC7\u0AB3\u0AB5\u0AC7\u0AB2",
  "settings.mapSignature": "Ed25519 \u0AB8\u0AB9\u0AC0",
  "settings.mapRefresh": "\u0AB9\u0AAE\u0AA3\u0ABE\u0A82 \u0AB0\u0ABF\u0AAB\u0ACD\u0AB0\u0AC7\u0AB6 \u0A95\u0AB0\u0ACB",
  "settings.mapRefreshed": "\u0AAE\u0AC7\u0AAA\u0ABF\u0A82\u0A97 \u0AB0\u0ABF\u0AAB\u0ACD\u0AB0\u0AC7\u0AB6 \u0AA5\u0AAF\u0AC1\u0A82.",
  "settings.mapRefreshFailed": "\u0AAE\u0AC7\u0AAA\u0ABF\u0A82\u0A97 \u0AB0\u0ABF\u0AAB\u0ACD\u0AB0\u0AC7\u0AB6 \u0AA8 \u0AA5\u0A88 \u0AB6\u0A95\u0ACD\u0AAF\u0AC1\u0A82 - \u0A89\u0AAA\u0AB2\u0AAC\u0ACD\u0AA7 \u0AB6\u0ACD\u0AB0\u0AC7\u0AB7\u0ACD\u0AA0 \u0AA8\u0A95\u0AB2 \u0AB5\u0AAA\u0AB0\u0ABE\u0AAF \u0A9B\u0AC7.",
  "settings.mapStatusRemote": "\u0A9A\u0A95\u0ABE\u0AB8\u0AC7\u0AB2\u0AC1\u0A82 - \u0AAE\u0AC7\u0AAA\u0ABF\u0A82\u0A97 \u0AB8\u0AB0\u0ACD\u0AB5\u0AB0\u0AAE\u0ABE\u0A82\u0AA5\u0AC0 \u0AAE\u0AC7\u0AB3\u0AB5\u0AC7\u0AB2 \u0AA4\u0ABE\u0A9C\u0AC0 \u0AA8\u0A95\u0AB2.",
  "settings.mapStatusCached": "\u0A9A\u0A95\u0ABE\u0AB8\u0AC7\u0AB2\u0AC1\u0A82 - \u0AA4\u0ABE\u0A9C\u0AC7\u0AA4\u0AB0\u0AA8\u0AC0 \u0A95\u0AC5\u0AB6 \u0AA8\u0A95\u0AB2.",
  "settings.mapStatusBundled": "\u0AAC\u0ABF\u0AB2\u0ACD\u0A9F-\u0A87\u0AA8 \u0AAC\u0AC7\u0A9D\u0AB2\u0ABE\u0A87\u0AA8 \u0AA8\u0A95\u0AB2 (\u0AB8\u0AB0\u0ACD\u0AB5\u0AB0 \u0A89\u0AAA\u0AB2\u0AAC\u0ACD\u0AA7 \u0AA8\u0AA5\u0AC0). \u0AB8\u0AB9\u0AC0 \u0AB8\u0ABE\u0A9A\u0AB5\u0AC7\u0AB2 \u0A9B\u0AC7.",
  "settings.mapStatusTampered": "\u0AB8\u0AB9\u0AC0 \u0AA4\u0AAA\u0ABE\u0AB8 \u0AA8\u0ABF\u0AB7\u0ACD\u0AAB\u0AB3 - \u0A86 \u0AA8\u0A95\u0AB2 \u0AA8\u0A95\u0ABE\u0AB0\u0AB5\u0ABE\u0AAE\u0ABE\u0A82 \u0A86\u0AB5\u0AC0 \u0A9B\u0AC7 \u0A85\u0AA8\u0AC7 \u0A89\u0AAA\u0AAF\u0ACB\u0A97\u0AAE\u0ABE\u0A82 \u0AA8\u0AA5\u0AC0.",
  "chip.mappingUnavailable": "\u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAE\u0AC7\u0AAA\u0ABF\u0A82\u0A97 \u0AB2\u0ACB\u0AA1 \u0AA5\u0A88 \u0AB6\u0A95\u0AC0 \u0AA8\u0AB9\u0AC0\u0A82 \u2014 \u0A8F\u0A95\u0ACD\u0AB8\u0A9F\u0AC7\u0AA8\u0ACD\u0AB6\u0AA8\u0AA8\u0ABE \u0AAC\u0AC7\u0A95\u0A97\u0ACD\u0AB0\u0ABE\u0A89\u0AA8\u0ACD\u0AA1 \u0AB5\u0AB0\u0ACD\u0A95\u0AB0\u0AC7 \u0A9C\u0AB5\u0ABE\u0AAC \u0A86\u0AAA\u0ACD\u0AAF\u0ACB \u0AA8\u0AA5\u0AC0. \u0AAA\u0ACB\u0AB0\u0ACD\u0A9F\u0AB2 \u0A9F\u0AC5\u0AAC \u0AAB\u0AB0\u0AC0 \u0AB2\u0ACB\u0AA1 \u0A95\u0AB0\u0AC0\u0AA8\u0AC7 \u0AAB\u0AB0\u0AC0 \u0AAA\u0ACD\u0AB0\u0AAF\u0ABE\u0AB8 \u0A95\u0AB0\u0ACB.",
  "popup.timeoutMapping": "\u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAE\u0AC7\u0AAA\u0ABF\u0A82\u0A97 \u0AB2\u0ACB\u0AA1 \u0AA5\u0AB5\u0ABE\u0AA8\u0ACB \u0AB8\u0AAE\u0AAF \u0AB8\u0AAE\u0ABE\u0AAA\u0ACD\u0AA4 \u0AA5\u0AAF\u0ACB ({seconds} \u0AB8\u0AC7\u0A95\u0A82\u0AA1). \u0A95\u0AA8\u0AC7\u0A95\u0ACD\u0AB6\u0AA8 \u0A9A\u0A95\u0ABE\u0AB8\u0AC0\u0AA8\u0AC7 \u0AAB\u0AB0\u0AC0 \u0AAA\u0ACD\u0AB0\u0AAF\u0ABE\u0AB8 \u0A95\u0AB0\u0ACB.",
  "popup.timeoutNoProgress": "\u0AAD\u0AB0\u0ABE\u0AA3 {seconds} \u0AB8\u0AC7\u0A95\u0A82\u0AA1\u0AAE\u0ABE\u0A82 \u0AB6\u0AB0\u0AC2 \u0AA8 \u0AA5\u0A88 \u2014 Form III \u0AAA\u0AC7\u0A9C \u0A9C\u0AB5\u0ABE\u0AAC \u0A86\u0AAA\u0AC0 \u0AB0\u0AB9\u0ACD\u0AAF\u0AC1\u0A82 \u0AA8\u0AA5\u0AC0. \u0A9F\u0AC5\u0AAC \u0AAB\u0AB0\u0AC0 \u0AB2\u0ACB\u0AA1 \u0A95\u0AB0\u0AC0\u0AA8\u0AC7 \u0AAB\u0AB0\u0AC0 \u0AAA\u0ACD\u0AB0\u0AAF\u0ABE\u0AB8 \u0A95\u0AB0\u0ACB.",
  "popup.timeoutStalled": "\u0AAD\u0AB0\u0ABE\u0AA3 {seconds} \u0AB8\u0AC7\u0A95\u0A82\u0AA1\u0AA5\u0AC0 \u0A85\u0A9F\u0A95\u0AC0 \u0A9B\u0AC7 \u2014 Form III \u0AAA\u0AC7\u0A9C\u0AC7 \u0A9C\u0AB5\u0ABE\u0AAC \u0A86\u0AAA\u0AB5\u0ABE\u0AA8\u0AC1\u0A82 \u0AAC\u0A82\u0AA7 \u0A95\u0AB0\u0ACD\u0AAF\u0AC1\u0A82 \u0A9B\u0AC7.",
  "popup.timeoutCap": "\u0AAD\u0AB0\u0ABE\u0AA3 \u0A95\u0AC1\u0AB2 \u0AB8\u0AAE\u0AAF \u0AAE\u0AB0\u0ACD\u0AAF\u0ABE\u0AA6\u0ABE ({seconds} \u0AB8\u0AC7\u0A95\u0A82\u0AA1) \u0AB5\u0A9F\u0ABE\u0AB5\u0AC0 \u0A97\u0A88 \u0A85\u0AA8\u0AC7 \u0AB0\u0ACB\u0A95\u0AC0 \u0AA6\u0AC7\u0AB5\u0ABE\u0A88 \u0A9B\u0AC7.",
  "popup.preview": "\u0AAB\u0AC7\u0AB0\u0AAB\u0ABE\u0AB0\u0ACB \u0A9C\u0AC1\u0A93",
  "popup.previewApply": "\u0AB2\u0ABE\u0A97\u0AC1 \u0A95\u0AB0\u0ACB \u2014 \u0AAB\u0ACB\u0AB0\u0ACD\u0AAE \u0AAD\u0AB0\u0ACB",
  "popup.undo": "\u0A9B\u0AC7\u0AB2\u0ACD\u0AB2\u0AC0 \u0AAB\u0ABF\u0AB2 \u0A85\u0AA8\u0AA1\u0AC1 \u0A95\u0AB0\u0ACB",
  "popup.undoDone": "{total} \u0AAE\u0ABE\u0A82\u0AA5\u0AC0 {restored} \u0AAB\u0AC0\u0AB2\u0ACD\u0AA1 \u0AA4\u0AC7\u0AAE\u0AA8\u0ABE \u0A9C\u0AC2\u0AA8\u0ABE \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF\u0ACB \u0AAA\u0AB0 \u0AAA\u0AC1\u0AA8\u0A83\u0AB8\u0ACD\u0AA5\u0ABE\u0AAA\u0ABF\u0AA4 \u0A95\u0AB0\u0ACD\u0AAF\u0ABE.",
  "popup.undoPartial": "{total} \u0AAE\u0ABE\u0A82\u0AA5\u0AC0 {restored} \u0AAA\u0AC1\u0AA8\u0A83\u0AB8\u0ACD\u0AA5\u0ABE\u0AAA\u0ABF\u0AA4; {failed} \u0AAA\u0AC1\u0AA8\u0A83\u0AB8\u0ACD\u0AA5\u0ABE\u0AAA\u0ABF\u0AA4 \u0AA5\u0A88 \u0AB6\u0A95\u0ACD\u0AAF\u0ABE \u0AA8\u0AB9\u0AC0\u0A82 (\u0AAA\u0AC7\u0A9C \u0AAB\u0AB0\u0AC0\u0AA5\u0AC0 \u0AAC\u0AA8\u0ACD\u0AAF\u0AC1\u0A82 \u0AB9\u0ACB\u0A88 \u0AB6\u0A95\u0AC7 \u0A9B\u0AC7).",
  "popup.undoStale": "\u0AAB\u0ABF\u0AB2 \u0AAA\u0A9B\u0AC0 \u0AAA\u0AC7\u0A9C \u0AAC\u0AA6\u0AB2\u0ABE\u0AAF\u0AC1\u0A82 \u2014 \u0AAA\u0AC1\u0AA8\u0A83\u0AB8\u0ACD\u0AA5\u0ABE\u0AAA\u0AA8 \u0A85\u0AAA\u0AC2\u0AB0\u0ACD\u0AA3 \u0AB9\u0ACB\u0A88 \u0AB6\u0A95\u0AC7 \u0A9B\u0AC7.",
  "popup.undoNone": "\u0A85\u0AA8\u0AA1\u0AC1 \u0A95\u0AB0\u0AB5\u0ABE \u0AAE\u0ABE\u0A9F\u0AC7 \u0A95\u0A82\u0A88 \u0AA8\u0AA5\u0AC0 \u2014 \u0A86 \u0AB8\u0AA4\u0ACD\u0AB0\u0AAE\u0ABE\u0A82 \u0A86 \u0A9F\u0AC5\u0AAC \u0AAA\u0AB0 \u0A95\u0ACB\u0A88 \u0AAB\u0ABF\u0AB2 \u0AA5\u0A88 \u0AA8\u0AA5\u0AC0.",
  "popup.previewUnresolved": "\u0A86 \u0AAA\u0AC7\u0A9C \u0AAA\u0AB0 \u0AAE\u0AB3\u0ACD\u0AAF\u0AC1\u0A82 \u0AA8\u0AA5\u0AC0",
  "popup.previewManual": "\u0AAE\u0AC7\u0AA8\u0ACD\u0AAF\u0AC1\u0A85\u0AB2 \u0AA4\u0AAC\u0A95\u0ACD\u0A95\u0ACB",
  "popup.previewNoValue": "(\u0A86\u0AAA\u0AC7\u0AB2 \u0AA8\u0AA5\u0AC0)"
};

// src/i18n/as.ts
var as = {
  // popup
  "popup.title": "Cformly \u09B8\u09CD\u09AC\u09AF\u09BC\u0982\u0995\u09CD\u09F0\u09BF\u09AF\u09BC-\u09AA\u09C2\u09F0\u09A3",
  "popup.eyebrow": "\u09B8\u09CD\u09AC\u09AF\u09BC\u0982\u0995\u09CD\u09F0\u09BF\u09AF\u09BC-\u09AA\u09C2\u09F0\u09A3",
  "popup.bandSub": "FRRO Form III \xB7 \u099A\u09C7\u0995-\u0987\u09A8\u09F0 \u09E8\u09EA \u0998\u09A3\u09CD\u099F\u09BE\u09F0 \u09AD\u09BF\u09A4\u09F0\u09A4",
  "popup.fillFromClipboard": "Clipboard \u09F0 \u09AA\u09F0\u09BE \u09AB\u09F0\u09CD\u09AE \u09AA\u09C2\u09F0 \u0995\u09F0\u0995",
  "popup.fillHint": "Cformly \u098F\u09AA\u09F0 \u09AA\u09F0\u09BE \u0985\u09A4\u09BF\u09A5\u09BF\u09F0 \u09AB\u09BF\u09B2\u09CD\u09A1\u09AC\u09CB\u09F0 \u0995\u09AA\u09BF \u0995\u09F0\u0995, \u09A4\u09BE\u09F0 \u09AA\u09BF\u099B\u09A4 \u098F\u0987 \u09AA'\u09F0\u09CD\u099F\u09C7\u09B2 \u09AB\u09F0\u09CD\u09AE \u09AA\u09C2\u09F0 \u0995\u09F0\u0995\u0964",
  "popup.clipboardReadFailed": "Clipboard \u09AA\u09A2\u09BC\u09BF\u09AC \u09AA\u09F0\u09BE \u09A8\u0997'\u09B2\u0964 \u09AC\u09CD\u09F0\u09BE\u0989\u099C\u09BE\u09F0\u09F0 clipboard permissions \u09AA\u09F0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09F0\u0995\u0964",
  "popup.clipboardEmpty": "Clipboard \u09A4 Cformly \u09AB\u09BF\u09B2\u09CD\u09A1 \u09A8\u09BE\u0987\u0964 \u0986\u0997\u09A4\u09C7 Cformly \u098F\u09AA\u09F0 \u09AA\u09F0\u09BE \u0985\u09A4\u09BF\u09A5\u09BF\u09F0 \u09AB\u09BF\u09B2\u09CD\u09A1\u09AC\u09CB\u09F0 \u0995\u09AA\u09BF \u0995\u09F0\u0995\u0964",
  "popup.settings": "Settings",
  "popup.loadingMapping": "\u09AB\u09F0\u09CD\u09AE mapping \u09B2'\u09A1 \u09B9\u09C8 \u0986\u099B\u09C7...",
  "popup.filling": "\u09AB\u09F0\u09CD\u09AE \u09AA\u09C2\u09F0 \u09B9\u09C8 \u0986\u099B\u09C7...",
  "popup.fillingProgress": "\u09AD\u09F0\u09BE \u09B9\u09C8\u099B\u09C7\u2026 \u09AB\u09BF\u09B2\u09CD\u09A1 {completed}/{total}",
  "popup.noTab": "\u0995\u09CB\u09A8\u09CB \u09B8\u0995\u09CD\u09F0\u09BF\u09AF\u09BC \u099F\u09C7\u09AC \u09AA\u09CB\u09F1\u09BE \u09A8\u0997'\u09B2\u0964",
  "popup.filled": "\u09AA\u09CD\u09F0\u09AF\u09BC\u09CB\u099C\u09A8\u09C0\u09AF\u09BC \u09AB\u09BF\u09B2\u09CD\u09A1 \u09AA\u09C2\u09F0 \u09B9'\u09B2: {required} \u09F0 \u09AD\u09BF\u09A4\u09F0\u09A4 {filledRequired} (\u09AE\u09C1\u09A0 {filled} \u09AA\u09C2\u09F0)",
  "popup.portalMismatch": "\u09AA'\u09F0\u09CD\u099F\u09C7\u09B2 \u09B8\u09BE\u09B2\u09B8\u09B2\u09A8\u09BF \u09A7\u09F0\u09BE \u09AA\u09F0\u09BF\u09B2 (DOM \u09B8\u09B2\u09A8\u09BF \u09B9\u09C8\u099B\u09C7)\u0964 Cformly \u098F\u09AA\u09A4 \u0985\u09A4\u09BF\u09A5\u09BF\u09F0 \u09AB\u09BF\u09B2\u09CD\u09A1\u09AC\u09CB\u09F0 \u09AA\u09C1\u09A8\u09F0 \u0995\u09AA\u09BF \u0995\u09F0\u09BF \u0986\u0995\u09CC \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09F0\u0995\u0964",
  "popup.missingElements": "\u0985\u09A8\u09C1\u09AA\u09B8\u09CD\u09A5\u09BF\u09A4 \u0989\u09AA\u09BE\u09A6\u09BE\u09A8: {list}",
  "popup.missingValues": "\u0985\u09A8\u09C1\u09AA\u09B8\u09CD\u09A5\u09BF\u09A4 \u09AE\u09BE\u09A8: {list}",
  "popup.manualFields": "\u09B9\u09BE\u09A4\u09C7 \u0995\u09F0\u09BF\u09AC\u09B2\u0997\u09C0\u09AF\u09BC\u09BE \u09AA\u09A6\u0995\u09CD\u09B7\u09C7\u09AA: {list}",
  "popup.unsupportedFields": "\u09B8\u09CD\u09AC\u09AF\u09BC\u0982\u0995\u09CD\u09F0\u09BF\u09AF\u09BC\u09AD\u09BE\u09F1\u09C7 \u09AA\u09C2\u09F0 \u0995\u09F0\u09BF\u09AC \u09A8\u09CB\u09F1\u09BE\u09F0\u09BE \u09AB\u09BF\u09B2\u09CD\u09A1: {list}",
  "popup.tooLongFields": "\u098F\u0987 \u09AB\u09BF\u09B2\u09CD\u09A1\u09AC\u09CB\u09F0\u09F0 \u09AC\u09BE\u09AC\u09C7 \u09AE\u09BE\u09A8 \u09AC\u09C7\u099B\u09BF \u09A6\u09C0\u0998\u09B2 \u2014 \u098F\u0995\u09CB \u09B2\u09BF\u0996\u09BE \u09A8\u09B9'\u09B2, \u099A\u09C1\u099F\u09BF \u09AE\u09BE\u09A8 \u099F\u09BE\u0987\u09AA \u0995\u09F0\u0995: {list}",
  "popup.unverifiedFields": "\u098F\u0987 \u09AB\u09BF\u09B2\u09CD\u09A1\u09AC\u09CB\u09F0 \u09AA\u09F0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09F0\u0995 \u2014 \u09AE\u09BE\u09A8 \u0996\u09BE\u09AA \u0996\u09BE\u0987 \u09A8\u09A5\u0995\u09BE \u09B9'\u09AC \u09AA\u09BE\u09F0\u09C7: {list}",
  "popup.applicationId": "Application ID: {id}",
  "popup.accommodationMismatch": "\u09B8\u09A4\u09F0\u09CD\u0995\u09AC\u09BE\u09A3\u09C0: FRRO \u099B\u09C7\u099A\u09A8 \u0985\u09A8\u09CD\u09AF \u09AA\u09CD\u09F0\u09AA\u09BE\u09F0\u09CD\u099F\u09BF\u09F0 \u09B9'\u09AC \u09AA\u09BE\u09F0\u09C7\u0964 \u09A6\u09BE\u0996\u09BF\u09B2 \u0995\u09F0\u09BE\u09F0 \u0986\u0997\u09A4\u09C7 \u09AA\u09F0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09F0\u0995\u0964",
  "popup.attention": "\u0995\u09BF\u099B\u09C1\u09AE\u09BE\u09A8 \u09AB\u09BF\u09B2\u09CD\u09A1\u09F0 \u0997\u09C1\u09F0\u09C1\u09A4\u09CD\u09AC \u09A6\u09F0\u0995\u09BE\u09F0\u0964 Cformly \u098F\u09AA\u09A4 \u0985\u09A4\u09BF\u09A5\u09BF\u09F0 \u09AB\u09BF\u09B2\u09CD\u09A1\u09AC\u09CB\u09F0 \u09AA\u09C1\u09A8\u09F0 \u0995\u09AA\u09BF \u0995\u09F0\u09BF \u0986\u0995\u09CC \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09F0\u0995\u0964",
  "popup.openPrint": "Individual Print \u0996\u09CB\u09B2\u0995",
  "popup.printNoId": "\u098F\u09A4\u09BF\u09AF\u09BC\u09BE\u09B2\u09C8 Application ID \u0995\u09C7\u09AA\u099A\u09BE\u09F0 \u09B9\u09CB\u09F1\u09BE \u09A8\u09BE\u0987 \u2014 \u0986\u0997\u09A4\u09C7 \u09AB\u09F0\u09CD\u09AE \u09AA\u09C2\u09F0 \u0995\u09F0\u0995\u0964",
  "popup.printSent": "ID {id} \u09F0 \u09A6\u09BE\u0996\u09BF\u09B2 \u09B9\u09CB\u09F1\u09BE \u0986\u09AC\u09C7\u09A6\u09A8 \u09AA\u09C1\u09A8\u09F0 \u0996\u09CB\u09B2\u09BE \u09B9'\u09B2\u0964 PDF \u09A1\u09BE\u0989\u09A8\u09B2'\u09A1 \u0995\u09F0\u09BF\u09AC\u09B2\u09C8 \u09AA'\u09F0\u09CD\u099F\u09C7\u09B2\u09F0 Individual Print \u09AE\u09C7\u09A8\u09C1 \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0 \u0995\u09F0\u0995\u0964",
  "popup.formFilled": "\u09AB\u09F0\u09CD\u09AE \u09AA\u09C2\u09F0 \u09B9'\u09B2\u0964 \u09AA'\u09F0\u09CD\u099F\u09C7\u09B2\u09A4 \u09F0\u09BF\u09AD\u09BF\u0989 \u0995\u09F0\u09BF \u09A6\u09BE\u0996\u09BF\u09B2 \u0995\u09F0\u0995\u0964",
  "popup.fillError": "\u09AA\u09C2\u09F0\u09A3\u09A4 \u09AD\u09C1\u09B2: {message}",
  "popup.connectionFailed": "FRRO \u09AA'\u09F0\u09CD\u099F\u09C7\u09B2 \u09AA\u09C3\u09B7\u09CD\u09A0\u09BE\u09B2\u09C8 \u09AA\u09CB\u09B9\u0981\u099A \u09A8\u09BE\u09AA\u09BE\u09B2\u09C7\u0964 \u098F\u0987 \u099F\u09C7\u09AC\u09A4 Form III \u09AA\u09C3\u09B7\u09CD\u09A0\u09BE \u0996\u09C1\u09B2\u09BF \u0986\u0995\u09CC \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09F0\u0995\u0964",
  "popup.unknownError": "\u0985\u099C\u09CD\u099E\u09BE\u09A4",
  "popup.apiBaseFallback": "\u09B8\u09A4\u09F0\u09CD\u0995\u09AC\u09BE\u09A3\u09C0: \u099C\u09AE\u09BE \u09A5\u0995\u09BE API URL \u0985\u09AE\u09BE\u09A8\u09CD\u09AF \u2014 \u09A1\u09BF\u09AB'\u09B2\u09CD\u099F \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0 \u09B9\u09C8\u099B\u09C7\u0964 Settings \u09A4 \u0986\u09AA\u09A1\u09C7\u099F \u0995\u09F0\u0995\u0964",
  "popup.mappingFallback": "\u09B8\u09A4\u09F0\u09CD\u0995\u09AC\u09BE\u09A3\u09C0: mapping \u099B\u09BE\u09F0\u09CD\u09AD\u09BE\u09F0 \u0985\u09AA\u09CD\u09F0\u09BE\u09AA\u09CD\u09AF \u2014 \u09AC\u09BF\u09B2\u09CD\u099F-\u0987\u09A8 \u09AB\u09BF\u09B2\u09CD\u09A1 \u09AE\u09C7\u09AA \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0 \u09B9\u09C8\u099B\u09C7, \u09AF\u09BF\u099F\u09CB \u09AA\u09C1\u09F0\u09A3\u09BE \u09B9'\u09AC \u09AA\u09BE\u09F0\u09C7\u0964",
  // settings
  "settings.title": "Cformly Settings",
  "settings.eyebrow": "Settings",
  "settings.bandSub": "\u09AB\u09F0\u09CD\u09AE mapping \u09AF\u09CB\u0997\u09BE\u09A8 \u09A7\u09F0\u09BE backend \u099B\u09C7\u099F \u0986\u09AA \u0995\u09F0\u0995\u0964",
  "settings.apiLabel": "Cformly API URL",
  "settings.apiHint": "\u09AB\u09F0\u09CD\u09AE mapping \u09AF\u09CB\u0997\u09BE\u09A8 \u09A7\u09F0\u09BE backend\u0964 \u0995\u09C7\u09F1\u09B2 HTTPS; localhost \u0995\u09C7\u09F1\u09B2 development builds \u09A4 \u099A\u09B2\u09C7\u0964",
  "settings.save": "\u099B\u09C7\u09AD \u0995\u09F0\u0995",
  "settings.back": "\u0998\u09C2\u09F0\u09BF \u09AF\u09BE\u0993\u0995",
  "settings.backInTab": "Settings \u099F\u09C7\u09AC \u09B9\u09BF\u099A\u09BE\u09AA\u09C7 \u0996\u09C1\u09B2\u09BF\u099B\u09C7 \u2014 fill popup \u09F0 \u09AC\u09BE\u09AC\u09C7 Cformly toolbar icon \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0 \u0995\u09F0\u0995\u0964",
  "settings.urlEmpty": "URL \u0996\u09BE\u09B2\u09C0 \u09B9'\u09AC \u09A8\u09CB\u09F1\u09BE\u09F0\u09C7\u0964",
  "settings.httpsOnly": "\u09B8\u09C1\u09F0\u0995\u09CD\u09B7\u09BE\u09F0 \u09AC\u09BE\u09AC\u09C7 \u0995\u09C7\u09F1\u09B2 HTTPS URLs \u09AE\u09BE\u09A8\u09CD\u09AF\u0964 production \u09F0 \u09AC\u09BE\u09AC\u09C7 https:// \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0 \u0995\u09F0\u0995\u0964",
  "settings.hostNotAllowed": "URL hostname localhost \u09AC\u09BE *.cformly.com \u09B9'\u09AC \u09B2\u09BE\u0997\u09BF\u09AC (\u09AA\u09CB\u09F1\u09BE \u0997'\u09B2: {host})\u0964",
  "settings.invalidUrl": "\u0985\u09AE\u09BE\u09A8\u09CD\u09AF URL\u0964 https:// \u0985\u09A8\u09CD\u09A4\u09F0\u09CD\u09AD\u09C1\u0995\u09CD\u09A4 \u0995\u09F0\u0995",
  "settings.urlPathNotAllowed": "\u0995\u09C7\u09F1\u09B2 bare origin \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0 \u0995\u09F0\u0995 \u2014 path, query \u0986\u09F0\u09C1 #fragment \u0986\u0981\u09A4\u09F0\u09BE\u0993\u0995\u0964",
  "settings.loopbackNotGranted": "Localhost API URLs \u0995\u09C7\u09F1\u09B2 development builds \u09A4 \u099A\u09B2\u09C7\u0964 \u098F\u0987 build \u098F \u0995\u09C7\u09F1\u09B2 https:// hosts \u09B2\u09C8\u09B9\u09C7 \u09AA\u09CB\u09B9\u0981\u099A \u09AA\u09BE\u09F0\u09C7\u0964",
  "settings.saved": "\u099B\u09C7\u09AD \u09B9'\u09B2\u0964",
  "settings.saveError": "\u099B\u09C7\u09AD \u0995\u09F0\u09BF\u09AC \u09AA\u09F0\u09BE \u09A8\u0997'\u09B2\u0964 \u0986\u0995\u09CC \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09F0\u0995\u0964",
  "settings.langLabel": "\u09AD\u09BE\u09B7\u09BE",
  "settings.langEnglish": "English",
  "settings.langHindi": "\u0939\u093F\u0928\u094D\u0926\u0940",
  "settings.langAuto": "\u09AC\u09CD\u09F0\u09BE\u0989\u099C\u09BE\u09F0 \u0985\u09A8\u09C1\u09B8\u09F0\u09A3 \u0995\u09F0\u0995",
  "settings.langHint": "\u0986\u09AA\u09C1\u09A8\u09BF \u09AC\u09BE\u099B\u09A8\u09BF \u09A8\u0995\u09F0\u09BE\u09B2\u09C8 \u09AC\u09CD\u09F0\u09BE\u0989\u099C\u09BE\u09F0\u09F0 \u09AD\u09BE\u09B7\u09BE \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0 \u09B9'\u09AC\u0964",
  // round-65: paste intake + in-page filing panel
  "popup.pasteLabel": "\u09A8\u09BE\u0987 \u09AB\u09BF\u09B2\u09CD\u09A1\u09AC\u09CB\u09F0 \u0987\u09AF\u09BC\u09BE\u09A4 \u09AA\u09C7\u09B7\u09CD\u099F \u0995\u09F0\u0995",
  "popup.pdfPick": "Cformly PDF \u0996\u09CB\u09B2\u0995",
  "popup.pdfLoaded": "\u0985\u09A4\u09BF\u09A5\u09BF\u09F0 \u09AB\u09BF\u09B2\u09CD\u09A1\u09B8\u09AE\u09C2\u09B9 Cformly PDF\u09F0 \u09AA\u09F0\u09BE \u09B2'\u09A1 \u09B9\u09C8\u099B\u09C7 \u2014 \u09A4\u09B2\u09A4 \u09AA\u09F0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09F0\u09BF Fill Form \u099F\u09BF\u09AA\u0995\u0964",
  "popup.pdfRejected": "\u098F\u0987 PDF\u0996\u09A8\u09A4 Cformly \u09AB\u09BF\u09B2\u09CD\u09A1 \u09A8\u09BE\u0987 \u09AC\u09BE \u09AA\u09A2\u09BC\u09BF\u09AC \u09AA\u09F0\u09BE \u09A8\u0997'\u09B2 \u2014 Cformly \u098F\u09AA\u09F0 \u09AA\u09F0\u09BE \u098F\u0995\u09CD\u09B8\u09AA'\u09F0\u09CD\u099F \u0995\u09F0\u09BE PDF\u0996\u09A8\u09B9\u09C7 \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0 \u0995\u09F0\u0995\u0964",
  "popup.pastePlaceholder": "\u0995\u09AA\u09BF \u0995\u09F0\u09BE Cformly \u09AB\u09BF\u09B2\u09CD\u09A1\u09AC\u09CB\u09F0 \u0987\u09AF\u09BC\u09BE\u09A4 \u09AA\u09C7\u09B7\u09CD\u099F \u0995\u09F0\u0995",
  "popup.pasteHint": "\u0995\u09CD\u09B2\u09BF\u09AA\u09AC\u09F0\u09CD\u09A1 \u09AC\u09BE\u099F\u09A8\u09C7 \u0995\u09BE\u09AE \u09A8\u0995\u09F0\u09BF\u09B2\u09C7, \u098F\u0987 \u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09F0\u09B2\u09C8 \u09AA\u09A0\u09CB\u09F1\u09BE \u09AB\u09BF\u09B2\u09CD\u09A1\u09AC\u09CB\u09F0 \u0987\u09AF\u09BC\u09BE\u09A4 \u09AA\u09C7\u09B7\u09CD\u099F \u0995\u09F0\u0995 (\u09A8\u09BE\u0987 \u099F\u09C7\u0995\u09CD\u09B8\u099F \u09AB\u09BE\u0987\u09B2 \u098F\u09F0\u0995), \u09A4\u09BE\u09F0 \u09AA\u09BE\u099B\u09A4 \u09AD\u09F0\u0995 \u099F\u09BF\u09AA\u0995\u0964",
  "popup.payloadTooLarge": "\u09AA\u09C7\u09B7\u09CD\u099F \u0995\u09F0\u09BE \u09B2\u09BF\u0996\u09A8\u09BF \u09AC\u09F0 \u09A1\u09BE\u0999\u09F0 \u2014 \u0995\u09C7\u09F1\u09B2 Cformly \u098F\u09AA\u09F0 \u09AA\u09F0\u09BE \u0995\u09AA\u09BF \u0995\u09F0\u09BE \u09AB\u09BF\u09B2\u09CD\u09A1 \u09AA\u09C7\u09B7\u09CD\u099F \u0995\u09F0\u0995\u0964",
  "panel.title": "Cformly \u2014 \u09AA'\u09F0\u09CD\u099F\u09BE\u09B2\u09A4 \u09AB\u09BE\u0987\u09B2\u09BF\u0982 \u09B8\u09AE\u09CD\u09AA\u09C2\u09F0\u09CD\u09A3 \u0995\u09F0\u0995",
  "panel.dismiss": "\u09AC\u09A8\u09CD\u09A7 \u0995\u09F0\u0995",
  "panel.filled": "\u09AD\u09F0\u09BE \u09AB\u09BF\u09B2\u09CD\u09A1: {filledRequired} / {required} \u09AC\u09BE\u09A7\u09CD\u09AF\u09A4\u09BE\u09AE\u09C2\u09B2\u0995",
  "panel.photoStep": "\u0985\u09A4\u09BF\u09A5\u09BF\u09F0 \u09AB\u099F\u09CB \u09B8\u0982\u09B2\u0997\u09CD\u09A8 \u0995\u09F0\u0995 (\u09AB\u09BE\u0987\u09B2 \u09AC\u09BE\u099B\u0995 \u2192 \u0986\u09AA\u09B2\u09CB\u09A1 \u0995\u09F0\u0995)",
  "panel.captchaStep": "\u09B8\u09C1\u09F0\u0995\u09CD\u09B7\u09BE \u0995'\u09A1 (CAPTCHA) \u099F\u09BE\u0987\u09AA \u0995\u09F0\u0995",
  "panel.saveStep": "\u099B\u09C7\u09AD \u0995\u09F0\u09BF \u0986\u0997\u09AC\u09BE\u09A2\u09BC\u0995 \u099F\u09BF\u09AA\u0995",
  "panel.warnSession": "Cformly \u09B8\u09A4\u09F0\u09CD\u0995\u09AC\u09BE\u09A3\u09C0: \u098F\u0987 FRRO \u099B\u09C7\u099B\u09A8 \u0986\u09A8 \u098F\u0996\u09A8 \u09B8\u09AE\u09CD\u09AA\u09A4\u09CD\u09A4\u09BF\u09F0 \u09B9'\u09AC \u09AA\u09BE\u09F0\u09C7 ({reason})\u0964 \u099B\u09C7\u09AD \u0995\u09F0\u09BE\u09F0 \u0986\u0997\u09A4\u09C7 \u09AA\u09F0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09F0\u0995\u0964",
  "panel.warnUnverified": "Cformly \u09B8\u09A4\u09F0\u09CD\u0995\u09AC\u09BE\u09A3\u09C0: \u098F\u0987 \u09AB\u09BF\u09B2\u09CD\u09A1\u09AC\u09CB\u09F0\u09F0 \u09AE\u09BE\u09A8\u09AC\u09CB\u09F0 \u09A8\u09A5\u0995\u09BE \u09B9'\u09AC \u09AA\u09BE\u09F0\u09C7: {list}\u0964 \u099B\u09C7\u09AD \u0995\u09F0\u09BE\u09F0 \u0986\u0997\u09A4\u09C7 \u09AA\u09F0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09F0\u0995\u0964",
  "panel.saving": "\u09AA'\u09F0\u09CD\u099F\u09BE\u09B2\u09F0 \u09A8\u09BF\u09B6\u09CD\u099A\u09BF\u09A4\u09BF\u09F0 \u09AC\u09BE\u09AC\u09C7 \u0985\u09AA\u09C7\u0995\u09CD\u09B7\u09BE\u2026",
  "panel.progress": "\u09AB\u09BF\u09B2\u09CD\u09A1 \u09AD\u09F0\u09BE \u09B9\u09C8\u099B\u09C7\u2026 {completed}/{total}",
  "panel.sessionExpired": "FRRO \u0985\u09A7\u09BF\u09AC\u09C7\u09B6\u09A8 \u09B6\u09C7\u09B7 \u09B9'\u09B2 \u2014 \u09AA\u09C1\u09A8\u09F0 \u09B2'\u0997 \u0987\u09A8 \u0995\u09F0\u0995, \u09AB\u09F0\u09CD\u09AE \u0996\u09C1\u09B2\u09BF Fill \u099F\u09BF\u09AA\u0995\u0964 \u0986\u09AA\u09CB\u09A8\u09BE\u09F0 \u0985\u09A4\u09BF\u09A5\u09BF\u09F0 \u09AC\u09BF\u09F1\u09F0\u09A3 Cformly \u098F\u09AA\u09A4 \u09B8\u09C1\u09F0\u0995\u09CD\u09B7\u09BF\u09A4 \u0986\u099B\u09C7\u0964",
  "panel.portalError": "\u09AA'\u09F0\u09CD\u099F\u09C7\u09B2\u09C7 \u09B8\u09AE\u09B8\u09CD\u09AF\u09BE \u09A6\u09C7\u0996\u09C1\u09F1\u09BE\u09B2\u09C7:",
  "panel.appIdFound": "\u09B8\u09AB\u09B2\u09AD\u09BE\u09F1\u09C7 \u09AB\u09BE\u0987\u09B2 \u09B9'\u09B2\u0964 \u0986\u09AC\u09C7\u09A6\u09A8 \u0986\u0987\u09A1\u09BF:",
  "panel.scanHint": "Cformly \u098F\u09AA \u0996\u09CB\u09B2\u0995 \u2192 \u09AA'\u09F0\u09CD\u099F\u09BE\u09B2\u09B2\u09C8 \u09AA\u09A0\u09BE\u0993\u0995 \u2192 \u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09F0\u09F0 \u09AA\u09F0\u09BE \u09B8\u09CD\u0995\u09C7\u09A8 \u0995\u09F0\u0995 \u0986\u09F0\u09C1 \u098F\u0987 \u0995'\u09A1\u09F0 \u09AB\u09BE\u09B2\u09C7 \u0995\u09C7\u09AE\u09C7\u09F0\u09BE \u09A7\u09F0\u0995 \u2014 \u09A8\u09BE\u0987 \u0986\u0987\u09A1\u09BF \u0995\u09AA\u09BF \u0995\u09F0\u0995\u0964",
  "panel.copy": "\u0986\u09AC\u09C7\u09A6\u09A8 \u0986\u0987\u09A1\u09BF \u0995\u09AA\u09BF \u0995\u09F0\u0995",
  "panel.copied": "\u0995\u09AA\u09BF \u09B9'\u09B2\u0964",
  "panel.confirmNotDetected": "\u09A8\u09BF\u09B6\u09CD\u099A\u09BF\u09A4\u09BF \u09AA\u09CB\u09F1\u09BE \u09A8\u0997'\u09B2 \u2014 \u09AA'\u09F0\u09CD\u099F\u09BE\u09B2\u09C7 \u099B\u09C7\u09AD \u0995\u09F0\u09BF\u099B\u09C7 \u09A8\u09C7 \u09A8\u09BE\u0987 \u09AA\u09F0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09F0\u0995, \u09A4\u09BE\u09F0 \u09AA\u09BF\u099B\u09A4 \u0986\u0997\u09AC\u09BE\u09A2\u09BC\u09BF \u09AF\u09BE\u0993\u0995\u0964",
  // round-66: photo attach affordances in the panel
  "panel.photoDrop": "\u0985\u09A4\u09BF\u09A5\u09BF\u09F0 \u09AB\u099F\u09CB \u09B8\u0982\u09B2\u0997\u09CD\u09A8 \u0995\u09F0\u09BF\u09AC\u09B2\u09C8 \u0987\u09AF\u09BC\u09BE\u09A4 \u098F\u09F0\u0995",
  "panel.photoBrowse": "\u09AC\u09CD\u09F0\u09BE\u0989\u099C\u2026",
  "panel.photoAttachFailed": "\u09B8\u09CD\u09AC\u09AF\u09BC\u0982\u0995\u09CD\u09F0\u09BF\u09AF\u09BC\u09AD\u09BE\u09F1\u09C7 \u09B8\u0982\u09B2\u0997\u09CD\u09A8 \u09A8\u09B9'\u09B2 \u2014 \u09AA'\u09F0\u09CD\u099F\u09C7\u09B2\u09F0 \u09A8\u09BF\u099C\u09BE \u09AB\u09BE\u0987\u09B2 \u09AC\u09BE\u099B\u0995 \u09AC\u09BE\u099F\u09A8 \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0 \u0995\u09F0\u0995\u0964",
  // round-66: in-page fill chip
  "chip.label": "Cformly",
  "chip.title": "\u098F\u0987 \u09AB\u09F0\u09CD\u09AE Cformly-\u09F0 \u09B8\u09B9\u09BE\u09AF\u09BC\u09A4 \u09AA\u09C2\u09F0\u09A3 \u0995\u09F0\u0995",
  "chip.hint": "\u098F\u0987 \u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09F0\u09B2\u09C8 \u09AA\u09A0\u09CB\u09F1\u09BE \u0985\u09A4\u09BF\u09A5\u09BF\u09F0 \u09A4\u09A5\u09CD\u09AF\u09B8\u09AE\u09C2\u09B9 \u0987\u09AF\u09BC\u09BE\u09A4 \u09AA\u09C7\u09B7\u09CD\u099F \u0995\u09F0\u0995 (\u09AC\u09BE \u099F\u09C7\u0995\u09CD\u09B8\u099F \u09AB\u09BE\u0987\u09B2 \u0987\u09AF\u09BC\u09BE\u09A4 \u098F\u09F0\u0995), \u09A4\u09BE\u09F0\u09AA\u09BF\u099B\u09A4 \u09AB\u09F0\u09CD\u09AE \u09AA\u09C2\u09F0\u09A3 \u0995\u09F0\u0995 \u099F\u09BF\u09AA\u0995\u0964",
  "chip.fill": "\u09AB\u09F0\u09CD\u09AE \u09AA\u09C2\u09F0\u09A3 \u0995\u09F0\u0995",
  "chip.filling": "\u09AA\u09C2\u09F0\u09A3 \u09B9\u09C8 \u0986\u099B\u09C7\u2026",
  "chip.empty": "\u09AA\u09C2\u09F0\u09A3 \u0995\u09F0\u09BF\u09AC\u09B2\u09C8 \u098F\u0995\u09CB \u09A8\u09BE\u0987 \u2014 \u09AA\u09CD\u09F0\u09A5\u09AE\u09C7 Cformly \u098F\u09AA\u09F0 \u09AA\u09F0\u09BE \u0995\u09AA\u09BF \u0995\u09F0\u09BE \u0985\u09A4\u09BF\u09A5\u09BF\u09F0 \u09A4\u09A5\u09CD\u09AF \u09AA\u09C7\u09B7\u09CD\u099F \u0995\u09F0\u0995\u0964",
  "chip.tooLarge": "\u09AA\u09C7\u09B7\u09CD\u099F \u0995\u09F0\u09BE \u099F\u09C7\u0995\u09CD\u09B8\u099F \u09AC\u09F0 \u09A1\u09BE\u0999\u09F0 \u2014 \u0995\u09C7\u09F1\u09B2 Cformly \u098F\u09AA\u09F0 \u09AA\u09F0\u09BE \u0995\u09AA\u09BF \u0995\u09F0\u09BE \u09A4\u09A5\u09CD\u09AF \u09AA\u09C7\u09B7\u09CD\u099F \u0995\u09F0\u0995\u0964",
  "chip.collapse": "\u09AC\u09A8\u09CD\u09A7 \u0995\u09F0\u0995",
  "chip.mappingFallback": "\u099F\u09CB\u0995\u09BE: \u09AE\u09C7\u09AA\u09BF\u0982 \u099A\u09BE\u09F0\u09CD\u09AD\u09BE\u09F0\u09A4 \u09B8\u0982\u09AF\u09CB\u0997 \u09A8\u09B9'\u09B2 \u2014 \u09AC\u09BF\u09B2\u09CD\u099F-\u0987\u09A8 \u09AB\u09BF\u09B2\u09CD\u09A1 \u09AE\u09C7\u09AA \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0 \u09B9\u09C8\u099B\u09C7, \u09AF\u09BF\u099F\u09CB \u09AA\u09C1\u09F0\u09A3\u09BF \u09B9'\u09AC \u09AA\u09BE\u09F0\u09C7\u0964",
  // round-66: popup first-run onboarding
  "onboarding.title": "\u09AA\u09CD\u09F0\u09A5\u09AE\u09AC\u09BE\u09F0 \u0987\u09AF\u09BC\u09BE\u09A4? \u09A4\u09BF\u09A8\u09BF\u099F\u09BE \u09AA\u09A6\u0995\u09CD\u09B7\u09C7\u09AA:",
  "onboarding.step1": "\u0986\u09AA\u09CB\u09A8\u09BE\u09F0 \u09AB\u09CB\u09A8\u09A4: \u0985\u09A4\u09BF\u09A5\u09BF \u0996\u09CB\u09B2\u0995 \u2192 \u09AA'\u09F0\u09CD\u099F\u09C7\u09B2\u09B2\u09C8 \u09AA\u09A0\u09BE\u0993\u0995 \u2192 \u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09F0\u09B2\u09C8 \u09AA\u09A0\u09BE\u0993\u0995\u0964",
  "onboarding.step2": "\u098F\u0987 \u0995\u09AE\u09CD\u09AA\u09BF\u0989\u099F\u09BE\u09F0\u09A4: \u09A8\u09BF\u099C\u0995\u09C7 \u09AA\u09A0\u09CB\u09F1\u09BE \u09A4\u09A5\u09CD\u09AF \u09A4\u09B2\u09F0 \u09AC\u09BE\u0995\u099A\u09A4 \u09AA\u09C7\u09B7\u09CD\u099F \u0995\u09F0\u0995 (\u09AC\u09BE \u09AB\u09F0\u09CD\u09AE \u09AA\u09C3\u09B7\u09CD\u09A0\u09BE\u09F0 \u09A8\u09C0\u09B2\u09BE Cformly \u09AC\u09BE\u099F\u09A8\u099F\u09CB \u099F\u09BF\u09AA\u0995)\u0964",
  "onboarding.step3": "\u09AB\u09F0\u09CD\u09AE \u09AA\u09C2\u09F0\u09A3 \u0995\u09F0\u0995 \u099F\u09BF\u09AA\u0995 \u2014 \u09AA'\u09F0\u09CD\u099F\u09C7\u09B2 \u09AB\u09F0\u09CD\u09AE \u09A8\u09BF\u099C\u09C7 \u09AA\u09C2\u09F0\u09A3 \u09B9'\u09AC\u0964 \u09AB\u099F\u09CB, \u09B8\u09C1\u09F0\u0995\u09CD\u09B7\u09BE \u0995'\u09A1 \u0986\u09F0\u09C1 \u099B\u09C7\u09AD \u0986\u09AA\u09C1\u09A8\u09BF \u0995\u09F0\u0995\u0964",
  "onboarding.done": "\u09AC\u09C1\u099C\u09BF\u09B2\u09CB\u0981",
  // roadmap 35: partial-fill resume offer band
  "resume.summary": "{total}\u099F\u09BE\u09F0 \u09AD\u09BF\u09A4\u09F0\u09A4 {filled}\u099F\u09BE \u09AB\u09BF\u09B2\u09CD\u09A1 {time} \u09AC\u09BE\u099C\u09A4 \u09AD\u09F0\u09BE \u09B9\u09C8\u099B\u09BF\u09B2\u0964 \u0986\u0995\u09CC \u09AD\u09F0\u09BF\u09AC\u09B2\u09C8 \u09AA\u09C1\u09A8\u09F0 \u0986\u09F0\u09AE\u09CD\u09AD \u0995\u09F0\u0995\u0964",
  "resume.button": "\u0986\u0995\u09CC \u09AD\u09F0\u09BE\u0993\u0995",
  // roadmap 41: portal-change canary refusal
  "canary.blocked": "\u098F\u0987 \u09AA\u09F0\u09CD\u099F\u09C7\u09B2 \u09AA\u09C3\u09B7\u09CD\u09A0\u09BE\u0996\u09A8 Cformly-\u09F0 \u099A\u09BF\u09A8\u09BE\u0995\u09BF Form III \u09F0 \u09A6\u09F0\u09C7 \u09A8\u09B9\u09AF\u09BC \u2014 \u09B8\u09AE\u09CD\u09AD\u09F1\u09A4\u0983 \u09AA\u09F0\u09CD\u099F\u09C7\u09B2\u0996\u09A8 \u09B8\u09B2\u09A8\u09BF \u09B9\u09C8\u099B\u09C7\u0964 \u098F\u09AC\u09BE\u09F0 Cformly \u098F\u09AA\u09F0 \u09AA\u09F0\u09BE \u0985\u09A4\u09BF\u09A5\u09BF \u09AB\u09BF\u09B2\u09CD\u09A1 \u0995\u09AA\u09BF \u0995\u09F0\u09BF \u09A8\u09BF\u099C\u09C7\u0987 \u09AD\u09F0\u09BE\u0993\u0995; \u0986\u09AE\u09BF \u0986\u09AA\u09A1\u09C7\u099F \u09AA\u09F0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09F0\u09BF \u0986\u099B\u09CB\u0981\u0964",
  "canary.detail": "\u098F\u0987 \u09AA\u09C3\u09B7\u09CD\u09A0\u09BE\u09A4 Cformly-\u09F0 \u099A\u09BF\u09A8\u09BE\u0995\u09BF {total}\u099F\u09BE \u09AB\u09BF\u09B2\u09CD\u09A1\u09F0 \u09AD\u09BF\u09A4\u09F0\u09A4 \u09AE\u09BE\u09A4\u09CD\u09F0 {found}\u099F\u09BE\u09B9\u09C7 \u09AA\u09CB\u09F1\u09BE \u0997\u09C8\u099B\u09C7\u0964",
  // roadmap 34: multi-guest fill queue (popup)
  "queue.title": "\u0985\u09A4\u09BF\u09A5\u09BF \u09B6\u09BE\u09F0\u09C0",
  "queue.add": "\u09B6\u09BE\u09F0\u09C0\u09A4 \u09AF\u09CB\u0997 \u09A6\u09BF\u09AF\u09BC\u0995",
  "queue.fill": "\u09AA\u09C2\u09F0 \u0995\u09F0\u0995",
  "queue.remove": "\u0986\u09A4\u09F0\u09BE\u0993\u0995",
  "queue.unnamed": "\u0985\u09A4\u09BF\u09A5\u09BF",
  "queue.added": "{name} \u0995 \u09B6\u09BE\u09F0\u09C0\u09A4 \u09AF\u09CB\u0997 \u09A6\u09BF\u09AF\u09BC\u09BE \u09B9'\u09B2\u0964",
  "queue.duplicate": "\u098F\u0987 \u0985\u09A4\u09BF\u09A5\u09BF\u099C\u09A8 \u0987\u09A4\u09BF\u09AE\u09A7\u09CD\u09AF\u09C7 \u09B6\u09BE\u09F0\u09C0\u09A4 \u0986\u099B\u09C7\u0964",
  "queue.full": "\u09B6\u09BE\u09F0\u09C0 \u09AD\u09F0\u09CD\u09A4\u09BF ({max} \u099C\u09A8 \u0985\u09A4\u09BF\u09A5\u09BF)\u0964 \u09AA\u09CD\u09F0\u09A5\u09AE\u09C7 \u098F\u099C\u09A8 \u0985\u09A4\u09BF\u09A5\u09BF\u09F0 \u09AB'\u09F0\u09CD\u09AE \u09AA\u09C2\u09F0 \u0995\u09F0\u0995 \u09A8\u09BE\u0987\u09AC\u09BE \u0986\u09A4\u09F0\u09BE\u0993\u0995\u0964",
  "queue.hint": "\u09AA\u09C2\u09F0 \u0995\u09F0\u09BE\u09F0 \u09AA\u09CD\u09F0\u09A4\u09C0\u0995\u09CD\u09B7\u09BE\u09A4 \u09A5\u0995\u09BE \u0985\u09A4\u09BF\u09A5\u09BF\u09B8\u0995\u09B2\u0964 \u09B8\u09AE\u09CD\u09AA\u09C2\u09F0\u09CD\u09A3 \u09AA\u09C2\u09F0\u09A3\u09F0 \u09AA\u09BF\u099B\u09A4 \u0985\u09A4\u09BF\u09A5\u09BF\u099C\u09A8 \u09B6\u09BE\u09F0\u09C0\u09F0 \u09AA\u09F0\u09BE \u0986\u09A4\u09F0\u09BE\u0987 \u09A6\u09BF\u09AF\u09BC\u09BE \u09B9\u09AF\u09BC; \u09AC\u09CD\u09F0\u09BE\u0989\u099C\u09BE\u09F0 \u09AC\u09A8\u09CD\u09A7 \u0995\u09F0\u09BF\u09B2\u09C7 \u09B6\u09BE\u09F0\u09C0 \u0996\u09BE\u09B2\u09C0 \u09B9\u09C8 \u09AF\u09BE\u09AF\u09BC\u0964",
  "queue.unavailable": "\u098F\u0987 \u09AC\u09CD\u09F0\u09BE\u0989\u099C\u09BE\u09F0\u09A4 \u0985\u09A4\u09BF\u09A5\u09BF \u09B6\u09BE\u09F0\u09C0 \u0989\u09AA\u09B2\u09AC\u09CD\u09A7 \u09A8\u09B9\u09AF\u09BC\u0964",
  // roadmap 38: stale content-script reload hint
  "popup.reloadHint": "\u098F\u0987 FRRO \u099F\u09C7\u09AC\u099F\u09CB Cformly \u0987\u09A8\u09B7\u09CD\u099F\u09B2 \u09AC\u09BE \u0986\u09AA\u09A1\u09C7\u099F \u09B9\u09CB\u09F1\u09BE\u09F0 \u0986\u0997\u09A4\u09C7 \u0996\u09CB\u09B2\u09BE \u09B9\u09C8\u099B\u09BF\u09B2\u0964 \u098F\u0987 \u099F\u09C7\u09AC\u099F\u09CB \u098F\u09AC\u09BE\u09F0 \u09F0\u09BF\u09B2'\u09A1 \u0995\u09F0\u0995 (F5), \u09A4\u09BE\u09F0 \u09AA\u09BF\u099B\u09A4 Fill \u099F\u09BF\u09AA\u0995\u0964",
  // roadmap 39: mapping status card (settings)
  "settings.mappingHeading": "\u09AB\u09F0\u09CD\u09AE \u09AE\u09C7\u09AA\u09BF\u0982",
  "settings.mapVersion": "\u09B8\u0982\u09B8\u09CD\u0995\u09F0\u09A3",
  "settings.mapLastVerified": "\u09B6\u09C7\u09B7 \u09B8\u09A4\u09CD\u09AF\u09BE\u09AA\u09BF\u09A4",
  "settings.mapFetchedAt": "\u0986\u09A8\u09BF \u09B2\u09CB\u09F1\u09BE \u09B9\u09C8\u099B\u09C7",
  "settings.mapSignature": "Ed25519 \u09B8\u09CD\u09AC\u09BE\u0995\u09CD\u09B7\u09F0",
  "settings.mapRefresh": "\u098F\u09A4\u09BF\u09AF\u09BC\u09BE \u09F0\u09BF\u09AB\u09CD\u09F0\u09C7\u099A \u0995\u09F0\u0995",
  "settings.mapRefreshed": "\u09AE\u09C7\u09AA\u09BF\u0982 \u09F0\u09BF\u09AB\u09CD\u09F0\u09C7\u099A \u09B9'\u09B2\u0964",
  "settings.mapRefreshFailed": "\u09AE\u09C7\u09AA\u09BF\u0982 \u09F0\u09BF\u09AB\u09CD\u09F0\u09C7\u099A \u0995\u09F0\u09BF\u09AC \u09A8\u09CB\u09F1\u09BE\u09F0\u09BF - \u0989\u09AA\u09B2\u09AC\u09CD\u09A7 \u09B6\u09CD\u09F0\u09C7\u09B7\u09CD\u09A0 \u09AA\u09CD\u09F0\u09A4\u09BF\u09B2\u09BF\u09AA\u09BF\u099F\u09CB \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0 \u09B9\u09C8 \u0986\u099B\u09C7\u0964",
  "settings.mapStatusRemote": "\u09B8\u09A4\u09CD\u09AF\u09BE\u09AA\u09BF\u09A4 - \u09AE\u09C7\u09AA\u09BF\u0982 \u099B\u09BE\u09F0\u09CD\u09AD\u09BE\u09F0\u09F0 \u09AA\u09F0\u09BE \u0985\u09A8\u09BE \u099F\u09BE\u099F\u0995\u09BE \u09AA\u09CD\u09F0\u09A4\u09BF\u09B2\u09BF\u09AA\u09BF\u0964",
  "settings.mapStatusCached": "\u09B8\u09A4\u09CD\u09AF\u09BE\u09AA\u09BF\u09A4 - \u09B6\u09C7\u09B9\u09A4\u09C0\u09AF\u09BC\u09BE \u0995\u09C7\u099B \u09AA\u09CD\u09F0\u09A4\u09BF\u09B2\u09BF\u09AA\u09BF\u0964",
  "settings.mapStatusBundled": "\u0985\u09A8\u09CD\u09A4\u09F0\u09CD\u09AD\u09C1\u0995\u09CD\u09A4 \u09AD\u09BF\u09A4\u09CD\u09A4\u09BF \u09AA\u09CD\u09F0\u09A4\u09BF\u09B2\u09BF\u09AA\u09BF (\u099B\u09BE\u09F0\u09CD\u09AD\u09BE\u09F0 \u09A8\u09BE\u0987)\u0964 \u09B8\u09CD\u09AC\u09BE\u0995\u09CD\u09B7\u09F0 \u0985\u0995\u09CD\u09B7\u09A4\u0964",
  "settings.mapStatusTampered": "\u09B8\u09CD\u09AC\u09BE\u0995\u09CD\u09B7\u09F0 \u09AA\u09F0\u09C0\u0995\u09CD\u09B7\u09BE \u09AC\u09CD\u09AF\u09F0\u09CD\u09A5 - \u098F\u0987 \u09AA\u09CD\u09F0\u09A4\u09BF\u09B2\u09BF\u09AA\u09BF\u0996\u09A8 \u09A8\u09BE\u0995\u099A \u0995\u09F0\u09BE \u09B9\u09C8\u099B\u09C7 \u0986\u09F0\u09C1 \u09AC\u09CD\u09AF\u09F1\u09B9\u09BE\u09F0\u09A4 \u09A8\u09BE\u0987\u0964",
  "chip.mappingUnavailable": "\u09AB\u09F0\u09CD\u09AE \u09AE\u09C7\u09AA\u09BF\u0982 \u09B2\u09CB\u09A1 \u0995\u09F0\u09BF\u09AC \u09AA\u09F0\u09BE \u09A8\u0997'\u09B2 \u2014 \u098F\u0995\u09CD\u09B8\u099F\u09C7\u09A8\u09B6\u09CD\u09AF\u09A8\u09F0 \u09AC\u09C7\u0995\u0997\u09CD\u09F0\u09BE\u0989\u09A3\u09CD\u09A1 \u09F1\u09F0\u09CD\u0995\u09BE\u09F0\u09C7 \u0989\u09A4\u09CD\u09A4\u09F0 \u09A6\u09BF\u09AF\u09BC\u09BE \u09A8\u09BE\u0987\u0964 \u09AA'\u09F0\u09CD\u099F\u09C7\u09B2 \u099F\u09C7\u09AC \u09AA\u09C1\u09A8\u09F0 \u09B2\u09CB\u09A1 \u0995\u09F0\u09BF \u0986\u0995\u09CC \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09F0\u0995\u0964",
  "popup.timeoutMapping": "\u09AB\u09F0\u09CD\u09AE \u09AE\u09C7\u09AA\u09BF\u0982 \u09B2\u09CB\u09A1 \u09B9\u09CB\u09F1\u09BE\u09F0 \u09B8\u09AE\u09AF\u09BC \u09B8\u09AE\u09BE\u09AA\u09CD\u09A4 ({seconds} \u099B\u09C7\u0995\u09C7\u09A3\u09CD\u09A1)\u0964 \u09B8\u0982\u09AF\u09CB\u0997 \u09AA\u09F0\u09C0\u0995\u09CD\u09B7\u09BE \u0995\u09F0\u09BF \u0986\u0995\u09CC \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09F0\u0995\u0964",
  "popup.timeoutNoProgress": "\u09AA\u09C2\u09F0\u09A3 \u0995\u09F0\u09BE {seconds} \u099B\u09C7\u0995\u09C7\u09A3\u09CD\u09A1\u09A4 \u0986\u09F0\u09AE\u09CD\u09AD \u09A8\u09B9'\u09B2 \u2014 Form III \u09AA\u09C3\u09B7\u09CD\u09A0\u09BE\u0987 \u09B8\u0981\u09B9\u09BE\u09F0\u09BF \u09A6\u09BF\u09AF\u09BC\u09BE \u09A8\u09BE\u0987\u0964 \u099F\u09C7\u09AC \u09AA\u09C1\u09A8\u09F0 \u09B2\u09CB\u09A1 \u0995\u09F0\u09BF \u0986\u0995\u09CC \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09F0\u0995\u0964",
  "popup.timeoutStalled": "\u09AA\u09C2\u09F0\u09A3 \u0995\u09F0\u09BE {seconds} \u099B\u09C7\u0995\u09C7\u09A3\u09CD\u09A1\u09F0\u09C7 \u09AC\u09A8\u09CD\u09A7 \u09B9\u09C8 \u0986\u099B\u09C7 \u2014 Form III \u09AA\u09C3\u09B7\u09CD\u09A0\u09BE\u0987 \u09B8\u0981\u09B9\u09BE\u09F0\u09BF \u09A6\u09BF\u09AF\u09BC\u09BE \u09AC\u09A8\u09CD\u09A7 \u0995\u09F0\u09BF\u099B\u09C7\u0964",
  "popup.timeoutCap": "\u09AA\u09C2\u09F0\u09A3 \u0995\u09F0\u09BE\u0987 \u09AE\u09C1\u09A0 \u09B8\u09AE\u09AF\u09BC\u09B8\u09C0\u09AE\u09BE ({seconds} \u099B\u09C7\u0995\u09C7\u09A3\u09CD\u09A1) \u0985\u09A4\u09BF\u0995\u09CD\u09F0\u09AE \u0995\u09F0\u09BF\u09B2\u09C7 \u0986\u09F0\u09C1 \u09AC\u09A8\u09CD\u09A7 \u0995\u09F0\u09BE \u09B9'\u09B2\u0964",
  "popup.preview": "\u09B8\u09B2\u09A8\u09BF \u099A\u09BE\u0993\u0995",
  "popup.previewApply": "\u09AA\u09CD\u09F0\u09AF\u09BC\u09CB\u0997 \u0995\u09F0\u0995 \u2014 \u09AB\u09F0\u09CD\u09AE \u09AA\u09C2\u09F0\u09A3 \u0995\u09F0\u0995",
  "popup.undo": "\u09B6\u09C7\u09B7\u09F0 \u09AB\u09BF\u09B2 \u0986\u09A8\u09A1\u09C1 \u0995\u09F0\u0995",
  "popup.undoDone": "{total}\u099F\u09BE\u09F0 \u09AD\u09BF\u09A4\u09F0\u09A4 {restored}\u099F\u09BE \u09AB\u09BF\u09B2\u09CD\u09A1 \u09AA\u09C1\u09F0\u09A3\u09BF \u09AE\u09BE\u09A8\u09B8\u09AE\u09C2\u09B9\u09B2\u09C8 \u09AA\u09C1\u09A8\u09F0\u09C1\u09A6\u09CD\u09A7\u09BE\u09F0 \u0995\u09F0\u09BE \u09B9'\u09B2\u0964",
  "popup.undoPartial": "{total}\u099F\u09BE\u09F0 \u09AD\u09BF\u09A4\u09F0\u09A4 {restored}\u099F\u09BE \u09AA\u09C1\u09A8\u09F0\u09C1\u09A6\u09CD\u09A7\u09BE\u09F0 \u09B9'\u09B2; {failed}\u099F\u09BE \u09AA\u09C1\u09A8\u09F0\u09C1\u09A6\u09CD\u09A7\u09BE\u09F0 \u0995\u09F0\u09BF\u09AC \u09AA\u09F0\u09BE \u09A8\u0997'\u09B2 (\u09AA\u09C3\u09B7\u09CD\u09A0\u09BE \u09AA\u09C1\u09A8\u09F0 \u09A8\u09BF\u09F0\u09CD\u09AE\u09BE\u09A3 \u09B9'\u09AC \u09AA\u09BE\u09F0\u09C7)\u0964",
  "popup.undoStale": "\u09AB\u09BF\u09B2\u09F0 \u09AA\u09BF\u099B\u09A4 \u09AA\u09C3\u09B7\u09CD\u09A0\u09BE \u09B8\u09B2\u09A8\u09BF \u09B9'\u09B2 \u2014 \u09AA\u09C1\u09A8\u09F0\u09C1\u09A6\u09CD\u09A7\u09BE\u09F0 \u0985\u09B8\u09AE\u09CD\u09AA\u09C2\u09F0\u09CD\u09A3 \u09B9'\u09AC \u09AA\u09BE\u09F0\u09C7\u0964",
  "popup.undoNone": "\u0986\u09A8\u09A1\u09C1 \u0995\u09F0\u09BF\u09AC\u09B2\u09C8 \u098F\u0995\u09CB \u09A8\u09BE\u0987 \u2014 \u098F\u0987 \u0985\u09A7\u09BF\u09AC\u09C7\u09B6\u09A8\u09A4 \u098F\u0987 \u099F\u09C7\u09AC\u09A4 \u0995\u09CB\u09A8\u09CB \u09AB\u09BF\u09B2 \u09B9\u09CB\u09F1\u09BE \u09A8\u09BE\u0987\u0964",
  "popup.previewUnresolved": "\u098F\u0987 \u09AA\u09C3\u09B7\u09CD\u09A0\u09BE\u09A4 \u09AA\u09CB\u09F1\u09BE \u09A8\u0997'\u09B2",
  "popup.previewManual": "\u09AE\u09C7\u09A8\u09C1\u09F1\u09C7\u09B2 \u09B8\u09CD\u09A4\u09F0",
  "popup.previewNoValue": "(\u09AA\u09CD\u09F0\u09A6\u09BE\u09A8 \u0995\u09F0\u09BE \u09A8\u09B9'\u09B2)"
};

// src/i18n.ts
var LANGUAGES = [
  { code: "en", native: "English" },
  { code: "hi", native: "\u0939\u093F\u0928\u094D\u0926\u0940" },
  { code: "kn", native: "\u0C95\u0CA8\u0CCD\u0CA8\u0CA1" },
  { code: "ta", native: "\u0BA4\u0BAE\u0BBF\u0BB4\u0BCD" },
  { code: "te", native: "\u0C24\u0C46\u0C32\u0C41\u0C17\u0C41" },
  { code: "ml", native: "\u0D2E\u0D32\u0D2F\u0D3E\u0D33\u0D02" },
  { code: "pa", native: "\u0A2A\u0A70\u0A1C\u0A3E\u0A2C\u0A40" },
  { code: "mr", native: "\u092E\u0930\u093E\u0920\u0940" },
  { code: "ur", native: "\u0627\u0631\u062F\u0648" },
  { code: "bn", native: "\u09AC\u09BE\u0982\u09B2\u09BE" },
  { code: "gu", native: "\u0A97\u0AC1\u0A9C\u0AB0\u0ABE\u0AA4\u0AC0" },
  { code: "as", native: "\u0985\u09B8\u09AE\u09C0\u09AF\u09BC\u09BE" }
];
var LANG_KEY = "lang";
var dictionaries = {
  en,
  hi,
  kn,
  ta,
  te,
  ml,
  pa,
  mr,
  ur,
  bn,
  gu,
  as
};
var messages = dictionaries;
function detectLang() {
  try {
    if (typeof navigator === "undefined") return "en";
    const candidates = navigator.languages && navigator.languages.length > 0 ? navigator.languages : [navigator.language];
    for (const cand of candidates) {
      const pref = (cand || "").toLowerCase();
      const hit = LANGUAGES.find(
        (l) => new RegExp(`^${l.code}\\b`, "i").test(pref)
      );
      if (hit) return hit.code;
    }
  } catch {
  }
  return "en";
}
async function loadLang() {
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.sync) {
      const stored = await chrome.storage.sync.get(LANG_KEY);
      const value = stored?.[LANG_KEY];
      if (typeof value === "string" && LANGUAGES.some((l) => l.code === value))
        return value;
    }
  } catch {
  }
  return detectLang();
}
function fmt(template, params) {
  return template.replace(
    /\{(\w+)\}/g,
    (_, key) => String(params[key] ?? `{${key}}`)
  );
}
function msg(lang, key, params) {
  const value = messages[lang][key] ?? messages.en[key] ?? key;
  return params ? fmt(value, params) : value;
}

// src/portal-ui.ts
var PORTAL_UI_STYLE_ID = "cformly-portal-ui";
var FOCUS_VISIBLE = `
  outline: 2px solid var(--cf-primary);
  outline-offset: 2px;
`;
var CSS = `
.cformly-root {
  --cf-paper: #f4efe4;
  --cf-surface: #ffffff;
  --cf-surface-muted: #ece6d8;
  --cf-hairline: #d9cfba;
  --cf-ink: #0e1a22;
  --cf-ink-muted: #56636d;
  --cf-primary: #0e5fb0;
  --cf-primary-deep: #094a8a;
  --cf-navy: #14263f;
  --cf-on-navy: #f4efe4;
  --cf-on-navy-muted: rgba(244, 239, 228, 0.72);
  --cf-marigold-deep: #8a5608;
  --cf-success: #1e7a4e;
  --cf-success-tint: #e3f1e9;
  --cf-danger: #b52f2f;
  --cf-danger-tint: #f9e7e7;
  --cf-mono: ui-monospace, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
  --cf-shadow-lg: 0 2px 6px rgba(14, 26, 34, 0.06), 0 22px 50px rgba(14, 26, 34, 0.13);
  --cf-shadow-navy: 0 4px 14px rgba(11, 23, 38, 0.35), 0 1px 3px rgba(14, 26, 34, 0.2);
  color: var(--cf-ink);
  font: 13px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
    "Helvetica Neue", Arial, sans-serif;
}
@media (prefers-color-scheme: dark) {
  .cformly-root {
    --cf-surface: #172029;
    --cf-surface-muted: #1d2731;
    --cf-hairline: #2a3640;
    --cf-ink: #e9eef0;
    --cf-ink-muted: #97a4ac;
    --cf-primary: #5aa6ec;
    --cf-primary-deep: #3e8edc;
    --cf-navy: #243c5e;
    --cf-on-navy: #eef3f5;
    --cf-on-navy-muted: rgba(238, 243, 245, 0.72);
    --cf-marigold-deep: #f2c879;
    --cf-success: #43c07e;
    --cf-success-tint: #1c3326;
    --cf-danger: #e26767;
    --cf-danger-tint: #381f1f;
    --cf-shadow-lg: 0 2px 6px rgba(0, 0, 0, 0.4), 0 22px 50px rgba(0, 0, 0, 0.6);
    --cf-shadow-navy: 0 4px 16px rgba(0, 0, 0, 0.55);
  }
}

/* ---- shared controls ---- */
.cformly-btn {
  border: none;
  border-radius: 14px;
  font: bold 13px/1 inherit;
  padding: 9px 16px;
  cursor: pointer;
  transition: transform 150ms ease-out, box-shadow 150ms ease-out,
    background-color 150ms ease-out;
}
.cformly-btn:active {
  transform: translateY(1px) scale(0.99);
}
.cformly-btn:focus-visible {
  ${FOCUS_VISIBLE}
}
.cformly-btn-primary {
  background: var(--cf-primary);
  color: #ffffff;
}
.cformly-btn-secondary {
  background: var(--cf-surface);
  color: var(--cf-ink);
  border: 1px solid var(--cf-hairline);
}
.cformly-btn-primary:disabled {
  opacity: 0.6;
  cursor: default;
}

.cformly-dismiss {
  border: none;
  background: none;
  font: bold 18px/1 inherit;
  color: var(--cf-on-navy-muted);
  cursor: pointer;
  padding: 2px 8px;
  border-radius: 8px;
  transition: color 150ms ease-out, background-color 150ms ease-out;
}
.cformly-dismiss:hover,
.cformly-dismiss:focus-visible {
  color: var(--cf-on-navy);
  background: rgba(244, 239, 228, 0.12);
}
.cformly-dismiss:focus-visible {
  ${FOCUS_VISIBLE}
}
/* Surface variant \u2014 the chip box's close button sits on --cf-surface, not
   the navy header; the navy-targeted colors above would vanish on it. */
.cformly-dismiss-ink {
  border: none;
  background: none;
  font: bold 18px/1 inherit;
  color: var(--cf-ink-muted);
  cursor: pointer;
  padding: 2px 8px;
  border-radius: 8px;
  transition: color 150ms ease-out, background-color 150ms ease-out;
}
.cformly-dismiss-ink:hover,
.cformly-dismiss-ink:focus-visible {
  color: var(--cf-ink);
  background: rgba(14, 26, 34, 0.08);
}
.cformly-dismiss-ink:focus-visible {
  ${FOCUS_VISIBLE}
}

/* ---- filing panel (bottom sheet) ---- */
.cformly-panel {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 2147483647;
  background: var(--cf-surface);
  color: var(--cf-ink);
  box-shadow: var(--cf-shadow-lg);
  padding: 0 0 12px;
}
.cformly-panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  background: var(--cf-navy);
  color: var(--cf-on-navy);
  border-radius: 0;
  padding: 10px 14px;
  margin: 0 0 8px;
}
.cformly-panel-title {
  font-size: 14px;
  letter-spacing: 0.2px;
}
.cformly-panel-body-pad {
  padding: 0 14px;
}
.cformly-warn {
  background: var(--cf-danger-tint);
  color: var(--cf-danger);
  padding: 8px 12px;
  margin: 8px 14px;
  font-weight: bold;
  border-radius: 10px;
  border-left: 3px solid var(--cf-danger);
}
.cformly-checklist {
  margin: 6px 14px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.cformly-check-row {
  display: flex;
  align-items: baseline;
  gap: 8px;
}
/* The inline (CSP-fallback) state span carries margin-right for the
   no-sheet case; with the sheet active the row gap owns the spacing. */
.cformly-check-row .cformly-state {
  margin-right: 0;
}
.cformly-state {
  font-family: var(--cf-mono);
  font-weight: bold;
  color: var(--cf-ink-muted);
}
.cformly-state-done {
  color: var(--cf-success);
}
.cformly-saving {
  color: var(--cf-marigold-deep);
  font-weight: bold;
  margin: 8px 14px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.cformly-saving::before {
  content: "";
  width: 8px;
  height: 8px;
  border-radius: 4px;
  background: var(--cf-marigold-deep);
  animation: cformly-pulse 1.6s ease-in-out infinite;
}
@keyframes cformly-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.35; }
}
.cformly-id-view {
  margin: 10px 14px 0;
  padding-top: 10px;
  border-top: 1px solid var(--cf-hairline);
}
.cformly-id-label {
  font-weight: bold;
  font-size: 11px;
  letter-spacing: 1.2px;
  text-transform: uppercase;
  color: var(--cf-ink-muted);
}
.cformly-id-value {
  font-family: var(--cf-mono);
  font-weight: bold;
  font-size: 26px;
  line-height: 1.3;
  letter-spacing: 1.5px;
  color: var(--cf-navy);
  margin: 4px 0 8px;
}
@media (prefers-color-scheme: dark) {
  .cformly-id-value {
    color: #a9c0de;
  }
}
.cformly-qr {
  display: block;
  /* The QR needs a light quiet zone in dark mode too \u2014 the phone decodes
     contrast, not theme. */
  background: #ffffff;
  border: 1px solid var(--cf-hairline);
  border-radius: 10px;
  padding: 6px;
}
.cformly-hint {
  color: var(--cf-ink-muted);
  margin-top: 8px;
}
.cformly-copy {
  margin-top: 8px;
}

/* photo affordances \u2014 lives INSIDE the checklist block (already inset 14px),
   so its own margins are vertical-only. */
.cformly-photo-actions {
  display: flex;
  gap: 8px;
  margin: 4px 0 6px;
}
.cformly-drop {
  flex: 1;
  border-radius: 12px;
  padding: 10px 12px;
  font-weight: bold;
  color: var(--cf-primary);
  cursor: pointer;
  text-align: center;
  transition: background-color 150ms ease-out, border-color 150ms ease-out;
}
.cformly-drop:hover,
.cformly-drop:focus-visible {
  /* Background only: the dashed border lives inline (CSP fallback + test
     contract) and an inline shorthand would beat any sheet border-color. */
  background: rgba(14, 95, 176, 0.06);
}
.cformly-drop:focus-visible {
  ${FOCUS_VISIBLE}
}
.cformly-browse {
  align-self: flex-start;
}

/* ---- fill chip (pill + paste box) ---- */
.cformly-chip-pill {
  position: fixed;
  bottom: 18px;
  right: 18px;
  z-index: 2147483646;
  background: var(--cf-navy);
  color: var(--cf-on-navy);
  border: none;
  border-radius: 22px;
  font: bold 14px/1 inherit;
  letter-spacing: 0.2px;
  padding: 13px 20px;
  cursor: pointer;
  box-shadow: var(--cf-shadow-navy);
  transition: transform 150ms ease-out, box-shadow 150ms ease-out;
}
.cformly-chip-pill:hover {
  transform: translateY(-1px);
}
.cformly-chip-pill:active {
  transform: translateY(0) scale(0.98);
}
.cformly-chip-pill:focus-visible {
  ${FOCUS_VISIBLE}
}
.cformly-chip-box {
  position: fixed;
  bottom: 70px;
  right: 18px;
  z-index: 2147483646;
  width: min(372px, calc(100vw - 36px));
  background: var(--cf-surface);
  color: var(--cf-ink);
  border: 1px solid var(--cf-hairline);
  border-radius: 18px;
  box-shadow: var(--cf-shadow-lg);
  padding: 14px;
  display: none;
}
.cformly-chip-title {
  font-size: 14px;
}
.cformly-chip-hint {
  color: var(--cf-ink-muted);
  margin: 6px 0;
}
.cformly-paste {
  width: 100%;
  box-sizing: border-box;
  height: 96px;
  border: 1px solid var(--cf-hairline);
  border-radius: 12px;
  background: var(--cf-surface-muted);
  color: var(--cf-ink);
  padding: 9px 10px;
  font: 12px/1.4 var(--cf-mono);
  resize: vertical;
}
.cformly-paste:focus {
  /* Outline only: the inline border shorthand beats sheet border-color. */
  outline: 2px solid var(--cf-primary);
  outline-offset: 1px;
}
.cformly-fill {
  margin-top: 10px;
}
.cformly-error {
  color: var(--cf-danger);
  font-weight: bold;
  margin-top: 8px;
}
.cformly-note {
  color: var(--cf-primary-deep);
  font-weight: bold;
  margin-top: 8px;
}

/* ---- captcha-focus ring (roadmap 40) ----
   A brief flash framing the CAPTCHA (or the Save row it sits beside) after a
   fill. The ring is aria-hidden decoration with pointer-events: none inline
   (inline so it holds even when a CSP blocks this sheet) \u2014 it can never
   intercept a click on the portal. */
.cformly-captcha-ring {
  position: absolute;
  z-index: 2147483640;
  border: 3px solid #8a5608;
  border-radius: 6px;
  box-shadow: 0 0 0 3px rgba(138, 86, 8, 0.25);
  animation: cformly-ring-pulse 1.2s ease-in-out 3;
}
@keyframes cformly-ring-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.35; }
}

@media (prefers-reduced-motion: reduce) {
  .cformly-btn,
  .cformly-btn:active,
  .cformly-chip-pill,
  .cformly-chip-pill:hover,
  .cformly-chip-pill:active,
  .cformly-dismiss,
  .cformly-drop {
    transition: none;
    transform: none;
    animation: none;
  }
  .cformly-saving::before {
    animation: none;
  }
  .cformly-captcha-ring {
    animation: none;
  }
}
`;
function ensurePortalUiStyles() {
  if (typeof document === "undefined") return null;
  const existing = document.getElementById(PORTAL_UI_STYLE_ID);
  if (existing) return existing;
  const style = document.createElement("style");
  style.id = PORTAL_UI_STYLE_ID;
  style.textContent = CSS;
  try {
    (document.head ?? document.documentElement).appendChild(style);
  } catch {
    return null;
  }
  return style;
}
function applyInlineStyles(el, style) {
  for (const decl of style.split(";")) {
    const idx = decl.indexOf(":");
    if (idx <= 0) continue;
    const prop = decl.slice(0, idx).trim();
    const value = decl.slice(idx + 1).trim();
    if (!prop || !value) continue;
    el.style.setProperty(prop, value);
  }
}
function styledElement(tag, style) {
  const el = document.createElement(tag);
  applyInlineStyles(el, style);
  return el;
}
function classedElement(tag, className, fallback = "") {
  const el = styledElement(tag, fallback);
  el.className = className;
  return el;
}

// src/panel.ts
var PANEL_ID = "cformly-filing-panel";
var PROGRESS_HUD_ID = "cformly-fill-progress";
var LEGACY_BANNER_ID = "cformly-fill-warning";
var APPID_QR_PREFIX = "CFORMLY-APPID:";
function buildAppIdQrPayload(applicationId) {
  return `${APPID_QR_PREFIX}${applicationId}`;
}
var CONFIRM_POLL_INTERVAL_MS = 1e3;
var CONFIRM_POLL_CAP_MS = 5 * 6e4;
var DISMISS_AFTER_ID_MS = 10 * 6e4;
function renderFillProgressHud(lang) {
  ensurePortalUiStyles();
  const prev = document.getElementById(PROGRESS_HUD_ID);
  prev?.remove();
  const hud = classedElement(
    "div",
    "cformly-root cformly-progress-hud",
    [
      "position:fixed",
      "bottom:0",
      "left:0",
      "right:0",
      "z-index:2147483647",
      "background:#14263f",
      "color:#f4efe4",
      "font:bold 13px/1.5 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
      "padding:10px 14px",
      "box-shadow:0 -2px 10px rgba(0,0,0,0.3)"
    ].join(";")
  );
  hud.id = PROGRESS_HUD_ID;
  hud.setAttribute("role", "status");
  hud.setAttribute("data-cformly-role", "progress");
  const text = document.createElement("span");
  text.textContent = msg(lang, "panel.progress", { completed: 0, total: 0 });
  hud.appendChild(text);
  const track = styledElement(
    "div",
    "height:4px;background:rgba(244,239,228,0.18);border-radius:2px;margin-top:8px;overflow:hidden"
  );
  const bar = styledElement(
    "div",
    "height:4px;width:0%;background:#e8a33d;border-radius:2px;transition:width 120ms ease"
  );
  track.appendChild(bar);
  hud.appendChild(track);
  document.documentElement.appendChild(hud);
  return {
    update: (completed, total) => {
      text.textContent = msg(lang, "panel.progress", {
        completed,
        total
      });
      const pct = total > 0 ? Math.round(completed / total * 100) : 100;
      bar.style.width = `${pct}%`;
    },
    dismiss: () => {
      hud.remove();
    }
  };
}
function copyText(text) {
  if (typeof navigator === "undefined" || !navigator.clipboard?.writeText)
    return Promise.resolve(false);
  return navigator.clipboard.writeText(text).then(
    () => true,
    () => false
  );
}
function attachFilesToInput(input, files) {
  if (typeof DataTransfer !== "function" || files.length === 0) return false;
  try {
    const dt = new DataTransfer();
    for (const f of files) dt.items.add(f);
    input.files = dt.files;
    input.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  } catch {
    return false;
  }
}
function createPhotoActions(lang, photoInput, onAttached) {
  const wrap = classedElement(
    "div",
    "cformly-photo-actions",
    "display:flex;gap:8px;margin:4px 0 6px"
  );
  const dropZone = classedElement(
    "div",
    "cformly-drop",
    "flex:1;border:2px dashed #0e5fb0;padding:10px 12px;font-weight:bold;color:#0e5fb0;cursor:pointer;text-align:center"
  );
  dropZone.textContent = msg(lang, "panel.photoDrop");
  const browseBtn = document.createElement("button");
  browseBtn.type = "button";
  browseBtn.textContent = msg(lang, "panel.photoBrowse");
  browseBtn.className = "cformly-btn cformly-btn-secondary cformly-browse";
  applyInlineStyles(
    browseBtn,
    "border:1px solid #d9cfba;background:#ffffff;color:#0e1a22;font:bold 13px sans-serif;padding:9px 16px;cursor:pointer;border-radius:14px"
  );
  const attach = (files) => {
    if (attachFilesToInput(photoInput, files)) {
      wrap.style.display = "none";
      onAttached();
    } else dropZone.textContent = msg(lang, "panel.photoAttachFailed");
  };
  dropZone.addEventListener("dragover", (e) => e.preventDefault());
  dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer?.files ?? []);
    if (files.length > 0) attach(files);
  });
  dropZone.addEventListener("click", () => photoInput.click());
  browseBtn.addEventListener("click", () => photoInput.click());
  wrap.appendChild(dropZone);
  wrap.appendChild(browseBtn);
  return wrap;
}
function appendWarnings(panel, result, lang) {
  const warnings = [];
  if (result.accommodationMismatch) {
    warnings.push(
      msg(lang, "panel.warnSession", {
        reason: result.accommodationWarning ?? ""
      })
    );
  }
  if (result.unverified.length > 0) {
    warnings.push(
      msg(lang, "panel.warnUnverified", {
        list: result.unverified.map(prettifyFieldName).join(", ")
      })
    );
  }
  if (warnings.length === 0) return;
  const warnBox = classedElement(
    "div",
    "cformly-warn",
    "background:#f9e7e7;color:#b52f2f;padding:8px 12px;margin:8px 14px;font-weight:bold;border-left:3px solid #b52f2f"
  );
  warnBox.setAttribute("role", "alert");
  warnBox.textContent = warnings.join(" ");
  panel.appendChild(warnBox);
}
function appendChecklistRow(checklist, label, done) {
  const row = classedElement(
    "div",
    "cformly-check-row",
    "display:flex;align-items:baseline;gap:8px"
  );
  const state = document.createElement("span");
  state.textContent = done ? "\u2713" : "\u2610";
  state.className = done ? "cformly-state cformly-state-done" : "cformly-state";
  applyInlineStyles(
    state,
    `color:${done ? "#1e7a4e" : "#56636d"};font-weight:bold;margin-right:6px`
  );
  const labelEl = document.createElement("span");
  labelEl.textContent = label;
  row.appendChild(state);
  row.appendChild(labelEl);
  checklist.appendChild(row);
  return {
    row,
    tick: () => {
      state.textContent = "\u2713";
      state.classList.add("cformly-state-done");
      state.style.color = "#1e7a4e";
    },
    untick: () => {
      state.textContent = "\u2610";
      state.classList.remove("cformly-state-done");
      state.style.color = "#56636d";
    },
    label: labelEl
  };
}
function createPanelElements(result, lang) {
  ensurePortalUiStyles();
  const panel = classedElement(
    "div",
    "cformly-root cformly-panel",
    [
      "position:fixed",
      "bottom:0",
      "left:0",
      "right:0",
      "z-index:2147483647",
      "background:#ffffff",
      "color:#0e1a22",
      "box-shadow:0 -2px 10px rgba(0,0,0,0.3)",
      "font:13px/1.5 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
      "padding:0 0 12px"
    ].join(";")
  );
  panel.id = PANEL_ID;
  panel.setAttribute("role", "status");
  const header = classedElement(
    "div",
    "cformly-panel-header",
    "display:flex;justify-content:space-between;align-items:center;gap:12px;background:#14263f;color:#f4efe4;padding:10px 14px;margin:0 0 8px"
  );
  const title = document.createElement("strong");
  title.className = "cformly-panel-title";
  title.textContent = msg(lang, "panel.title");
  header.appendChild(title);
  const dismissBtn = document.createElement("button");
  dismissBtn.type = "button";
  dismissBtn.textContent = "\xD7";
  dismissBtn.className = "cformly-dismiss";
  dismissBtn.setAttribute("aria-label", msg(lang, "panel.dismiss"));
  applyInlineStyles(
    dismissBtn,
    "border:none;background:none;font:bold 18px/1 sans-serif;color:rgba(244,239,228,0.72);cursor:pointer;padding:2px 8px"
  );
  header.appendChild(dismissBtn);
  panel.appendChild(header);
  appendWarnings(panel, result, lang);
  const checklist = classedElement(
    "div",
    "cformly-checklist",
    "margin:6px 14px;display:flex;flex-direction:column;gap:4px"
  );
  checklist.setAttribute("data-cformly-role", "checklist");
  panel.appendChild(checklist);
  appendChecklistRow(
    checklist,
    msg(lang, "panel.filled", {
      filledRequired: result.requiredFilled,
      required: result.totalRequired
    }),
    true
  );
  const photoRow = appendChecklistRow(
    checklist,
    msg(lang, "panel.photoStep"),
    false
  );
  appendChecklistRow(checklist, msg(lang, "panel.captchaStep"), false);
  const saveRow = appendChecklistRow(
    checklist,
    msg(lang, "panel.saveStep"),
    false
  );
  const savingRow = classedElement(
    "div",
    "cformly-saving",
    "display:none;color:#8a5608;font-weight:bold;margin:8px 14px"
  );
  savingRow.setAttribute("data-cformly-role", "saving");
  savingRow.textContent = msg(lang, "panel.saving");
  panel.appendChild(savingRow);
  const idView = classedElement(
    "div",
    "cformly-id-view",
    "display:none;margin:10px 14px 0;padding-top:10px;border-top:1px solid #d9cfba"
  );
  idView.setAttribute("data-cformly-role", "app-id");
  const idLabel = document.createElement("div");
  idLabel.className = "cformly-id-label";
  idLabel.textContent = msg(lang, "panel.appIdFound");
  applyInlineStyles(
    idLabel,
    "font-weight:bold;font-size:11px;letter-spacing:1.2px;text-transform:uppercase;color:#56636d"
  );
  const idValue = classedElement(
    "div",
    "cformly-id-value",
    "font:bold 26px/1.3 ui-monospace,'SF Mono',Menlo,Consolas,monospace;letter-spacing:1.5px;color:#14263f;margin:4px 0 8px"
  );
  const qrCanvas = document.createElement("canvas");
  qrCanvas.width = 160;
  qrCanvas.height = 160;
  qrCanvas.className = "cformly-qr";
  applyInlineStyles(
    qrCanvas,
    "display:block;background:#ffffff;border:1px solid #d9cfba;border-radius:10px;padding:6px"
  );
  const scanHint = document.createElement("div");
  scanHint.textContent = msg(lang, "panel.scanHint");
  scanHint.className = "cformly-hint";
  applyInlineStyles(scanHint, "color:#56636d;margin-top:8px");
  const copyBtn = document.createElement("button");
  copyBtn.type = "button";
  copyBtn.textContent = msg(lang, "panel.copy");
  copyBtn.className = "cformly-btn cformly-btn-primary cformly-copy";
  applyInlineStyles(
    copyBtn,
    "margin-top:8px;background:#0e5fb0;color:#ffffff;border:none;border-radius:14px;font:bold 13px sans-serif;padding:9px 16px;cursor:pointer"
  );
  idView.appendChild(idLabel);
  idView.appendChild(idValue);
  idView.appendChild(qrCanvas);
  idView.appendChild(scanHint);
  idView.appendChild(copyBtn);
  panel.appendChild(idView);
  document.documentElement.appendChild(panel);
  return {
    panel,
    checklist,
    photoRow: photoRow.row,
    photoTick: photoRow.tick,
    saveTick: saveRow.tick,
    saveUntick: saveRow.untick,
    saveLabel: saveRow.label,
    savingRow,
    idView,
    idValue,
    qrCanvas,
    copyBtn,
    dismissBtn
  };
}
function renderFilingPanel(result, opts) {
  const lang = opts.lang;
  document.getElementById(PANEL_ID)?.remove();
  document.getElementById(LEGACY_BANNER_ID)?.remove();
  const els = createPanelElements(result, lang);
  const bannerHeight = els.panel.getBoundingClientRect?.().height ?? 0;
  const prevPadding = document.body?.style.paddingBottom ?? "";
  if (document.body && bannerHeight > 0)
    document.body.style.paddingBottom = `${bannerHeight}px`;
  const cleanups = [];
  let confirmTimer = null;
  const stopConfirmPoll = () => {
    if (confirmTimer !== null) {
      clearInterval(confirmTimer);
      confirmTimer = null;
    }
  };
  const showApplicationId = (applicationId) => {
    stopConfirmPoll();
    els.checklist.style.display = "none";
    els.savingRow.style.display = "none";
    els.idValue.textContent = applicationId;
    els.idView.style.display = "block";
    void opts.renderQr(els.qrCanvas, buildAppIdQrPayload(applicationId)).catch(() => {
    });
    const dismissTimer = setTimeout(() => dismiss(), DISMISS_AFTER_ID_MS);
    cleanups.push(() => clearTimeout(dismissTimer));
  };
  const photoEl = document.querySelector(
    opts.photoSelector
  );
  if (photoEl) {
    const actions = createPhotoActions(lang, photoEl, () => els.photoTick());
    els.photoRow.after(actions);
    const onPhoto = () => {
      els.photoTick();
      actions.style.display = "none";
    };
    photoEl.addEventListener("change", onPhoto);
    cleanups.push(() => photoEl.removeEventListener("change", onPhoto));
  }
  const saveEl = document.querySelector(
    opts.saveSelector
  );
  if (saveEl) {
    const failSaveStep = (labelText) => {
      stopConfirmPoll();
      els.saveUntick();
      els.savingRow.style.display = "none";
      els.saveLabel.textContent = labelText;
      els.saveLabel.style.color = "#b52f2f";
    };
    const onSave = () => {
      els.saveTick();
      els.savingRow.style.display = "block";
      if (confirmTimer === null) {
        const startedAt = performance.now();
        confirmTimer = setInterval(() => {
          const portalError = opts.scanPortalError?.() ?? null;
          if (portalError) {
            const clipped = portalError.length > 240 ? `${portalError.slice(0, 240)}\u2026` : portalError;
            failSaveStep(`${msg(lang, "panel.portalError")} ${clipped}`);
            return;
          }
          if (opts.probeSessionExpired?.()) {
            failSaveStep(msg(lang, "panel.sessionExpired"));
            return;
          }
          const id = opts.scanApplicationId();
          if (id) showApplicationId(id);
          else if (performance.now() - startedAt >= (opts.confirmPollCapMs ?? CONFIRM_POLL_CAP_MS)) {
            failSaveStep(msg(lang, "panel.confirmNotDetected"));
          }
        }, opts.confirmPollIntervalMs ?? CONFIRM_POLL_INTERVAL_MS);
        cleanups.push(stopConfirmPoll);
      }
    };
    saveEl.addEventListener("click", onSave, true);
    cleanups.push(() => saveEl.removeEventListener("click", onSave, true));
  }
  if (result.applicationId) showApplicationId(result.applicationId);
  function dismiss() {
    for (const fn of cleanups.splice(0)) {
      try {
        fn();
      } catch {
      }
    }
    els.panel.remove();
    if (document.body) document.body.style.paddingBottom = prevPadding;
  }
  els.copyBtn.addEventListener("click", () => {
    const id = els.idValue.textContent ?? "";
    if (!id) return;
    void copyText(id).then((copied) => {
      if (!copied) return;
      els.copyBtn.textContent = msg(lang, "panel.copied");
      setTimeout(() => {
        els.copyBtn.textContent = msg(lang, "panel.copy");
      }, 2e3);
    });
  });
  els.dismissBtn.addEventListener("click", dismiss);
  return { dismiss };
}
var RESUME_CARD_ID = "cformly-resume-card";
var CANARY_REFUSAL_ID = "cformly-canary-refusal";
function renderNoticeBand(opts) {
  ensurePortalUiStyles();
  document.getElementById(opts.id)?.remove();
  const baseStyle = [
    "position:fixed",
    "bottom:0",
    "left:0",
    "right:0",
    "z-index:2147483645",
    "background:#14263f",
    "color:#f4efe4",
    "font:bold 13px/1.5 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif"
  ];
  if (opts.tone === "alert") baseStyle.push("border-top:3px solid #b3261e");
  baseStyle.push(
    "padding:10px 14px",
    "display:flex;gap:12px;align-items:center",
    "box-shadow:0 -2px 10px rgba(0,0,0,0.3)"
  );
  const band = classedElement(
    "div",
    `cformly-root cformly-notice cformly-notice-${opts.tone}`,
    baseStyle.join(";")
  );
  band.id = opts.id;
  band.setAttribute("role", opts.role);
  band.setAttribute("data-cformly-role", "notice");
  const linesWrap = styledElement("div", "flex:1");
  for (const line of opts.messages) {
    const p = document.createElement("div");
    p.textContent = line;
    p.className = "cformly-notice-line";
    linesWrap.appendChild(p);
  }
  band.appendChild(linesWrap);
  let actionBtn = null;
  if (opts.action) {
    actionBtn = document.createElement("button");
    actionBtn.type = "button";
    actionBtn.textContent = opts.action.label;
    actionBtn.className = "cformly-btn cformly-btn-primary cformly-notice-go";
    applyInlineStyles(
      actionBtn,
      "background:#0e5fb0;color:#ffffff;border:none;border-radius:14px;font:bold 13px sans-serif;padding:9px 16px;cursor:pointer;white-space:nowrap"
    );
    band.appendChild(actionBtn);
  }
  const closeBtn = document.createElement("button");
  closeBtn.type = "button";
  closeBtn.textContent = "\xD7";
  closeBtn.className = "cformly-dismiss-ink";
  closeBtn.setAttribute("aria-label", msg(opts.lang, "panel.dismiss"));
  applyInlineStyles(
    closeBtn,
    "border:none;background:none;font:bold 18px/1 sans-serif;color:rgba(244,239,228,0.72);cursor:pointer;padding:2px 8px"
  );
  band.appendChild(closeBtn);
  const dismiss = () => {
    band.remove();
  };
  const action = opts.action;
  if (action && actionBtn) {
    actionBtn.addEventListener("click", () => {
      action.onClick();
      dismiss();
    });
  }
  closeBtn.addEventListener("click", dismiss);
  document.documentElement.appendChild(band);
  return { dismiss };
}
function renderResumeCard(options) {
  return renderNoticeBand({
    id: RESUME_CARD_ID,
    role: "status",
    tone: "info",
    lang: options.lang,
    messages: [options.summary],
    action: {
      label: msg(options.lang, "resume.button"),
      onClick: options.onResume
    }
  });
}
function renderCanaryRefusal(options) {
  return renderNoticeBand({
    id: CANARY_REFUSAL_ID,
    role: "alert",
    tone: "alert",
    lang: options.lang,
    messages: [
      msg(options.lang, "canary.blocked"),
      msg(options.lang, "canary.detail", {
        found: options.found,
        total: options.total
      })
    ]
  });
}

// src/pdf-payload.ts
var CFORMLY_PDF_MARKER = "%CFORMLY:P1:";
var MAX_ENCODED_BLOCK_CHARS = 32768;
var B64URL_REV = (() => {
  const table = new Int8Array(128).fill(-1);
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  for (let i = 0; i < 64; i++) {
    const code = alphabet.charCodeAt(i);
    table[code] = i;
  }
  return table;
})();
var B64URL_CHARS = (() => {
  const flags = new Array(128).fill(false);
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  for (let i = 0; i < alphabet.length; i++)
    flags[alphabet.charCodeAt(i)] = true;
  return flags;
})();
function startsWithPdfHeader(bytes) {
  const magic = "%PDF-";
  if (bytes.length < magic.length) return false;
  for (let i = 0; i < magic.length; i++)
    if (bytes[i] !== magic.charCodeAt(i)) return false;
  return true;
}
function findLastMarkerEnd(bytes) {
  outer: for (let i = bytes.length - CFORMLY_PDF_MARKER.length; i >= 0; i--) {
    for (let j = 0; j < CFORMLY_PDF_MARKER.length; j++)
      if (bytes[i + j] !== CFORMLY_PDF_MARKER.charCodeAt(j)) continue outer;
    return i + CFORMLY_PDF_MARKER.length;
  }
  return -1;
}
function revAt(encoded, pos) {
  const v = B64URL_REV[encoded.charCodeAt(pos)];
  return v === void 0 || v < 0 ? -1 : v;
}
function urlTailInto(out, o, encoded, i, extra) {
  const a = revAt(encoded, i);
  const b = revAt(encoded, i + 1);
  if (a < 0 || b < 0) return -1;
  if (extra === 2) {
    out[o] = (a << 2 | b >>> 4) & 255;
    return o + 1;
  }
  const c = revAt(encoded, i + 2);
  if (c < 0) return -1;
  const n = a << 12 | b << 6 | c;
  out[o] = n >>> 10 & 255;
  out[o + 1] = n >>> 2 & 255;
  return o + 2;
}
function base64UrlDecode(encoded) {
  const extra = encoded.length % 4;
  if (extra === 1) return null;
  const tailBytes = extra === 0 ? 0 : extra === 2 ? 1 : 2;
  const out = new Uint8Array(Math.floor(encoded.length / 4) * 3 + tailBytes);
  let o = 0;
  let i = 0;
  while (i + 3 < encoded.length) {
    let n = 0;
    for (let k = 0; k < 4; k++) {
      const v = revAt(encoded, i + k);
      if (v < 0) return null;
      n = n << 6 | v;
    }
    out[o++] = n >>> 16 & 255;
    out[o++] = n >>> 8 & 255;
    out[o++] = n & 255;
    i += 4;
  }
  if (extra !== 0) {
    o = urlTailInto(out, o, encoded, i, extra);
    if (o < 0) return null;
  }
  return out.subarray(0, o);
}
var STRICT_UTF8 = new TextDecoder("utf-8", { fatal: true });
function scanEncodedRun(bytes, start) {
  let end = start;
  while (end < bytes.length) {
    const byte = bytes[end];
    if (byte === 10) return end;
    const code = byte;
    if (code >= 128 || !B64URL_CHARS[code]) return -1;
    if (end - start >= MAX_ENCODED_BLOCK_CHARS) return -1;
    end++;
  }
  return -1;
}
function extractPdfPayload(bytes) {
  if (!startsWithPdfHeader(bytes)) return { ok: false, reason: "not-pdf" };
  const start = findLastMarkerEnd(bytes);
  if (start < 0) return { ok: false, reason: "no-marker" };
  const termAt = scanEncodedRun(bytes, start);
  if (termAt < start + 1) return { ok: false, reason: "corrupt" };
  let ascii = "";
  for (let i = start; i < termAt; i++)
    ascii += String.fromCharCode(bytes[i]);
  const decoded = base64UrlDecode(ascii);
  if (!decoded || decoded.length === 0) return { ok: false, reason: "corrupt" };
  try {
    const text = STRICT_UTF8.decode(decoded);
    if (!text.trim()) return { ok: false, reason: "corrupt" };
    return { ok: true, text };
  } catch {
    return { ok: false, reason: "corrupt" };
  }
}

// src/pdf-intake.ts
function isCformlyPdf(file) {
  if (file.type === "application/pdf") return true;
  return file.name.toLowerCase().endsWith(".pdf");
}
async function intakeGuestPdfFile(file) {
  if (file.size > MAX_PASTED_CHARS) return { ok: false, reason: "too-large" };
  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const outcome = extractPdfPayload(bytes);
    if (!outcome.ok) return { ok: false, reason: "rejected" };
    if (Object.keys(parseClipboardPayload(outcome.text)).length === 0)
      return { ok: false, reason: "rejected" };
    return { ok: true, text: outcome.text };
  } catch {
    return { ok: false, reason: "rejected" };
  }
}

// src/chip.ts
var CHIP_ID = "cformly-fill-chip";
function createChipElements(lang) {
  ensurePortalUiStyles();
  const pill = document.createElement("button");
  pill.type = "button";
  pill.textContent = msg(lang, "chip.label");
  pill.className = "cformly-root cformly-chip-pill";
  applyInlineStyles(
    pill,
    [
      "position:fixed",
      "bottom:18px",
      "right:18px",
      "z-index:2147483646",
      "background:#14263f",
      "color:#f4efe4",
      "border:none",
      "border-radius:22px",
      "font:bold 14px/1 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
      "padding:13px 20px",
      "cursor:pointer",
      "box-shadow:0 4px 14px rgba(11,23,38,0.35)"
    ].join(";")
  );
  const box = classedElement(
    "div",
    "cformly-root cformly-chip-box",
    [
      "position:fixed",
      "bottom:70px",
      "right:18px",
      "z-index:2147483646",
      "width:min(372px, calc(100vw - 36px))",
      "background:#ffffff",
      "color:#0e1a22",
      "border:1px solid #d9cfba",
      "border-radius:18px",
      "box-shadow:0 4px 16px rgba(0,0,0,0.3)",
      "font:13px/1.5 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
      "padding:14px",
      "display:none"
    ].join(";")
  );
  const header = styledElement(
    "div",
    "display:flex;justify-content:space-between;align-items:center;gap:10px"
  );
  const title = document.createElement("strong");
  title.className = "cformly-chip-title";
  title.textContent = msg(lang, "chip.title");
  header.appendChild(title);
  const closeBtn = document.createElement("button");
  closeBtn.type = "button";
  closeBtn.textContent = "\xD7";
  closeBtn.className = "cformly-dismiss-ink";
  closeBtn.setAttribute("aria-label", msg(lang, "chip.collapse"));
  applyInlineStyles(
    closeBtn,
    "border:none;background:none;font:bold 18px/1 sans-serif;color:#56636d;cursor:pointer;padding:2px 8px"
  );
  header.appendChild(closeBtn);
  box.appendChild(header);
  const hint = classedElement(
    "div",
    "cformly-chip-hint",
    "color:#56636d;margin:6px 0"
  );
  hint.textContent = msg(lang, "chip.hint");
  box.appendChild(hint);
  const textarea = document.createElement("textarea");
  textarea.className = "cformly-paste";
  applyInlineStyles(
    textarea,
    "width:100%;box-sizing:border-box;height:96px;border:1px solid #d9cfba;background:#ece6d8;color:#0e1a22;border-radius:12px;padding:9px 10px;font:12px/1.4 ui-monospace,'SF Mono',Menlo,Consolas,monospace;resize:vertical"
  );
  textarea.setAttribute("aria-label", msg(lang, "chip.title"));
  box.appendChild(textarea);
  const fillBtn = document.createElement("button");
  fillBtn.type = "button";
  fillBtn.textContent = msg(lang, "chip.fill");
  fillBtn.className = "cformly-btn cformly-btn-primary cformly-fill";
  applyInlineStyles(
    fillBtn,
    "margin-top:10px;background:#0e5fb0;color:#ffffff;border:none;border-radius:14px;font:bold 13px sans-serif;padding:9px 16px;cursor:pointer"
  );
  box.appendChild(fillBtn);
  const errorRow = classedElement(
    "div",
    "cformly-error",
    "display:none;color:#b52f2f;font-weight:bold;margin-top:8px"
  );
  errorRow.setAttribute("role", "alert");
  box.appendChild(errorRow);
  const noteRow = classedElement(
    "div",
    "cformly-note",
    "display:none;color:#094a8a;font-weight:bold;margin-top:8px"
  );
  box.appendChild(noteRow);
  const root = styledElement("div", "");
  root.id = CHIP_ID;
  root.appendChild(pill);
  root.appendChild(box);
  document.documentElement.appendChild(root);
  return {
    root,
    pill,
    box,
    textarea,
    fillBtn,
    errorRow,
    noteRow,
    closeBtn
  };
}
function renderFillChip(opts) {
  const lang = opts.lang;
  document.getElementById(CHIP_ID)?.remove();
  const els = createChipElements(lang);
  const expand = () => {
    els.box.style.display = "block";
    els.pill.style.display = "none";
    els.errorRow.style.display = "none";
    els.textarea.focus();
  };
  const collapse = () => {
    els.box.style.display = "none";
    els.pill.style.display = "block";
  };
  els.pill.addEventListener("click", expand);
  els.closeBtn.addEventListener("click", collapse);
  els.textarea.addEventListener("dragover", (e) => e.preventDefault());
  els.textarea.addEventListener("drop", (e) => {
    e.preventDefault();
    const file = e.dataTransfer?.files?.[0];
    if (!file) return;
    if (isCformlyPdf(file)) {
      void intakeGuestPdfFile(file).then((outcome) => {
        if (!outcome.ok) {
          els.errorRow.textContent = msg(
            lang,
            outcome.reason === "too-large" ? "chip.tooLarge" : "popup.pdfRejected"
          );
          els.errorRow.style.display = "block";
          return;
        }
        els.textarea.value = outcome.text;
      });
      return;
    }
    if (file.size > MAX_PASTED_CHARS) {
      els.errorRow.textContent = msg(lang, "chip.tooLarge");
      els.errorRow.style.display = "block";
      return;
    }
    void file.text().then((text) => {
      els.textarea.value = text;
    }).catch(() => {
    });
  });
  els.fillBtn.addEventListener("click", () => {
    const text = els.textarea.value.trim();
    if (!text) {
      els.errorRow.textContent = msg(lang, "chip.empty");
      els.errorRow.style.display = "block";
      return;
    }
    if (text.length > MAX_PASTED_CHARS) {
      els.errorRow.textContent = msg(lang, "chip.tooLarge");
      els.errorRow.style.display = "block";
      return;
    }
    els.errorRow.style.display = "none";
    els.noteRow.style.display = "none";
    els.fillBtn.disabled = true;
    els.fillBtn.textContent = msg(lang, "chip.filling");
    opts.onFillText(text).then((outcome) => {
      if (outcome.ok) {
        if (outcome.warning) {
          els.noteRow.textContent = outcome.warning;
          els.noteRow.style.display = "block";
          setTimeout(dismiss, 8e3);
        } else dismiss();
        return;
      }
      els.fillBtn.disabled = false;
      els.fillBtn.textContent = msg(lang, "chip.fill");
      els.errorRow.textContent = outcome.error ?? msg(lang, "chip.empty");
      els.errorRow.style.display = "block";
    }).catch(() => {
      els.fillBtn.disabled = false;
      els.fillBtn.textContent = msg(lang, "chip.fill");
      els.errorRow.textContent = msg(lang, "chip.empty");
      els.errorRow.style.display = "block";
    });
  });
  function dismiss() {
    els.root.remove();
  }
  return { dismiss, collapse };
}

// src/canary.ts
var CANARY_MISSING_FRACTION = 0.3;
function resolveEntry(m, doc, opts) {
  if (m.by.labelText) {
    return opts.findLabelInput ? opts.findLabelInput(m.by.labelText) : void 0;
  }
  const selector = resolveSelector(m);
  if (!selector) {
    return m.by.name || m.by.id ? null : void 0;
  }
  try {
    return doc.querySelector(selector) ?? null;
  } catch {
    return null;
  }
}
function probeMappingPresence(mapping, doc, opts = {}) {
  let total = 0;
  let found = 0;
  const missingFields = [];
  for (const m of mapping.mappings) {
    const el = resolveEntry(m, doc, opts);
    if (el === void 0) continue;
    total += 1;
    const inOwnUi = el !== null && typeof el.closest === "function" && el.closest(".cformly-root") !== null;
    if (el && !inOwnUi) found += 1;
    else missingFields.push(m.appField);
  }
  return { total, found, missingFields };
}
function shouldRefuseFill(stats) {
  if (stats.total === 0) return false;
  return (stats.total - stats.found) / stats.total > CANARY_MISSING_FRACTION;
}

// src/resume.ts
function sessionArea() {
  if (typeof chrome === "undefined" || !chrome.storage?.session || typeof chrome.storage.session.get !== "function" || typeof chrome.storage.session.set !== "function" || typeof chrome.storage.session.remove !== "function")
    return null;
  return chrome.storage.session;
}
var RESUME_MAX_AGE_MS = 24 * 60 * 60 * 1e3;
var RESUME_KEY_PREFIX = "cformly_last_fill:";
function resumeStorageKey(tabId) {
  return `${RESUME_KEY_PREFIX}${tabId}`;
}
function parseStoredFillState(raw) {
  if (typeof raw !== "object" || raw === null) return null;
  const r = raw;
  if (typeof r.payload !== "object" || r.payload === null) return null;
  if (!Array.isArray(r.filledFields)) return null;
  if (typeof r.totalFields !== "number") return null;
  if (typeof r.savedAtMs !== "number") return null;
  const payload = {};
  for (const [k, v] of Object.entries(r.payload))
    if (typeof v === "string") payload[k] = v;
  return {
    payload,
    filledFields: r.filledFields.filter(
      (f) => typeof f === "string"
    ),
    totalFields: r.totalFields,
    savedAtMs: r.savedAtMs
  };
}
async function saveStoredFillState(tabId, state) {
  const area = sessionArea();
  if (area === null || tabId < 0) return false;
  try {
    await area.set({ [resumeStorageKey(tabId)]: state });
    return true;
  } catch {
    return false;
  }
}
async function readStoredFillState(tabId) {
  const area = sessionArea();
  if (area === null || tabId < 0) return null;
  try {
    const result = await area.get(resumeStorageKey(tabId));
    return parseStoredFillState(result[resumeStorageKey(tabId)]);
  } catch {
    return null;
  }
}
async function clearStoredFillState(tabId) {
  const area = sessionArea();
  if (area === null || tabId < 0) return;
  try {
    await area.remove(resumeStorageKey(tabId));
  } catch {
  }
}
async function getOwnTabId() {
  try {
    if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage)
      return null;
    const response = await chrome.runtime.sendMessage({
      type: "CFORMLY_GET_TAB_ID"
    });
    if (response?.ok && typeof response.tabId === "number")
      return response.tabId;
    return null;
  } catch {
    return null;
  }
}
function isCompleteFill(result) {
  return result.requiredFilled === result.totalRequired && !result.fallbackRecommended;
}
function evaluateResumeOffer(stored, nowMs) {
  if (stored === null) return { offer: false, reason: "none" };
  if (Object.keys(stored.payload).length === 0)
    return { offer: false, reason: "empty" };
  if (stored.filledFields.length === 0)
    return { offer: false, reason: "empty" };
  const ageMs = nowMs - stored.savedAtMs;
  if (ageMs < 0 || ageMs >= RESUME_MAX_AGE_MS)
    return { offer: false, reason: "stale" };
  if (stored.filledFields.length >= stored.totalFields)
    return { offer: false, reason: "already-complete" };
  return { offer: true, reason: "fresh" };
}

// src/preview.ts
var norm = (s) => (s ?? "").trim().toLowerCase().replace(/\s+/g, " ");
function isSelectControl(element) {
  return element.tagName.toLowerCase() === "select" && !!element.options;
}
function currentValueOf(element, control, queryAllRadios) {
  if (control === "radio") {
    const name = element.name ?? "";
    const checked = name ? queryAllRadios(name).find((r) => r.checked === true) : element.checked === true ? element : void 0;
    return checked?.value ?? "";
  }
  if (isSelectControl(element)) {
    const selected = Array.from(element.options ?? []).find(
      (opt) => opt.value === element.value
    );
    return selected ? selected.text : element.value ?? "";
  }
  return element.value ?? "";
}
function buildFillPreview(payload, mapping, options) {
  const queryAllRadios = makeQueryAllRadios(options.queryAll);
  const rows = [];
  for (const m of mapping.mappings) {
    const row = {
      field: m.appField,
      label: prettifyFieldName(m.appField),
      kind: "unresolved",
      currentValue: "",
      newValue: ""
    };
    try {
      const element = m.by.labelText && options.findLabelInput ? options.findLabelInput(m.by.labelText) : (() => {
        const selector = resolveSelector(m);
        return selector ? options.querySelector(selector) : null;
      })();
      if (!element) {
        rows.push(row);
        continue;
      }
      row.currentValue = currentValueOf(element, m.control, queryAllRadios);
      if (m.control === "file") {
        row.kind = "manual";
        rows.push(row);
        continue;
      }
      const raw = payload[m.appField];
      const value = m.transform ? applyTransform(m.transform, raw, {
        ...payload,
        __applyField: m.appField
      }) : raw;
      if (value === void 0 || value === "") {
        row.kind = "no-value";
        rows.push(row);
        continue;
      }
      row.newValue = value;
      const machineValue = element.value ?? "";
      row.kind = row.currentValue === "" || m.dependsOn && isSelectControl(element) && machineValue === "" ? "fill" : norm(row.currentValue) === norm(value) || isSelectControl(element) && norm(machineValue) === norm(value) ? "unchanged" : "changed";
    } catch {
      row.kind = "unresolved";
    }
    rows.push(row);
  }
  return rows;
}

// src/undo.ts
var UNDO_KEY_PREFIX = "cformly_undo:";
function undoStorageKey(tabId) {
  return `${UNDO_KEY_PREFIX}${tabId}`;
}
function sessionArea2() {
  if (typeof chrome === "undefined" || !chrome.storage?.session || typeof chrome.storage.session.get !== "function" || typeof chrome.storage.session.set !== "function" || typeof chrome.storage.session.remove !== "function")
    return null;
  return chrome.storage.session;
}
function priorValueOf(element, control, queryAllRadios) {
  if (control === "radio") {
    const name = element.name ?? "";
    const checked = name ? queryAllRadios(name).find((r) => r.checked === true) : element.checked === true ? element : void 0;
    return { kind: "radio", value: checked?.value ?? "", radioName: name };
  }
  if (element.tagName.toLowerCase() === "select")
    return { kind: "select", value: element.value ?? "" };
  return { kind: "text", value: element.value ?? "" };
}
function captureUndoSnapshot(mapping, options, url) {
  const queryAllRadios = makeQueryAllRadios(options.queryAll);
  const entries = [];
  for (const m of mapping.mappings) {
    if (m.control === "file") continue;
    try {
      const element = m.by.labelText && options.findLabelInput ? options.findLabelInput(m.by.labelText) : (() => {
        const selector = resolveSelector(m);
        return selector ? options.querySelector(selector) : null;
      })();
      if (!element) continue;
      const prior = priorValueOf(element, m.control, queryAllRadios);
      entries.push({
        field: m.appField,
        kind: prior.kind,
        selector: m.by.labelText && options.findLabelInput ? `label:"${m.by.labelText}"` : resolveSelector(m),
        ...m.by.labelText ? { labelText: m.by.labelText } : {},
        value: prior.value,
        ...prior.radioName !== void 0 ? { radioName: prior.radioName } : {}
      });
    } catch {
    }
  }
  return { entries, url, savedAtMs: Date.now() };
}
function parseUndoSnapshot(raw) {
  if (typeof raw !== "object" || raw === null) return null;
  const r = raw;
  if (!Array.isArray(r.entries)) return null;
  if (typeof r.url !== "string" || typeof r.savedAtMs !== "number") return null;
  const entries = [];
  for (const e of r.entries) {
    if (typeof e !== "object" || e === null) continue;
    const entry = e;
    if (typeof entry.field !== "string" || entry.kind !== "text" && entry.kind !== "select" && entry.kind !== "radio" || typeof entry.value !== "string" || typeof entry.selector !== "string")
      continue;
    entries.push({
      field: entry.field,
      kind: entry.kind,
      selector: entry.selector,
      ...typeof entry.labelText === "string" ? { labelText: entry.labelText } : {},
      value: entry.value,
      ...typeof entry.radioName === "string" ? { radioName: entry.radioName } : {}
    });
  }
  if (entries.length === 0) return null;
  return { entries, url: r.url, savedAtMs: r.savedAtMs };
}
async function saveUndoSnapshot(tabId, snapshot) {
  const area = sessionArea2();
  if (area === null || tabId < 0) return false;
  try {
    await area.set({ [undoStorageKey(tabId)]: snapshot });
    return true;
  } catch {
    return false;
  }
}
async function readUndoSnapshot(tabId) {
  const area = sessionArea2();
  if (area === null || tabId < 0) return null;
  try {
    const result = await area.get(undoStorageKey(tabId));
    return parseUndoSnapshot(result[undoStorageKey(tabId)]);
  } catch {
    return null;
  }
}
async function clearUndoSnapshot(tabId) {
  const area = sessionArea2();
  if (area === null || tabId < 0) return;
  try {
    await area.remove(undoStorageKey(tabId));
  } catch {
  }
}
function applyUndoSnapshot(snapshot, options, eventFactory, currentUrl) {
  const queryAllRadios = makeQueryAllRadios(options.queryAll);
  let restored = 0;
  const failed = [];
  for (const entry of snapshot.entries) {
    let element = null;
    try {
      element = entry.labelText && options.findLabelInput ? options.findLabelInput(entry.labelText) : entry.selector ? options.querySelector(entry.selector) : null;
    } catch {
      element = null;
    }
    const outcome = restorePriorValue(
      element,
      entry.kind,
      entry.value,
      entry.radioName,
      eventFactory,
      queryAllRadios
    );
    if (outcome === "restored") restored += 1;
    else failed.push(entry.field);
  }
  return {
    restored,
    total: snapshot.entries.length,
    failed,
    navigated: currentUrl !== snapshot.url
  };
}

// src/content-heavy.ts
var activePanel = null;
var activeHud = null;
var activeResumeCard = null;
var cachedOwnTabId;
var fillGeneration = 0;
var SUPERSEDED_RESPONSE = {
  ok: false,
  error: "Superseded by a newer fill \u2014 the latest result stands."
};
var hasFilledThisDocument = false;
function resetFillLifecycleForTests() {
  hasFilledThisDocument = false;
  fillGeneration = 0;
  cachedOwnTabId = void 0;
  activeResumeCard?.dismiss();
  activeResumeCard = null;
  dismissCaptchaRing();
}
var DEPENDENT_TIMEOUT_MS = 5e3;
var DEPENDENT_POLL_INTERVAL_MS = 100;
var DEPENDENT_STALE_CAP_MS = 1500;
function checkAccommodationMatch(expectedAccommodationId) {
  const accocodEl = document.querySelector(
    "[name=accocod], #accocod"
  );
  const portalAccocod = accocodEl?.value?.trim() ?? "";
  if (expectedAccommodationId && portalAccocod) {
    if (normalizeAccommodationCode(expectedAccommodationId) !== normalizeAccommodationCode(portalAccocod)) {
      return {
        matches: false,
        reason: `Accommodation code mismatch: expected "${expectedAccommodationId}" but the portal session is for code "${portalAccocod}". Verify you are logged into the correct FRRO account.`
      };
    }
  }
  return {
    matches: true,
    reason: "Accommodation matches or could not be verified (allowed)."
  };
}
function captureApplicationId() {
  const bodyText = document.body?.textContent ?? "";
  return extractApplicationId(bodyText);
}
function openIndividualPrint(applicationId) {
  const printInput = document.querySelector(
    'input[name="Filerfno"], #Filerfno'
  );
  if (!printInput) return false;
  printInput.value = applicationId;
  printInput.dispatchEvent(new Event("input", { bubbles: true }));
  printInput.dispatchEvent(new Event("change", { bubbles: true }));
  const goBtn = document.querySelector(
    '#GetFileno, input[onclick*="GetFileNo"]'
  );
  if (!goBtn) return false;
  goBtn.click();
  return true;
}
async function waitForDependentDropdown(field, _dependsOn) {
  const fieldToPortalName = {
    indiaCityDistrict: "applicant_refstatedistr",
    visaSubType: "applicant_visa_subtype_code",
    nextDestinationCityDistrict: "applicant_next_destination_city_district_IN"
  };
  const portalName = fieldToPortalName[field];
  if (!portalName) return true;
  const select = document.querySelector(
    `[name="${portalName}"]`
  );
  if (!select) return false;
  const optionSet = () => new Set(Array.from(select.options).map((o) => `${o.value}\0${o.text}`));
  const initialSet = optionSet();
  const hadStaleOptions = initialSet.size > 1;
  let prevSet = hadStaleOptions ? initialSet : null;
  const startTime = performance.now();
  while (performance.now() - startTime < DEPENDENT_TIMEOUT_MS) {
    const current = optionSet();
    if (hadStaleOptions) {
      if (!sameSet(current, initialSet)) return true;
      if (performance.now() - startTime >= DEPENDENT_STALE_CAP_MS) return true;
    } else if (current.size > 1) {
      if (prevSet && sameSet(current, prevSet)) return true;
      prevSet = current;
    }
    await new Promise(
      (resolve) => setTimeout(resolve, DEPENDENT_POLL_INTERVAL_MS)
    );
  }
  console.warn(
    `Cformly: dependent dropdown "${field}" did not populate within ${DEPENDENT_TIMEOUT_MS}ms`
  );
  return false;
}
function sameSet(a, b) {
  if (a.size !== b.size) return false;
  for (const v of a) if (!b.has(v)) return false;
  return true;
}
function toFillableElement(el) {
  if (!el) return null;
  return el;
}
function toFillableElements(nodeList) {
  return Array.from(nodeList);
}
function findLabelInputElement(text) {
  const labels = document.querySelectorAll("label");
  const needle = text.trim().toLowerCase();
  let best = null;
  let bestScore = -1;
  for (const label of labels) {
    const labelText = (label.textContent ?? "").trim().toLowerCase();
    let score;
    if (labelText === needle) score = 3;
    else if (labelText.startsWith(needle)) score = 2;
    else if (labelText.includes(needle)) score = 1;
    else continue;
    if (score <= bestScore) continue;
    const forId = label.getAttribute("for");
    let el = forId ? document.getElementById(forId) : null;
    el ??= label.querySelector("input, select, textarea");
    if (!el) continue;
    const he = el;
    if (he.offsetParent === null && (typeof getComputedStyle !== "function" || getComputedStyle(he).position !== "fixed"))
      continue;
    const disabled = el.disabled;
    if (disabled) continue;
    best = el;
    bestScore = score;
  }
  return best ? toFillableElement(best) : null;
}
function looksLikeLoginPage() {
  if (/login/i.test(location.href) && !/formc\.jsp/i.test(location.href))
    return true;
  return document.querySelector("input[type=password]") !== null;
}
function scanPortalErrorBanner() {
  const ERROR_SELECTORS = [
    '[class*="err"]',
    '[class*="Err"]',
    '[id*="err"]',
    '[id*="Err"]',
    'font[color="red"]',
    'font[color="RED"]',
    '[role="alert"]',
    ".alert"
  ].join(",");
  let matches;
  try {
    matches = document.querySelectorAll(ERROR_SELECTORS);
  } catch {
    return null;
  }
  for (const el of matches) {
    const he = el;
    if (he.closest?.(".cformly-root")) continue;
    if (he.offsetParent === null && (typeof getComputedStyle !== "function" || getComputedStyle(he).position !== "fixed"))
      continue;
    const text = (el.textContent ?? "").replace(/\s+/g, " ").trim();
    if (text.length >= 3) return text.slice(0, 300);
  }
  return null;
}
function relayProgress(completed, total) {
  try {
    const sent = chrome.runtime.sendMessage({
      type: "CFORMLY_FILL_PROGRESS",
      completed,
      total
    });
    const maybe = sent;
    if (maybe && typeof maybe.catch === "function") {
      maybe.catch(() => {
      });
    }
  } catch {
  }
}
async function handleFillMessage(message) {
  if (message.type === "CFORMLY_PING")
    return { ok: true, result: emptyResult() };
  if (message.type === "CFORMLY_PRINT") {
    try {
      if (openIndividualPrint(message.applicationId))
        return { ok: true, result: emptyResult() };
      return {
        ok: false,
        error: "Individual Print: no Application-ID resume form (Filerfno/GetFileno) on this page. Open the portal's Individual Print / resume page, then retry."
      };
    } catch (err) {
      return {
        ok: false,
        error: err instanceof Error ? err.message : "Print failed"
      };
    }
  }
  if (message.type === "CFORMLY_PREVIEW") {
    try {
      const preview = buildFillPreview(message.payload, message.mapping, {
        querySelector: (selector) => toFillableElement(document.querySelector(selector)),
        queryAll: (selector) => toFillableElements(document.querySelectorAll(selector)),
        findLabelInput: findLabelInputElement
      });
      return { ok: true, preview };
    } catch (err) {
      return {
        ok: false,
        error: err instanceof Error ? err.message : "Preview failed"
      };
    }
  }
  if (message.type === "CFORMLY_UNDO_STATUS") {
    const tabId = await resolveOwnTabId();
    const snapshot = tabId !== null ? await readUndoSnapshot(tabId) : null;
    return {
      ok: true,
      undoStatus: {
        available: snapshot !== null,
        urlMatches: snapshot !== null && snapshot.url === location.href
      }
    };
  }
  if (message.type === "CFORMLY_UNDO") {
    const tabId = await resolveOwnTabId();
    const snapshot = tabId !== null ? await readUndoSnapshot(tabId) : null;
    if (snapshot === null) {
      return {
        ok: false,
        error: msg(
          await resolvePanelLang(),
          "popup.undoNone"
        )
      };
    }
    const outcome = applyUndoSnapshot(
      snapshot,
      {
        querySelector: (selector) => toFillableElement(document.querySelector(selector)),
        queryAll: (selector) => toFillableElements(document.querySelectorAll(selector)),
        findLabelInput: findLabelInputElement
      },
      (type) => new Event(type, { bubbles: true }),
      location.href
    );
    if (tabId !== null) await clearUndoSnapshot(tabId);
    return { ok: true, undo: outcome };
  }
  if (message.type !== "CFORMLY_FILL") {
    return {
      ok: false,
      error: `Unknown message type: ${message["type"]}`
    };
  }
  const gen = ++fillGeneration;
  const { payload, mapping } = message;
  if (!/formc\.jsp/i.test(location.href)) {
    return {
      ok: false,
      error: "This is not the Form III fill page (formc.jsp). Open the guest's Form III form, then retry."
    };
  }
  if (document.querySelector("input[type=password]") !== null) {
    return {
      ok: false,
      error: "Your FRRO session appears to have expired (the login page is showing). Log in again, open the guest's Form III form, then press Fill. Your guest details are kept."
    };
  }
  let accommodationWarning;
  if (message.accommodationId) {
    const check = checkAccommodationMatch(message.accommodationId);
    if (!check.matches) accommodationWarning = check.reason;
  }
  activePanel?.dismiss();
  activePanel = null;
  activeResumeCard?.dismiss();
  activeResumeCard = null;
  const lang = await resolvePanelLang();
  if (gen !== fillGeneration) return SUPERSEDED_RESPONSE;
  if (captureApplicationId() === null) {
    const probe = probeMappingPresence(mapping, document, {
      // Adapt the engine's element type to the canary's minimal surface.
      findLabelInput: (text) => {
        const el = findLabelInputElement(text);
        return el ? el : null;
      }
    });
    if (shouldRefuseFill(probe)) {
      activePanel = renderCanaryRefusal({
        lang,
        found: probe.found,
        total: probe.total
      });
      return {
        ok: false,
        error: msg(lang, "canary.blocked")
      };
    }
  }
  const resumeTabId = await resolveOwnTabId();
  if (gen !== fillGeneration) return SUPERSEDED_RESPONSE;
  activeHud?.dismiss();
  const hud = renderFillProgressHud(lang);
  activeHud = hud;
  const undoSnapshot = captureUndoSnapshot(
    mapping,
    {
      querySelector: (selector) => toFillableElement(document.querySelector(selector)),
      queryAll: (selector) => toFillableElements(document.querySelectorAll(selector)),
      findLabelInput: findLabelInputElement
    },
    location.href
  );
  let result;
  try {
    result = await runFill(payload, mapping, {
      querySelector: (selector) => toFillableElement(document.querySelector(selector)),
      queryAll: (selector) => toFillableElements(document.querySelectorAll(selector)),
      eventFactory: (type) => new Event(type, { bubbles: true }),
      waitForDependent: waitForDependentDropdown,
      findLabelInput: findLabelInputElement,
      onProgress: ({ completed, total }) => {
        if (gen !== fillGeneration) return;
        hud.update(completed, total);
        relayProgress(completed, total);
      }
    });
  } catch (err) {
    if (activeHud === hud) {
      hud.dismiss();
      activeHud = null;
    }
    throw err;
  }
  if (activeHud === hud) {
    hud.dismiss();
    activeHud = null;
  }
  if (gen !== fillGeneration) return SUPERSEDED_RESPONSE;
  if (accommodationWarning) {
    result.accommodationMismatch = true;
    result.accommodationWarning = accommodationWarning;
  }
  highlightManualFields(mapping.mappings, result.manual);
  const applicationId = result.filled.length > 0 || !hasFilledThisDocument ? captureApplicationId() : null;
  if (applicationId) result.applicationId = applicationId;
  hasFilledThisDocument = true;
  if (gen !== fillGeneration) return SUPERSEDED_RESPONSE;
  if (result.filled.length > 0 && resumeTabId !== null)
    void saveUndoSnapshot(resumeTabId, undoSnapshot);
  activePanel = renderFilingPanel(result, {
    lang,
    photoSelector: resolvePhotoSelector(mapping.mappings, result.manual),
    saveSelector: "#pmsbmt",
    renderQr: (canvas, text) => import_qrcode.default.toCanvas(canvas, text, { width: 160, margin: 1 }),
    scanApplicationId: captureApplicationId,
    // Roadmap 32/33: post-Save probes — a login redirect means the session
    // expired; a visible error banner means the portal rejected the save.
    probeSessionExpired: looksLikeLoginPage,
    scanPortalError: scanPortalErrorBanner
  });
  void persistFillOutcome(
    gen,
    resumeTabId,
    message.payload,
    mapping.mappings.length,
    result
  );
  if (applicationId === null) assistCaptchaFocus();
  return { ok: true, result };
}
function hasSessionStorage() {
  return typeof chrome !== "undefined" && !!chrome.storage?.session;
}
async function resolveOwnTabId() {
  if (!hasSessionStorage()) return null;
  if (cachedOwnTabId !== void 0) return cachedOwnTabId;
  cachedOwnTabId = await getOwnTabId();
  return cachedOwnTabId;
}
async function persistFillOutcome(gen, tabId, payload, totalFields, result) {
  try {
    if (tabId === null || tabId < 0) return;
    if (gen !== fillGeneration) return;
    if (isCompleteFill(result)) {
      await clearStoredFillState(tabId);
      return;
    }
    if (result.filled.length === 0) return;
    await saveStoredFillState(tabId, {
      payload,
      filledFields: result.filled,
      totalFields,
      savedAtMs: Date.now()
    });
  } catch {
  }
}
async function resumeLastFill(state) {
  activeResumeCard?.dismiss();
  activeResumeCard = null;
  let mapping;
  try {
    mapping = (await getMappingViaBackground()).mapping;
  } catch (err) {
    console.warn("Cformly resume:", err instanceof Error ? err.message : err);
    return;
  }
  const acc = extractAccommodation(state.payload);
  const response = await handleFillMessage({
    type: "CFORMLY_FILL",
    payload: state.payload,
    mapping,
    ...acc.accommodationId ? { accommodationId: acc.accommodationId } : {},
    ...acc.establishmentName ? { establishmentName: acc.establishmentName } : {}
  });
  if (!response.ok) console.warn("Cformly resume:", response.error);
}
async function mountResumeOffer() {
  try {
    if (window.self !== window.top) return;
    if (!/formc\.jsp/i.test(location.href)) return;
    const tabId = await resolveOwnTabId();
    if (tabId === null || tabId < 0) return;
    const stored = await readStoredFillState(tabId);
    if (!evaluateResumeOffer(stored, Date.now()).offer || stored === null)
      return;
    const lang = await resolvePanelLang();
    const time = new Date(stored.savedAtMs).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit"
    });
    const summary = msg(lang, "resume.summary", {
      filled: stored.filledFields.length,
      total: stored.totalFields,
      time
    });
    activeResumeCard = renderResumeCard({
      lang,
      summary,
      onResume: () => void resumeLastFill(stored)
    });
  } catch {
  }
}
async function resolvePanelLang() {
  try {
    return await loadLang();
  } catch {
    return "en";
  }
}
function resolvePhotoSelector(mappings, manualFields) {
  for (const appField of manualFields) {
    const entry = mappings.find((m) => m.appField === appField);
    if (!entry) continue;
    try {
      const selector = resolveSelector(entry);
      if (selector && !selector.includes(":contains")) return selector;
    } catch {
    }
  }
  return "input[type=file][name=file1]";
}
function highlightManualFields(mappings, manualFields) {
  if (manualFields.length === 0) return;
  for (const appField of manualFields) {
    const entry = mappings.find((m) => m.appField === appField);
    if (!entry) continue;
    try {
      const selector = resolveSelector(entry);
      const el = selector ? document.querySelector(selector) : null;
      if (!el) continue;
      el.scrollIntoView({ block: "center" });
      el.style.outline = "3px solid #b3261e";
      el.style.outlineOffset = "2px";
    } catch {
    }
  }
}
var CAPTCHA_RING_MS = 4e3;
var CAPTCHA_RING_PAD = 6;
var activeCaptchaRing = null;
var captchaRingTimer = null;
function locateCaptchaTarget(doc) {
  const PROBE = '[id*="captcha" i], [name*="captcha" i], [class*="captcha" i]';
  let probe = null;
  try {
    for (const el of doc.querySelectorAll(PROBE)) {
      if (el.closest(".cformly-root")) continue;
      const he = el;
      if (he.offsetParent === null && (typeof getComputedStyle !== "function" || getComputedStyle(he).position !== "fixed"))
        continue;
      probe = el;
      break;
    }
  } catch {
    probe = null;
  }
  if (probe) {
    const row = probe.closest("td, tr, fieldset, p, li");
    const img = row?.querySelector("img");
    if (img && !img.closest(".cformly-root"))
      return { el: img, kind: "captcha" };
    return { el: probe, kind: "captcha" };
  }
  const save = doc.querySelector("#pmsbmt");
  if (save) return { el: save, kind: "submit-row" };
  return null;
}
function prefersReducedMotion() {
  try {
    const mm = globalThis.matchMedia;
    if (typeof mm !== "function") return false;
    return mm("(prefers-reduced-motion: reduce)").matches;
  } catch {
    return false;
  }
}
function dismissCaptchaRing() {
  if (captchaRingTimer !== null) {
    clearTimeout(captchaRingTimer);
    captchaRingTimer = null;
  }
  activeCaptchaRing?.remove();
  activeCaptchaRing = null;
}
function presentCaptchaTarget(target) {
  const reduce = prefersReducedMotion();
  try {
    target.el.scrollIntoView({
      behavior: reduce ? "auto" : "smooth",
      block: "center"
    });
  } catch {
  }
  dismissCaptchaRing();
  const doc = target.el.ownerDocument;
  const rect = target.el.getBoundingClientRect();
  const view = doc.defaultView;
  const ring = classedElement(
    "div",
    "cformly-captcha-ring",
    // CSP-degradation floor (see portal-ui.ts): identical to the sheet's
    // static ring minus the pulse/shadow.
    "position:absolute;z-index:2147483640;pointer-events:none;border:3px solid #8a5608;border-radius:6px;"
  );
  ring.setAttribute("aria-hidden", "true");
  ring.style.top = `${rect.top + (view?.scrollY ?? 0) - CAPTCHA_RING_PAD}px`;
  ring.style.left = `${rect.left + (view?.scrollX ?? 0) - CAPTCHA_RING_PAD}px`;
  ring.style.width = `${rect.width + CAPTCHA_RING_PAD * 2}px`;
  ring.style.height = `${rect.height + CAPTCHA_RING_PAD * 2}px`;
  ensurePortalUiStyles();
  doc.documentElement.appendChild(ring);
  activeCaptchaRing = ring;
  captchaRingTimer = setTimeout(dismissCaptchaRing, CAPTCHA_RING_MS);
}
function assistCaptchaFocus() {
  const target = locateCaptchaTarget(document);
  if (!target) return null;
  presentCaptchaTarget(target);
  return target.kind;
}
function emptyResult() {
  return {
    filled: [],
    missingElements: [],
    missingValues: [],
    unsupported: [],
    manual: [],
    unverified: [],
    tooLong: [],
    totalRequired: 0,
    requiredFilled: 0,
    portalMismatchDetected: false,
    fallbackRecommended: false
  };
}
async function mountFillChip() {
  try {
    if (window.self !== window.top) return;
    if (!/formc\.jsp/i.test(location.href)) return;
    const lang = await resolvePanelLang();
    renderFillChip({ lang, onFillText: fillFromPastedText });
  } catch {
  }
}
async function getMappingViaBackground() {
  let response;
  try {
    response = await chrome.runtime.sendMessage({
      type: "CFORMLY_GET_MAPPING"
    });
  } catch {
  }
  if (response?.ok && "mapping" in response)
    return { mapping: response.mapping, source: response.source };
  const detail = response && !response.ok && "error" in response ? ` (${response.error})` : "";
  throw new Error(
    `Form mapping unavailable: the Cformly background worker did not answer${detail}`
  );
}
async function fillFromPastedText(text) {
  const payload = parseClipboardPayload(text);
  if (Object.keys(payload).length === 0)
    return { ok: false, error: msg(await resolvePanelLang(), "chip.empty") };
  let mapping;
  let source;
  try {
    ({ mapping, source } = await getMappingViaBackground());
  } catch {
    return {
      ok: false,
      error: msg(await resolvePanelLang(), "chip.mappingUnavailable")
    };
  }
  const acc = extractAccommodation(payload);
  const fillMessage = {
    type: "CFORMLY_FILL",
    payload,
    mapping,
    ...acc.accommodationId ? { accommodationId: acc.accommodationId } : {},
    ...acc.establishmentName ? { establishmentName: acc.establishmentName } : {}
  };
  const response = await handleFillMessage(fillMessage);
  if (!response.ok) return { ok: false, error: response.error };
  const warning = source === "bundled" ? msg(await resolvePanelLang(), "chip.mappingFallback") : void 0;
  return { ok: true, ...warning ? { warning } : {} };
}
function initPortalUi() {
  void mountFillChip();
  void mountResumeOffer();
}
export {
  assistCaptchaFocus,
  captureApplicationId,
  checkAccommodationMatch,
  findLabelInputElement,
  getMappingViaBackground,
  handleFillMessage,
  initPortalUi,
  locateCaptchaTarget,
  openIndividualPrint,
  presentCaptchaTarget,
  resetFillLifecycleForTests,
  scanPortalErrorBanner
};
