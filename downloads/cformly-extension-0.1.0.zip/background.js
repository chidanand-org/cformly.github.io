"use strict";
(() => {
  // ../../packages/form-mapping/src/signing.ts
  var FORM_MAPPING_PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEALaHzQlhjkg17HTJ7g5M9VdeUYxLp5eQ+vsIg3iFbFjg=
-----END PUBLIC KEY-----`;
  function isPlainObject(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function canonicalStringify(value) {
    if (Array.isArray(value))
      return `[${value.map((v) => canonicalStringify(v)).join(",")}]`;
    if (isPlainObject(value)) {
      const keys = Object.keys(value).sort();
      return `{${keys.map((k) => `${JSON.stringify(k)}:${canonicalStringify(value[k])}`).join(",")}}`;
    }
    return JSON.stringify(value);
  }
  function signedPayload(mapping) {
    const { signature: _signature, ...rest } = mapping;
    return canonicalStringify(rest);
  }
  function pemToDer(pem) {
    const body = pem.replace(/-----BEGIN [^-]+-----/, "").replace(/-----END [^-]+-----/, "").replace(/\s+/g, "");
    const binary = atob(body);
    const bytes = new Uint8Array(new ArrayBuffer(binary.length));
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }
  async function verifyMappingSignature(mapping, publicKeyPem = FORM_MAPPING_PUBLIC_KEY) {
    try {
      const sig = mapping.signature;
      if (typeof sig !== "string" || sig.length === 0) return false;
      if (typeof globalThis.crypto?.subtle === "undefined") return false;
      const key = await globalThis.crypto.subtle.importKey(
        "spki",
        pemToDer(publicKeyPem),
        { name: "Ed25519" },
        false,
        ["verify"]
      );
      const data = new TextEncoder().encode(signedPayload(mapping));
      return await globalThis.crypto.subtle.verify(
        "Ed25519",
        key,
        Uint8Array.from(atob(sig), (c) => c.charCodeAt(0)),
        data
      );
    } catch {
      return false;
    }
  }

  // ../../packages/form-mapping/src/portal-data/select-options.json
  var select_options_default = {
    star_rat: {
      id: "star_rat",
      options: [
        {
          value: "1s",
          label: "One Star"
        },
        {
          value: "2s",
          label: "Two Star"
        },
        {
          value: "3s",
          label: "Three Star"
        },
        {
          value: "4s",
          label: "Four Star"
        },
        {
          value: "5s",
          label: "Five Star"
        },
        {
          value: "6s",
          label: "Others"
        }
      ]
    },
    u_secques: {
      id: "u_secques",
      options: [
        {
          value: "2",
          label: "What is the name of the hospital where you were born?"
        },
        {
          value: "4",
          label: "What is the name of the street where you grew up?"
        },
        {
          value: "3",
          label: "What is the name of your favorite book?"
        },
        {
          value: "1",
          label: "What is your favorite author?"
        },
        {
          value: "5",
          label: "where did you meet your spouse?"
        }
      ]
    },
    u_gender: {
      id: "u_gender",
      options: [
        {
          value: "M",
          label: "Male"
        },
        {
          value: "F",
          label: "Female"
        },
        {
          value: "X",
          label: "Transgender"
        }
      ]
    },
    u_nationality: {
      id: "u_nationality",
      options: [
        {
          value: "IND",
          label: "INDIA"
        },
        {
          value: "AFG",
          label: "AFGHANISTAN"
        },
        {
          value: "ALA",
          label: "ALAND ISLANDS"
        },
        {
          value: "ALB",
          label: "ALBANIA"
        },
        {
          value: "DZA",
          label: "ALGERIA"
        },
        {
          value: "ASM",
          label: "AMERICAN SAMOA"
        },
        {
          value: "AND",
          label: "ANDORRA"
        },
        {
          value: "AGO",
          label: "ANGOLA"
        },
        {
          value: "AIA",
          label: "ANGUILLA"
        },
        {
          value: "ATG",
          label: "ANTIGUA AND BARBUDA"
        },
        {
          value: "ARG",
          label: "ARGENTINA"
        },
        {
          value: "ARM",
          label: "ARMENIA"
        },
        {
          value: "ABW",
          label: "ARUBA"
        },
        {
          value: "AUS",
          label: "AUSTRALIA"
        },
        {
          value: "AUT",
          label: "AUSTRIA"
        },
        {
          value: "AZE",
          label: "AZERBAIJAN"
        },
        {
          value: "BHS",
          label: "BAHAMAS"
        },
        {
          value: "BHR",
          label: "BAHRAIN"
        },
        {
          value: "BGD",
          label: "BANGLADESH"
        },
        {
          value: "BRB",
          label: "BARBADOS"
        },
        {
          value: "BLR",
          label: "BELARUS"
        },
        {
          value: "BEL",
          label: "BELGIUM"
        },
        {
          value: "BLZ",
          label: "BELIZE"
        },
        {
          value: "BEN",
          label: "BENIN (DAHOMEY)"
        },
        {
          value: "BMU",
          label: "BERMUDA"
        },
        {
          value: "BTN",
          label: "BHUTAN"
        },
        {
          value: "BOL",
          label: "BOLIVIA"
        },
        {
          value: "BIH",
          label: "BOSNIA AND HERZEGOVINA"
        },
        {
          value: "BWA",
          label: "BOTSWANA"
        },
        {
          value: "BVT",
          label: "BOUVET ISLAND"
        },
        {
          value: "BRA",
          label: "BRAZIL"
        },
        {
          value: "IOT",
          label: "BRITISH INDIAN OCEAN TERRITORY"
        },
        {
          value: "BRN",
          label: "BRUNEI DARUSSALAM"
        },
        {
          value: "BGR",
          label: "BULGARIA"
        },
        {
          value: "BFA",
          label: "BURKINA FASO ( UPPER VOLTA)"
        },
        {
          value: "BDI",
          label: "BURUNDI"
        },
        {
          value: "KHM",
          label: "CAMBODIA (KAMPUCHEA)"
        },
        {
          value: "CMR",
          label: "CAMEROON"
        },
        {
          value: "CAN",
          label: "CANADA"
        },
        {
          value: "CPV",
          label: "CAPE VERDE ISLANDS"
        },
        {
          value: "XCC",
          label: "CARRIBEAN COMMUNITY"
        },
        {
          value: "CYM",
          label: "CAYMAN ISLANDS"
        },
        {
          value: "CAF",
          label: "CENTRAL AFRICAN REPUBLIC"
        },
        {
          value: "TCD",
          label: "CHAD"
        },
        {
          value: "CHL",
          label: "CHILE"
        },
        {
          value: "CHN",
          label: "CHINA"
        },
        {
          value: "CXR",
          label: "CHRISTMAS ISLANDS"
        },
        {
          value: "CCK",
          label: "COCOS (KEELING) ISLANDS"
        },
        {
          value: "COL",
          label: "COLOMBIA"
        },
        {
          value: "COM",
          label: "COMOROS"
        },
        {
          value: "COG",
          label: "CONGO"
        },
        {
          value: "COD",
          label: "CONGO, DEMOCRATIC REPUBLIC OF THE (ZAIRE)"
        },
        {
          value: "COK",
          label: "COOK ISLANDS"
        },
        {
          value: "CRI",
          label: "COSTA RICA"
        },
        {
          value: "CIV",
          label: "COTE DIVOIRE"
        },
        {
          value: "HRV",
          label: "CROATIA -REPUBLIC OF CROATIA"
        },
        {
          value: "CUB",
          label: "CUBA"
        },
        {
          value: "CYP",
          label: "CYPRUS"
        },
        {
          value: "CZE",
          label: "CZECH REPUBLIC"
        },
        {
          value: "DNK",
          label: "DENMARK"
        },
        {
          value: "DJI",
          label: "DJIBOUTI"
        },
        {
          value: "DMA",
          label: "DOMINICA"
        },
        {
          value: "DOM",
          label: "DOMINICAN REPUBLIC"
        },
        {
          value: "TLS",
          label: "EAST TIMOR, DEMOCRATIC REPUBLIC OF"
        },
        {
          value: "ECU",
          label: "ECUADOR"
        },
        {
          value: "EGY",
          label: "EGYPT"
        },
        {
          value: "SLV",
          label: "EL SALVADOR"
        },
        {
          value: "GNQ",
          label: "EQUITORIAL GUINEA"
        },
        {
          value: "ERI",
          label: "ERITREA"
        },
        {
          value: "EST",
          label: "ESTONIA"
        },
        {
          value: "ETH",
          label: "ETHIOPIA"
        },
        {
          value: "FLK",
          label: "FALKLAND ISLANDS (MALVINAS)"
        },
        {
          value: "FRO",
          label: "FAROE ISLANDS"
        },
        {
          value: "FJI",
          label: "FIJI"
        },
        {
          value: "FIN",
          label: "FINLAND"
        },
        {
          value: "FRA",
          label: "FRANCE"
        },
        {
          value: "FXX",
          label: "FRANCE METROPOLITAN"
        },
        {
          value: "GUF",
          label: "FRENCH GUIANA"
        },
        {
          value: "ATF",
          label: "FRENCH SOUTHERN TERRITORIES"
        },
        {
          value: "GAB",
          label: "GABON"
        },
        {
          value: "GMB",
          label: "GAMBIA"
        },
        {
          value: "GEO",
          label: "GEORGIA"
        },
        {
          value: "DEU",
          label: "GERMANY"
        },
        {
          value: "GHA",
          label: "GHANA"
        },
        {
          value: "GIB",
          label: "GIBRALTAR"
        },
        {
          value: "GRC",
          label: "GREECE"
        },
        {
          value: "GRL",
          label: "GREENLAND"
        },
        {
          value: "GRD",
          label: "GRENADA"
        },
        {
          value: "GLP",
          label: "GUADELOUPE"
        },
        {
          value: "GUM",
          label: "GUAM"
        },
        {
          value: "GTM",
          label: "GUATEMALA"
        },
        {
          value: "GGY",
          label: "GUERNSEY"
        },
        {
          value: "GIN",
          label: "GUINEA"
        },
        {
          value: "GNB",
          label: "GUINEA BISSAU"
        },
        {
          value: "GUY",
          label: "GUYANA"
        },
        {
          value: "HTI",
          label: "HAITI"
        },
        {
          value: "HMD",
          label: "HEARD AND MCDONALD ISLANDS"
        },
        {
          value: "VAT",
          label: "HOLY SEE (VATICAN CITY STATE)"
        },
        {
          value: "HND",
          label: "HONDURAS"
        },
        {
          value: "HKG",
          label: "HONG KONG"
        },
        {
          value: "HUN",
          label: "HUNGARY"
        },
        {
          value: "ISL",
          label: "ICELAND"
        },
        {
          value: "IDN",
          label: "INDONESIA"
        },
        {
          value: "IRN",
          label: "IRAN"
        },
        {
          value: "IRQ",
          label: "IRAQ"
        },
        {
          value: "IRL",
          label: "IRELAND"
        },
        {
          value: "IMN",
          label: "ISLE OF MAN"
        },
        {
          value: "ISR",
          label: "ISRAEL"
        },
        {
          value: "ITA",
          label: "ITALY"
        },
        {
          value: "JAM",
          label: "JAMAICA"
        },
        {
          value: "JPN",
          label: "JAPAN"
        },
        {
          value: "JEY",
          label: "JERSEY"
        },
        {
          value: "JOR",
          label: "JORDAN"
        },
        {
          value: "KAZ",
          label: "KAZAKHSTAN"
        },
        {
          value: "KEN",
          label: "KENYA"
        },
        {
          value: "SWZ",
          label: "KINGDOM OF ESWATINI"
        },
        {
          value: "KIR",
          label: "KIRIBATI"
        },
        {
          value: "PRK",
          label: "KOREA, DEMOCRATIC PEOPLES REPUBLIC OF"
        },
        {
          value: "KOR",
          label: "KOREA, REPUBLIC OF"
        },
        {
          value: "KWT",
          label: "KUWAIT"
        },
        {
          value: "KGZ",
          label: "KYRGYZSTAN"
        },
        {
          value: "LAO",
          label: "LAOS"
        },
        {
          value: "LVA",
          label: "LATVIA"
        },
        {
          value: "LBN",
          label: "LEBANON"
        },
        {
          value: "LSO",
          label: "LESOTHO"
        },
        {
          value: "LBR",
          label: "LIBERIA"
        },
        {
          value: "LBY",
          label: "LIBYA"
        },
        {
          value: "LIE",
          label: "LIECHTENSTEIN"
        },
        {
          value: "LTU",
          label: "LITHUANIA"
        },
        {
          value: "LUX",
          label: "LUXEMBOURG"
        },
        {
          value: "MAC",
          label: "MACAU"
        },
        {
          value: "MDG",
          label: "MADAGASCAR"
        },
        {
          value: "MWI",
          label: "MALAWI"
        },
        {
          value: "MYS",
          label: "MALAYSIA"
        },
        {
          value: "MDV",
          label: "MALDIVES"
        },
        {
          value: "MLI",
          label: "MALI"
        },
        {
          value: "MLT",
          label: "MALTA"
        },
        {
          value: "MHL",
          label: "MARSHALL ISLANDS"
        },
        {
          value: "MTQ",
          label: "MARTINIQUE"
        },
        {
          value: "MRT",
          label: "MAURITANIA"
        },
        {
          value: "MUS",
          label: "MAURITIUS"
        },
        {
          value: "MYT",
          label: "MAYOTTE"
        },
        {
          value: "MEX",
          label: "MEXICO"
        },
        {
          value: "FSM",
          label: "MICRONESIA, FEDERATED STATES OF"
        },
        {
          value: "MDA",
          label: "MOLDOVA, REPUBLIC OF"
        },
        {
          value: "MCO",
          label: "MONACO"
        },
        {
          value: "MNG",
          label: "MONGOLIA"
        },
        {
          value: "MNE",
          label: "MONTENEGRO"
        },
        {
          value: "MSR",
          label: "MONTSERRAT"
        },
        {
          value: "MAR",
          label: "MOROCCO"
        },
        {
          value: "MOZ",
          label: "MOZAMBIQUE"
        },
        {
          value: "MMR",
          label: "MYANMAR (BURMA)"
        },
        {
          value: "NAM",
          label: "NAMIBIA"
        },
        {
          value: "NRU",
          label: "NAURU"
        },
        {
          value: "NPL",
          label: "NEPAL"
        },
        {
          value: "NLD",
          label: "NETHERLANDS"
        },
        {
          value: "ANT",
          label: "NETHERLANDS ANTILLES"
        },
        {
          value: "NTZ",
          label: "NEUTRAL ZONE"
        },
        {
          value: "NCL",
          label: "NEW CALEDONIA"
        },
        {
          value: "NZL",
          label: "NEW ZEALAND"
        },
        {
          value: "NIC",
          label: "NICARAGUA"
        },
        {
          value: "NER",
          label: "NIGER"
        },
        {
          value: "NGA",
          label: "NIGERIA"
        },
        {
          value: "NIU",
          label: "NIUE"
        },
        {
          value: "NFK",
          label: "NORFOLK ISLAND"
        },
        {
          value: "MNP",
          label: "NORTHERN MARIANA ISLANDS"
        },
        {
          value: "NOR",
          label: "NORWAY"
        },
        {
          value: "OMN",
          label: "OMAN"
        },
        {
          value: "PAK",
          label: "PAKISTAN"
        },
        {
          value: "PLW",
          label: "PALAU"
        },
        {
          value: "PSE",
          label: "PALESTINE"
        },
        {
          value: "PAN",
          label: "PANAMA"
        },
        {
          value: "PNG",
          label: "PAPUA NEW GUINEA"
        },
        {
          value: "PRY",
          label: "PARAGUAY"
        },
        {
          value: "XXX",
          label: "PERSON OF UNSPECIFIED NATIONALITY"
        },
        {
          value: "PER",
          label: "PERU"
        },
        {
          value: "PHL",
          label: "PHILIPPINES"
        },
        {
          value: "PCN",
          label: "PITCAIRN"
        },
        {
          value: "POL",
          label: "POLAND"
        },
        {
          value: "PRT",
          label: "PORTUGAL"
        },
        {
          value: "PRI",
          label: "PUERTO RICO"
        },
        {
          value: "QAT",
          label: "QATAR"
        },
        {
          value: "XXB",
          label: "REFUGEE"
        },
        {
          value: "XXC",
          label: "REFUGEE (NON-CONVENTIONAL) OTHER THAN XXB"
        },
        {
          value: "MKD",
          label: "REPUBLIC OF NORTH MACEDONIA"
        },
        {
          value: "UNK",
          label: "RESIDENT OF KOSOVO (UNMIK)"
        },
        {
          value: "REU",
          label: "REUNION ISLANDS"
        },
        {
          value: "ROU",
          label: "ROMANIA"
        },
        {
          value: "RUS",
          label: "RUSSIAN FEDERATION"
        },
        {
          value: "RWA",
          label: "RWANDA"
        },
        {
          value: "BLM",
          label: "SAINT BARTHELEMY"
        },
        {
          value: "SHN",
          label: "SAINT HELENA, ASCENSION AND TRISTAN DA CUNHA"
        },
        {
          value: "KNA",
          label: "SAINT KITTS AND NEVIS"
        },
        {
          value: "LCA",
          label: "SAINT LUCIA"
        },
        {
          value: "SPM",
          label: "SAINT PIERRE AND MIQUELON"
        },
        {
          value: "VCT",
          label: "SAINT VINCENT AND THE GRENADINES"
        },
        {
          value: "WSM",
          label: "SAMOA"
        },
        {
          value: "SMR",
          label: "SAN MARINO"
        },
        {
          value: "STP",
          label: "SAO TOME AND PRINCIPE"
        },
        {
          value: "SAU",
          label: "SAUDI ARABIA"
        },
        {
          value: "SEN",
          label: "SENEGAL"
        },
        {
          value: "SRB",
          label: "SERBIA"
        },
        {
          value: "SYC",
          label: "SEYCHELLES"
        },
        {
          value: "SLE",
          label: "SIERRA LEONE"
        },
        {
          value: "SGP",
          label: "SINGAPORE"
        },
        {
          value: "SVK",
          label: "SLOVAK REPUBLIC"
        },
        {
          value: "SVN",
          label: "SLOVENIA"
        },
        {
          value: "SLB",
          label: "SOLOMON ISLANDS"
        },
        {
          value: "SOM",
          label: "SOMALIA"
        },
        {
          value: "ZAF",
          label: "SOUTH AFRICA"
        },
        {
          value: "SGS",
          label: "SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS"
        },
        {
          value: "SSD",
          label: "SOUTH SUDAN"
        },
        {
          value: "XOM",
          label: "SOVEREIGN MILITARY ORDER OF MALTA"
        },
        {
          value: "ESP",
          label: "SPAIN"
        },
        {
          value: "LKA",
          label: "SRI LANKA"
        },
        {
          value: "XXA",
          label: "STATELESS PERSON"
        },
        {
          value: "SDN",
          label: "SUDAN"
        },
        {
          value: "SUR",
          label: "SURINAME"
        },
        {
          value: "SJM",
          label: "SVALBARD AND JAN MAYEN ISLANDS"
        },
        {
          value: "SWE",
          label: "SWEDEN"
        },
        {
          value: "CHE",
          label: "SWITZERLAND"
        },
        {
          value: "SYR",
          label: "SYRIA"
        },
        {
          value: "TWN",
          label: "TAIWAN"
        },
        {
          value: "TJK",
          label: "TAJIKISTAN"
        },
        {
          value: "TZA",
          label: "TANZANIA"
        },
        {
          value: "THA",
          label: "THAILAND"
        },
        {
          value: "TBT",
          label: "TIBETAN ORIGIN"
        },
        {
          value: "TGO",
          label: "TOGO"
        },
        {
          value: "TKL",
          label: "TOKELAU"
        },
        {
          value: "TON",
          label: "TONGA"
        },
        {
          value: "TTO",
          label: "TRINIDAD AND TOBAGO"
        },
        {
          value: "TUN",
          label: "TUNISIA"
        },
        {
          value: "TUR",
          label: "TURKEY"
        },
        {
          value: "TKM",
          label: "TURKMENISTAN"
        },
        {
          value: "TCA",
          label: "TURKS AND CAICOS ISLANDS"
        },
        {
          value: "TUV",
          label: "TUVALU"
        },
        {
          value: "UGA",
          label: "UGANDA"
        },
        {
          value: "GBD",
          label: "UK BRITISH DEPENDENT TERRITORIES CITIZEN"
        },
        {
          value: "GBO",
          label: "UK BRITISH OVERSEAS CITIZEN"
        },
        {
          value: "GBN",
          label: "UK BRITISH OVERSEAS NATIONAL"
        },
        {
          value: "GBP",
          label: "UK BRITISH PROTECTED PERSON"
        },
        {
          value: "GBS",
          label: "UK BRITISH SUBJECT"
        },
        {
          value: "UKR",
          label: "UKRAINE"
        },
        {
          value: "ARE",
          label: "UNITED ARAB EMIRATES"
        },
        {
          value: "GBR",
          label: "UNITED KINGDOM"
        },
        {
          value: "UNO",
          label: "UNITED NATIONS ORGANIZATION"
        },
        {
          value: "UNA",
          label: "UNITED NATIONS SPECIALIZED AGENCY"
        },
        {
          value: "UMI",
          label: "UNITED STATES MINOR OUTLYING ISLANDS"
        },
        {
          value: "USA",
          label: "UNITED STATES OF AMERICA"
        },
        {
          value: "URY",
          label: "URUGUAY"
        },
        {
          value: "UZB",
          label: "UZBEKISTAN"
        },
        {
          value: "VUT",
          label: "VANUATU (NEW HEBRIDES)"
        },
        {
          value: "VEN",
          label: "VENEZUELA"
        },
        {
          value: "VNM",
          label: "VIETNAM"
        },
        {
          value: "VGB",
          label: "VIRGIN ISLANDS (BRITISH)"
        },
        {
          value: "VIR",
          label: "VIRGIN ISLANDS (US)"
        },
        {
          value: "WLF",
          label: "WALLIS AND FUTUNA ISLANDS"
        },
        {
          value: "ESH",
          label: "WESTERN SAHARA"
        },
        {
          value: "YEM",
          label: "YEMEN"
        },
        {
          value: "YUG",
          label: "YUGOSLAVIA"
        },
        {
          value: "ZMB",
          label: "ZAMBIA"
        },
        {
          value: "ZWE",
          label: "ZIMBABWE"
        }
      ]
    },
    state: {
      id: "state",
      options: [
        {
          value: "1",
          label: "ANDAMAN AND NICOBAR ISLANDS"
        },
        {
          value: "2",
          label: "ANDHRA PRADESH"
        },
        {
          value: "3",
          label: "ARUNACHAL PRADESH"
        },
        {
          value: "4",
          label: "ASSAM"
        },
        {
          value: "5",
          label: "BIHAR"
        },
        {
          value: "34",
          label: "CHANDIGARH"
        },
        {
          value: "6",
          label: "CHHATTISGARH"
        },
        {
          value: "39",
          label: "DADRA AND NAGAR HAVELI AND DAMAN AND DIU"
        },
        {
          value: "8",
          label: "DELHI"
        },
        {
          value: "9",
          label: "GOA"
        },
        {
          value: "10",
          label: "GUJARAT"
        },
        {
          value: "11",
          label: "HARYANA"
        },
        {
          value: "12",
          label: "HIMACHAL PRADESH"
        },
        {
          value: "13",
          label: "JAMMU AND KASHMIR"
        },
        {
          value: "14",
          label: "JHARKHAND"
        },
        {
          value: "15",
          label: "KARNATAKA"
        },
        {
          value: "16",
          label: "KERALA"
        },
        {
          value: "38",
          label: "LADAKH"
        },
        {
          value: "36",
          label: "LAKSHADWEEP"
        },
        {
          value: "17",
          label: "MADHYA PRADESH"
        },
        {
          value: "18",
          label: "MAHARASHTRA"
        },
        {
          value: "19",
          label: "MANIPUR"
        },
        {
          value: "20",
          label: "MEGHALAYA"
        },
        {
          value: "21",
          label: "MIZORAM"
        },
        {
          value: "22",
          label: "NAGALAND"
        },
        {
          value: "23",
          label: "ODISHA"
        },
        {
          value: "24",
          label: "PUDUCHERRY"
        },
        {
          value: "25",
          label: "PUNJAB"
        },
        {
          value: "26",
          label: "RAJASTHAN"
        },
        {
          value: "27",
          label: "SIKKIM"
        },
        {
          value: "28",
          label: "TAMIL NADU"
        },
        {
          value: "37",
          label: "TELANGANA"
        },
        {
          value: "29",
          label: "TRIPURA"
        },
        {
          value: "31",
          label: "UTTARAKHAND"
        },
        {
          value: "30",
          label: "UTTAR PRADESH"
        },
        {
          value: "32",
          label: "WEST BENGAL"
        }
      ]
    },
    acco_type: {
      id: "acco_type",
      options: [
        {
          value: "BB",
          label: "Bed and Breakfast"
        },
        {
          value: "D",
          label: "Dharmshala"
        },
        {
          value: "GH",
          label: "Guest House"
        },
        {
          value: "H",
          label: "Hotel"
        },
        {
          value: "IH",
          label: "Individual House"
        },
        {
          value: "I",
          label: "Institute"
        },
        {
          value: "O",
          label: "Others"
        },
        {
          value: "S",
          label: "Service Apartment"
        }
      ]
    },
    state_o: {
      id: "state_o",
      options: [
        {
          value: "1",
          label: "ANDAMAN AND NICOBAR ISLANDS"
        },
        {
          value: "2",
          label: "ANDHRA PRADESH"
        },
        {
          value: "3",
          label: "ARUNACHAL PRADESH"
        },
        {
          value: "4",
          label: "ASSAM"
        },
        {
          value: "5",
          label: "BIHAR"
        },
        {
          value: "34",
          label: "CHANDIGARH"
        },
        {
          value: "6",
          label: "CHHATTISGARH"
        },
        {
          value: "39",
          label: "DADRA AND NAGAR HAVELI AND DAMAN AND DIU"
        },
        {
          value: "8",
          label: "DELHI"
        },
        {
          value: "9",
          label: "GOA"
        },
        {
          value: "10",
          label: "GUJARAT"
        },
        {
          value: "11",
          label: "HARYANA"
        },
        {
          value: "12",
          label: "HIMACHAL PRADESH"
        },
        {
          value: "13",
          label: "JAMMU AND KASHMIR"
        },
        {
          value: "14",
          label: "JHARKHAND"
        },
        {
          value: "15",
          label: "KARNATAKA"
        },
        {
          value: "16",
          label: "KERALA"
        },
        {
          value: "38",
          label: "LADAKH"
        },
        {
          value: "36",
          label: "LAKSHADWEEP"
        },
        {
          value: "17",
          label: "MADHYA PRADESH"
        },
        {
          value: "18",
          label: "MAHARASHTRA"
        },
        {
          value: "19",
          label: "MANIPUR"
        },
        {
          value: "20",
          label: "MEGHALAYA"
        },
        {
          value: "21",
          label: "MIZORAM"
        },
        {
          value: "22",
          label: "NAGALAND"
        },
        {
          value: "23",
          label: "ODISHA"
        },
        {
          value: "24",
          label: "PUDUCHERRY"
        },
        {
          value: "25",
          label: "PUNJAB"
        },
        {
          value: "26",
          label: "RAJASTHAN"
        },
        {
          value: "27",
          label: "SIKKIM"
        },
        {
          value: "28",
          label: "TAMIL NADU"
        },
        {
          value: "37",
          label: "TELANGANA"
        },
        {
          value: "29",
          label: "TRIPURA"
        },
        {
          value: "31",
          label: "UTTARAKHAND"
        },
        {
          value: "30",
          label: "UTTAR PRADESH"
        },
        {
          value: "32",
          label: "WEST BENGAL"
        }
      ]
    }
  };

  // ../../packages/form-mapping/src/portal-data/formc-select-options.json
  var formc_select_options_default = {
    source: "Live FRRO portal formc.jsp extraction (2026-07-19)",
    specialCategory: {
      fieldName: "applicant_special_category",
      options: [
        { value: "13", label: "Born in India" },
        { value: "3", label: "Crew" },
        { value: "7", label: "Diplomat Exempted" },
        { value: "4", label: "Emergency Transit" },
        { value: "14", label: "Indian Origin" },
        { value: "12", label: "Loss of Passport" },
        { value: "10", label: "OCI" },
        { value: "6", label: "Official Exempted" },
        { value: "8", label: "Other Exempted" },
        { value: "9", label: "Others" },
        { value: "11", label: "PIO" },
        { value: "2", label: "Refugee" },
        { value: "5", label: "TLP" }
      ]
    },
    visaType: {
      fieldName: "applicant_visatype",
      onchange: "visaTypeModalClose(),showvisasubtype(this.value,'ptype',document.OnlineForm.applicant_visa_subtype_code.value,document.OnlineForm.applicant_visa_subtype_code);",
      options: [
        { value: "161", label: "AYUSH VISA" },
        { value: "1", label: "BUSINESS VISA" },
        { value: "2", label: "CONFERENCE VISA" },
        { value: "91", label: "DIPLOMATIC DEPENDENT VISA" },
        { value: "3", label: "DIPLOMATIC VISA" },
        {
          value: "97",
          label: "DOUBLE ENTRY VISA (ONLY FOR BANGLADESH NATIONALS)"
        },
        { value: "37", label: "e-Emergency X-Misc Visa" },
        { value: "44", label: "e-Entry Visa" },
        { value: "50", label: "e-Family Visa" },
        { value: "45", label: "e-Film Visa" },
        { value: "51", label: "e-Miscellaneous Visa" },
        { value: "46", label: "e-Mountaineering Visa" },
        { value: "4", label: "EMPLOYMENT VISA" },
        { value: "94", label: "ENTRY VISA" },
        { value: "48", label: "e-PRODUCTION INVESTMENT VISA" },
        { value: "42", label: "e-Student Visa" },
        { value: "43", label: "e-Student X Visa" },
        { value: "47", label: "e-Transit Visa" },
        { value: "98", label: "e-VISA" },
        { value: "52", label: "FAMILY VISA" },
        { value: "28", label: "FILMS VISA" },
        { value: "6", label: "JOURNALIST VISA" },
        { value: "7", label: "LONG TERM VISA" },
        { value: "92", label: "MEDICAL VISA" },
        { value: "54", label: "MISCELLANEOUS VISA" },
        { value: "10", label: "MISC SP PERMISSION" },
        { value: "11", label: "MISSIONARY VISA" },
        { value: "93", label: "MOUNTAINEERING VISA" },
        { value: "22", label: "OCI" },
        { value: "90", label: "OFFICIAL DEPENDENT VISA" },
        { value: "12", label: "OFFICIAL VISA" },
        { value: "53", label: "PAKISTAN SPECIFIC VISAS" },
        { value: "13", label: "PIO CARD HOLDER" },
        { value: "96", label: "PLIGRIM VISA(ONLY FOR PAKISTAN NATIONALS)" },
        { value: "16", label: "STUDENT VISA" },
        { value: "24", label: "TEMPORARY LANDING PERMIT" },
        { value: "17", label: "TOURIST VISA" },
        { value: "57", label: "TOURIST VISA FIVE YEARS" },
        { value: "56", label: "TOURIST VISA ONE MONTH" },
        { value: "18", label: "TRANSIT VISA" },
        { value: "33", label: "UN DIPLOMAT VISA" },
        { value: "19", label: "UNITED NATION" },
        { value: "34", label: "UN OFFICIAL VISA" },
        { value: "99", label: "VISA-ON-ARRIVAL" },
        { value: "95", label: "VISITOR VISA(ONLY FOR PAKISTAN NATIONALS)" },
        { value: "55", label: "WORK VISA" }
      ]
    },
    purposeOfVisit: {
      fieldName: "applicant_purpovisit",
      options: [
        { value: "18", label: "Accompanying Parents" },
        { value: "9", label: "Accompanying Patient" },
        { value: "10", label: "Accompanying Patient as Doctor" },
        { value: "17", label: "Accompanying Spouse" },
        { value: "6", label: "Business" },
        { value: "12", label: "Diplomatic" },
        { value: "5", label: "Education" },
        { value: "13", label: "Employment" },
        { value: "19", label: "Internship" },
        { value: "2", label: "Joining spouse" },
        { value: "7", label: "Journalism" },
        { value: "8", label: "Medical Treatment of self" },
        { value: "1", label: "Meeting friends/relatives" },
        { value: "3", label: "Minor child(either parent is Indian)" },
        { value: "11", label: "Official" },
        { value: "15", label: "Others" },
        { value: "4", label: "Seminar/conference in India" },
        { value: "14", label: "Studies" },
        { value: "20", label: "Surrogacy" },
        { value: "16", label: "Tourism" }
      ]
    },
    dobFormat: {
      fieldName: "dobformat",
      fieldId: "",
      onchange: "document.OnlineForm.applicant_dob.value='';document.OnlineForm.applicant_age.value=''",
      options: [
        { value: "DY", label: "Date of birth in DD/MM/YYYY" },
        { value: "YY", label: "Year of birth in YYYY" },
        { value: "MY", label: "Month & Year of birth in MM/YYYY" },
        { value: "AG", label: "Age in XXX years" }
      ]
    },
    sex: {
      fieldName: "applicant_sex",
      options: [
        { value: "M", label: "Male" },
        { value: "F", label: "Female" },
        { value: "X", label: "Transgender" }
      ]
    }
  };

  // ../../packages/form-mapping/src/portal-data/index.ts
  var portalSelects = {
    ...formc_select_options_default,
    ...select_options_default
  };
  var nationalityOptions = portalSelects.u_nationality?.options ?? [];
  var stateOptions = portalSelects.state?.options ?? [];
  var accommodationTypeOptions = portalSelects.acco_type?.options ?? [
    { value: "BB", label: "Bed and Breakfast" },
    { value: "D", label: "Dharmshala" },
    { value: "GH", label: "Guest House" },
    { value: "H", label: "Hotel" },
    { value: "IH", label: "Individual House" },
    { value: "I", label: "Institute" },
    { value: "O", label: "Others" },
    { value: "S", label: "Service Apartment" }
  ];
  var starRatingOptions = portalSelects.star_rat?.options ?? [
    { value: "1s", label: "One Star" },
    { value: "2s", label: "Two Star" },
    { value: "3s", label: "Three Star" },
    { value: "4s", label: "Four Star" },
    { value: "5s", label: "Five Star" },
    { value: "6s", label: "Others" }
  ];
  var sexOptions = portalSelects.u_gender?.options ?? [
    { value: "M", label: "Male" },
    { value: "F", label: "Female" },
    { value: "X", label: "Transgender" }
  ];
  var specialCategoryOptions = portalSelects.specialCategory?.options ?? [];
  var visaTypeOptions = portalSelects.visaType?.options ?? [];
  var purposeOfVisitOptions = portalSelects.purposeOfVisit?.options ?? [];

  // ../../packages/form-mapping/src/index.ts
  var ARRIVAL_FIELD_MAPS = [
    // --- B1: Personal Details ---
    {
      appField: "surname",
      by: { name: "applicant_surname", id: "applicant_surname" },
      control: "text",
      required: false
      // optional per single-name passports (companion spec B1)
    },
    {
      appField: "givenName",
      by: { name: "applicant_givenname", id: "applicant_givenname" },
      control: "text",
      required: true
    },
    {
      appField: "sex",
      by: { name: "applicant_sex", id: "applicant_sex" },
      control: "select",
      required: true
      // Portal uses M/F/X directly — no transform needed (values match our schema)
    },
    {
      appField: "dobFormat",
      by: { name: "dobformat" },
      // NO id on this select (verified)
      control: "select",
      transform: "dob_format_label",
      required: true
    },
    {
      appField: "dateOfBirth",
      by: { name: "applicant_dob", id: "applicant_dob" },
      control: "date",
      transform: "date_ddmmyyyy",
      required: true
    },
    {
      appField: "age",
      by: { name: "applicant_age", id: "applicant_age" },
      control: "text",
      transform: "number",
      required: false
      // only entered in AGE mode; readOnly when DY format
    },
    {
      appField: "specialCategory",
      by: {
        name: "applicant_special_category",
        id: "applicant_special_category"
      },
      control: "select",
      transform: "special_category_code",
      required: true
    },
    {
      appField: "nationality",
      by: { name: "applicant_nationality", id: "applicant_nationality" },
      control: "select",
      transform: "country_alpha3",
      required: true
    },
    // --- B2: Address in country where residing permanently ---
    {
      appField: "permanentAddressAbroad",
      by: { name: "applicant_permaddr", id: "applicant_permaddr" },
      control: "textarea",
      required: true
    },
    {
      appField: "permanentCityAbroad",
      by: { name: "applicant_permcity", id: "applicant_permcity" },
      control: "text",
      required: true
    },
    {
      appField: "permanentCountry",
      by: { name: "applicant_permcountry", id: "applicant_permcountry" },
      control: "select",
      transform: "country_alpha3",
      required: true
    },
    // --- B3: Address/Reference in India (host-defaulted) ---
    {
      appField: "indiaAddress",
      by: { name: "applicant_refaddr", id: "applicant_refaddr" },
      control: "textarea",
      required: true
    },
    {
      appField: "indiaState",
      by: { name: "applicant_refstate", id: "applicant_refstate" },
      control: "select",
      transform: "state_code",
      required: true
    },
    {
      appField: "indiaCityDistrict",
      by: { name: "applicant_refstatedistr", id: "applicant_refstatedistr" },
      control: "select",
      transform: "district_code",
      required: true,
      dependsOn: "indiaState"
      // dependent dropdown: showcities() AJAX (companion spec B3, D4 step 4)
    },
    {
      appField: "indiaPincode",
      by: { name: "applicant_refpincode", id: "applicant_refpincode" },
      control: "text",
      required: true
    },
    // --- B4: Passport Details ---
    {
      appField: "passportNumber",
      by: { name: "applicant_passpno", id: "applicant_passpno" },
      control: "text",
      required: true
    },
    {
      appField: "passportPlaceOfIssueCity",
      by: { name: "applicant_passplcofissue", id: "applicant_passplcofissue" },
      control: "text",
      required: true
    },
    {
      appField: "passportPlaceOfIssueCountry",
      by: { name: "passport_issue_country", id: "passport_issue_country" },
      control: "select",
      transform: "country_alpha3",
      required: true
    },
    {
      appField: "passportDateOfIssue",
      by: { name: "applicant_passpdoissue", id: "applicant_passpdoissue" },
      control: "date",
      transform: "date_ddmmyyyy",
      required: true
    },
    {
      appField: "passportValidTill",
      by: { name: "applicant_passpvalidtill", id: "applicant_passpvalidtill" },
      control: "date",
      transform: "date_ddmmyyyy",
      required: true
    },
    // --- B5: Visa Details ---
    {
      appField: "visaNumber",
      by: { name: "applicant_visano", id: "applicant_visano" },
      control: "text",
      required: true
    },
    {
      appField: "visaPlaceOfIssueCity",
      by: { name: "applicant_visaplcoissue", id: "applicant_visaplcoissue" },
      control: "text",
      required: true
    },
    {
      appField: "visaPlaceOfIssueCountry",
      by: { name: "visa_issue_country", id: "visa_issue_country" },
      control: "select",
      transform: "country_alpha3",
      required: true
    },
    {
      appField: "visaDateOfIssue",
      by: { name: "applicant_visadoissue", id: "applicant_visadoissue" },
      control: "date",
      transform: "date_ddmmyyyy",
      required: true
    },
    {
      appField: "visaValidTill",
      by: { name: "applicant_visavalidtill", id: "applicant_visavalidtill" },
      control: "date",
      transform: "date_ddmmyyyy",
      required: true
    },
    {
      appField: "visaType",
      by: { name: "applicant_visatype", id: "applicant_visatype" },
      control: "select",
      transform: "visa_type_code",
      required: true
    },
    {
      appField: "visaSubType",
      by: {
        name: "applicant_visa_subtype_code",
        id: "applicant_visa_subtype_code"
      },
      control: "select",
      required: false,
      dependsOn: "visaType"
      // dependent dropdown: showvisasubtype() AJAX (companion spec B5, D4 step 4)
    },
    // --- B6: Arrival Information ---
    {
      appField: "arrivedFromCountry",
      by: {
        name: "applicant_arrivedfromcountry",
        id: "applicant_arrivedfromcountry"
      },
      control: "select",
      transform: "country_alpha3",
      required: true
    },
    {
      appField: "arrivedFromCity",
      by: { name: "applicant_arrivedfromcity", id: "applicant_arrivedfromcity" },
      control: "text",
      required: true
    },
    {
      appField: "arrivedFromPlace",
      by: {
        name: "applicant_arrivedfromplace",
        id: "applicant_arrivedfromplace"
      },
      control: "text",
      required: true
    },
    {
      appField: "dateOfArrivalIndia",
      by: { name: "applicant_doarrivalindia", id: "applicant_doarrivalindia" },
      control: "date",
      transform: "date_ddmmyyyy",
      required: true
    },
    {
      appField: "checkInDate",
      by: { name: "applicant_doarrivalhotel", id: "applicant_doarrivalhotel" },
      control: "date",
      transform: "date_ddmmyyyy",
      required: true
    },
    {
      appField: "checkInTime",
      by: {
        name: "applicant_timeoarrivalhotel",
        id: "applicant_timeoarrivalhotel"
      },
      control: "time",
      transform: "time_hhmm",
      required: true
    },
    {
      appField: "intendedDurationDays",
      by: { name: "applicant_intnddurhotel", id: "applicant_intnddurhotel" },
      control: "text",
      transform: "number",
      required: true
    },
    // --- B7: Other Details ---
    {
      appField: "employedInIndia",
      by: { name: "employed" },
      // NO id on this radio (verified)
      control: "radio",
      transform: "yesno_y_n",
      required: true
    },
    {
      appField: "purposeOfVisit",
      by: { name: "applicant_purpovisit", id: "applicant_purpovisit" },
      control: "select",
      transform: "purpose_code",
      required: true
    },
    {
      appField: "nextDestinationType",
      by: { name: "applicant_next_dest_country_flag_r" },
      // NO id (verified)
      control: "radio",
      transform: "next_destination_i_o",
      required: true
    },
    {
      appField: "nextDestinationState",
      by: {
        name: "applicant_next_destination_state_IN",
        id: "applicant_next_destination_state_IN"
      },
      control: "select",
      transform: "state_code",
      required: false,
      dependsOn: "nextDestinationType"
      // only shown when Inside India (I)
    },
    {
      appField: "nextDestinationCityDistrict",
      by: {
        name: "applicant_next_destination_city_district_IN",
        id: "applicant_next_destination_city_district_IN"
      },
      control: "select",
      transform: "district_code",
      required: false,
      dependsOn: "nextDestinationState"
      // showcities_dest() AJAX
    },
    {
      appField: "nextDestinationPlace",
      by: {
        name: "applicant_next_destination_place_IN",
        id: "applicant_next_destination_place_IN"
      },
      control: "text",
      required: false,
      dependsOn: "nextDestinationType"
    },
    {
      appField: "contactPhoneIndia",
      by: {
        name: "applicant_contactnoinindia",
        id: "applicant_contactnoinindia"
      },
      control: "text",
      required: false
    },
    {
      appField: "mobileIndia",
      by: {
        name: "applicant_mcontactnoinindia",
        id: "applicant_mcontactnoinindia"
      },
      control: "text",
      required: false
    },
    {
      appField: "contactPhoneAbroad",
      by: { name: "applicant_contactnoperm", id: "applicant_contactnoperm" },
      control: "text",
      required: false
    },
    {
      appField: "mobileAbroad",
      by: { name: "applicant_mcontactnoperm", id: "applicant_mcontactnoperm" },
      control: "text",
      required: false
    },
    {
      appField: "remarks",
      by: { name: "applicant_remark", id: "applicant_remark" },
      control: "textarea",
      required: false
    },
    // Photo upload (companion spec A4/A5/D11): the portal photo is file1
    // (VERIFIED). The extension cannot set file inputs (browser security) — the
    // host manually Choose File / Upload / Save. With NO entry, the engine
    // never reported 'manual', so a fill could render fully green with the
    // mandatory guest photo unattached. This entry surfaces the step.
    {
      appField: "guestPhoto",
      by: { name: "file1", id: "file1" },
      control: "file",
      required: true
    }
  ];
  var DEFAULT_FORM_MAPPING = {
    version: 3,
    // v3: verified against live portal (2026-07-19)
    signature: "aJy91Swo0/cK6Hy1TLG4C2jnC8/Y+USCtONWZiKd3yzi5ib8D81a27WCK9Nvb6Wn6N1dlRO+3QYu+0zPnCThCg==",
    lastVerified: "2026-07-19T14:04:08Z",
    photoFieldSelector: "input[type=file][name=file1]",
    // VERIFIED: was uploadPhoto
    photoMaxSizeBytes: 5e4,
    // companion spec A4: 50 KB hard ceiling
    mappings: ARRIVAL_FIELD_MAPS
  };

  // src/api-base.ts
  var ALLOWED_HOSTS = ["localhost", "127.0.0.1"];
  var ALLOWED_DOMAIN = "cformly.com";
  function isHostAllowed(hostname) {
    return ALLOWED_HOSTS.includes(hostname) || hostname === ALLOWED_DOMAIN || hostname.endsWith("." + ALLOWED_DOMAIN);
  }
  function validateApiBase(raw) {
    const trimmed = raw.trim().replace(/\/+$/, "");
    let url;
    try {
      url = new URL(trimmed);
    } catch {
      return null;
    }
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    if (url.username !== "" || url.password !== "") return null;
    if (url.protocol === "http:" && !ALLOWED_HOSTS.includes(url.hostname))
      return null;
    if (url.protocol === "https:" && ALLOWED_HOSTS.includes(url.hostname))
      return null;
    if (!isHostAllowed(url.hostname)) return null;
    if (url.pathname !== "/" || url.search !== "" || url.hash !== "") return null;
    return trimmed;
  }
  function loopbackHostsGranted(manifest) {
    const grants = manifest?.host_permissions ?? [];
    return grants.some(
      (pattern) => /^http:\/\/(localhost|127\.0\.0\.1)\//.test(pattern)
    );
  }

  // src/mapping.ts
  var STORAGE_KEY = "cformly_mapping_cache";
  var CACHE_TTL_MS = 60 * 60 * 1e3;
  var cacheKey = (baseUrl) => `${STORAGE_KEY}:${cacheOrigin(baseUrl)}`;
  function cacheOrigin(baseUrl) {
    if (!baseUrl) return "default";
    try {
      return new URL(baseUrl).origin;
    } catch {
      return "invalid";
    }
  }
  var SELECTOR_RE = /^[a-zA-Z0-9_\-:. ]{1,100}$/;
  var TRANSFORM_NAMES = /* @__PURE__ */ new Set([
    "date_ddmmyyyy",
    "time_hhmm",
    "yesno_y_n",
    "next_destination_i_o",
    "dob_format_label",
    "special_category_code",
    "visa_type_code",
    "purpose_code",
    "country_alpha3",
    "state_code",
    "district_code",
    "string",
    "number"
  ]);
  function parseMapping(raw) {
    if (typeof raw !== "object" || raw === null) return null;
    const obj = raw;
    if (typeof obj.version !== "number" || !Number.isSafeInteger(obj.version) || obj.version < 1)
      return null;
    if (typeof obj.signature !== "string") return null;
    if (!Array.isArray(obj.mappings)) return null;
    if (typeof obj.photoFieldSelector !== "string") return null;
    if (!obj.photoFieldSelector.trim()) return null;
    for (const m of obj.mappings) {
      if (typeof m !== "object" || m === null) return null;
      const mapping = m;
      if (typeof mapping.appField !== "string") return null;
      if (typeof mapping.control !== "string") return null;
      if (mapping.required !== void 0 && typeof mapping.required !== "boolean")
        return null;
      if (mapping.dependsOn !== void 0 && typeof mapping.dependsOn !== "string")
        return null;
      if (mapping.control !== "text" && mapping.control !== "textarea" && mapping.control !== "select" && mapping.control !== "radio" && mapping.control !== "file" && mapping.control !== "date" && mapping.control !== "time")
        return null;
      const by = mapping.by;
      if (typeof by !== "object" || by === null) return null;
      const byObj = by;
      if (!byObj.name && !byObj.id && !byObj.labelText) return null;
      for (const key of ["name", "id", "labelText"]) {
        const v = byObj[key];
        if (v !== void 0 && (typeof v !== "string" || v.trim() !== v || v.length === 0 || !SELECTOR_RE.test(v)))
          return null;
        if (v !== void 0 && key !== "labelText" && /^\d/.test(v))
          return null;
      }
      if (mapping.transform !== void 0 && (typeof mapping.transform !== "string" || !TRANSFORM_NAMES.has(mapping.transform)))
        return null;
    }
    const seenFields = /* @__PURE__ */ new Set();
    for (const m of obj.mappings) {
      const appField = m.appField;
      if (typeof appField === "string") {
        if (seenFields.has(appField)) return null;
        seenFields.add(appField);
      }
    }
    return raw;
  }
  async function isSigned(mapping) {
    try {
      return await verifyMappingSignature(mapping);
    } catch {
      return false;
    }
  }
  async function readCache(baseUrl) {
    if (typeof chrome === "undefined" || !chrome.storage?.local) return null;
    try {
      const key = cacheKey(baseUrl);
      const result = await chrome.storage.local.get(key);
      const cached = result[key];
      if (!cached) return null;
      if (typeof cached.fetchedAt !== "number" || !Number.isFinite(cached.fetchedAt) || cached.fetchedAt > Date.now() || Date.now() - cached.fetchedAt > CACHE_TTL_MS) {
        void evictCache(baseUrl);
        return null;
      }
      const mapping = parseMapping(cached.mapping);
      if (!mapping || !await isSigned(mapping)) {
        void evictCache(baseUrl);
        return null;
      }
      return mapping;
    } catch {
      return null;
    }
  }
  async function writeCache(mapping, baseUrl) {
    if (typeof chrome === "undefined" || !chrome.storage?.local) return;
    try {
      const entry = { mapping, fetchedAt: Date.now() };
      await chrome.storage.local.set({ [cacheKey(baseUrl)]: entry });
    } catch (err) {
      console.warn("Cformly: mapping cache write failed", err);
    }
  }
  async function evictCache(baseUrl) {
    if (typeof chrome === "undefined" || !chrome.storage?.local) return;
    try {
      await chrome.storage.local.remove(cacheKey(baseUrl));
    } catch {
    }
  }
  async function fetchRemote(baseUrl, clientVersion) {
    const inflightKey = `${baseUrl}\0${clientVersion ?? ""}`;
    const existing = pendingRemote.get(inflightKey);
    if (existing) return existing;
    const p = fetchRemoteOnce(baseUrl, clientVersion).finally(() => {
      pendingRemote.delete(inflightKey);
    });
    pendingRemote.set(inflightKey, p);
    return p;
  }
  var pendingRemote = /* @__PURE__ */ new Map();
  async function fetchRemoteOnce(baseUrl, clientVersion) {
    const query = clientVersion !== void 0 && clientVersion !== null ? `?clientVersion=${clientVersion}` : "";
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 1e4);
    try {
      const res = await fetch(`${baseUrl}/api/form-mapping/current${query}`, {
        signal: controller.signal
      });
      if (!res.ok) return null;
      const contentType = res.headers.get("content-type") ?? "";
      if (!contentType.includes("application/json")) return null;
      const contentLength = Number(res.headers.get("content-length") ?? "0");
      if (Number.isFinite(contentLength) && contentLength > 1e6)
        return null;
      const data = await res.json();
      if (data.upToDate === true) return null;
      const candidate = data.mapping ?? data;
      const parsed = parseMapping(candidate);
      if (!parsed) return null;
      if (!await isSigned(parsed)) return null;
      if (clientVersion !== void 0 && parsed.version < clientVersion)
        return null;
      await writeCache(parsed, baseUrl);
      return parsed;
    } catch {
      return null;
    } finally {
      clearTimeout(timer);
    }
  }
  async function getMapping(baseUrl) {
    const floor = DEFAULT_FORM_MAPPING.version;
    const cached = await readCache(baseUrl);
    if (cached && cached.version >= floor) {
      if (baseUrl) void fetchRemote(baseUrl, floor).catch(() => {
      });
      lastMappingSource = "cache";
      return cached;
    }
    if (baseUrl) {
      const remote = await fetchRemote(baseUrl, floor);
      if (remote) {
        lastMappingSource = "remote";
        return remote;
      }
    }
    if (cached) void evictCache(baseUrl);
    lastMappingSource = "bundled";
    return DEFAULT_FORM_MAPPING;
  }
  var lastMappingSource = "bundled";
  function lastMappingSourceName() {
    return lastMappingSource;
  }
  var API_BASE_KEY = "cformly_api_base";
  var DEFAULT_API_BASE = "https://api.cformly.com";
  async function resolveApiBase() {
    try {
      const result = await chrome.storage.local.get(API_BASE_KEY);
      const stored = result[API_BASE_KEY];
      if (typeof stored === "string") {
        const validated = validateApiBase(stored);
        if (validated) {
          try {
            const url = new URL(validated);
            const isLoopback = url.hostname === "localhost" || url.hostname === "127.0.0.1";
            if (isLoopback && typeof chrome !== "undefined" && typeof chrome.runtime?.getManifest === "function" && !loopbackHostsGranted(
              chrome.runtime.getManifest()
            ))
              return { base: DEFAULT_API_BASE, storedInvalid: true };
          } catch {
            return { base: DEFAULT_API_BASE, storedInvalid: true };
          }
          return { base: validated, storedInvalid: false };
        }
        return { base: DEFAULT_API_BASE, storedInvalid: true };
      }
    } catch {
    }
    return { base: DEFAULT_API_BASE, storedInvalid: false };
  }

  // src/install.ts
  var PROBE_KEY = "cformly_install_probe";
  async function probeSessionStorage() {
    try {
      const session = chrome.storage?.session;
      if (!session || typeof session.get !== "function" || typeof session.set !== "function" || typeof session.remove !== "function")
        return false;
      const marker = String(Date.now());
      await session.set({ [PROBE_KEY]: marker });
      const readBack = await session.get(PROBE_KEY);
      await session.remove(PROBE_KEY);
      return readBack[PROBE_KEY] === marker;
    } catch {
      return false;
    }
  }
  async function probeMapping() {
    try {
      const { base } = await resolveApiBase();
      const mapping = await getMapping(base);
      let signatureOk = false;
      try {
        signatureOk = await verifyMappingSignature(mapping);
      } catch {
        signatureOk = false;
      }
      return { source: lastMappingSourceName(), signatureOk };
    } catch {
      return { source: lastMappingSourceName(), signatureOk: false };
    }
  }
  async function runInstallSelfTest() {
    const sessionOk = await probeSessionStorage();
    const { source, signatureOk } = await probeMapping();
    return { workerAlive: true, sessionOk, mappingSource: source, signatureOk };
  }
  function applySelfTestBadge(outcome) {
    try {
      const action = chrome.action;
      if (typeof chrome === "undefined" || !action || typeof action.setBadgeText !== "function")
        return;
      const healthy = outcome.sessionOk && outcome.signatureOk;
      void action.setBadgeText({ text: healthy ? "OK" : "!" });
      if (typeof action.setBadgeBackgroundColor === "function") {
        void action.setBadgeBackgroundColor({
          color: healthy ? "#188038" : "#b3261e"
        });
      }
    } catch {
    }
  }
  function registerInstallSelfTest() {
    try {
      chrome.runtime?.onInstalled?.addListener((details) => {
        if (details?.reason !== "install" && details?.reason !== "update") return;
        void runInstallSelfTest().then((outcome) => applySelfTestBadge(outcome)).catch(
          () => applySelfTestBadge({
            workerAlive: true,
            sessionOk: false,
            mappingSource: "bundled",
            signatureOk: false
          })
        );
      });
    } catch {
    }
  }

  // src/background.ts
  function isBackgroundMessage(message) {
    if (typeof message !== "object" || message === null) return false;
    const type = message.type;
    return type === "CFORMLY_GET_MAPPING" || type === "CFORMLY_GET_TAB_ID";
  }
  function handleGetMappingMessage(getMappingFn, sendResponse) {
    getMappingFn().then(({ mapping, source }) => sendResponse({ ok: true, mapping, source })).catch(
      (err) => sendResponse({
        ok: false,
        error: err instanceof Error ? err.message : "Mapping lookup failed"
      })
    );
  }
  async function resolveMappingForContext() {
    const { base } = await resolveApiBase();
    const mapping = await getMapping(base);
    return { mapping, source: lastMappingSourceName() };
  }
  chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
      if (sender.id !== chrome.runtime.id) {
        sendResponse({ ok: false, error: "Unauthorized sender" });
        return false;
      }
      if (!isBackgroundMessage(message)) return false;
      if (message.type === "CFORMLY_GET_TAB_ID") {
        sendResponse({
          ok: true,
          tabId: typeof sender.tab?.id === "number" ? sender.tab.id : null
        });
        return false;
      }
      handleGetMappingMessage(resolveMappingForContext, sendResponse);
      return true;
    }
  );
  registerInstallSelfTest();
})();
